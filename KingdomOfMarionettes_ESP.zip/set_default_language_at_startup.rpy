init 1000 python:
    renpy.game.preferences.language = "spanish"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
