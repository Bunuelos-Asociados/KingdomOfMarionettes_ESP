

translate spanish strings:


    old "Back"
    new "Atrás"


    old "History"
    new "Historial"


    old "Skip"
    new "Saltar"


    old "Auto"
    new "Auto"


    old "Save"
    new "Guardar"


    old "Q.Save"
    new "Guardado Rápido"


    old "Q.Load"
    new "Carga Rápida"


    old "Prefs"
    new "Preferencias"


    old "Start"
    new "Iniciar"


    old "Load"
    new "Cargar"


    old "Preferences"
    new "Preferencias"


    old "End Replay"
    new "Finalizar Repetición"


    old "Main Menu"
    new "Menú Principal"


    old "About"
    new "Acerca de"


    old "Help"
    new "Ayuda"


    old "Quit"
    new "Salir"


    old "Return"
    new "Volver"


    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"


    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"


    old "Page {}"
    new "Página {}"


    old "Automatic saves"
    new "Guardados automáticos"


    old "Quick saves"
    new "Guardados rápidos"


    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"


    old "empty slot"
    new "ranura vacía"


    old "<"
    new "<"


    old "{#auto_page}A"
    new "{#auto_page}A"


    old "{#quick_page}Q"
    new "{#quick_page}Q"


    old ">"
    new ">"


    old "Upload Sync"
    new "Subir sincronización"


    old "Download Sync"
    new "Descargar sincronización"


    old "Display"
    new "Pantalla"


    old "Window"
    new "Ventana"


    old "Fullscreen"
    new "Pantalla completa"


    old "Unseen Text"
    new "Texto no leído"


    old "After Choices"
    new "Después de elecciones"


    old "Transitions"
    new "Transiciones"


    old "Text Speed"
    new "Velocidad de texto"


    old "Auto-Forward Time"
    new "Tiempo de avance automático"


    old "Music Volume"
    new "Volumen de música"


    old "Sound Volume"
    new "Volumen de sonido"


    old "Test"
    new "Prueba"


    old "Voice Volume"
    new "Volumen de voz"


    old "Mute All"
    new "Silenciar todo"


    old "The dialogue history is empty."
    new "El historial de diálogo está vacío."


    old "Keyboard"
    new "Teclado"


    old "Mouse"
    new "Ratón"


    old "Gamepad"
    new "Control"


    old "Enter"
    new "Enter"


    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."


    old "Space"
    new "Espacio"


    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."


    old "Arrow Keys"
    new "Teclas de flecha"


    old "Navigate the interface."
    new "Navegar por la interfaz."


    old "Escape"
    new "Escape"


    old "Accesses the game menu."
    new "Accede al menú del juego."


    old "Ctrl"
    new "Ctrl"


    old "Skips dialogue while held down."
    new "Omite el diálogo mientras se mantiene presionado."


    old "Tab"
    new "Tab"


    old "Toggles dialogue skipping."
    new "Activa/desactiva el salto de diálogo."


    old "Page Up"
    new "Re Pág"


    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."


    old "Page Down"
    new "Av Pág"


    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."


    old "Hides the user interface."
    new "Oculta la interfaz de usuario."


    old "Takes a screenshot."
    new "Toma una captura de pantalla."


    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la {a=https://www.renpy.org/l/voicing}lectura automática{/a}."


    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."


    old "Left Click"
    new "Clic izquierdo"


    old "Middle Click"
    new "Clic medio"


    old "Right Click"
    new "Clic derecho"


    old "Mouse Wheel Up"
    new "Rueda del ratón arriba"


    old "Mouse Wheel Down"
    new "Rueda del ratón abajo"


    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nBotón A/Inferior"


    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"


    old "Right Shoulder"
    new "Botón superior derecho"


    old "D-Pad, Sticks"
    new "D-Pad, Joysticks"


    old "Start, Guide, B/Right Button"
    new "Start, Guide, Botón B/Derecho"


    old "Y/Top Button"
    new "Botón Y/Superior"


    old "Calibrate"
    new "Calibrar"


    old "Yes"
    new "Sí"


    old "No"
    new "No"


    old "Skipping"
    new "Saltar"


    old "Menu"
    new "Menú"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
