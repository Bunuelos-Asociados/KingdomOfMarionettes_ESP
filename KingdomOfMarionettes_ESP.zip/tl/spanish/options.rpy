

translate spanish strings:


    old "Kingdom Of Marionettes"
    new "Kingdom Of Marionettes"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
