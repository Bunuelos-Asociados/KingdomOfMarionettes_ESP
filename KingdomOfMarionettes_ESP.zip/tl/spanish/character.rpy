


translate spanish ask_player_name_f1b999d0:


    jes "Oh, dulce tarta de crema. ¡Compartimos el mismo nombre! Qué milagro tan verdaderamente maravilloso."


translate spanish ask_player_name_9ea78486:


    jes "Mmm... en ese caso, llamarte por tu nombre sería bastante problemático. Se sentiría extraño estar llamándome a mí mismo."


translate spanish ask_player_name_5c49eeec:


    jes "Así que, en su lugar, te otorgaré un apodo. ¡Sweety! ¿No suena encantador? Dulce, como una tarta de fresa."


translate spanish ask_player_name_5d49a77b:


    jes "Y lo que es más, incluso comparte las mismas letras finales. sweeTY, JesTYn. ¿No sueno como un genio?"


translate spanish ask_player_name_95d15ecd:


    mc "Um... en realidad, le falta una 'N'."


translate spanish ask_player_name_b2120850:


    jes "Entonces, Sweetyn."


translate spanish ask_player_name_dcb6e45a:


    "... Supongo que eso servirá."


translate spanish ask_player_name_39b7cb58:


    jes "...¿Qué? ¿Knighter?? Pffft ¡Ajjjajajajajjajaa! !Ohhh!, ¿¡el cielo y la tierra están tratando de jugarme una broma?!"


translate spanish ask_player_name_4bd194ca:


    jes "Sin duda es un nombre audaz y con un aire heroico, te lo concedo. Pero simplemente no puedo permitirte conservarlo."


translate spanish ask_player_name_4374fe19:


    jes "Si el gruñón maestro llegara a enterarse... oh, temo imaginar en cuántos pedazos terminarías"


translate spanish ask_player_name_2ce068df:


    jes "Así que te sugiero que elijas otro nombre."


translate spanish ask_player_name_8e28f667:


    mc "Pero mi nombre realmente es Knighter..."


translate spanish ask_player_name_89c76285:


    jes "Y yo te digo que ya no puedes usar ese nombre."


translate spanish ask_player_name_cbd182b0:


    jes "O como dije hace unos segundos... te convertirías en nada más que fragmentos dispersos en un abrir y cerrar de ojos."


translate spanish ask_player_name_888f0c8a:


    jes "Así que te sugiero encarecidamente que elijas un nuevo nombre. Inmediatamente."


translate spanish ask_player_name_447bf2f1:


    jes "Hmm... me encuentro preguntándome, dulce humano."


translate spanish ask_player_name_339d8616:


    jes "¿Es que tus oídos no funcionan y no escuchaste lo que dije antes, o simplemente eres rebelde? Apenas hay diferencia."


translate spanish ask_player_name_8a79e23c:


    jes "Muy bien. Ya que sigues insistiendo con lo mismo, te daré un nombre yo mismo."


translate spanish ask_player_name_9fccd482:


    jes "A partir de este momento, tu nombre será... Stubbornelle."


translate spanish ask_player_name_0f4cd710:


    mc "Pero—"


translate spanish ask_player_name_babbb6eb:


    jes "Tatatatat~ Sin quejas."


translate spanish ask_player_name_759260e6:


    jes "¡Oh, por Dios! ¿Wizzy? ¿Escuché bien?"


translate spanish ask_player_name_5686fc26:


    jes "Qué adorable. Solo espera a que Wizzy, el mago real, se entere de esto."


translate spanish ask_player_name_14e6ddf6:


    jes "Estoy absolutamente seguro, mil y un por ciento, de que su corazón brillará como una estrella cuando sepa que tiene un gemelo completamente nuevo."


translate spanish ask_player_name_1acc92f3:


    "{color=#FF2727}......{/color}"


translate spanish ask_player_name_a49f3494:


    "{color=#FF2727}oh..... really...?{/color}"


translate spanish ask_player_name_5345f543:


    "{color=#FF2727}ha....haha....{/color}"


translate spanish ask_player_name_9d05eb66:


    "{color=#FF2727}{cps=220}HAHAHAHAHHAHAHHAHAHAHAHAHAHAHHAHHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHA HAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHHAHAHAHAH AHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHA HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAH{/cps}{/color}"


translate spanish ask_player_name_0fd4d656:


    "......"


translate spanish ask_player_name_278c7e29:


    "........."


translate spanish ask_player_name_2f4f0bc8:


    jes "Ah... it's really an honour to be meeting you [player_call]"


translate spanish ask_player_name_f1b999d0_1:


    jes "Oh, dulce tarta de crema. ¡Compartimos el mismo nombre! Qué milagro tan verdaderamente maravilloso."


translate spanish ask_player_name_9ea78486_1:


    jes "Mmm... en ese caso, llamarte por tu nombre sería bastante problemático. Se sentiría extraño estar llamándome a mí mismo."


translate spanish ask_player_name_5c49eeec_1:


    jes "Así que, en su lugar, te otorgaré un apodo. ¡Sweety! ¿No suena encantador? Dulce, como una tarta de fresa."


translate spanish ask_player_name_5d49a77b_1:


    jes "Y lo que es más, incluso comparte las mismas letras finales. sweeTY, JesTYn. ¿No sueno como un genio?"


translate spanish ask_player_name_95d15ecd_1:


    mc "Um... en realidad, le falta una 'N'."


translate spanish ask_player_name_b2120850_1:


    jes "Entonces, Sweetyn."


translate spanish ask_player_name_dcb6e45a_1:


    "... Supongo que eso servirá."


translate spanish ask_player_name_39b7cb58_1:


    jes "...¿Qué? ¿Knighter?? Pffft ¡Ajjjajajajajjajaa! !Ohhh!, ¿¡el cielo y la tierra están tratando de jugarme una broma?!"


translate spanish ask_player_name_4bd194ca_1:


    jes "Sin duda es un nombre audaz y con un aire heroico, te lo concedo. Pero simplemente no puedo permitirte conservarlo."


translate spanish ask_player_name_4374fe19_1:


    jes "Si el gruñón maestro llegara a enterarse... oh, temo imaginar en cuántos pedazos terminarías"


translate spanish ask_player_name_2ce068df_1:


    jes "Así que te sugiero que elijas otro nombre."


translate spanish ask_player_name_8e28f667_1:


    mc "Pero mi nombre realmente es Knighter..."


translate spanish ask_player_name_89c76285_1:


    jes "Y yo te digo que ya no puedes usar ese nombre."


translate spanish ask_player_name_cbd182b0_1:


    jes "O como dije hace unos segundos... te convertirías en nada más que fragmentos dispersos en un abrir y cerrar de ojos."


translate spanish ask_player_name_888f0c8a_1:


    jes "Así que te sugiero encarecidamente que elijas un nuevo nombre. Inmediatamente."


translate spanish ask_player_name_447bf2f1_1:


    jes "Hmm... me encuentro preguntándome, dulce humano."


translate spanish ask_player_name_339d8616_1:


    jes "¿Es que tus oídos no funcionan y no escuchaste lo que dije antes, o simplemente eres rebelde? Apenas hay diferencia."


translate spanish ask_player_name_8a79e23c_1:


    jes "Muy bien. Ya que sigues insistiendo con lo mismo, te daré un nombre yo mismo."


translate spanish ask_player_name_9fccd482_1:


    jes "A partir de este momento, tu nombre será... Stubbornelle."


translate spanish ask_player_name_0f4cd710_1:


    mc "Pero—"


translate spanish ask_player_name_babbb6eb_1:


    jes "Tatatatat~ Sin quejas."


translate spanish ask_player_name_759260e6_1:


    jes "¡Oh, por Dios! ¿Wizzy? ¿Escuché bien?"


translate spanish ask_player_name_5686fc26_1:


    jes "Qué adorable. Solo espera a que Wizzy, el mago real, se entere de esto."


translate spanish ask_player_name_14e6ddf6_1:


    jes "Estoy absolutamente seguro, mil y un por ciento, de que su corazón brillará como una estrella cuando sepa que tiene un gemelo completamente nuevo."


translate spanish ask_player_name_1acc92f3_1:


    "{color=#FF2727}......{/color}"


translate spanish ask_player_name_a49f3494_1:


    "{color=#FF2727}oh..... really...?{/color}"


translate spanish ask_player_name_5345f543_1:


    "{color=#FF2727}ha....haha....{/color}"


translate spanish ask_player_name_9d05eb66_1:


    "{color=#FF2727}{cps=220}HAHAHAHAHHAHAHHAHAHAHAHAHAHAHHAHHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHA HAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHHAHAHAHAH AHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHA HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAH{/cps}{/color}"


translate spanish ask_player_name_0fd4d656_1:


    "......"


translate spanish ask_player_name_278c7e29_1:


    "........."


translate spanish ask_player_name_2f4f0bc8_1:


    jes "Ah... it's really an honour to be meeting you [player_call]"

translate spanish strings:


    old "Jestyn"
    new "Jestyn"


    old "Jester puppet"
    new "Bufón Marioneta "


    old "Knighter"
    new "Knighter"


    old "Knight puppet"
    new "Caballero Marioneta "


    old "???"
    new "???"


    old "You"
    new "Tú"


    old "Farmer"
    new "Granjero"


    old "Debt collector"
    new "Cobrador de deudas"


    old "Narrator"
    new "Narrador"


    old "She / Her"
    new "Ella"


    old "He / Him"
    new "Él"


    old "They / Them"
    new "Elle"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
