


translate spanish start_8cba0c84:


    "¿Quién habría imaginado que acabaría en una situación tan extraña?"


translate spanish start_9ece5d1e:


    "Todo comenzó porque necesitaba encontrar trabajo a toda costa."


translate spanish start_866fca32:


    "Claro que estaba al límite. Mis ahorros se estaban agotando y todavía tenía innumerables gastos diarios, además de deudas por pagar."


translate spanish start_aaed3db5:


    "Apliqué a todo tipo de lugares, pero sentía que la suerte me odiaba completamente."


translate spanish start_0c268043:


    "En una situación así, ya no me importaba qué tipo de trabajo fuera, mientras pagara. Limpiar baños, atrapar osos… haría lo que fuera."


translate spanish start_1715a48e:


    "Fue entonces cuando encontré este trabajo en línea…"


translate spanish start_62e8aaa8:


    "Un puesto de seguridad en un teatro abandonado. En serio, ¿por qué un lugar que ya no funciona necesitaría siquiera un guardia de seguridad?"


translate spanish start_518151f5:


    "Kingdom of Marionettes. Había escuchado que este lugar solía ser famoso por sus espectáculos de marionetas hace mucho tiempo."


translate spanish start_d79b2a65:


    "Oh. Solo tres deberes. Deber número uno: mantener el teatro a salvo de vándalos. Hmm… probablemente pueda encargarme de eso."


translate spanish start_3d379df2:


    "Deber número dos: limpiar el teatro. Técnicamente eso está fuera del trabajo de un guardia de seguridad, pero da igual mientras paguen."


translate spanish start_7d1d2bbf:


    "Deber número tres: asegurarse de que ninguna marioneta esté desaparecida y caminando por ahí."


translate spanish start_5f9b772e:


    "…."


translate spanish start_2e251073:


    "Hmm. Tal vez tengo tanto sueño que lo leí mal."


translate spanish start_51aac7de:


    "Asegurarse de que ninguna marioneta esté desaparecida… y caminando por ahí."


translate spanish start_0ec8e943:


    "E–espera. ¿Caminando?? ¿Asegurarme de que no haya marionetas caminando?? ¿¡Qué significa eso!?"


translate spanish start_f403a2a7:


    "Jajaja… tal vez querían decir asegurarse de que nadie robe las marionetas. Sí. Tiene que ser eso. Quien haya escrito esto debe estar bromeando."


translate spanish start_c3d87f84:


    "Muy bien entonces. Hagámoslo."


translate spanish start_715f3a0c:


    "Aquí está… después de tanto tiempo, por fin conseguí un trabajo."


translate spanish start_af32477a:


    "Curiosamente, este trabajo no requirió una entrevista."


translate spanish start_5879a4bf:


    "Cuando los contacté ayer, todo se resolvió casi de inmediato."


translate spanish start_ab106452:


    "Casi pensé que era una estafa, pero por suerte no lo era."


translate spanish start_e097aece:


    "Bien. Tengo tres tareas. Primero, mantener el lugar a salvo de vándalos. Afortunadamente, no ha habido señales de problemas hasta ahora."


translate spanish start_bdaa902b:


    "Eso solo deja limpiar el teatro y asegurarme de que todas las marionetas estén presentes."


translate spanish rest_56ca1470:


    "Regreso directamente a mi habitación y le informo al jefe."


translate spanish rest_8ab3cee1:


    "Todas mis tareas están terminadas. Ahora lo único que queda es hacer guardia."


translate spanish rest_28cb0594:


    "Ser guardia de seguridad no parece tan malo. Me pagan solo por vigilar."


translate spanish rest_2c46a105:


    "El pago no es excelente, pero es mejor que nada."


translate spanish rest_27e93ae7:


    u "¿Qué debería hacer mientras estoy de guardia…?"


translate spanish rest_ebe1d624:


    u "Estoy que no doy más… pero no puedo permitirme dormir."


translate spanish rest_945d4661:


    "Saco mi teléfono y empiezo a navegar por internet."


translate spanish rest_b8f03606:


    "Mi conocimiento sobre este teatro sigue siendo bastante limitado y mi curiosidad puede más que yo, así que decido buscar información en línea."


translate spanish rest_991d8857:


    "Kingdom of Marionettes. Un teatro de marionetas que cuenta la historia de la vida cotidiana de marionetas en un reino."


translate spanish rest_4a83d812:


    "Con razón las marionetas que vi antes estaban vestidas con trajes de una época real."


translate spanish rest_ca8ea766:


    "Kingdom of Marionettes era conocido por sus presentaciones divertidas y fascinantes, realzadas por los encantadores diseños de las marionetas."


translate spanish rest_c77259cb:


    "¿De verdad este lugar era tan famoso en ese entonces? Incluso vendían mercancía y todo tipo de cosas."


translate spanish rest_bb8e8b8a:


    "Incluso había una encuesta de personajes favoritos. Eso es bastante tierno."


translate spanish rest_9ddf8fdc:


    "El primer lugar fue para el bufón. A la gente realmente le gustan los personajes raros, ¿eh?"


translate spanish rest_e0d2acba:


    "El segundo lugar fue el caballero, y el tercero el mago."


translate spanish rest_5d396cc2:


    "Toda esta información sobre el teatro me atrapa por completo y, antes de darme cuenta, llevo media hora desplazándome."


translate spanish rest_6da0153b:


    u "Oh, mierda. Necesito revisar el CCTV."


translate spanish performance_2e984f22:


    jespuppet "Mmmm…"


translate spanish performance_52c6096a:


    "Entonces la marioneta chasquea los dedos, y en un instante, desaparece de frente a mí."


translate spanish performance_32ef791c:


    "E–¿qué…? ¿A dónde fue ahora??"


translate spanish performance_28c03380:


    jespuppet "Una mano tan pequeña y suave… como algodón… coooomo la patita de un gatito."


translate spanish performance_92e087b5:


    "Acaricia mi brazo suavemente con su mano de marioneta."


translate spanish performance_14d553fd:


    jespuppet "Una forma tan pequeña… tan fácilmente quebradiza… y aun así llena de calidez y movimiento…"


translate spanish performance_854a6ec0:


    jespuppet "Un recipiente que reacciona, tiembla y cambia de una forma tan hermosa…"


translate spanish performance_49562cdd:


    jespuppet "Y ese rostro… siempre cambiando, siempre contando historias sin siquiera proponérselo…"


translate spanish performance_0fd4d656:


    "……"


translate spanish performance_2fa81cee:


    "¿¿¿Me está… examinando???"


translate spanish performance_bccc696a:


    jespuppet "Realmente eres huuuumano"


translate spanish performance_69941a63:


    u "S–sí… soy humano…"


translate spanish performance_8f13a297:


    "Respondo con una voz nerviosa, cargada de miedo."


translate spanish performance_269b7f47:


    jespuppet "Pasaron segundos… luego horas… días… semanas… meses… años…"


translate spanish performance_b886c43e:


    jespuppet "Ha pasado tanto tiempo desde que todo aquello se desvaneció."


translate spanish performance_e9ca8105:


    jespuppet "Un reino que alguna vez fue tan animado, tan magnífico, tan lleno de alegría… ahora ha sido reducido al silencio."


translate spanish performance_815c1411:


    jespuppet "Un reino que alguna vez fue liderado por un gobernante, alguien que nos guiaba a todos hacia nuestro propósito, hacia nuestras vidas, ahora ha desaparecido."


translate spanish performance_71afbde2:


    jespuppet "Como aves jóvenes abandonadas por su progenitor antes de estar listas para volar, fuimos dejados a merced de la confusión… del desespero…"


translate spanish performance_be92aa84:


    jespuppet "Nos movemos sin dirección ni destino, sin saber a dónde estamos destinados a ir…"


translate spanish performance_20a833f9:


    jespuppet "Y aun así… creemos. Que algún día… una nueva luz aparecerá para guiarnos."


translate spanish performance_8e276719:


    jespuppet "Un líder que nos dará vida una vez más y nos conducirá hacia las vidas que siempre estuvimos destinados a vivir…"


translate spanish performance_906a604e:


    jespuppet "Esperamos… y tuvimos esperanza. Esperamos… y esperamos. Una y otra vez, hasta que ambas cosas se volvieron indistinguibles, como si nunca hubieran debido separarse."


translate spanish performance_7db42dc6:


    jespuppet "Y así, ese círculo perduró. Se mantuvo a través del paso del tiempo… hasta ahora. Haaasta este mismo día, que silenciosamente se atreve a llamarse a sí mismo un punto de inflexión."


translate spanish performance_347fdeee:


    jespuppet "¿Continuará este círculo su suave y despiadada danza, inquebrantable, inmutable?"


translate spanish performance_fcf1079e:


    jespuppet "¿O finalmente comenzará a agrietarse… a fracturarse… y por fin romperse, otorgándonos liberación del ciclo al que llamamos vida?"


translate spanish performance_0fd4d656_1:


    "……"


translate spanish performance_1084310d:


    "Eh… ¿de qué está hablando tan de repente? No entiendo. ¿Me está contando un cuento de hadas?"


translate spanish performance_461954a5:


    jespuppet "Un reino… un lugar nunca ajeno a la política, un dominio impregnado de tensión, donde la seriedad acecha bajo su lujosa y brillante superficie."


translate spanish performance_2c4d81b0:


    jespuppet "Como el hielo, amargamente frío, requiere al menos un poco de calidez. No… quizás la mitad de esa calidez para mantener su equilibrio."


translate spanish performance_1e2492ef:


    jespuppet "Y es precisamente por eso que estoy aquí. Para suavizar el ambiente, para brindar risas, para llevar alegría dondequiera que esta se desvanezca."


translate spanish performance_cad34bcc:


    jespuppet "Ahora… ¿puedes adivinar quién soy?"


translate spanish performance_092283e8:


    "E–Esta persona… no, esta marioneta… parece disfrutar mucho hablar…"


translate spanish performance_a4075a92:


    u "Eh… ¿eres un… bufón?"


translate spanish performance_3310f055:


    jespuppet "¡Ding, ding, ding! ¡Correcto!"


translate spanish performance_1a52fa9d:


    jes "Aunque, para ser precisos, bufón es solo mi rol. Permíteme presentarme apropiadamente ante ti, dulce humano. Mi nombre es Jestyn. Puedes llamarme Jestyn."


translate spanish performance_446cde29:


    jes "Aunque algunos prefieren Jes, Jesy, Tyn-Tyn y muchas otras variaciones, me temo."


translate spanish performance_ad2cd72e:


    jes "Ahora que te he ofrecido mi nombre, permíteme, solo esta vez, pedir el tuyo a cambio."


translate spanish performance_9051201a:


    jes "[player_call]… qué nombre tan encantador para un alma tan encantadora."


translate spanish performance_5b8aa077:


    jes "¿Y cuál es tu pronombre?"


translate spanish performance_09cd3e7f:


    jes "Entendido."


translate spanish performance_fa21c7df:


    jes "Pero dime… ¿Qué te trae a este reino, me pregunto? ¿Acaso estás cumpliendo un deber para la corona?"


translate spanish performance_48d18b2c:


    "Sigue refiriéndose a este teatro como un reino. Está empezando a confundirme."


translate spanish performance_f7ef9773:


    "Además, la forma en que habla es realmente extraña."


translate spanish performance_3bd8f634:


    "Pero… da igual. Seguiré el juego por ahora. Solo quiero salir de aquí lo antes posible."


translate spanish performance_664a72de:


    mc "Y–yo solo soy guardia de seguridad. Mi trabajo es vigilar este teatro… y hacer un poco de limpieza de paso."


translate spanish performance_a175816a:


    "Espero que mi respuesta lo satisfaga."


translate spanish performance_33c8f8bd:


    "Pero de repente, empieza a reír, y no tengo idea de por qué. ¿De verdad mi respuesta le resulta tan graciosa?"


translate spanish performance_20da2bb0:


    jes "Ah… ¿un guardián, dices? Qué nooooble vocación. Un protector del reino, alguien que se mantiene firme, luchando hasta la última gota de sangre."


translate spanish performance_d8bc5de1:


    jes "Y sin embargo… lamentablemente, no puedes convertirte en un guardián aquí."


translate spanish performance_519eacf2:


    mc "¿Q–qué quieres decir?"


translate spanish performance_90c9f9b2:


    jes "Verás, ya tenemos a un caballero que sirve como el escudo de este reino. Su nombre es Knighter. Y no tenemos intención de aceptar a otro."


translate spanish performance_34356624:


    jes "Un caballero es más que suficiente."


translate spanish performance_d8a0138b:


    "¿Está… hablando de los roles en este teatro?"


translate spanish performance_e985e405:


    mc "Oh… entonces supongo que solo seré un limpiador…"


translate spanish performance_8a9f02b8:


    jes "Ya tenemos suficientes doncellas aquí, y no creo que sea posible añadir otra."


translate spanish performance_4cfdcb02:


    mc "Muy bien entonces. Supongo que simplemente no seré nadie."


translate spanish performance_4d4e6485:


    jes "Oh no, no… todo aquel que llega aquí debe tener su propio rol."


translate spanish performance_f0711c5e:


    jes "Y el rol que actualmente está vacante… es el del rey, la reina, el gobernante del reino."


translate spanish performance_f9ed36da:


    mc "E–está bien… eh… pero ¿¿por qué solo está vacío el puesto de rey?? ¿Qué pasó con el rey anterior?"


translate spanish performance_dc20a6b6:


    "Cuando revisé las marionetas antes, había una habitación etiquetada como 'The King'. Así que la marioneta rey debió haber existido."


translate spanish performance_b2b283fa:


    jes "Lamentablemente, falleció."


translate spanish performance_ce801f57:


    mc "Oh… lo siento. Mis condolencias."


translate spanish performance_2f036b9a:


    jes "Está bien, mi querid[poss!t]. Así es simplemente la vida. La gente va y viiiiene. Es parte de un ciclo del que no puedes escapar. Creo que los humanos entienden muy bien eso."


translate spanish performance_5bf47951:


    "Luego aplaudió."


translate spanish performance_d94e3c51:


    jes "Ha pasado mucho tiempo desde que el rey falleció. Este reino se ha vuelto terriblemente oscuro… lleno de silencio, sin dirección ni alegría."


translate spanish performance_1f957725:


    jes "Y debo admitir… se ha vuelto bastante aburrido aquí."


translate spanish performance_c6da68e6:


    jes "Pero ahora que he conocido a un humano tan dulce frente a mí, ¿por qué no me concedes un pequeño juego, Su Majestad?"


translate spanish performance_6c977b5a:


    mc "….. ¿Su Majestad? ¿yo?"


translate spanish performance_e6d429b2:


    "Su sonrisa se ensanchó."


translate spanish performance_9bc84d96:


    jes "Sí. Juguemos un poco a actuar. Tú fingirás ser [obj!t] [title!t], y yo… seré tu bufón."


translate spanish performance_fc5d52a4:


    jes "Oh, perdóname. He sido un bufón desde el principio. Qué torpe de mi parte."


translate spanish performance_91abef26:


    "Jestyn chasqueó los dedos y, antes de darme cuenta, se había movido al escenario."


translate spanish performance_1a9aa838:


    jes "Ahora bien… ¿permitimos que la función comience?"


translate spanish performance_98e1e946:


    mc "E–espera, ¡espera! ¡Nunca he actuado antes! ¡Ni siquiera sé cómo—"


translate spanish performance_f38844b3:


    jes "Oh no, mi querid[poss!t]… Simplemente vive, como si siempre hubieras sido el gobernante de este reino."


translate spanish performance_e84b7420:


    "Jestyn volvió a chasquear los dedos."


translate spanish performance_5afda8b6:


    "Y en un instante, me encontré ya en el escenario, sentad[poss!t] en un lujoso trono, con una corona descansando sobre mi cabeza."


translate spanish performance_bf5bf7f9:


    mc "¿Qu–qué?!"


translate spanish performance_88a957a0:


    nara "{color=#E0AE4B}Un día, bajo el abrasador sol del verano, el reino fue golpeado por problemas una vez más. Los granjeros estaban llenos de tristeza mientras el implacable calor del verano quemaba la tierra.{/color}"


translate spanish performance_51554ab9:


    nara "{color=#E0AE4B}Los cultivos se marchitaron y fracasaron bajo la sequía, dejando los campos estériles. Como resultado, los granjeros sufrieron grandes pérdidas, sin cosecha que vender.{/color}"


translate spanish performance_8364a461:


    nara "{color=#E0AE4B}Al final, los granjeros llevaron su situación ante Su Majestad, con la esperanza de que [subj!t] les brindara ayuda y alivio.{/color}"


translate spanish performance_c231e200:


    "Miré a mi alrededor, intentando encontrar la fuente de la voz que sonaba como un narrador."


translate spanish performance_6aa45380:


    nara "{color=#E0AE4B}Dentro del reino, Su Majestad se encontraba sentad[poss!t] en su trono, con su expresión nublada por la confusión, cuando Jestyn, el bufón real, apareció ante [subj!t] para transmitir los problemas que enfrentaban los granjeros{/color}"


translate spanish performance_01422283:


    jes "Buenas noches, Su Majestad."


translate spanish performance_a64afe78:


    "Jestyn apareció y se inclinó ante mí con la mayor reverencia."


translate spanish performance_e9042124:


    jes "Qué día taaaan verdaderamente hermoso es hoy."


translate spanish performance_af5db24b:


    jes "Un día igualmente adecuado para atender los pequeños problemas que surgen dentro del reino… ¿no está de acuerdo, Su Majestad?"


translate spanish performance_f95a4fa4:


    mc "¿Problemas… en el reino?"


translate spanish performance_4874d63f:


    jes "En efecto, Su Majestad."


translate spanish performance_f9c09460:


    jes "Últimamente, los habitantes del pueblo han comenzado a expresar sus preocupaciones. Las cosechas han fracasado, abatidas por la implacable sequía de la estación seca."


translate spanish performance_05d74c2d:


    jes "Y como era de esperarse, tal infortunio los ha dejado… bastante faltos de recursos."


translate spanish performance_9f21f0aa:


    jes "Por favor, pase, querido invitado."


translate spanish performance_d534aa3a:


    nara "{color=#E0AE4B}Un hombre que trabajaba como granjero entró entonces, después de que Jestyn le concediera permiso para pasar.{/color}"


translate spanish performance_e943668d:


    "De repente, una marioneta vestida como granjero dio un paso al frente y se arrodilló ante mí."


translate spanish performance_b64f7501:


    farm "Saludos, Su Majestad. Por favor, perdone mi atrevimiento, pero venimos ante usted para solicitar humildemente su ayuda."


translate spanish performance_9ae10a62:


    farm "Debido al fracaso de las cosechas, ya no tenemos los medios para reemplazar los cultivos que se marchitaron, ni contamos con fondos para cubrir nuestras necesidades diarias…"


translate spanish performance_9d72adad:


    farm "Por lo tanto, le suplicamos… que nos brinde su guía."


translate spanish performance_972b6338:


    "Al haber sido arrastrado al papel de [obj!t] [title!t] sin previo aviso, la confusión me invadió."


translate spanish performance_595efd78:


    "Mis propios problemas estaban lejos de resolverse, ¡y ahora se esperaba que encontrara una manera de salvar también a los granjeros!"


translate spanish performance_ec04fee4:


    mc "E–eh…"


translate spanish performance_15a64d5d:


    "¿Qué se supone que debo hacer…?"


translate spanish problem2_e3bea3c4:


    mc "….. ¿Ya terminó?"


translate spanish problem2_70f8e564:


    jes "¿Terminó?"


translate spanish problem2_fb4c14c0:


    jes "Si gobernar un reino fuera tan sencillo, Su Majestad, me temo que tendríamos muchas menos reinas."


translate spanish problem2_4e766586:


    "Aún hay más…"


translate spanish problem2_a7674f73:


    nara "{color=#E0AE4B}El día transcurrió lentamente dentro del reino. Y sin que Su Majestad lo notara, el tiempo que una vez marcaba las nueve de la mañana ya había avanzado hasta la una de la tarde.{/color}"


translate spanish problem2_a95fab49:


    nara "{color=#E0AE4B}En ese preciso momento, una carta formal de otro reino llegó repentinamente.{/color}"


translate spanish problem2_a5e90a9f:


    nara "{color=#E0AE4B}Al enterarse de esto, el mayordomo tomó rápidamente la carta y se dispuso a entregársela a Su Majestad.{/color}"


translate spanish problem2_007b68af:


    "De repente, una marioneta vestida de mayordomo se acercó a Jestyn y le entregó un pergamino."


translate spanish problem2_9ad1e23c:


    "Jestyn lo leyó por un momento. Su expresión se volvió concentrada, antes de que sus ojos se dirigieran hacia mí y esa amplia sonrisa regresara a su rostro."


translate spanish problem2_65c94ba0:


    jes "Su Majestad, hemos recibido una solicitud sumamente asombrosa y bastante intrigante de un reino vecino."


translate spanish problem2_33b6191e:


    "Todo está escrito aquí, en tinta, sobre este pergamino."


translate spanish problem2_ebec001e:


    jes "En resumen, desean comprar una pequeña porción de tierra a lo largo de nuestra frontera, bajo el pretexto de facilitar el comercio."


translate spanish problem2_e32448da:


    jes "Si Su Majestad acepta este acuerdo, están preparados para ofrecer una compensación en monedas de oro. Una cantidad que estoy bastante seguro haría que Su Majestad sufriera un infarto en el acto~"


translate spanish problem2_f70a91f0:


    jes "Entonces… ¿qué hará, Su Majestad?"


translate spanish problem2_445e6ea5:


    "Oh no… esto está empezando a sonar complicado. ¿Qué debería hacer?"


translate spanish after_acting_372cd5aa:


    jes "Muy bien entonces. Informaré a nuestros vecinos de la voluntad de Su Majestad."


translate spanish after_acting_661a8003:


    jes "Y creo que, por ahora, los asuntos que Su Majestad debía resolver han llegado al final del programa de hoy."


translate spanish after_acting_917307e9:


    jes "Puede descansar ahora, Su Majestad~"


translate spanish after_acting_093871f9:


    "Por fin… termina. No sé si mi cerebro puede soportar más cosas de reino."


translate spanish after_acting_e6132cd8:


    "Antes de poder relajarme finalmente, mi teléfono sonó."


translate spanish after_acting_7578997d:


    "Oh no… tiene que ser el cobrador de deudas."


translate spanish after_acting_acb0e640:


    "De verdad no quiero lidiar con esto ahora mismo. No tengo el dinero para pagar."


translate spanish after_acting_21ad1c53:


    "Pero realmente no tengo elección…"


translate spanish after_acting_4e85cb4d:


    mc "¿Hola?"


translate spanish after_acting_83e04508:


    debt "[player_call] ¡Sabes por qué te estoy llamando, verdad?"


translate spanish after_acting_5a64fdcd:


    mc "Claro…"


translate spanish after_acting_d0d55219:


    debt "¿Entonces?"


translate spanish after_acting_fe5086ae:


    mc "Lo siento… no puedo pagarlo ahora mismo."


translate spanish after_acting_18aa1915:


    mc "Pero acabo de conseguir un trabajo otra vez. Solo necesitas esperar hasta el día de pago."


translate spanish after_acting_7c7d602e:


    debt "Haaah… está bien. Pero recuerda, ya has retrasado esto por cinco meses."


translate spanish after_acting_cc837eb4:


    mc "Lo sé… lo sé… gracias por tu comprensión…"


translate spanish after_acting_17c0a825:


    "Momentos después de terminar la llamada, apoyé mi cuerpo contra el asiento, necesitando un breve descanso."


translate spanish after_acting_3345f35d:


    "Tengo que pagarlo en un mes…"


translate spanish after_acting_a63b6d6b:


    "Pasé mis dedos por mi cabello con frustración, antes de recordar que Jestyn aún estaba frente a mí."


translate spanish after_acting_9e566277:


    mc "Oh— lo siento, Jestyn. Eso era solo un asunto personal—"


translate spanish after_acting_4dda5812:


    "De repente, la mano de Jestyn se cerró suavemente sobre mi hombro. Me miró con esa amplia sonrisa suya."


translate spanish after_acting_a32261d7:


    jes "Su Majestad, sus asuntos personales son asuntos del reino."


translate spanish after_acting_d24de394:


    jes "Y eso los convierte en mi preocupación también, como bufón del reino."


translate spanish after_acting_be56e838:


    jes "Por lo que observé en su conversación a través de esa tecnología hace un momento, parece que Su Majestad está en deuda… con otro reino, ¿estoy en lo correcto?"


translate spanish after_acting_2b35b6fe:


    mc "…"


translate spanish after_acting_07f99d29:


    mc "Sí…"


translate spanish after_acting_fbbe8638:


    "Su mano sobre mi hombro amasó suavemente la tensión. Al instante, sentí cómo me relajaba."


translate spanish after_acting_3a4a6a82:


    jes "Puede contarme sus problemas, Su Majestad."


translate spanish after_acting_ddf56c7b:


    jes "Después de todo, soy su bufón más leal… y el único…"


translate spanish after_acting_0fd4d656:


    "……"


translate spanish after_acting_0acac695:


    mc "… He estado pensando en las finanzas del reino durante mucho tiempo. Han estado disminuyendo cada vez más."


translate spanish after_acting_164f9f77:


    jes "Oh, vaya~"


translate spanish after_acting_e0fe2d11:


    mc "Sí… en aquel entonces yo… podrías decir que formé una especie de amistad con el gobernante de otro reino."


translate spanish after_acting_2ea7ab35:


    mc "Ese reino necesitaba ayuda porque enfrentaban un problema similar."


translate spanish after_acting_eea581d9:


    mc "Pero al final, ese reino solo me estaba utilizando y luego me traicionaron."


translate spanish after_acting_45f2d9f0:


    mc "Así que… tuve que pedir prestados fondos a otros reinos. Y ahora… nuestro reino está cargado con una deuda considerable."


translate spanish after_acting_a9d7652c:


    mc "He estado tratando de encontrar otras fuentes de ingresos solo para mantener la estabilidad."


translate spanish after_acting_f35ef482:


    "Después de explicar todos mis problemas llenos de metáforas, Jestyn no dijo nada por un momento."


translate spanish after_acting_3d1a6ef7:


    "El silencio envolvió el aire entre nosotros."


translate spanish after_acting_ed5ba8b5:


    jes "¿Sabe por qué el león es honrado como el rey del bosque, Su Majestad?"


translate spanish after_acting_d1dd8d04:


    "Por un segundo, me sentí confundido por su repentina pregunta sobre el león."


translate spanish after_acting_5fe678b3:


    mc "Eh… ¿porque son majestuosos?"


translate spanish after_acting_ff7db947:


    jes "En efecto. Son majestuosos. Son temibles. Son resilientes, depredadores ápice, situados en la cima."


translate spanish after_acting_8a60221d:


    jes "Ahora, imagine un conejo. ¿Por qué el conejo nunca es llamado el rey del bosque?"


translate spanish after_acting_732e8b36:


    mc "Porque… ¿los conejos son demasiado gentiles? ¿Pequeños? ¿No lo suficientemente intimidantes?"


translate spanish after_acting_7f9f0b7b:


    jes "Gentiles."


translate spanish after_acting_26030657:


    jes "Demasiado indecisos… y, ah, trágicamente humanos."


translate spanish after_acting_0c515d6e:


    jes "Y lo más importante… confían en los demás con demasiada facilidad."


translate spanish after_acting_ed23a5fd:


    jes "Cualidades muy nobles… para un alma sufriente. No tanto para [obj!t] [title!t]."


translate spanish after_acting_2669f073:


    jes "Pensaste que al ayudar a otros, ellos te querrían. Que te sonreirían, estarían a tu lado y te llamarían amigo."


translate spanish after_acting_12293362:


    jes "¡Y luego BOOM! ¡Qué sorpresa tan encantadora! ¡Has sido engañad[poss!t]! ¡Estafad[poss!t]! ¡Tocad[poss!t] como una dulce melodía! ¡Jajajajajajaja!"


translate spanish after_acting_b3646884:


    "Se rió de forma maniaca."


translate spanish after_acting_b62ffb44:


    jes "¿No es perfectamente irónico?"


translate spanish after_acting_0fc512df:


    "Jestyn habló con una sonrisa, cada risa delicada y educada… pero cada palabra se sentía como una afilada hoja presionada contra mi pecho."


translate spanish after_acting_3c32a577:


    "Una vez leí que la tarea de un bufón en un reino… es entretener. Y parte de eso… es revelar la verdad a través de la burla."


translate spanish funny_8d463535:


    "Ya lo veo. Sí… debo seguir el juego."


translate spanish funny_f004a6f1:


    mc "¡Jajajaja! No estás… equivocado, Jestyn."


translate spanish annoying_444727e3:


    "Pero la forma en que dijo eso…"


translate spanish annoying_8ea1f22a:


    "Sus palabras atravesaban mi corazón de manera letal."


translate spanish annoying_b7842494:


    "No voy a mentir, eso es muy molesto."


translate spanish advice_14e3cae9:


    jes "Verá, Su Majestad, las reglas de este mundo no son un dulce cuento donde la bondad siempre es recompensada con bondad. Creo que ya lo sabe."


translate spanish advice_aceede3e:


    jes "A veces el juego es mucho más simple que eso. A veces, la regla es simplemente devorar… o ser devorado."


translate spanish advice_5a4a31da:


    mc "¿Quiere decir que debería convertirme en un león?"


translate spanish advice_b805fab8:


    jes "Oh no, no, Su Majestad. Eso no será necesario. ¿Por qué? La expresión en su rostro, tan privada de sueño, ya es bastante aterradora."


translate spanish advice_520b089f:


    "Se ríe burlonamente mientras me observa fruncir el ceño."


translate spanish advice_1b24106c:


    jes "Jeje, perdóneme, Su Majestad. Solo estaba bromeando. No le estoy diciendo que se convierta en un león."


translate spanish advice_f2e1bab4:


    jes "¿Alguna vez ha considerado… combinar un conejo y un león?"


translate spanish advice_b8a4300d:


    mc "Eh… ¿no se vería como una especie de mutante?"


translate spanish advice_b39d6b88:


    jes "No ese tipo de combinación, Su Majestad…"


translate spanish advice_f34bf4fe:


    "Hace un ligero gesto con el dedo."


translate spanish advice_ca0b66f8:


    jes "La apariencia de un conejo, pero el corazón de un león. Como un lobo bajo piel de oveja, si me pregunta."


translate spanish advice_16187254:


    "Hace una pausa."


translate spanish advice_54063081:


    jes "Y además… confíe solo en aquellos a su alrededor a quienes realmente conoce."


translate spanish advice_df231ede:


    jes "Aquellos que permanecerán leales a ti, pase lo que pase. ¿Difícil? Sí. Pero esa es simplemente la verdad."


translate spanish advice_6a7308d5:


    jes "Y después de eso… quizá aquellos leales a ti incluso te ayuden a destruir a quienes te han hecho daño."


translate spanish advice_e2419ffb:


    jes "{color=#FF2727}Solo por ti.{/color}"


translate spanish advice_47adc674:


    jes "Entiendes lo que quiero decir, ¿no es así, Su Majestad?"


translate spanish advice_2f85c766:


    "Sus palabras me dejan perdido en mis pensamientos."


translate spanish advice_d8581df8:


    "Ahora que lo pienso… realmente soy alguien que busca complacer a los demás."


translate spanish advice_3cc35a6d:


    mc "Lo entiendo… pero cambiar eso no es fácil."


translate spanish advice_e13b0076:


    "Jestyn deja escapar una suave risa. Sus ojos se entrecierran mientras su sonrisa se ensancha lentamente."


translate spanish advice_bab18eb3:


    jes "Muy cierto, Su Majestad… y es precisamente por eso."


translate spanish advice_64883bc1:


    jes "Tal vez, en lugar de preguntarte qué más puedes dar… deberías preguntarte qué es lo que aún te niegas a tomar."


translate spanish advice_891258a4:


    "Jestyn se aleja de mí, dándome espacio para reflexionar sobre el significado de sus palabras."


translate spanish advice_4c28949b:


    "Sus palabras siempre son difíciles de entender…"


translate spanish advice_9e9daed2:


    "Aplaude, sacándome de mis pensamientos."


translate spanish advice_f3ef196f:


    jes "Ahora… permítame presentarle un entretenimiento. Debe estar cansado de trabajar todo el día, ¿verdad, Su Majestad?"


translate spanish advice_62999dc6:


    jes "Por mucho que adore esa expresión suya, como un murciélago despertado a plena luz del día, preferiría no verlo siempre con un rostro tan completamente carente de alegría…"


translate spanish advice_3bdcf7c5:


    "Se ríe suavemente. A mí me deja con muy poco de qué reír."


translate spanish advice_1d738662:


    jes "Haré que sonría una vez más. Derritiendo el frío de su vida con el fuego del deleite que traigo."


translate spanish advice_767cd509:


    jes "Permítame~"


translate spanish advice_1d7cf93b:


    "Jestyn chasquea los dedos. En un instante, algo aparece en sus manos."


translate spanish advice_0a0d80da:


    "Era un pequeño objeto rectangular, envuelto en una capa dorada y atado cuidadosamente con una cinta roja."


translate spanish advice_def0ad19:


    mc "¿Qué es?"


translate spanish advice_31a87d5e:


    "Jestyn me lo entrega, permitiéndome abrirlo yo mismo."


translate spanish advice_eabac4e2:


    mc "¿Chocolate?"


translate spanish advice_f033135f:


    jes "En efecto, Su Majestad. A todo el mundo le gusta el chocolate. ¿A quién no? Así que espero que le guste."


translate spanish advice_4cd27f3c:


    jes "Y no es un chocolate cualquiera."


translate spanish advice_f7a516c1:


    jes "Elaboré cada paso con todo mi corazón. Cuidadosamente, con delicadeza y con la mayor devoción."


translate spanish advice_d916d371:


    jes "Así que espero que saboree mi chocolate hecho a mano y no olvide el color de su envoltura, Su Majestad~"


translate spanish eatchocolate_3697085d:


    "Bueno… ya que me lo había dado, no podía rechazarlo. No tenía corazón para hacerlo."


translate spanish eatchocolate_ba8cabbe:


    "Partí un trozo del chocolate y lo llevé a mi boca."


translate spanish eatchocolate_f185d9cc:


    "En el momento en que tocó mi lengua, pude sentir cómo se derretía."


translate spanish eatchocolate_cd55feb8:


    "Pero al mismo tiempo, vi cómo la sonrisa de Jestyn se afilaba y fue entonces cuando lo sentí."


translate spanish eatchocolate_4b1aad94:


    mc "¡Ugh—?!"


translate spanish eatchocolate_a8c586c7:


    "Una sensación ardiente se extendió por mi lengua."


translate spanish eatchocolate_69ebc829:


    jes "Oh, cielos… parece que alguien olvidó el color de la envoltura~"


translate spanish eatchocolate_8f5595d0:


    "Jestyn soltó una risa suave al ver mi rostro enrojecer por el calor."


translate spanish eatchocolate_90893ba6:


    mc "¿Q–qué clase de chocolate es este?!"


translate spanish eatchocolate_44960690:


    jes "Jeje. Es chocolate, por supuesto. Pero encuentro los ingredientes habituales bastante aburridos. Nada nuevo. Qué tedioso."


translate spanish eatchocolate_70eaca9d:


    jes "¡Y entonces! Se me ocurrió una idea brillante. ¿Por qué no añadir algo nuevo a la receta?"


translate spanish eatchocolate_2f9e35fe:


    jes "Así que le añadí chile en polvo."


translate spanish eatchocolate_9bbcefec:


    "Lo miré, completamente sin palabras. ¿¡Qué clase de lógica es esa!?"


translate spanish eatchocolate_e9a00209:


    jes "Pobrecito, Su Majestad. Pero esa expresión suya, tan alterada y enrojecida, es simplemente adorable."


translate spanish eatchocolate_0e55d190:


    "Jestyn me entregó entonces un vaso de agua para beber."


translate spanish eatchocolate_0534be04:


    "¿Cómo caí en su broma tan fácilmente?"


translate spanish donteat_5d8ce5a8:


    "Miré el chocolate por un momento."


translate spanish donteat_0260f83c:


    "No quería rechazar el regalo de alguien… pero mis instintos me decían que algo no estaba bien."


translate spanish donteat_278c7e29:


    "………"


translate spanish donteat_17f2ebd7:


    mc "¿Jestyn?"


translate spanish donteat_32797f5c:


    jes "Sí, Su Majestad?"


translate spanish donteat_098db61c:


    mc "Esto no es un chocolate normal, ¿verdad?"


translate spanish donteat_9809117e:


    "Su sonrisa no se desvaneció en lo más mínimo mientras me miraba."


translate spanish donteat_77c8fcdd:


    jes "¿Oh? ¿Y qué le hace decir eso, Su Majestad?"


translate spanish donteat_c9725607:


    jes "Ah… para ser honesto, me duele que me acuse así. Le di ese chocolate con sinceridad."


translate spanish donteat_90b3aaad:


    "Su sonrisa se desvaneció lentamente, reemplazada por la expresión de alguien profundamente herido."


translate spanish donteat2_95213de5:


    mc "No me mientas."


translate spanish donteat2_8b2d262f:


    mc "Hay algo en este chocolate, ¿no es así? No voy a caer."


translate spanish donteat2_3f2af826:


    jes "….."


translate spanish donteat2_68fc2657:


    jes "Pfft… khuhu…"


translate spanish donteat2_7a0c2c91:


    "Jestyn dejó escapar una suave risa. Y con eso, todo quedó demostrado."


translate spanish donteat2_f6bbaa0f:


    jes "Jejeje… ¡ahahahahaha!"


translate spanish donteat2_f62305b9:


    jes "Ahh… así que alguien no olvidó el color de la envoltura después de todo."


translate spanish donteat2_52551e79:


    jes "Eres más perspicaz de lo que pareces, Su Majestad…"


translate spanish donteat2_79b789ab:


    jes "Sí. Le añadí algo al chocolate."


translate spanish donteat2_1df16ba6:


    "Dejé caer el chocolate al suelo."


translate spanish donteat2_6f68c9a6:


    mc "E–entonces ¿qué le pusiste?! ¡No me digas que es veneno! ¿¡Estás tratando de matarme!?"


translate spanish donteat2_e05a60ec:


    jes "¿Veneno?! ¡AHAHAHAHAHAHA!"


translate spanish donteat2_96c92fd7:


    jes "Oh, Su Majestad, no soy tan cruel. Solo fue una broma. Y nunca haría algo tan despiadado por el bien de una broma."


translate spanish donteat2_08e2742c:


    jes "Es chocolate, por supuesto. Pero encuentro los ingredientes habituales bastante aburridos. Nada nuevo. Qué tedioso."


translate spanish donteat2_70eaca9d:


    jes "¡Y entonces! Se me ocurrió una idea brillante. ¿Por qué no añadir algo nuevo a la receta?"


translate spanish donteat2_2f9e35fe:


    jes "Así que le añadí chile en polvo."


translate spanish donteat2_9bbcefec:


    "Lo miré, completamente sin palabras. ¿¡Qué clase de lógica es esa!?"


translate spanish freakymomen_65855918:


    jes "Jejeje. Por favor, perdóneme, Su Majestad. Esta vez le daré un entretenimiento adecuado. Prometo que no es otra broma."


translate spanish freakymomen_9524c3a6:


    "Jestyn chasqueó los dedos."


translate spanish balls_ef621327:


    mc "… ¿pelotas?"


translate spanish balls_95449cd9:


    jes "Correcto."


translate spanish balls_8524ccab:


    "Sin esperar más, comenzó a hacer malabares con una habilidad impresionante."


translate spanish balls_d78cf6b9:


    "Las pelotas volaban de una mano a otra, mezcladas con algunos trucos llamativos. Era evidente que lo había hecho innumerables veces antes."


translate spanish balls_1a48c3f4:


    "Entonces, su mirada se dirigió hacia mí."


translate spanish balls_9f05f094:


    jes "¡Debe continuar con mis malabares, Su Majestad!"


translate spanish balls_3fb0e546:


    mc "Espera, ¿qué—?"


translate spanish balls_3f766e70:


    "Antes de que pudiera terminar la frase, Jestyn lanzó todas las pelotas hacia mí."


translate spanish balls_d8cf2bd5:


    "Por más que lo intenté, fue inútil. Las pelotas se escapaban de mis manos y golpeaban el suelo antes de que pudiera siquiera mantenerlas en el aire."


translate spanish balls_b69104d7:


    "Al ver mi patético intento, Jestyn estalló en carcajadas."


translate spanish balls_3ce7a169:


    jes "¿En serio, Su Majestad? Ni siquiera puede atraparlas, mucho menos hacer malabares."


translate spanish balls_3b768363:


    mc "¡Claro que no! ¡Nunca he hecho esto antes!"


translate spanish balls_32a85459:


    "Las pelotas rodaron por el escenario, dispersándose a mis pies."


translate spanish balls_4faa5ed5:


    jes "¡Ah, ah, ah! No se vea tan derrotado ya, Su Majestad."


translate spanish balls_da52edfd:


    jes "Pensé que los humanos eran bastante buenos atrapando cosas. Oportunidades, promesas, responsabilidades."


translate spanish balls_ddc21682:


    "Se ríe suavemente, como si acabara de decir una broma inocente."


translate spanish balls_81f3ccdb:


    mc "Me las lanzaste sin aviso…"


translate spanish balls_1da73b32:


    jes "¿Lo hice?"


translate spanish balls_42d168c2:


    "Inclina la cabeza, las campanillas de su gorro tintineando débilmente."


translate spanish balls_97bfd332:


    jes "Mis disculpas entonces. A veces olvido que no todos disfrutan de las sorpresas tanto como yo."


translate spanish balls_d7fbe90a:


    "Se agachó y recogió una de las pelotas caídas, haciéndola girar ligeramente sobre su palma."


translate spanish balls_7c2ed117:


    jes "Dígame, ¿qué cree que son los malabares, Su Majestad?"


translate spanish balls_d44ced45:


    mc "Eh… ¿lanzar cosas? ¿Tratar de no dejarlas caer?"


translate spanish balls_7bf63dbf:


    jes "Hoho… una respuesta honesta. Me gusta."


translate spanish balls_78579f7a:


    jes "Los malabares son equilibrio. Ritmo. Saber qué pelota atrapar primero y cuál debes permitir que caiga."


translate spanish balls_f11d3722:


    "Lanza la pelota al aire con naturalidad, atrapándola con facilidad."


translate spanish balls_18837d02:


    "Luego deja que la pelota se le escape de los dedos y golpee el escenario con un sonido seco. Después me mira nuevamente."


translate spanish home_b2dbb149:


    jes "Creo que su tiempo en este reino ha llegado a su fin."


translate spanish home_28fa5188:


    "Me confunde lo que quiere decir, pero cuando miro mi reloj, marca las 5:30 a. m."


translate spanish home_ab05c1c8:


    mc "Oh… mi turno ha terminado."


translate spanish home_3f1bdbf6:


    "Toma mi mano y besa el dorso."


translate spanish home_8079daff:


    "Sus labios se sienten fríos, pero la sensación envía calor recorriendo mi cuerpo hasta el corazón."


translate spanish home_42a2cc2b:


    jes "Entonces, hasta que nos volvamos a encontrar,"


translate spanish home_1632ba7e:


    jes "dulce human[poss!t]…"


translate spanish home_3cdae3c3:


    "Después de decir eso, Jestyn camina hacia la parte oscura del escenario y desaparece."


translate spanish home_9342fca3:


    "Finalmente regreso a mi pequeño y miserable apartamento."


translate spanish home_f52f2dbb:


    "Y lo que pasó hoy fue realmente algo…"


translate spanish home_3df4b499:


    "Marionetas vivientes… y siendo tratad[poss!t] como algún tipo de [title!t]."


translate spanish home_4e207e4e:


    "Qué día tan extraño. Siento que me estoy volviendo loco."


translate spanish home_5ef7297b:


    "¿Debería volver mañana otra vez? Toda esta situación se siente muy inquietante…"


translate spanish home_07bdde05:


    "….."


translate spanish home_aeb9b1ae:


    "… Claro que tengo que ir. Mi deuda no se va a pagar sola. Necesito el dinero. Buscar otro trabajo sería demasiado difícil para mí ahora mismo."


translate spanish home_9f059fed:


    "No sé qué pasará conmigo después."


translate spanish home_71178961:


    "Por ahora, será mejor que duerma un poco. Estoy completamente agotad[poss!t]."


translate spanish home_a20cefa7:


    "…"


translate spanish home_5f9b772e:


    "…."


translate spanish home_0fd4d656:


    "……"


translate spanish home_bbd50ba8:


    jes "Pasaron segundos… luego horas… días… semanas… meses… años…"


translate spanish home_cfeb39ac:


    jes "Ha pasado tanto tiempo desde que todo aquello se desvaneció."


translate spanish home_5554f270:


    jes "Y después de tanto tiempo… por fin te he encontrado…"


translate spanish home_d4bb94ed:


    jes "Mi [title!t]"


translate spanish home_4b236792:


    jes "Su Majestad… realmente le agradezco por hoy. Me ha hecho tan insoportablemente feliz…"


translate spanish home_d12460ef:


    jes "Ah… pero… volverá esta noche, ¿verdad…?"


translate spanish home_dc48b27e:


    jes "Claro… claro que lo hará. Aún hay tantas cosas que podemos hacer juntos. Simplemente no podría soportarlo si no viniera."


translate spanish home_77ea8a7d:


    jes "Le enseñaré malabares. Dijo que quería que lo hiciera, ¿verdad? Entonces le enseñaré todo. Cada truco, cada movimiento, hasta que sus manos se muevan exactamente como las mías."


translate spanish home_91c7b2d2:


    jes "Luego le mostraré trucos de magia… unos que prometo le robarán el aliento. Oh, y hay tantas marionetas esperando conocerle… para ser organizadas… para pertenecer donde usted desee. Y luego… y luego…"


translate spanish home_53ae36ac:


    jes "Podemos jugar otra vez como antes, Su Majestad. Soy su leal bufón, arrodillado ante mi amo como un sabueso devoto."


translate spanish home_c3fcfba9:


    jes "Oh, no tiene idea de cómo esa sensación hizo latir mi corazón… cómo me hizo sentir que le pertenecía… sí… le pertenezco a usted, [obj!t] [title!t] [player_call]"


translate spanish home_3b7654bf:


    jes "Podemos cenar juntos, dormir juntos, cantar juntos, bailar juntos… siempre juntos… y luego… y luego…"


translate spanish home_a1abeaae:


    jes "Oh, dulce acidez y crema, hay tantas cosas que podríamos hacer que apenas sé por dónde empezar… mientras nunca se aparte de mi lado."


translate spanish home_555bdd3f:


    jes "De verdad… ¿qué me ha hecho, Su Majestad…? Estoy empezando a creer que es un hechicero de poder aterrador. Ni siquiera Wizzy, el mago real, podría torcer un corazón de esta forma…"


translate spanish home_3523e422:


    jes "Siento como si hubiera caído en su telaraña… envuelto con fuerza, incapaz de escapar… simplemente esperando ser devorado por usted… y aun así… no creo querer resistirme en absoluto."


translate spanish home_067bdf0d:


    jes "Apenas me reconozco ya, Su Majestad… pero de alguna manera, no deseo volver atrás."


translate spanish home_86f0ef77:


    jes "El reino lo necesita… yo lo necesito."


translate spanish home_45e4e473:


    jes "No. Lo quiero… lo anhelo… Mi [title!t], [player_call]…"


translate spanish home_8e8701f7:


    jes "Nunca antes había sentido algo tan abrumador… quiero quedarme a su lado, observar cómo respira, grabar su imagen en mi mente, tocarle… y quizá… hundirme aún más en usted, hasta que no quede nada más que nosotros…"


translate spanish home_6ee728d3:


    jes "Ah— no, no, no. Qué inapropiado de mi parte. Un simple bufón tocando a su [title!t] con tanta osadía… pero si usted me diera permiso, atesoraría cada centímetro de usted con la mayor devoción."


translate spanish home_a1e6d275:


    jes "Oh, Mi [title!t], apenas puedo soportar la espera para verle de nuevo… desearía que el tiempo avanzara rápido… y al mismo tiempo se congelara por completo cuando estoy con usted. Si tan solo pudiera doblar el tiempo mismo. Solo para usted."


translate spanish home_d3bd5717:


    jes "Me retiro ahora, Mi [title!t]… que sus sueños estén llenos de mí…"


translate spanish home_6ebbd0f1:


    jes "[player_call]"


translate spanish start_8cba0c84_1:


    "¿Quién habría pensado que acabaría en una situación tan extraña?"


translate spanish start_9ece5d1e_1:


    "Todo comenzó porque necesitaba desesperadamente encontrar trabajo."


translate spanish start_866fca32_1:


    "Claro que la situación me tenía al límite. Mis ahorros se estaban acabando, y todavía tenía innumerables gastos de vida además de deudas por pagar."


translate spanish start_aaed3db5_1:


    "Apliqué a todo tipo de lugares, pero sentía que la suerte me odiaba completamente."


translate spanish start_0c268043_1:


    "En una situación así, ya no me importaba qué tipo de trabajo fuera, mientras pagara. Limpiar baños, atrapar osos… haría lo que fuera."


translate spanish start_1715a48e_1:


    "Fue entonces cuando encontré este trabajo en línea…"


translate spanish start_62e8aaa8_1:


    "Un puesto de seguridad en un teatro abandonado. En serio, ¿por qué un lugar que ya no funciona necesitaría siquiera un guardia de seguridad?"


translate spanish start_518151f5_1:


    "Kingdom of Marionettes. Había escuchado que este lugar solía ser famoso por sus espectáculos de marionetas hace mucho tiempo."


translate spanish start_d79b2a65_1:


    "Oh. Solo tres deberes. Deber número uno: mantener el teatro a salvo de vándalos. Hmm… probablemente pueda encargarme de eso."


translate spanish start_3d379df2_1:


    "Deber número dos: limpiar el teatro. Técnicamente eso está fuera del trabajo de un guardia de seguridad, pero da igual mientras paguen."


translate spanish start_7d1d2bbf_1:


    "Deber número tres: asegurarse de que ninguna marioneta esté desaparecida y caminando por ahí."


translate spanish start_5f9b772e_1:


    "…."


translate spanish start_2e251073_1:


    "Hmm. Tal vez llevo tanto tiempo sin dormir que lo leí mal."


translate spanish start_51aac7de_1:


    "Asegurarse de que ninguna marioneta esté desaparecida… y caminando por ahí."


translate spanish start_0ec8e943_1:


    "E–espera. ¿Caminando?? ¿Asegurarme de que no haya marionetas caminando?? ¿¡Qué significa eso!?"


translate spanish start_f403a2a7_1:


    "Jajaja… tal vez querían decir asegurarse de que nadie robe las marionetas. Sí. Tiene que ser eso. Quien haya escrito esto debe estar bromeando."


translate spanish start_c3d87f84_1:


    "Muy bien entonces. Hagámoslo."


translate spanish start_715f3a0c_1:


    "Aquí está… después de tanto tiempo, por fin conseguí un trabajo."


translate spanish start_af32477a_1:


    "Curiosamente, este trabajo no requirió una entrevista."


translate spanish start_5879a4bf_1:


    "Cuando los contacté ayer, todo se resolvió casi de inmediato."


translate spanish start_ab106452_1:


    "Casi pensé que era una estafa, pero por suerte no lo era."


translate spanish start_e097aece_1:


    "Bien. Tengo tres tareas. Primero, mantener el lugar a salvo de vándalos. Afortunadamente, no ha habido señales de problemas hasta ahora."


translate spanish start_bdaa902b_1:


    "Eso solo deja limpiar el teatro y asegurarme de que todas las marionetas estén presentes."


translate spanish rest_56ca1470_1:


    "Regreso directamente a mi habitación y le informo al jefe."


translate spanish rest_8ab3cee1_1:


    "Todas mis tareas están terminadas. Ahora lo único que queda es hacer guardia."


translate spanish rest_28cb0594_1:


    "Ser guardia de seguridad no parece tan malo. Me pagan solo por vigilar."


translate spanish rest_2c46a105_1:


    "El pago no es excelente, pero es mejor que nada."


translate spanish rest_27e93ae7_1:


    u "¿Qué debería hacer mientras estoy de guardia…?"


translate spanish rest_ebe1d624_1:


    u "Estoy que no doy más… pero no puedo permitirme dormir."


translate spanish rest_945d4661_1:


    "Saco mi teléfono y empiezo a navegar por internet."


translate spanish rest_b8f03606_1:


    "Mi conocimiento sobre este teatro sigue siendo bastante limitado y mi curiosidad puede más que yo, así que decido buscar información en línea."


translate spanish rest_991d8857_1:


    "Kingdom of Marionettes. Un teatro de marionetas que cuenta la historia de la vida cotidiana de marionetas en un reino."


translate spanish rest_4a83d812_1:


    "Con razón las marionetas que vi antes estaban vestidas con trajes de una época real."


translate spanish rest_ca8ea766_1:


    "Kingdom of Marionettes era conocido por sus presentaciones divertidas y fascinantes, realzadas por los encantadores diseños de las marionetas."


translate spanish rest_c77259cb_1:


    "¿De verdad este lugar era tan famoso en ese entonces? Incluso vendían mercancía y todo tipo de cosas."


translate spanish rest_bb8e8b8a_1:


    "Incluso había una encuesta de personajes favoritos. Eso es bastante tierno."


translate spanish rest_9ddf8fdc_1:


    "El primer lugar fue para el bufón. A la gente realmente le gustan los personajes raros, ¿eh?"


translate spanish rest_e0d2acba_1:


    "El segundo lugar fue el caballero, y el tercero el mago."


translate spanish rest_5d396cc2_1:


    "Toda esta información sobre el teatro me atrapa por completo y, antes de darme cuenta, llevo media hora desplazándome."


translate spanish rest_6da0153b_1:


    u "Oh, mierda. Necesito revisar el CCTV."


translate spanish performance_2e984f22_1:


    jespuppet "Mmmm…"


translate spanish performance_52c6096a_1:


    "Entonces la marioneta chasquea los dedos, y en un instante, desaparece de frente a mí."


translate spanish performance_32ef791c_1:


    "E–¿qué…? ¿A dónde fue ahora??"


translate spanish performance_28c03380_1:


    jespuppet "Una mano tan pequeña y suave… como algodón… coooomo la patita de un gatito."


translate spanish performance_92e087b5_1:


    "Acaricia mi brazo suavemente con su mano de marioneta."


translate spanish performance_14d553fd_1:


    jespuppet "Una forma tan pequeña… tan fácilmente quebradiza… y aun así llena de calidez y movimiento…"


translate spanish performance_854a6ec0_1:


    jespuppet "Un recipiente que reacciona, tiembla y cambia de una forma tan hermosa…"


translate spanish performance_49562cdd_1:


    jespuppet "Y ese rostro… siempre cambiando, siempre contando historias sin siquiera proponérselo…"


translate spanish performance_0fd4d656_2:


    "……"


translate spanish performance_2fa81cee_1:


    "¿¿¿Me está… examinando???"


translate spanish performance_bccc696a_1:


    jespuppet "Realmente eres huuuumano"


translate spanish performance_69941a63_1:


    u "S–sí… soy humano…"


translate spanish performance_8f13a297_1:


    "Respondo con una voz nerviosa, cargada de miedo."


translate spanish performance_269b7f47_1:


    jespuppet "Pasaron segundos… luego horas… días… semanas… meses… años…"


translate spanish performance_b886c43e_1:


    jespuppet "Ha pasado tanto tiempo desde que todo aquello se desvaneció."


translate spanish performance_e9ca8105_1:


    jespuppet "Un reino que alguna vez fue tan animado, tan magnífico, tan lleno de alegría… ahora ha sido reducido al silencio."


translate spanish performance_815c1411_1:


    jespuppet "Un reino que alguna vez fue liderado por un gobernante, alguien que nos guiaba a todos hacia nuestro propósito, hacia nuestras vidas, ahora ha desaparecido."


translate spanish performance_71afbde2_1:


    jespuppet "Como aves jóvenes abandonadas por su progenitor antes de estar listas para volar, fuimos dejados a merced de la confusión… del desespero…"


translate spanish performance_be92aa84_1:


    jespuppet "Nos movemos sin dirección ni destino, sin saber a dónde estamos destinados a ir…"


translate spanish performance_20a833f9_1:


    jespuppet "Y aun así… creemos. Que algún día… una nueva luz aparecerá para guiarnos."


translate spanish performance_8e276719_1:


    jespuppet "Un líder que nos dará vida una vez más y nos conducirá hacia las vidas que siempre estuvimos destinados a vivir…"


translate spanish performance_906a604e_1:


    jespuppet "Esperamos… y tuvimos esperanza. Esperamos… y esperamos. Una y otra vez, hasta que ambas cosas se volvieron indistinguibles, como si nunca hubieran debido separarse."


translate spanish performance_7db42dc6_1:


    jespuppet "Y así, ese círculo perduró. Se mantuvo a través del paso del tiempo… hasta ahora. Haaasta este mismo día, que silenciosamente se atreve a llamarse a sí mismo un punto de inflexión."


translate spanish performance_347fdeee_1:


    jespuppet "¿Continuará este círculo su suave y despiadada danza, inquebrantable, inmutable?"


translate spanish performance_fcf1079e_1:


    jespuppet "¿O finalmente comenzará a agrietarse… a fracturarse… y por fin romperse, otorgándonos liberación del ciclo al que llamamos vida?"


translate spanish performance_0fd4d656_3:


    "……"


translate spanish performance_1084310d_1:


    "Eh… ¿de qué está hablando tan de repente? No entiendo. ¿Me está contando un cuento de hadas?"


translate spanish performance_461954a5_1:


    jespuppet "Un reino… un lugar nunca ajeno a la política, un dominio impregnado de tensión, donde la seriedad acecha bajo su lujosa y brillante superficie."


translate spanish performance_2c4d81b0_1:


    jespuppet "Como el hielo, amargamente frío, requiere al menos un poco de calidez. No… quizás la mitad de esa calidez para mantener su equilibrio."


translate spanish performance_1e2492ef_1:


    jespuppet "Y es precisamente por eso que estoy aquí. Para suavizar el ambiente, para brindar risas, para llevar alegría dondequiera que esta se desvanezca."


translate spanish performance_cad34bcc_1:


    jespuppet "Ahora… ¿puedes adivinar quién soy?"


translate spanish performance_092283e8_1:


    "E–Esta persona… no, esta marioneta… parece disfrutar mucho hablar…"


translate spanish performance_a4075a92_1:


    u "Eh… ¿eres un… bufón?"


translate spanish performance_3310f055_1:


    jespuppet "¡Ding, ding, ding! ¡Correcto!"


translate spanish performance_1a52fa9d_1:


    jes "Aunque, para ser precisos, bufón es solo mi rol. Permíteme presentarme apropiadamente ante ti, dulce human[poss!t]. Mi nombre es Jestyn. Puedes llamarme Jestyn."


translate spanish performance_446cde29_1:


    jes "Aunque algunos prefieren Jes, Jesy, Tyn-Tyn y muchas otras variaciones, me temo."


translate spanish performance_ad2cd72e_1:


    jes "Ahora que te he ofrecido mi nombre, permíteme, solo esta vez, pedir el tuyo a cambio."


translate spanish performance_9051201a_1:


    jes "[player_call]… qué nombre tan encantador para un alma tan encantadora."


translate spanish performance_5b8aa077_1:


    jes "¿Y cuál es tu pronombre?"


translate spanish performance_09cd3e7f_1:


    jes "Entendido."


translate spanish performance_fa21c7df_1:


    jes "Pero dime… ¿Qué te trae a este reino, me pregunto? ¿Acaso estás cumpliendo un deber para la corona?"


translate spanish performance_48d18b2c_1:


    "Sigue refiriéndose a este teatro como un reino. Está empezando a confundirme."


translate spanish performance_f7ef9773_1:


    "Además, la forma en que habla es realmente extraña."


translate spanish performance_3bd8f634_1:


    "Pero… da igual. Seguiré el juego por ahora. Solo quiero salir de aquí lo antes posible."


translate spanish performance_664a72de_1:


    mc "Y–yo solo soy guardia de seguridad. Mi trabajo es vigilar este teatro… y hacer un poco de limpieza de paso."


translate spanish performance_a175816a_1:


    "Espero que mi respuesta lo satisfaga."


translate spanish performance_33c8f8bd_1:


    "Pero de repente, empieza a reír, y no tengo idea de por qué. ¿De verdad mi respuesta le resulta tan graciosa?"


translate spanish performance_20da2bb0_1:


    jes "Ah… ¿un guardián, dices? Qué nooooble vocación. Un protector del reino, alguien que se mantiene firme, luchando hasta la última gota de sangre."


translate spanish performance_d8bc5de1_1:


    jes "Y sin embargo… lamentablemente, no puedes convertirte en un guardián aquí."


translate spanish performance_519eacf2_1:


    mc "¿Q–qué quieres decir?"


translate spanish performance_90c9f9b2_1:


    jes "Verás, ya tenemos a un caballero que sirve como el escudo de este reino. Su nombre es Knighter. Y no tenemos intención de aceptar a otro."


translate spanish performance_34356624_1:


    jes "Un caballero es más que suficiente."


translate spanish performance_d8a0138b_1:


    "¿Está… hablando de los roles en este teatro?"


translate spanish performance_e985e405_1:


    mc "Oh… entonces supongo que solo seré un limpiador…"


translate spanish performance_8a9f02b8_1:


    jes "Ya tenemos suficientes doncellas aquí, y no creo que sea posible añadir otra."


translate spanish performance_4cfdcb02_1:


    mc "Muy bien entonces. Supongo que simplemente no seré nadie."


translate spanish performance_4d4e6485_1:


    jes "Oh no, no… todo aquel que llega aquí debe tener su propio rol."


translate spanish performance_f0711c5e_1:


    jes "Y el rol que actualmente está vacante… es el del rey, la reina, el gobernante del reino."


translate spanish performance_f9ed36da_1:


    mc "E–está bien… eh… pero ¿por qué solo está vacío el puesto de rey?? ¿Qué pasó con el rey anterior?"


translate spanish performance_dc20a6b6_1:


    "Cuando revisé las marionetas antes, había una habitación etiquetada como 'The King'. Así que la marioneta rey debió haber existido."


translate spanish performance_b2b283fa_1:


    jes "Lamentablemente, falleció."


translate spanish performance_ce801f57_1:


    mc "Oh… lo siento. Mis condolencias."


translate spanish performance_2f036b9a_1:


    jes "Está bien, mi querid[poss!t]. Así es simplemente la vida. La gente va y viiiiene. Es parte de un ciclo del que no puedes escapar. Creo que los humanos entienden muy bien eso."


translate spanish performance_5bf47951_1:


    "Luego aplaudió."


translate spanish performance_d94e3c51_1:


    jes "Ha pasado mucho tiempo desde que el rey falleció. Este reino se ha vuelto terriblemente oscuro… lleno de silencio, sin dirección ni alegría."


translate spanish performance_1f957725_1:


    jes "Y debo admitir… se ha vuelto bastante aburrido aquí."


translate spanish performance_c6da68e6_1:


    jes "Pero ahora que he conocido a un humano tan dulce frente a mí, ¿por qué no me concedes un pequeño juego, Su Majestad?"


translate spanish performance_6c977b5a_1:


    mc "….. ¿Su Majestad? ¿yo?"


translate spanish performance_e6d429b2_1:


    "Su sonrisa se ensanchó."


translate spanish performance_9bc84d96_1:


    jes "Sí. Juguemos un poco a actuar. Tú fingirás ser [obj!t] [title!t], y yo… seré tu bufón."


translate spanish performance_fc5d52a4_1:


    jes "Oh, perdóname. He sido un bufón desde el principio. Qué torpe de mi parte."


translate spanish performance_91abef26_1:


    "Jestyn chasqueó los dedos y, antes de darme cuenta, se había movido al escenario."


translate spanish performance_1a9aa838_1:


    jes "Ahora bien… ¿permitimos que la función comience?"


translate spanish performance_98e1e946_1:


    mc "E–espera, ¡espera! ¡Nunca he actuado antes! ¡Ni siquiera sé cómo—"


translate spanish performance_f38844b3_1:


    jes "Oh no, mi querid[poss!t]… Simplemente vive, como si siempre hubieras sido el gobernante de este reino."


translate spanish performance_e84b7420_1:


    "Jestyn volvió a chasquear los dedos."


translate spanish performance_5afda8b6_1:


    "Y en un instante, me encontré ya en el escenario, sentad[poss!t] en un lujoso trono, con una corona descansando sobre mi cabeza."


translate spanish performance_bf5bf7f9_1:


    mc "¿Qu–qué?!"


translate spanish performance_88a957a0_1:


    nara "{color=#E0AE4B}Un día, bajo el abrasador sol del verano, el reino fue golpeado por problemas una vez más. Los granjeros estaban llenos de tristeza mientras el implacable calor del verano quemaba la tierra.{/color}"


translate spanish performance_51554ab9_1:


    nara "{color=#E0AE4B}Los cultivos se marchitaron y fracasaron bajo la sequía, dejando los campos estériles. Como resultado, los granjeros sufrieron grandes pérdidas, sin cosecha que vender.{/color}"


translate spanish performance_8364a461_1:


    nara "{color=#E0AE4B}Al final, los granjeros llevaron su situación ante Su Majestad, con la esperanza de que [subj!t] les brindara ayuda y alivio.{/color}"


translate spanish performance_c231e200_1:


    "Miré a mi alrededor, intentando encontrar la fuente de la voz que sonaba como un narrador."


translate spanish performance_6aa45380_1:


    nara "{color=#E0AE4B}Dentro del reino, Su Majestad se encontraba sentad[poss!t] en su trono, con su expresión nublada por la confusión, cuando Jestyn, el bufón real, apareció ante [subj!t] para transmitir los problemas que enfrentaban los granjeros{/color}"


translate spanish performance_01422283_1:


    jes "Buenas noches, Su Majestad."


translate spanish performance_a64afe78_1:


    "Jestyn apareció y se inclinó ante mí con la mayor reverencia."


translate spanish performance_e9042124_1:


    jes "Qué día taaaan verdaderamente hermoso es hoy."


translate spanish performance_af5db24b_1:


    jes "Un día igualmente adecuado para atender los pequeños problemas que surgen dentro del reino… ¿no está de acuerdo, Su Majestad?"


translate spanish performance_f95a4fa4_1:


    mc "¿Problemas… en el reino?"


translate spanish performance_4874d63f_1:


    jes "En efecto, Su Majestad."


translate spanish performance_f9c09460_1:


    jes "Últimamente, los habitantes del pueblo han comenzado a expresar sus preocupaciones. Las cosechas han fracasado, abatidas por la implacable sequía de la estación seca."


translate spanish performance_05d74c2d_1:


    jes "Y como era de esperarse, tal infortunio los ha dejado… bastante faltos de recursos."


translate spanish performance_9f21f0aa_1:


    jes "Por favor, pase, querido invitado."


translate spanish performance_d534aa3a_1:


    nara "{color=#E0AE4B}Un hombre que trabajaba como granjero entró entonces, después de que Jestyn le concediera permiso para pasar.{/color}"


translate spanish performance_e943668d_1:


    "De repente, una marioneta vestida como granjero dio un paso al frente y se arrodilló ante mí."


translate spanish performance_b64f7501_1:


    farm "Saludos, Su Majestad. Por favor, perdone mi atrevimiento, pero venimos ante usted para solicitar humildemente su ayuda."


translate spanish performance_9ae10a62_1:


    farm "Debido al fracaso de las cosechas, ya no tenemos los medios para reemplazar los cultivos que se marchitaron, ni contamos con fondos para cubrir nuestras necesidades diarias…"


translate spanish performance_9d72adad_1:


    farm "Por lo tanto, le suplicamos… que nos brinde su guía."


translate spanish performance_972b6338_1:


    "Al haber sido arrastrado al papel de [obj!t] [title!t] sin previo aviso, la confusión me invadió."


translate spanish performance_595efd78_1:


    "Mis propios problemas estaban lejos de resolverse, ¡y ahora se esperaba que encontrara una manera de salvar también a los granjeros!"


translate spanish performance_ec04fee4_1:


    mc "E–eh…"


translate spanish performance_15a64d5d_1:


    "¿Qué se supone que debo hacer…?"


translate spanish problem2_e3bea3c4_1:


    mc "….. ¿Ya terminó?"


translate spanish problem2_70f8e564_1:


    jes "¿Terminó?"


translate spanish problem2_fb4c14c0_1:


    jes "Si gobernar un reino fuera tan sencillo, Su Majestad, me temo que tendríamos muchas menos reinas."


translate spanish problem2_4e766586_1:


    "Aún hay más…"


translate spanish problem2_a7674f73_1:


    nara "{color=#E0AE4B}El día transcurrió lentamente dentro del reino. Y sin que Su Majestad lo notara, el tiempo que una vez marcaba las nueve de la mañana ya había avanzado hasta la una de la tarde.{/color}"


translate spanish problem2_a95fab49_1:


    nara "{color=#E0AE4B}En ese preciso momento, una carta formal de otro reino llegó repentinamente.{/color}"


translate spanish problem2_a5e90a9f_1:


    nara "{color=#E0AE4B}Al enterarse de esto, el mayordomo tomó rápidamente la carta y se dispuso a entregársela a Su Majestad.{/color}"


translate spanish problem2_007b68af_1:


    "De repente, una marioneta vestida de mayordomo se acercó a Jestyn y le entregó un pergamino."


translate spanish problem2_9ad1e23c_1:


    "Jestyn lo leyó por un momento. Su expresión se volvió concentrada, antes de que sus ojos se dirigieran hacia mí y esa amplia sonrisa regresara a su rostro."


translate spanish problem2_65c94ba0_1:


    jes "Su Majestad, hemos recibido una solicitud sumamente asombrosa y bastante intrigante de un reino vecino."


translate spanish problem2_33b6191e_1:


    "Todo está escrito aquí, en tinta, sobre este pergamino."


translate spanish problem2_ebec001e_1:


    jes "En resumen, desean comprar una pequeña porción de tierra a lo largo de nuestra frontera, bajo el pretexto de facilitar el comercio."


translate spanish problem2_e32448da_1:


    jes "Si Su Majestad acepta este acuerdo, están preparados para ofrecer una compensación en monedas de oro. Una cantidad que estoy bastante seguro haría que Su Majestad sufriera un infarto en el acto~"


translate spanish problem2_f70a91f0_1:


    jes "Entonces… ¿qué hará, Su Majestad?"


translate spanish problem2_445e6ea5_1:


    "Oh no… esto está empezando a sonar complicado. ¿Qué debería hacer?"


translate spanish after_acting_372cd5aa_1:


    jes "Muy bien entonces. Informaré a nuestros vecinos de la voluntad de Su Majestad."


translate spanish after_acting_661a8003_1:


    jes "Y creo que, por ahora, los asuntos que Su Majestad debía resolver han llegado al final del programa de hoy."


translate spanish after_acting_917307e9_1:


    jes "Puede descansar ahora, Su Majestad~"


translate spanish after_acting_093871f9_1:


    "Por fin… termina. No sé si mi cerebro puede soportar más cosas de reino."


translate spanish after_acting_e6132cd8_1:


    "Antes de poder relajarme finalmente, mi teléfono sonó."


translate spanish after_acting_7578997d_1:


    "Oh no… tiene que ser el cobrador de deudas."


translate spanish after_acting_acb0e640_1:


    "De verdad no quiero lidiar con esto ahora mismo. No tengo el dinero para pagar."


translate spanish after_acting_21ad1c53_1:


    "Pero realmente no tengo elección…"


translate spanish after_acting_4e85cb4d_1:


    mc "¿Hola?"


translate spanish after_acting_83e04508_1:


    debt "[player_call] ¡Sabes por qué te estoy llamando, verdad?"


translate spanish after_acting_5a64fdcd_1:


    mc "Claro…"


translate spanish after_acting_d0d55219_1:


    debt "¿Entonces?"


translate spanish after_acting_fe5086ae_1:


    mc "Lo siento… no puedo pagarlo ahora mismo."


translate spanish after_acting_18aa1915_1:


    mc "Pero acabo de conseguir un trabajo otra vez. Solo necesitas esperar hasta el día de pago."


translate spanish after_acting_7c7d602e_1:


    debt "Haaah… está bien. Pero recuerda, ya has retrasado esto por cinco meses."


translate spanish after_acting_cc837eb4_1:


    mc "Lo sé… lo sé… gracias por tu comprensión…"


translate spanish after_acting_17c0a825_1:


    "Momentos después de terminar la llamada, apoyé mi cuerpo contra el asiento, necesitando un breve descanso."


translate spanish after_acting_3345f35d_1:


    "Tengo que pagarlo en un mes…"


translate spanish after_acting_a63b6d6b_1:


    "Pasé mis dedos por mi cabello con frustración, antes de recordar que Jestyn aún estaba frente a mí."


translate spanish after_acting_9e566277_1:


    mc "Oh— lo siento, Jestyn. Eso era solo un asunto personal—"


translate spanish after_acting_4dda5812_1:


    "De repente, la mano de Jestyn se cerró suavemente sobre mi hombro. Me miró con esa amplia sonrisa suya."


translate spanish after_acting_a32261d7_1:


    jes "Su Majestad, sus asuntos personales son asuntos del reino."


translate spanish after_acting_d24de394_1:


    jes "Y eso los convierte en mi preocupación también, como bufón del reino."


translate spanish after_acting_be56e838_1:


    jes "Por lo que observé en su conversación a través de esa tecnología hace un momento, parece que Su Majestad está en deuda… con otro reino, ¿estoy en lo correcto?"


translate spanish after_acting_2b35b6fe_1:


    mc "…"


translate spanish after_acting_07f99d29_1:


    mc "Sí…"


translate spanish after_acting_fbbe8638_1:


    "Su mano sobre mi hombro amasó suavemente la tensión. Al instante, sentí cómo me relajaba."


translate spanish after_acting_3a4a6a82_1:


    jes "Puede contarme sus problemas, Su Majestad."


translate spanish after_acting_ddf56c7b_1:


    jes "Después de todo, soy su bufón más leal… y el único…"


translate spanish after_acting_0fd4d656_1:


    "……"


translate spanish after_acting_0acac695_1:


    mc "… He estado pensando en las finanzas del reino durante mucho tiempo. Han estado disminuyendo cada vez más."


translate spanish after_acting_164f9f77_1:


    jes "Oh, vaya~"


translate spanish after_acting_e0fe2d11_1:


    mc "Sí… en aquel entonces yo… podrías decir que formé una especie de amistad con el gobernante de otro reino."


translate spanish after_acting_2ea7ab35_1:


    mc "Ese reino necesitaba ayuda porque enfrentaban un problema similar."


translate spanish after_acting_eea581d9_1:


    mc "Pero al final, ese reino solo me estaba utilizando y luego me traicionaron."


translate spanish after_acting_45f2d9f0_1:


    mc "Así que… tuve que pedir prestados fondos a otros reinos. Y ahora… nuestro reino está cargado con una deuda considerable."


translate spanish after_acting_a9d7652c_1:


    mc "He estado tratando de encontrar otras fuentes de ingresos solo para mantener la estabilidad."


translate spanish after_acting_f35ef482_1:


    "Después de explicar todos mis problemas llenos de metáforas, Jestyn no dijo nada por un momento."


translate spanish after_acting_3d1a6ef7_1:


    "El silencio envolvió el aire entre nosotros."


translate spanish after_acting_ed5ba8b5_1:


    jes "¿Sabe por qué el león es honrado como el rey del bosque, Su Majestad?"


translate spanish after_acting_d1dd8d04_1:


    "Por un segundo, me sentí confundido por su repentina pregunta sobre el león."


translate spanish after_acting_5fe678b3_1:


    mc "Eh… ¿porque son majestuosos?"


translate spanish after_acting_ff7db947_1:


    jes "En efecto. Son majestuosos. Son temibles. Son resilientes, depredadores ápice, situados en la cima."


translate spanish after_acting_8a60221d_1:


    jes "Ahora, imagine un conejo. ¿Por qué el conejo nunca es llamado el rey del bosque?"


translate spanish after_acting_732e8b36_1:


    mc "Porque… ¿los conejos son demasiado gentiles? ¿Pequeños? ¿No lo suficientemente intimidantes?"


translate spanish after_acting_7f9f0b7b_1:


    jes "Gentiles."


translate spanish after_acting_26030657_1:


    jes "Demasiado indecisos… y, ah, trágicamente humanos."


translate spanish after_acting_0c515d6e_1:


    jes "Y lo más importante… confían en los demás con demasiada facilidad."


translate spanish after_acting_ed23a5fd_1:


    jes "Cualidades muy nobles… para un alma sufriente. No tanto para [obj!t] [title!t]."


translate spanish after_acting_2669f073_1:


    jes "Pensaste que al ayudar a otros, ellos te querrían. Que te sonreirían, estarían a tu lado y te llamarían amigo."


translate spanish after_acting_12293362_1:


    jes "¡Y luego BOOM! ¡Qué sorpresa tan encantadora! ¡Has sido engañad[poss!t]! ¡Estafad[poss!t]! ¡Tocad[poss!t] como una dulce melodía! ¡Jajajajajajaja!"


translate spanish after_acting_b3646884_1:


    "Se rió de forma maniaca."


translate spanish after_acting_b62ffb44_1:


    jes "¿No es perfectamente irónico?"


translate spanish after_acting_0fc512df_1:


    "Jestyn habló con una sonrisa, cada risa delicada y educada… pero cada palabra se sentía como una afilada hoja presionada contra mi pecho."


translate spanish after_acting_3c32a577_1:


    "Una vez leí que la tarea de un bufón en un reino… es entretener. Y parte de eso… es revelar la verdad a través de la burla."


translate spanish funny_8d463535_1:


    "Ya lo veo. Sí… debo seguir el juego."


translate spanish funny_f004a6f1_1:


    mc "¡Jajajaja! No estás… equivocado, Jestyn."


translate spanish annoying_444727e3_1:


    "Pero la forma en que dijo eso…"


translate spanish annoying_8ea1f22a_1:


    "Sus palabras atravesaban mi corazón de manera letal."


translate spanish annoying_b7842494_1:


    "No voy a mentir, eso es muy molesto."


translate spanish advice_14e3cae9_1:


    jes "Verá, Su Majestad, las reglas de este mundo no son un dulce cuento donde la bondad siempre es recompensada con bondad. Creo que ya lo sabe."


translate spanish advice_aceede3e_1:


    jes "A veces el juego es mucho más simple que eso. A veces, la regla es simplemente devorar… o ser devorado."


translate spanish advice_5a4a31da_1:


    mc "¿Quiere decir que debería convertirme en un león?"


translate spanish advice_b805fab8_1:


    jes "Oh no, no, Su Majestad. Eso no será necesario. ¿Por qué? La expresión en su rostro, tan privada de sueño, ya es bastante aterradora."


translate spanish advice_520b089f_1:


    "Se ríe burlonamente mientras me observa fruncir el ceño."


translate spanish advice_1b24106c_1:


    jes "Jeje, perdóneme, Su Majestad. Solo estaba bromeando. No le estoy diciendo que se convierta en un león."


translate spanish advice_f2e1bab4_1:


    jes "¿Alguna vez ha considerado… combinar un conejo y un león?"


translate spanish advice_b8a4300d_1:


    mc "Eh… ¿no se vería como una especie de mutante?"


translate spanish advice_b39d6b88_1:


    jes "No ese tipo de combinación, Su Majestad…"


translate spanish advice_f34bf4fe_1:


    "Hace un ligero gesto con el dedo."


translate spanish advice_ca0b66f8_1:


    jes "La apariencia de un conejo, pero el corazón de un león. Como un lobo bajo piel de oveja, si me pregunta."


translate spanish advice_16187254_1:


    "Hace una pausa."


translate spanish advice_54063081_1:


    jes "Y además… confíe solo en aquellos a su alrededor a quienes realmente conoce."


translate spanish advice_df231ede_1:


    jes "Aquellos que permanecerán leales a ti, pase lo que pase. ¿Difícil? Sí. Pero esa es simplemente la verdad."


translate spanish advice_6a7308d5_1:


    jes "Y después de eso… quizá aquellos leales a ti incluso te ayuden a destruir a quienes te han hecho daño."


translate spanish advice_e2419ffb_1:


    jes "{color=#FF2727}Solo por ti.{/color}"


translate spanish advice_47adc674_1:


    jes "Entiendes lo que quiero decir, ¿no es así, Su Majestad?"


translate spanish advice_2f85c766_1:


    "Sus palabras me dejan perdido en mis pensamientos."


translate spanish advice_d8581df8_1:


    "Ahora que lo pienso… realmente soy alguien que busca complacer a los demás."


translate spanish advice_3cc35a6d_1:


    mc "Lo entiendo… pero cambiar eso no es fácil."


translate spanish advice_e13b0076_1:


    "Jestyn deja escapar una suave risa. Sus ojos se entrecierran mientras su sonrisa se ensancha lentamente."


translate spanish advice_bab18eb3_1:


    jes "Muy cierto, Su Majestad… y es precisamente por eso."


translate spanish advice_64883bc1_1:


    jes "Tal vez, en lugar de preguntarte qué más puedes dar… deberías preguntarte qué es lo que aún te niegas a tomar."


translate spanish advice_891258a4_1:


    "Jestyn se aleja de mí, dándome espacio para reflexionar sobre el significado de sus palabras."


translate spanish advice_4c28949b_1:


    "Sus palabras siempre son difíciles de entender…"


translate spanish advice_9e9daed2_1:


    "Aplaude, sacándome de mis pensamientos."


translate spanish advice_f3ef196f_1:


    jes "Ahora… permítame presentarle un entretenimiento. Debe estar cansad[poss!t] de trabajar todo el día, ¿verdad, Su Majestad?"


translate spanish advice_62999dc6_1:


    jes "Por mucho que adore esa expresión suya, como un murciélago despertado a plena luz del día, preferiría no verlo siempre con un rostro tan completamente carente de alegría…"


translate spanish advice_3bdcf7c5_1:


    "Se ríe suavemente. A mí me deja con muy poco de qué reír."


translate spanish advice_1d738662_1:


    jes "Haré que sonría una vez más. Derritiendo el frío de su vida con el fuego del deleite que traigo."


translate spanish advice_767cd509_1:


    jes "Permítame~"


translate spanish advice_1d7cf93b_1:


    "Jestyn chasquea los dedos. En un instante, algo aparece en sus manos."


translate spanish advice_0a0d80da_1:


    "Era un pequeño objeto rectangular, envuelto en una capa dorada y atado cuidadosamente con una cinta roja."


translate spanish advice_def0ad19_1:


    mc "¿Qué es?"


translate spanish advice_31a87d5e_1:


    "Jestyn me lo entrega, permitiéndome abrirlo yo mismo."


translate spanish advice_eabac4e2_1:


    mc "¿Chocolate?"


translate spanish advice_f033135f_1:


    jes "En efecto, Su Majestad. A todo el mundo le gusta el chocolate. ¿A quién no? Así que espero que le guste."


translate spanish advice_4cd27f3c_1:


    jes "Y no es un chocolate cualquiera."


translate spanish advice_f7a516c1_1:


    jes "Elaboré cada paso con todo mi corazón. Cuidadosamente, con delicadeza y con la mayor devoción."


translate spanish advice_d916d371_1:


    jes "Así que espero que saboree mi chocolate hecho a mano y no olvide el color de su envoltura, Su Majestad~"


translate spanish eatchocolate_3697085d_1:


    "Bueno… ya que me lo había dado, no podía rechazarlo. No tenía corazón para hacerlo."


translate spanish eatchocolate_ba8cabbe_1:


    "Partí un trozo del chocolate y lo llevé a mi boca."


translate spanish eatchocolate_f185d9cc_1:


    "En el momento en que tocó mi lengua, pude sentir cómo se derretía."


translate spanish eatchocolate_cd55feb8_1:


    "Pero al mismo tiempo, vi cómo la sonrisa de Jestyn se afilaba y fue entonces cuando lo sentí."


translate spanish eatchocolate_4b1aad94_1:


    mc "¡Ugh—?!"


translate spanish eatchocolate_a8c586c7_1:


    "Una sensación ardiente se extendió por mi lengua."


translate spanish eatchocolate_69ebc829_1:


    jes "Oh, cielos… parece que alguien olvidó el color de la envoltura~"


translate spanish eatchocolate_8f5595d0_1:


    "Jestyn soltó una risa suave al ver mi rostro enrojecer por el calor."


translate spanish eatchocolate_90893ba6_1:


    mc "¿Q–qué clase de chocolate es este?!"


translate spanish eatchocolate_44960690_1:


    jes "Jeje. Es chocolate, por supuesto. Pero encuentro los ingredientes habituales bastante aburridos. Nada nuevo. Qué tedioso."


translate spanish eatchocolate_70eaca9d_1:


    jes "¡Y entonces! Se me ocurrió una idea brillante. ¿Por qué no añadir algo nuevo a la receta?"


translate spanish eatchocolate_2f9e35fe_1:


    jes "Así que le añadí chile en polvo."


translate spanish eatchocolate_9bbcefec_1:


    "Lo miré, completamente sin palabras. ¿¡Qué clase de lógica es esa!?"


translate spanish eatchocolate_e9a00209_1:


    jes "Pobrecito, Su Majestad. Pero esa expresión suya, tan alterada y enrojecida, es simplemente adorable."


translate spanish eatchocolate_0e55d190_1:


    "Jestyn me entregó entonces un vaso de agua para beber."


translate spanish eatchocolate_0534be04_1:


    "¿Cómo caí en su broma tan fácilmente?"


translate spanish donteat_5d8ce5a8_1:


    "Miré el chocolate por un momento."


translate spanish donteat_0260f83c_1:


    "No quería rechazar el regalo de alguien… pero mis instintos me decían que algo no estaba bien."


translate spanish donteat_278c7e29_1:


    "………"


translate spanish donteat_17f2ebd7_1:


    mc "¿Jestyn?"


translate spanish donteat_32797f5c_1:


    jes "Sí, Su Majestad?"


translate spanish donteat_098db61c_1:


    mc "Esto no es un chocolate normal, ¿verdad?"


translate spanish donteat_9809117e_1:


    "Su sonrisa no se desvaneció en lo más mínimo mientras me miraba."


translate spanish donteat_77c8fcdd_1:


    jes "¿Oh? ¿Y qué le hace decir eso, Su Majestad?"


translate spanish donteat_c9725607_1:


    jes "Ah… para ser honesto, me duele que me acuse así. Le di ese chocolate con sinceridad."


translate spanish donteat_90b3aaad_1:


    "Su sonrisa se desvaneció lentamente, reemplazada por la expresión de alguien profundamente herido."


translate spanish donteat2_95213de5_1:


    mc "No me mientas."


translate spanish donteat2_8b2d262f_1:


    mc "Hay algo en este chocolate, ¿no es así? No voy a caer."


translate spanish donteat2_3f2af826_1:


    jes "….."


translate spanish donteat2_68fc2657_1:


    jes "Pfft… khuhu…"


translate spanish donteat2_7a0c2c91_1:


    "Jestyn dejó escapar una suave risa. Y con eso, todo quedó demostrado."


translate spanish donteat2_f6bbaa0f_1:


    jes "Jejeje… ¡ahahahahaha!"


translate spanish donteat2_f62305b9_1:


    jes "Ahh… así que alguien no olvidó el color de la envoltura después de todo."


translate spanish donteat2_52551e79_1:


    jes "Eres más perspicaz de lo que pareces, Su Majestad…"


translate spanish donteat2_79b789ab_1:


    jes "Sí. Le añadí algo al chocolate."


translate spanish donteat2_1df16ba6_1:


    "Dejé caer el chocolate al suelo."


translate spanish donteat2_6f68c9a6_1:


    mc "E–entonces ¿qué le pusiste?! ¡No me digas que es veneno! ¿¡Estás tratando de matarme!?"


translate spanish donteat2_e05a60ec_1:


    jes "¿Veneno?! ¡AHAHAHAHAHAHA!"


translate spanish donteat2_96c92fd7_1:


    jes "Oh, Su Majestad, no soy tan cruel. Solo fue una broma. Y nunca haría algo tan despiadado por el bien de una broma."


translate spanish donteat2_08e2742c_1:


    jes "Es chocolate, por supuesto. Pero encuentro los ingredientes habituales bastante aburridos. Nada nuevo. Qué tedioso."


translate spanish donteat2_70eaca9d_1:


    jes "¡Y entonces! Se me ocurrió una idea brillante. ¿Por qué no añadir algo nuevo a la receta?"


translate spanish donteat2_2f9e35fe_1:


    jes "Así que le añadí chile en polvo."


translate spanish donteat2_9bbcefec_1:


    "Lo miré, completamente sin palabras. ¿¡Qué clase de lógica es esa!?"


translate spanish freakymomen_65855918_1:


    jes "Jejeje. Por favor, perdóneme, Su Majestad. Esta vez le daré un entretenimiento adecuado. Prometo que no es otra broma."


translate spanish freakymomen_9524c3a6_1:


    "Jestyn chasqueó los dedos."


translate spanish balls_ef621327_1:


    mc "… ¿pelotas?"


translate spanish balls_95449cd9_1:


    jes "Correcto."


translate spanish balls_8524ccab_1:


    "Sin esperar más, comenzó a hacer malabares con una habilidad impresionante."


translate spanish balls_d78cf6b9_1:


    "Las pelotas volaban de una mano a otra, mezcladas con algunos trucos llamativos. Era evidente que lo había hecho innumerables veces antes."


translate spanish balls_1a48c3f4_1:


    "Entonces, su mirada se dirigió hacia mí."


translate spanish balls_9f05f094_1:


    jes "¡Debe continuar con mis malabares, Su Majestad!"


translate spanish balls_3fb0e546_1:


    mc "Espera, ¿qué—?"


translate spanish balls_3f766e70_1:


    "Antes de que pudiera terminar la frase, Jestyn lanzó todas las pelotas hacia mí."


translate spanish balls_d8cf2bd5_1:


    "Por más que lo intenté, fue inútil. Las pelotas se escapaban de mis manos y golpeaban el suelo antes de que pudiera siquiera mantenerlas en el aire."


translate spanish balls_b69104d7_1:


    "Al ver mi patético intento, Jestyn estalló en carcajadas."


translate spanish balls_3ce7a169_1:


    jes "¿En serio, Su Majestad? Ni siquiera puede atraparlas, mucho menos hacer malabares."


translate spanish balls_3b768363_1:


    mc "¡Claro que no! ¡Nunca he hecho esto antes!"


translate spanish balls_32a85459_1:


    "Las pelotas rodaron por el escenario, dispersándose a mis pies."


translate spanish balls_4faa5ed5_1:


    jes "¡Ah, ah, ah! No se vea tan derrotad[poss!t] ya, Su Majestad."


translate spanish balls_da52edfd_1:


    jes "Pensé que los humanos eran bastante buenos atrapando cosas. Oportunidades, promesas, responsabilidades."


translate spanish balls_ddc21682_1:


    "Se ríe suavemente, como si acabara de decir una broma inocente."


translate spanish balls_81f3ccdb_1:


    mc "Me las lanzaste sin aviso…"


translate spanish balls_1da73b32_1:


    jes "¿Lo hice?"


translate spanish balls_42d168c2_1:


    "Inclina la cabeza, las campanillas de su gorro tintineando débilmente."


translate spanish balls_97bfd332_1:


    jes "Mis disculpas entonces. A veces olvido que no todos disfrutan de las sorpresas tanto como yo."


translate spanish balls_d7fbe90a_1:


    "Se agachó y recogió una de las pelotas caídas, haciéndola girar ligeramente sobre su palma."


translate spanish balls_7c2ed117_1:


    jes "Dígame, ¿qué cree que son los malabares, Su Majestad?"


translate spanish balls_d44ced45_1:


    mc "Eh… ¿lanzar cosas? ¿Tratar de no dejarlas caer?"


translate spanish balls_7bf63dbf_1:


    jes "Hoho… una respuesta honesta. Me gusta."


translate spanish balls_78579f7a_1:


    jes "Los malabares son equilibrio. Ritmo. Saber qué pelota atrapar primero y cuál debes permitir que caiga."


translate spanish balls_f11d3722_1:


    "Lanza la pelota al aire con naturalidad, atrapándola con facilidad."


translate spanish balls_18837d02_1:


    "Luego deja que la pelota se le escape de los dedos y golpee el escenario con un sonido seco. Después me mira nuevamente."


translate spanish home_b2dbb149_1:


    jes "Creo que su tiempo en este reino ha llegado a su fin."


translate spanish home_28fa5188_1:


    "Me confunde lo que quiere decir, pero cuando miro mi reloj, marca las 5:30 a. m."


translate spanish home_ab05c1c8_1:


    mc "Oh… mi turno ha terminado."


translate spanish home_3f1bdbf6_1:


    "Toma mi mano y besa el dorso."


translate spanish home_8079daff_1:


    "Sus labios se sienten fríos, pero la sensación envía calor recorriendo mi cuerpo hasta el corazón."


translate spanish home_42a2cc2b_1:


    jes "Entonces, hasta que nos volvamos a encontrar,"


translate spanish home_1632ba7e_1:


    jes "dulce human[poss!t]…"


translate spanish home_3cdae3c3_1:


    "Después de decir eso, Jestyn camina hacia la parte oscura del escenario y desaparece."


translate spanish home_9342fca3_1:


    "Finalmente regreso a mi pequeño y miserable apartamento."


translate spanish home_f52f2dbb_1:


    "Y lo que pasó hoy fue realmente algo…"


translate spanish home_3df4b499_1:


    "Marionetas vivientes… y siendo tratado como algún tipo de [title!t]."


translate spanish home_4e207e4e_1:


    "Qué día tan extraño. Siento que me estoy volviendo loco."


translate spanish home_5ef7297b_1:


    "¿Debería volver mañana otra vez? Toda esta situación se siente muy inquietante…"


translate spanish home_07bdde05_1:


    "….."


translate spanish home_aeb9b1ae_1:


    "… Claro que tengo que ir. Mi deuda no se va a pagar sola. Necesito el dinero. Buscar otro trabajo sería demasiado difícil para mí ahora mismo."


translate spanish home_9f059fed_1:


    "No sé qué pasará conmigo después."


translate spanish home_71178961_1:


    "Por ahora, será mejor que duerma un poco. Estoy completamente agotad[poss!t]."


translate spanish home_a20cefa7_1:


    "…"


translate spanish home_5f9b772e_1:


    "…."


translate spanish home_0fd4d656_1:


    "……"


translate spanish home_bbd50ba8_1:


    jes "Pasaron segundos… luego horas… días… semanas… meses… años…"


translate spanish home_cfeb39ac_1:


    jes "Ha pasado tanto tiempo desde que todo aquello se desvaneció."


translate spanish home_5554f270_1:


    jes "Y después de tanto tiempo… por fin te he encontrado…"


translate spanish home_d4bb94ed_1:


    jes "Mi [title!t]"


translate spanish home_4b236792_1:


    jes "Su Majestad… realmente le agradezco por hoy. Me ha hecho tan insoportablemente feliz…"


translate spanish home_d12460ef_1:


    jes "Ah… pero… volverá esta noche, ¿verdad…?"


translate spanish home_dc48b27e_1:


    jes "Claro… claro que lo hará. Aún hay tantas cosas que podemos hacer juntos. Simplemente no podría soportarlo si no viniera."


translate spanish home_77ea8a7d_1:


    jes "Le enseñaré malabares. Dijo que quería que lo hiciera, ¿verdad? Entonces le enseñaré todo. Cada truco, cada movimiento, hasta que sus manos se muevan exactamente como las mías."


translate spanish home_91c7b2d2_1:


    jes "Luego le mostraré trucos de magia… unos que prometo le robarán el aliento. Oh, y hay tantas marionetas esperando conocerle… para ser organizadas… para pertenecer donde usted desee. Y luego… y luego…"


translate spanish home_53ae36ac_1:


    jes "Podemos jugar otra vez como antes, Su Majestad. Soy su leal bufón, arrodillado ante mi amo como un sabueso devoto."


translate spanish home_c3fcfba9_1:


    jes "Oh, no tiene idea de cómo esa sensación hizo latir mi corazón… cómo me hizo sentir que le pertenecía… sí… le pertenezco a usted, [obj!t] [title!t] [player_call]"


translate spanish home_3b7654bf_1:


    jes "Podemos cenar juntos, dormir juntos, cantar juntos, bailar juntos… siempre juntos… y luego… y luego…"


translate spanish home_a1abeaae_1:


    jes "Oh, dulce acidez y crema, hay tantas cosas que podríamos hacer que apenas sé por dónde empezar… mientras nunca se aparte de mi lado."


translate spanish home_555bdd3f_1:


    jes "De verdad… ¿qué me ha hecho, Su Majestad…? Estoy empezando a creer que es un hechicero de poder aterrador. Ni siquiera Wizzy, el mago real, podría torcer un corazón de esta forma…"


translate spanish home_3523e422_1:


    jes "Siento como si hubiera caído en su telaraña… envuelto con fuerza, incapaz de escapar… simplemente esperando ser devorado por usted… y aun así… no creo querer resistirme en absoluto."


translate spanish home_067bdf0d_1:


    jes "Apenas me reconozco ya, Su Majestad… pero de alguna manera, no deseo volver atrás."


translate spanish home_86f0ef77_1:


    jes "El reino lo necesita… yo lo necesito."


translate spanish home_45e4e473_1:


    jes "No. Lo quiero… lo anhelo… Mi [title!t], [player_call]…"


translate spanish home_8e8701f7_1:


    jes "Nunca antes había sentido algo tan abrumador… quiero quedarme a su lado, observar cómo respira, grabar su imagen en mi mente, tocarle… y quizá… hundirme aún más en usted, hasta que no quede nada más que nosotros…"


translate spanish home_6ee728d3_1:


    jes "Ah— no, no, no. Qué inapropiado de mi parte. Un simple bufón tocando a su [title!t] con tanta osadía… pero si usted me diera permiso, atesoraría cada centímetro de usted con la mayor devoción."


translate spanish home_a1e6d275_1:


    jes "Oh, Mi [title!t], apenas puedo soportar la espera para verle de nuevo… desearía que el tiempo avanzara rápido… y al mismo tiempo se congelara por completo cuando estoy con usted. Si tan solo pudiera doblar el tiempo mismo. Solo para usted."


translate spanish home_d3bd5717_1:


    jes "Me retiro ahora, Mi [title!t]… que sus sueños estén llenos de mí…"


translate spanish home_6ebbd0f1_1:


    jes "[player_call]"

translate spanish strings:


    old "Cleaning up"
    new "Limpiar"


    old "Checking puppets"
    new "Revisar marionetas"


    old "All done"
    new "Todo listo"


    old "Check outer gate"
    new "Revisar puerta exterior"


    old "Check corridor 1"
    new "Revisar pasillo 1"


    old "Check theater hall"
    new "Revisar sala del teatro"


    old "Check storage"
    new "Revisar almacén"


    old "Check stage"
    new "Revisar escenario"


    old "Give them money"
    new "Darles dinero"


    old "Build water channels"
    new "Construir canales de agua"


    old "Give them new seeds"
    new "Darles nuevas semillas"


    old "I need time to think"
    new "Necesito tiempo para pensar"


    old "You should find a solution yourselves"
    new "Deberían encontrar una solución ustedes mismos"


    old "Agree"
    new "Aceptar"


    old "Refuse"
    new "Rechazar"


    old "Delay"
    new "Retrasar"


    old "Laugh with it"
    new "Reírse de ello"


    old "That's annoying"
    new "Eso es molesto"


    old "Eat"
    new "Comer"


    old "Don't eat"
    new "No comer"


    old "Trust him"
    new "Confiar en él"


    old "Don't trust him"
    new "No confiar en él"


    old "Balls"
    new "Pelotas"


    old "Collar"
    new "Collar"
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
