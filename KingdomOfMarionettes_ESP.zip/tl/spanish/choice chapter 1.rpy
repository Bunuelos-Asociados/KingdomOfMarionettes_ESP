


translate spanish q_clean_007736fc:


    "El jefe dijo que podía limpiarlo poco a poco. No es necesario terminar todo en un solo día."


translate spanish q_clean_9b49ffe9:


    "En ese caso, empezaré limpiando el escenario."


translate spanish q_clean_8529c83d:


    "Me dirijo al cuarto de almacenamiento para reunir algunos suministros de limpieza."


translate spanish q_clean_ced0f145:


    "Dios… Está tan oscuro aquí dentro. Apenas puedo ver algo."


translate spanish q_clean_518cf120:


    "Intenté encender la luz, pero por supuesto está rota. Como era de esperarse."


translate spanish q_clean_c0d8882e:


    "Enciendo mi linterna."


translate spanish q_clean_2883f898:


    "Mucho mejor."


translate spanish q_clean_09b91d84:


    "El cuarto de almacenamiento en sí está bastante sucio. Lo limpiaré en otro momento."


translate spanish q_clean_0565892b:


    "Estoy tan pendiente de reunir los suministros que me sobresalto cuando mi pie pisa algo."


translate spanish q_clean_ff4925b4:


    "Cuando miro hacia abajo, veo una pelota roja."


translate spanish q_clean_40b51288:


    "Oh. Solo es una pelota. No recuerdo haber visto una pelota roja antes."


translate spanish q_clean_e0c420d6:


    "Debí haberla pasado por alto."


translate spanish q_clean_c8112e95:


    "Una vez que compruebo que he reunido todos los suministros de limpieza, regreso hacia el escenario."


translate spanish q_clean_5f9b772e:


    "…."


translate spanish q_clean_3e4d017f:


    "No voy a mentir, este pasillo es bastante inquietante. Y no solo este pasillo. Todo este lugar se siente espeluznante y oscuro."


translate spanish q_clean_798a6618:


    "Puertas oxidadas están cubiertas con capas de periódicos viejos. Las paredes agrietadas están manchadas con grafitis dejados por vándalos."


translate spanish q_clean_f5cb8c8d:


    "La mayoría de las luces están rotas o no funcionan. Solo unas pocas siguen encendidas y aun así parpadean. El polvo y la suciedad se adhieren a cada rincón."


translate spanish q_clean_35210aef:


    "Por supuesto, eso no es sorprendente. Este teatro de marionetas ha estado cerrado durante mucho tiempo. Si no recuerdo mal, Kingdom of Marionettes cerró alrededor del año en que nací."


translate spanish q_clean_df28e148:


    "¿De verdad nadie ha intentado hacerse cargo de este lugar en todo este tiempo? Se siente como un desperdicio dejarlo abandonado. El lugar aún luce tan grandioso."


translate spanish q_clean_c65a501b:


    "Tal vez este lugar podría reconvertirse en un cine… o en un restaurante de alta gama."


translate spanish q_clean_ab9bfdd1:


    "O quizá alguien incluso podría reabrir este teatro de marionetas. Eso sería realmente interesante."


translate spanish q_clean_44e1d0c4:


    "Empiezo a barrer el suelo del escenario, moviéndome de un extremo al otro."


translate spanish q_clean_cb669769:


    "Solo barrer el suelo del escenario es suficiente para agotarme. El escenario es enorme, y las gruesas capas de polvo son persistentes y difíciles de quitar."


translate spanish q_clean_b2fb9f11:


    "Miro a mi alrededor, luego hacia los asientos del público."


translate spanish q_clean_408f1ebc:


    u "....Esto va a tomar más tiempo de lo que pensé."


translate spanish q_clean_cb4478df:


    "Después de limpiar el escenario durante lo que se siente como dos o tres horas, finalmente termino."


translate spanish q_clean_19d2159a:


    u "Bueno… al menos el escenario ya está listo."


translate spanish q_clean_7869af94:


    "A este ritmo, probablemente necesitaré alrededor de dos días completos solo para limpiar esta área."


translate spanish q_clean_9511e2aa:


    "Mi cuerpo está completamente agotado después de barrer, trapear, limpiar las cortinas y todo lo demás. No tengo fuerzas para continuar."


translate spanish q_clean_ee0d93b6:


    "Probablemente, sea porque casi no hago ejercicio y vivo a base de fideos instantáneos. Con razón mi resistencia es terrible. ¿Qué puedo hacer?"


translate spanish q_clean_22ba0d55:


    "Por ahora, dejaré de limpiar."


translate spanish q_check_c9b76fbe:


    u "Según el jefe, hay alrededor de veinte marionetas en este teatro. Son bastantes."


translate spanish q_check_850ba768:


    "Camino hacia la sala donde se guardan todas las marionetas, ubicada al final del pasillo."


translate spanish q_check_b3aed74e:


    "En serio… ¿Quién pensó que era buena idea poner la sala de marionetas al final de un pasillo tan oscuro?"


translate spanish q_check_a368bdaa:


    "Debo necesitar tanto el dinero que hasta parece que disfruto entrar a una casa embrujada."


translate spanish q_check_697ea20e:


    "Agarro el pomo de la puerta y tomo una respiración profunda antes de abrirla finalmente."


translate spanish q_check_8f572daf:


    u "...¿Esta es la sala de marionetas? No me equivoqué, ¿verdad?"


translate spanish q_check_c21d5803:


    "Si me lo preguntas, parece más una prisión."


translate spanish q_check_5659b7ea:


    "Esperaba ver un montón de marionetas colgadas en las paredes o algo así."


translate spanish q_check_b38fefda:


    "Pero, curiosamente, cada marioneta parece tener su propia habitación."


translate spanish q_check_d2a81a0e:


    u "Bien. Hora de empezar a contar."


translate spanish q_check_84cadd21:


    "Saco un papel que contiene la lista de marionetas."


translate spanish q_check_22236f41:


    "¿A quién debería revisar primero?"


translate spanish jester_89be6b80:


    u "Veamos el bufón marioneta."


translate spanish jester_c256c017:


    "Camino hacia una puerta con el nombre “Jester” escrito en ella y luego miro a través de la mirilla de la puerta."


translate spanish jester_550046b3:


    "La habitación del bufón marioneta está decorada con patrones de rayas de varios colores. Principalmente negro, rojo y amarillo."


translate spanish jester_7c90aa6a:


    "Está llena de todo tipo de accesorios de acrobacia: pelotas, un monociclo y muchos otros."


translate spanish jester_36ccba3a:


    "Al mirar más de cerca, finalmente veo al bufón marioneta de pie en una esquina de la habitación."


translate spanish jester_f899971f:


    "No puedo ver su rostro, ya que la marioneta está ligeramente encorvada, pero al menos sé que está ahí."


translate spanish jester_af8c02e6:


    "Bufón marioneta revisado."


translate spanish knight_2b9e7e38:


    "Camino hacia la puerta etiquetada como “Knight”."


translate spanish knight_3a5d3464:


    "La habitación del caballero marioneta está ordenada."


translate spanish knight_90b56432:


    "Un escudo resistente e imponente está montado en la pared, junto con… varias otras decoraciones de escudos."


translate spanish knight_e8b46306:


    "Hay bastantes escudos, todos con diferentes formas y diseños."


translate spanish knight_f4a356a3:


    "Sobre la cama, veo una marioneta sentada erguida, con una capa rojo oscuro cubriendo su rostro."


translate spanish knight_ab31fa00:


    "No cabe duda de que es el caballero marioneta. Revisado."


translate spanish king_0cfd0c39:


    "Camino hacia la puerta etiquetada como “King”."


translate spanish king_31aed451:


    "Cuando miro dentro, la habitación es lujosa."


translate spanish king_1e1a4741:


    "Hay una cama tamaño king con cortinas, una chaise longue (sillón) que parece cómoda y varias pinturas."


translate spanish king_f8c4285b:


    "Examino cada rincón de la habitación, pero no puedo encontrar al rey marioneta por ninguna parte."


translate spanish king_69585039:


    "Oh no… ¿Falta el rey marioneta?"


translate spanish king_095a9964:


    "Reviso la lista de marionetas que llevo, pero tampoco veo el nombre del rey marioneta en ella."


translate spanish king_63f1d603:


    "Supongo que nunca hubo un rey marioneta para empezar. O… ¿Lleva mucho tiempo desaparecido?"


translate spanish after_check_1eaecb19:


    "Solo he revisado dos marionetas hasta ahora. Será mejor que me dé prisa y le informe los resultados al jefe."


translate spanish after_check_0fd4d656:


    "……"


translate spanish after_check_3928a113:


    "……"


translate spanish after_check_2399eb56:


    "Después de pasar unos minutos más revisando las marionetas, finalmente termino. Todas las marionetas de la lista están presentes."


translate spanish outer_gate_b34ae8e6:


    "Reviso la cámara en la puerta exterior. No hay nada ahí."


translate spanish corridor1_c72765eb:


    "Reviso la cámara del pasillo 1. No hay nada ahí."


translate spanish theater_hall_268f0f81:


    "Reviso la cámara del teatro. No hay nada ahí."


translate spanish storage_60018e7d:


    "Reviso la cámara del cuarto de almacenamiento. No hay nad—"


translate spanish storage_07bdde05:


    "….."


translate spanish storage_ec12a37f:


    "Retiro lo que dije."


translate spanish storage_d1e5ea7b:


    "Alguien acaba de pasar por el cuarto de almacenamiento."


translate spanish storage_ec128e67:


    "..... ¿Fue un vándalo?"


translate spanish storage_0d0b3bbd:


    "No. Eso no tiene sentido."


translate spanish storage_660da02e:


    u "¿Cómo entró?"


translate spanish storage_2bf4407d:


    "Maldita sea. Tengo que revisarlo ahora mismo antes de que esos vándalos hagan algo que complique aún más mi trabajo."


translate spanish storage_827a69d5:


    "Rápidamente, tomo una linterna y un bastón para defenderme, luego salgo corriendo de la habitación hacia el área de almacenamiento."


translate spanish storage_8fae22bb:


    "Cuando llego al cuarto de almacenamiento, no encuentro nada."


translate spanish storage_b32bb8cd:


    "Sin embargo, la puerta está abierta. Prueba de que lo que vi en el CCTV era real y no solo mi imaginación."


translate spanish storage_38ea61a0:


    "Tengo un mal presentimiento. Sea quien sea esta persona, está en algún lugar del pasillo."


translate spanish storage_d4986972:


    "Agarro mi bastón con la mayor fuerza posible y avanzo lentamente hacia el pasillo."


translate spanish storage_07bdde05_1:


    "….."


translate spanish storage_28fde3a8:


    "Está completamente oscuro… será mejor que encienda la linterna."


translate spanish storage_75b742b1:


    "Bien—"


translate spanish storage_0fd4d656:


    "……"


translate spanish storage_fae4f937:


    "¿Qué demonios es eso…?"


translate spanish storage_07384e83:


    "Después de encender la linterna, finalmente puedo ver el oscuro camino que se extiende frente a mí."


translate spanish storage_6ce9e3dc:


    "Pero también puedo ver otra cosa…"


translate spanish storage_ba16a89e:


    "Una figura alta de pie al final del pasillo."


translate spanish storage_0ccefa30:


    "La figura está envuelta en una capa roja, con los bordes desgarrados y raídos. Su atuendo se parece al de un caballero."


translate spanish storage_a20cefa7:


    "..."


translate spanish storage_8eef97dc:


    "No… esto no es un vándalo."


translate spanish storage_69b1dd44:


    "Es el caballero marioneta que revisé antes…"


translate spanish storage_764814f9:


    "¿Cómo podría una marioneta estar de pie aquí…?"


translate spanish storage_6e05f8d5:


    "No puede ser. Las marionetas no se mueven…"


translate spanish storage_dacbdb3f:


    "Tal vez unos vándalos entraron y movieron al caballero marioneta hasta aquí. Y como me notaron, la devolvieron para poder escapar lo más rápido posible."


translate spanish storage_67153a08:


    "Sí. Tiene que ser eso."


translate spanish storage_48500d95:


    "Antes de poder calmarme con todas esas posibilidades, la cabeza de la marioneta se mueve y gira para mirarme directamente."


translate spanish storage_07bdde05_2:


    "….."


translate spanish storage_ec12a37f_1:


    "Retiro lo que dije."


translate spanish storage_2ad222a5:


    knipuppet "...Intruso..."


translate spanish storage_3dceb7a7:


    "Esa marioneta puede hablar."


translate spanish storage_7e9edd46:


    "Cálmate... cálmate.. no entres en pánico..."


translate spanish storage_acbb964c:


    "¿Pero qué debería hacer en esta situación?"


translate spanish keep_silent_c3af6791:


    "Me quedo ahí, sin poder moverme. No sé qué hacer. Incluso si digo algo, temo que solo empeore las cosas."


translate spanish keep_silent_3607f28a:


    "Nunca imaginé una situación en la que una marioneta me hablara."


translate spanish who_1c4c3699:


    "No dijo nada más."


translate spanish who_3607f28a:


    "Nunca imaginé una situación en la que una marioneta me hablara."


translate spanish run_75016de9:


    "Sin pensarlo dos veces, me di la vuelta y corrí directo hacia mi oficina."


translate spanish run_b99f9743:


    "Una vez llegué, cerré la puerta con llave lo más rápido que pude."


translate spanish run_87cb2fa2:


    u "La marioneta estaba realmente viva... habló. ¿Estoy soñando...?"


translate spanish run_26be82b4:


    u "Siento que he perdido la cordura... ¿O tal vez ya la había perdido...?"


translate spanish run_739e7b43:


    "Intenté calmarme y retrocedí lentamente, pero manteniendo la vista fija en la puerta."


translate spanish run_c2c42034:


    "Me preparé para la llegada de la marioneta a mi oficina, pero incluso después de cinco minutos, no escuché nada."


translate spanish run_a42eff31:


    "¿La marioneta no me siguió?"


translate spanish run_c0f35448:


    "Justo cuando estaba a punto de sentir alivio, de repente, una mano cubrió mis ojos."


translate spanish run_6576ac53:


    "Todo mi cuerpo se quedó rígido al sentir a alguien detrás de mí."


translate spanish run_5b99436a:


    "¿Desde cuándo?"


translate spanish run_a4e46cc5:


    "No me atreví a gritar ni a resistirme. Tenía demasiado miedo."


translate spanish run_56db3b30:


    who "Mm... esperaba que gritaras. Pero parece que te portas muy bien. Mucho mejor de lo que anticipaba."


translate spanish run_92ca7c2f:


    "Una voz suave susurró justo junto a mi oído. Es aguda, extrañamente juguetona, casi infantil."


translate spanish run_47c70280:


    "Luego siento otra mano posarse lentamente sobre mi hombro, haciéndome sobresaltarme."


translate spanish run_87b5833c:


    who "Calma. El peligro ha pasado. Puedes permitirte relajarte."


translate spanish run_7434f661:


    who "¿Por qué no vienes conmigo por ahora? Te aseguro que no soy alguien a quien debas temer."


translate spanish run_cd23c268:


    who "Después de todo, cualquier invitado que pise este reino debería ser recibido adecuadamente. ¿No estás de acuerdo?"


translate spanish run_09805a88:


    "Está bien... quien sea que esté detrás de mí suena lo suficientemente amable. Aun así, probablemente sea mejor seguirle el juego."


translate spanish run_3b9dac57:


    "Asiento con la cabeza."


translate spanish run_aa4a51a8:


    who "Excelente. Ahora ven conmigo."


translate spanish dicekek_cf8a8d55:


    "De repente, en un abrir y cerrar de ojos, una mano se aferra a mi garganta."


translate spanish dicekek_81d2627a:


    u "¡UGH—?!"


translate spanish dicekek_a520c5f9:


    "El caballero marioneta está justo frente a mí, asfixiándome con una velocidad aterradora."


translate spanish dicekek_c77602ae:


    knipuppet "Una vez más... un intruso..."


translate spanish dicekek_ba39f550:


    knipuppet "Parece que cada vez más intrusos han estado llegando a este reino últimamente."


translate spanish dicekek_c9d66958:


    knipuppet "Qué afortunado..."


translate spanish dicekek_ad9b9c93:


    "Su agarre se aprieta alrededor de mi cuello, cortando mi respiración."


translate spanish dicekek_092dbe35:


    "¡Va a matarme!"


translate spanish dicekek_0c70cc9f:


    "Lucho con toda la fuerza que tengo, golpeando su brazo, pateando sus piernas, intentando desesperadamente liberarme."


translate spanish dicekek_2ac20e83:


    "Pero es inútil. Es mucho más fuerte que yo. Ni siquiera se mueve."


translate spanish dicekek_1c461bb5:


    "Mi visión se vuelve cada vez más borrosa, hundiéndose en la oscuridad."


translate spanish dicekek_604dcb18:


    "¿De verdad así termina mi vida? ¿A manos de una marioneta viviente?"


translate spanish dicekek_1b3cfe4f:


    "Justo antes de perder completamente la conciencia, una mano cubre mis ojos de repente."


translate spanish dicekek_82b66c7b:


    knipuppet "...¿Qué estás haciendo aquí?"


translate spanish dicekek_68005f19:


    "¿Eh? ¿Quién es este detrás de mí? ¿¿Otra marioneta??"


translate spanish dicekek_15d4cc7a:


    who "Knighter, creo que ya he mencionado esto antes. ¿No sería mejor que cualquier visitante que entre en nuestro reino me sea confiado?"


translate spanish dicekek_acae9e6b:


    kni "¿Para qué? ¿Para que lleves a cabo ese absurdo plan tuyo?"


translate spanish dicekek_fab6c484:


    who "Amigo mío, eres libre de dudar de mí si así lo deseas. No te culparía por ello. Pero necesito a este visitante. Eso lo entiendes... ¿Verdad?"


translate spanish dicekek_9d5517c8:


    "De repente, el pasillo queda en silencio. No tengo idea de lo que está pasando."


translate spanish dicekek_60c8dd55:


    "El caballero marioneta llamado Knighter resopla con irritación antes de soltar abruptamente mi cuello."


translate spanish dicekek_7bc2613a:


    "Escucho sus pasos alejándose, una clara señal de que se ha ido."


translate spanish dicekek_a9f09942:


    "Aun así, la mano que cubre mis ojos no se mueve, manteniendo mi visión suavemente bloqueada."


translate spanish dicekek_47c70280:


    "Luego siento otra mano posarse lentamente sobre mi hombro, haciéndome sobresaltarme."


translate spanish dicekek_87b5833c:


    who "Calma. El peligro ha pasado. Puedes permitirte relajarte."


translate spanish dicekek_7434f661:


    who "¿Por qué no vienes conmigo por ahora? Te aseguro que no soy alguien a quien debas temer."


translate spanish dicekek_cd23c268:


    who "Después de todo, cualquier invitado que pise este reino debería ser recibido adecuadamente. ¿No estás de acuerdo?"


translate spanish dicekek_09805a88:


    "Está bien... quien sea que esté detrás de mí suena lo suficientemente amable. Aun así, probablemente sea mejor seguirle el juego."


translate spanish dicekek_3b9dac57:


    "Asiento con la cabeza."


translate spanish dicekek_aa4a51a8:


    who "Excelente. Ahora ven conmigo."


translate spanish ke_stage_b582c00f:


    "La figura detrás de mí me guía hacia adelante, llevándome a donde quiere mientras mantiene mis ojos cubiertos."


translate spanish ke_stage_5f6ec595:


    "Después de un rato, se detiene."


translate spanish ke_stage_5b135711:


    who "Hemos llegado. Ahora, por favor, toma asiento aquí y ponte a gusto."


translate spanish ke_stage_e6257ec1:


    "Me guía suavemente para sentarme."


translate spanish ke_stage_79c0981a:


    "Luego, su mano se aparta de mis ojos, permitiéndome ver finalmente."


translate spanish ke_stage_1a188bd4:


    "Esto es... el teatro..."


translate spanish ke_stage_b4c0bae0:


    "Me doy la vuelta, intentando ver quién me ha estado guiando todo este tiempo."


translate spanish ke_stage_8c1dee58:


    "Pero no hay nadie ahí."


translate spanish ke_stage_d74acb68:


    u "¿Qué? ¿A dónde fue esa persona?"


translate spanish ke_stage_f8bdd8e4:


    jespuppet "¡¡BOO!!"


translate spanish ke_stage_2d2d5001:


    u "¡¡AAARGH!!"


translate spanish ke_stage_e950a86c:


    "Aun sin haber tenido tiempo de prepararme y tratando de procesar lo que estaba pasando, grito cuando, sin previo aviso, alguien aparece justo frente a mí."


translate spanish ke_stage_558d92b2:


    "Cubre suavemente mi boca, como indicando que no me hará daño y que guarde silencio."


translate spanish ke_stage_0e4a568f:


    jespuppet "Shh..."


translate spanish ke_stage_825c63ab:


    "Siento como si mi alma casi hubiera salido de mi cuerpo por un segundo."


translate spanish ke_stage_88d43b28:


    "Lentamente, retira su mano de mis labios."


translate spanish ke_stage_bffbc981:


    "La figura está vestida como un bufón. Campanillas cuelgan de las puntas de su gorro, y su atuendo es de color rojo, negro, blanco y amarillo."


translate spanish ke_stage_a20cefa7:


    "..."


translate spanish ke_stage_233f662e:


    "Espera un segundo... ¿no es ese—?"


translate spanish ke_stage_c82304b6:


    "Es... el bufón marioneta."


translate spanish ke_stage_6fd8ae18:


    "...se... se mueve por sí solo."


translate spanish ke_stage_c32ace20:


    "Recordé la lista de tareas que leí antes de postularme ayer."


translate spanish ke_stage_e167b255:


    "Asegúrate de que ninguna de las marionetas falte... ni esté caminando."


translate spanish ke_stage_817f648a:


    "En ese momento, lo creí al ver con mis propios ojos al caballero marioneta y la marioneta bufón moverse."


translate spanish ke_stage_09fcc39a:


    "...Esto no es una broma. Están vivos."


translate spanish stage_94b9fe55:


    "Reviso la cámara del escenario. No hay nad—"


translate spanish stage_b84bd283:


    "Espera un segundo... ¿Qué demonios es eso?"


translate spanish stage_c1b70496:


    "A través de la cámara de seguridad, puedo ver una figura de pie en el centro del escenario."


translate spanish stage_42d23433:


    "Es difícil distinguirla en la oscuridad, pero no cabe duda de que hay alguien allí."


translate spanish stage_d83ab720:


    "¿Son los vándalos? ¿Cómo lograron entrar?"


translate spanish stage_723bc5e7:


    "Maldita sea. Tengo que revisarlo ahora mismo... antes de que esos vándalos hagan algo que complique aún más mi trabajo."


translate spanish stage_91a606e1:


    "Rápidamente, tomo una linterna y un bastón para defenderme, luego salgo corriendo hacia el teatro."


translate spanish stage_07bdde05:


    "….."


translate spanish stage_415559a8:


    "Entro en el teatro y miro hacia el escenario oscuro."


translate spanish stage_35da436d:


    "Está demasiado oscuro para ver a alguien con claridad. Tendré que acercarme."


translate spanish stage_f8bdd8e4:


    jespuppet "¡¡BOO!!"


translate spanish stage_2d2d5001:


    u "¡¡AAARGH!!"


translate spanish stage_acf8eb8e:


    "Aun sin haber tenido tiempo de prepararme y tratando de procesar lo que estaba pasando, dejo escapar el grito más fuerte de mi vida cuando, sin previo aviso, la figura ya estaba justo frente a mí."


translate spanish stage_c9bc9322:


    "Cubre suavemente mi boca, como indicando que no me hará daño."


translate spanish stage_0e4a568f:


    jespuppet "Shh..."


translate spanish stage_825c63ab:


    "Siento como si mi alma casi hubiera salido de mi cuerpo por un segundo."


translate spanish stage_88d43b28:


    "Lentamente, retira su mano de mis labios."


translate spanish stage_bffbc981:


    "La figura está vestida como un bufón. Campanillas cuelgan de las puntas de su gorro, y su atuendo es de color rojo, negro, blanco y amarillo."


translate spanish stage_a20cefa7:


    "..."


translate spanish stage_424f7eee:


    "Espera un segundo... ¿no es ese—?"


translate spanish stage_25128f12:


    "Es... el bufón marioneta que revisé antes."


translate spanish stage_c8f7d405:


    "Está... ¿Moviéndose? ¡¿Moviéndose por sí solo?!"


translate spanish stage_caf1c301:


    "¿Cómo es eso siquiera posible?"


translate spanish stage_36477dbc:


    "De repente, recordé la lista de tareas que leí antes de postularme ayer."


translate spanish stage_4c151d0c:


    "Asegúrate de que ninguna de las marionetas falte… ni esté caminando."


translate spanish stage_d376b6ab:


    "En ese momento, lo creí al verlo con mis propios ojos y mi propia mente."


translate spanish stage_c6159c84:


    "...Esto no es una broma. Están vivos."


translate spanish money_9b08e166:


    "Tal vez podría darles dinero... así podrían comprar lo que necesiten."


translate spanish money_97ae167e:


    mc "¿Y si les doy algunos fondos? Proporcionaré lo que necesiten. Ya sea para comprar nuevas semillas o cubrir sus necesidades diarias."


translate spanish money_283791da:


    nara "{color=#E0AE4B}Al escuchar la decisión de [obj!t] [title!t] de proporcionar a los agricultores todos los fondos que necesitaran, el corazón del agricultor saltó de alegría.{/color}"


translate spanish money_618ce9e7:


    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."


translate spanish money_436d3ea4:


    farm "¡Oh, por supuesto, Su Majestad! Eso suena como una buena idea. ¡Muchas gracias!"


translate spanish money_ee3ef29a:


    nara "{color=#E0AE4B}Con el corazón lleno de alegría, el agricultor finalmente abandonó el palacio para dar la buena noticia.{/color}"


translate spanish money_abbe3b80:


    "El agricultor marioneta se levantó y salió del escenario."


translate spanish money_54f54627:


    "Pude sentir la mirada de Jestyn fija en mí."


translate spanish money_f2905482:


    jes "Oh, Su Majestad. Qué decisión tan sabi[poss!t] y bondados[poss!t]."


translate spanish money_f1222d64:


    jes "Proporcionar fondos a los agricultores para cubrir sus necesidades básicas. No es una mala idea en absoluto."


translate spanish money_510a1e83:


    "Hizo una pausa."


translate spanish money_2cd83f90:


    jes "Es usted muy amable, Su Majestad. Y la bondad es algo hermoso."


translate spanish money_13dea7c0:


    jes "Pero cuando se da sin límites... se convierte en expectativa."


translate spanish money_a61e186e:


    "Inclinó la cabeza."


translate spanish money_e79aa23e:


    jes "Dígame, ¿Cuántas monedas se necesitan para alimentar a un reino?"


translate spanish money_d27df0f0:


    mc "Uhm... eso es..."


translate spanish money_79861712:


    jes "Ah, discúlpeme."


translate spanish money_173ff528:


    jes "Olvidé que es usted muy generos[poss!t]."


translate spanish money_5d8ee5db:


    "Sonrió."


translate spanish money_d8235c83:


    jes "El reino debe ser bastante pequeño... si la generosidad por sí sola es suficiente para sostenerlo."


translate spanish money_631a098c:


    "Tiene razón..."


translate spanish money_fecd91a3:


    "Ser [obj!t] [title!t] es realmente difícil…"


translate spanish money_8ebdfdc5:


    "Quiero decir, solo soy guardia de seguridad, que esta desesperad[poss!t] por dinero solo para sobrevivir."


translate spanish money_e82a19a7:


    "Y ahora, de repente, me están obligando a interpretar el papel de [obj!t] [title!t] por marionetas vivientes."


translate spanish money_9c6e8d8c:


    "Realmente no soy apt[poss!t] para ser un líder."


translate spanish channels_f6b65596:


    "No sé mucho sobre agricultura, pero una vez leí que la sequía puede manejarse construyendo canales de agua."


translate spanish channels_91942fe8:


    "Mmm... no creo que sea una mala idea. Eso espero."


translate spanish channels_1e7871e5:


    mc "¿Qué tal si construimos canales de agua? Así los cultivos no se secarán."


translate spanish channels_59eec820:


    nara "{color=#E0AE4B}Al escuchar la decisión de [obj!t] [title!t] de construir canales de agua, el corazón del agricultor saltó de alegría.{/color}"


translate spanish channels_618ce9e7:


    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."


translate spanish channels_ebae100a:


    "El agricultor pareció pensar por un momento, luego asintió de acuerdo."


translate spanish channels_385c2411:


    farm "Por supuesto, Su Majestad. Es una buena idea."


translate spanish channels_808ee39d:


    "Suspiro con alivio."


translate spanish channels_cdee7ca5:


    mc "Entonces proporcionaré los fondos para construir los canales lo antes posible."


translate spanish channels_fcacb4d6:


    farm "Muy bien, Su Majestad. Muchas gracias."


translate spanish channels_ee3ef29a:


    nara "{color=#E0AE4B}Con el corazón lleno de alegría, el agricultor finalmente abandonó el palacio para dar la buena noticia.{/color}"


translate spanish channels_abbe3b80:


    "El agricultor marioneta se levantó y salió del escenario."


translate spanish channels_d3df1e05:


    "Después de eso, el agricultor se levantó y abandonó el escenario."


translate spanish channels_54f54627:


    "Pude sentir la mirada de Jestyn fija en mí."


translate spanish channels_7fcb8644:


    jes "Una elección verdaderamente admirable, Su Majestad."


translate spanish channels_e1111f9d:


    jes "Canales de agua para combatir la sequía. Una solución que mira hacia el futuro."


translate spanish channels_61a603ca:


    jes "Pensó en la próxima temporada... y en la siguiente."


translate spanish channels_466d8ae9:


    "Hizo una pausa, sonriendo."


translate spanish channels_51e307fc:


    jes "Quizá demasiado hacia el futuro."


translate spanish channels_80f10282:


    jes "Dígame, Su Majestad. ¿Cuál era el problema del agricultor en este momento?"


translate spanish channels_5e9f4520:


    "¿Eh?"


translate spanish channels_625d0c5d:


    "La sequía provocó que los cultivos fallaran, dejándolos sin ingresos para comprar nuevas semillas... y..."


translate spanish channels_7777ddff:


    mc "Sin dinero para cubrir sus necesidades diarias..."


translate spanish channels_7d3aa4cc:


    jes "¡Oh, excelente! ¡Lo recordó! ¡Cinco estrellas por visión!"


translate spanish channels_75a0ebbc:


    jes "Y aun así... un agricultor hambriento no puede comer una cosecha futura."


translate spanish channels_3077e7bf:


    "Se rió suavemente."


translate spanish channels_febb6fba:


    jes "Parece que necesitará hacer algo más que simplemente construir canales de agua."


translate spanish channels_50bcfa87:


    "Oh… tiene razón…"


translate spanish channels_fecd91a3:


    "Ser [obj!t] [title!t] es realmente difícil…"


translate spanish channels_8ebdfdc5:


    "Quiero decir, solo soy guardia de seguridad, que esta desesperad[poss!t] por dinero solo para sobrevivir."


translate spanish channels_800a9434:


    "Y ahora, de repente, me están obligando a interpretar el papel de una reina por marionetas vivientes."


translate spanish channels_9c6e8d8c:


    "Realmente no soy apt[poss!t] para ser un líder."


translate spanish seeds_05418970:


    "Los cultivos fallaron durante la temporada seca. Si no recuerdo mal, hay plantas que pueden sobrevivir a condiciones secas."


translate spanish seeds_f5412774:


    mc "¿Hay cultivos que puedan sobrevivir a la sequía?"


translate spanish seeds_2b54f80a:


    "El agricultor guardó silencio, pensando."


translate spanish seeds_8d8bbcc6:


    farm "¡Ah! Sí los hay, Su Majestad. Tomates, maíz y cultivos de raíz, por ejemplo."


translate spanish seeds_b6241d51:


    mc "Entonces, ¿Qué tal si cambiamos a cultivos que puedan sobrevivir la temporada seca? Proporcionaré las semillas que necesiten."


translate spanish seeds_d7ab5505:


    nara "{color=#E0AE4B}Al escuchar la decisión de [obj!t] [title!t] de proporcionar nuevas semillas a los agricultores, el corazón del agricultor saltó de alegría.{/color}"


translate spanish seeds_618ce9e7:


    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."


translate spanish seeds_3a688fd4:


    "El agricultor asintió de acuerdo."


translate spanish seeds_629c7591:


    farm "Entiendo, Su Majestad. Gracias por su ayuda."


translate spanish seeds_ee3ef29a:


    nara "{color=#E0AE4B}Con el corazón lleno de alegría, el agricultor finalmente abandonó el palacio para dar la buena noticia.{/color}"


translate spanish seeds_abbe3b80:


    "El agricultor marioneta se levantó y salió del escenario."


translate spanish seeds_d3df1e05:


    "Después de eso, el agricultor se levantó y abandonó el escenario."


translate spanish seeds_54f54627:


    "Pude sentir la mirada de Jestyn fija en mí."


translate spanish seeds_934cc55f:


    jes "Una decisión muy sabia, Su Majestad."


translate spanish seeds_211c6330:


    jes "Elegir cultivos que puedan soportar el duro sol de la temporada seca, para que los agricultores ya no tengan que preocuparse por que sus cultivos mueran."


translate spanish seeds_25a9b9fe:


    jes "Su forma de pensar realmente mira hacia adelante. Consideró genuinamente cómo podría ser su futuro."


translate spanish seeds_510a1e83:


    "Hizo una pausa."


translate spanish seeds_1c64c52d:


    jes "Un plan brillante para mañana... pero, ¿Qué comerán esta noche?"


translate spanish seeds_4cb2462c:


    "Me quedo paralizad[poss!t]."


translate spanish seeds_533ce45d:


    jes "¿Recuerda qué tipo de problema tenía el agricultor hace un momento? "


translate spanish seeds_5e9f4520:


    "¿Eh?"


translate spanish seeds_625d0c5d:


    "La sequía provocó que los cultivos fallaran, dejándolos sin ingresos para comprar nuevas semillas... y..."


translate spanish seeds_7777ddff:


    mc "Sin dinero para cubrir sus necesidades diarias..."


translate spanish seeds_7d3aa4cc:


    jes "¡Oh, excelente! ¡Lo recordó! ¡Cinco estrellas por visión!"


translate spanish seeds_b2bb6ca5:


    jes "Los cultivos no crecen de la noche a la mañana, Su Majestad. Confío en que lo sabe."


translate spanish seeds_3077e7bf:


    "Se rió suavemente."


translate spanish seeds_823f0634:


    "Oh... tiene razón..."


translate spanish seeds_12da887b:


    jes "Parece que necesitará hacer algo más que eso."


translate spanish seeds_50bcfa87:


    "Oh… tiene razón…"


translate spanish seeds_fecd91a3:


    "Ser [obj!t] [title!t] es realmente difícil…"


translate spanish seeds_8ebdfdc5:


    "Quiero decir, solo soy guardia de seguridad, que esta desesperad[poss!t] por dinero solo para sobrevivir."


translate spanish seeds_800a9434:


    "Y ahora, de repente, me están obligando a interpretar el papel de una reina por marionetas vivientes."


translate spanish seeds_9c6e8d8c:


    "Realmente no soy apt[poss!t] para ser un líder."


translate spanish time_7ecb0508:


    "¿Qué necesita un agricultor para evitar que los cultivos fracasen durante la temporada seca…?"


translate spanish time_313eb8ad:


    "¿Dinero? ¿Semillas? ¿Pero eso realmente es suficiente para enfrentar esto?"


translate spanish time_3f0be528:


    "Dios mío…"


translate spanish time_5552f504:


    mc "Lo siento… yo… necesito más tiempo para pensar."


translate spanish time_c41d70d8:


    nara "{color=#E0AE4B}Al escuchar las palabras de [obj!t] [title!t], el agricultor intentó comprender que tales decisiones no podían tomarse con prisa. Aun así, su corazón permanecía inquieto.{/color}"


translate spanish time_618ce9e7:


    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."


translate spanish time_ac1bd28d:


    "El agricultor asintió, comprendiendo."


translate spanish time_4c65c579:


    farm "Muy bien, Su Majestad. Por favor, le pedimos su ayuda…"


translate spanish time_be39b031:


    "Después de eso, el agricultor marioneta abandonó el escenario."


translate spanish time_3702aefd:


    nara "{color=#E0AE4B}Desde una esquina de la sala, el bufón observaba a [obj!t] [title!t] con una mirada aguda, su sonrisa habitual aún fija en su rostro.{/color}"


translate spanish time_cd5e6247:


    nara "{color=#E0AE4B}Parecía que el bufón deseaba decirle unas palabras a [obj!t] [title!t].{/color}"


translate spanish time_54f54627:


    "Pude sentir la mirada de Jestyn fija en mí."


translate spanish time_cacbe634:


    jes "¿Más tiempo, Su Majestad?"


translate spanish time_14688fd9:


    "Sonrió, divertido."


translate spanish time_fd6e3b5c:


    jes "Qué encantador."


translate spanish time_a889852b:


    jes "Muy bien, tómese todo el tiempo que necesite."


translate spanish time_de9cb362:


    jes "Solo recuerde…"


translate spanish time_6878d401:


    "Se inclinó ligeramente hacia adelante."


translate spanish time_792809bf:


    jes "La temporada seca no es conocida por su paciencia. Ni tampoco las personas hambrientas."


translate spanish time_50bcfa87:


    "Oh… tiene razón…"


translate spanish time_fecd91a3:


    "Ser [obj!t] [title] es realmente difícil…"


translate spanish time_8ebdfdc5:


    "Quiero decir, solo soy guardia de seguridad, que esta desesperad[poss!t] por dinero solo para sobrevivir."


translate spanish time_800a9434:


    "Y ahora, de repente, me están obligando a interpretar el papel de una reina por marionetas vivientes."


translate spanish time_9c6e8d8c:


    "Realmente no soy apt[poss!t] para ser un líder."


translate spanish yourselves_5f9b772e:


    "…."


translate spanish yourselves_9373dc2d:


    "Esto es estúpido."


translate spanish yourselves_72bbf181:


    "No soy [obj!t] [title!t]. Solo soy guardia de seguridad."


translate spanish yourselves_e40328e6:


    "Quiero irme a casa."


translate spanish yourselves_2297ff89:


    mc "Creo que puedes resolver tu problema por tu cuenta."


translate spanish yourselves_4b6ef1a4:


    mc "No entiendo de agricultura, y como agricultor, deberías saber mejor qué hacer."


translate spanish yourselves_7426e176:


    farm "...Su Majestad... se lo suplico..."


translate spanish yourselves_8aa21722:


    farm "¡¡SE LO SUPLICO!!"


translate spanish yourselves_01cea383:


    "La marioneta sujetó mi hombro con fuerza."


translate spanish yourselves_69eb1ab6:


    "Muy, muy fuerte."


translate spanish yourselves_fee87583:


    farm "{color=#FF2727}{cps=220}no otra vez{/cps}{/color}"


translate spanish yourselves_fcbf8c3d:


    farm "{color=#FF2727}{cps=220}¡¡NO OTRA VEZ!!{/cps}{/color}"


translate spanish yourselves_a8e541b2:


    "¿Q–qué... es esto...?"


translate spanish yourselves_078dff8c:


    "De repente, de repente, mi cabeza comenzó a palpitar violentamente, como si la estuvieran retorciendo."


translate spanish yourselves_7c1bc812:


    "Mi visión se volvió borrosa. Aun así, entre la niebla, vi algo... algo que ni siquiera podía empezar a comprender."


translate spanish yourselves_606f26f5:


    farm "{color=#FF2727}{cps=220}¡NO ME ABANDONARÁS COMO ÉL, ¿VERDAD?!{/cps}{/color}"


translate spanish yourselves_cfc71ebb:


    farm "{color=#FF2727}{cps=220}¡¡NO ME ABANDONES!!{/cps}{/color}"


translate spanish yourselves_642fb35c:


    jes "Ups~"


translate spanish yourselves_4ca1c9a7:


    "Jestyn lo tomó del hombro y lo apartó de mí."


translate spanish yourselves_23809793:


    jes "¿No escuchaste lo que dijo Su Majestad, mi querido amigo agricultor?"


translate spanish yourselves_9ec360c0:


    jes "Su Majestad dijo que puedes encontrar tu propio camino. Al menos, ¡Su Majestad cree en tus capacidades!"


translate spanish yourselves_20ca5cc2:


    jes "Ser honrado con la confianza de Su Majestad es como haber sido bendecido por el milagro del Hada Madre. Deberías sentirte honrado."


translate spanish yourselves_8de16e70:


    jes "Ahora, lo mejor sería que regresaras y pensaras cuidadosamente en lo que debes hacer. ¿Entiendes, amigo mío?"


translate spanish yourselves_73880861:


    farm "Yo... lo entiendo... por favor, perdone mi insolencia, Su Majestad."


translate spanish yourselves_860a1e6b:


    nara "{color=#E0AE4B}Con el corazón pesado, el agricultor finalmente abandonó el reino.{/color}"


translate spanish yourselves_dc6f9e94:


    nara "{color=#E0AE4B}Al escuchar la decisión previa de Su Majestad, Jestyn simplemente mantuvo su sonrisa habitual.{/color}"


translate spanish yourselves_b172629f:


    "Pude sentir la mirada aguda de Jestyn dirigida hacia mí."


translate spanish yourselves_70f40038:


    jes "…."


translate spanish yourselves_8f599295:


    jes "Pffft… {size= 15}no muy diferente, ¿eh?{/size}"


translate spanish yourselves_6046db3b:


    mc "¿Eh? ¿Dijiste algo?"


translate spanish yourselves_456a66bd:


    jes "No, no, no. No dije nada, Su Majestad."


translate spanish yourselves_b6a39c97:


    jes "No está equivocad[poss!t]. Todo el poder está en sus manos."


translate spanish yourselves_43d17dc6:


    jes "Puede hacer lo que desee con ese poder."


translate spanish yourselves_fdb0e29e:


    "Aunque Jestyn dijo eso, pude ver cómo su sonrisa se volvía más afilada."


translate spanish yourselves_0b6fbd6f:


    jes "Hmm… aunque, para ser completamente honesto, es algo decepcionante… si me lo pregunta."


translate spanish teach_a8068edd:


    mc "Bueno, como bufón que es bueno haciendo malabares, ¿por qué no me enseñas?"


translate spanish teach_1c3b3e2c:


    "Se queda inmóvil por un momento."


translate spanish teach_9b495d15:


    jes "¿Enseñarte? ¿Quieres decir… enseñarte a hacer malabares?"


translate spanish teach_6fd4a9b4:


    mc "Sí. Al menos, quiero intentar no dejarlas caer de inmediato."


translate spanish teach_0263f09b:


    "La verdad, ya estoy exhaust[poss!t]. Pero siento que no puedo detenerme aquí."


translate spanish teach_58e954d7:


    "La expresión sorprendida de Jestyn se transforma lentamente en una amplia sonrisa."


translate spanish teach_4f006298:


    jes "Qué interesante. Muy bien, entonces."


translate spanish teach_8bf8d88c:


    "Recoge las pelotas que habían caído y me las devuelve."


translate spanish teach_eacef35b:


    jes "Adelante, inténtalo."


translate spanish teach_b34a0dec:


    "Me preparo y empiezo a lanzar las pelotas, pero la mirada de Jestyn me pone nervios[poss!t]."


translate spanish teach_4fae875f:


    "Aun así, las lanzo al aire."


translate spanish teach_0ed3c7cd:


    "Jestyn deja escapar una risa suave mientras observa mi intento."


translate spanish teach_e0860bcf:


    jes "Su Majestad, difícilmente puede llamarse malabares si lo hace tan lento."


translate spanish teach_d965a6a7:


    mc "¡Oh, vamos! ¡Estoy aprendiendo!"


translate spanish teach_ec065d5c:


    "Chasquea los dedos y, de repente, aparecen más pelotas en su mano."


translate spanish teach_daa28512:


    "Él también empieza a hacer malabares. Aunque se siente menos como práctica y más como presumir."


translate spanish teach_5faeebe1:


    "Realiza truco tras truco con facilidad, mientras yo… continúo lanzando las pelotas lentamente, lo que insisto en llamar “malabares”."


translate spanish teach_ffdb6aa0:


    "La forma en que se burla de mí es realmente irritante."


translate spanish teach_e097e94f:


    "Cuando intento acelerar, algunas pelotas casi se me escapan de las manos y otras caen al suelo."


translate spanish teach_658c6e28:


    jes "¡Ja, ja, ja! Vamos, admítelo, simplemente no puedes hacerlo, Su Majestad."


translate spanish teach_d7f95ee5:


    mc "Pero te pedí que me enseñaras. No que te burlaras de mí. No siento que me estés enseñando algo sobre malabares."


translate spanish teach_89d9c769:


    jes "Sí lo hago, querid[poss!t]. Te enseño a través de la experiencia."


translate spanish teach_54057719:


    mc "No creo que así funcione…"


translate spanish teach_59761f3d:


    jes "Ah, pero qué entusiasmo tan notable por aprender, querid[poss!t]. Tal dedicación sin duda merece… un regalo."


translate spanish teach_75dac18b:


    "Jestyn de repente lanza una sola pelota hacia mí, sobresaltándome y haciendo que todas las demás se me caigan."


translate spanish teach_d9c47830:


    "Cuando intento atraparla, la pelota desaparece de la nada."


translate spanish teach_7b26cc90:


    jes "¿Oh? Parece que tus habilidades para atrapar son igual de pésimas, Su Majestad."


translate spanish teach_ccdac953:


    jes "Permítame. La atraparé por usted."


translate spanish teach_4a05fb50:


    "Su brazo se extiende, deteniéndose justo detrás de mi oreja."


translate spanish teach_562d842e:


    jes "¿Te gustaría adivinar dónde está la pelota?"


translate spanish snakebunny_9bb39788:


    jes "Cuando elijo su mano izquierda, aparece un pequeño muñeco de serpiente."


translate spanish snakebunny_640c5bae:


    jes "Una excelente elección, Su Majestad."


translate spanish snakebunny_bc7fc48c:


    jes "Un regalo de mí… para usted."


translate spanish snakebunny_78dff35c:


    "Da un paso atrás."


translate spanish snakebunny_5ae637bc:


    "¿Acaba de hacer un truco de magia?"


translate spanish snakebunny_d9a9687a:


    mc "¡Oh! ¡Eso es genial! ¿Cómo lo hiciste?"


translate spanish snakebunny_597f50e6:


    "Jestyn guarda silencio por un momento, antes de que su sonrisa regrese lentamente."


translate spanish snakebunny_c87ad347:


    jes "Ese es un secreto de bufón, querid[poss!t]. Nunca podría decírtelo~"


translate spanish snakebunny_1a1e1df0:


    "Dijo Jestyn con tono juguetón."


translate spanish snakebunny_b2afd01b:


    mc "Entonces… ¿puedo ver más?"


translate spanish snakebunny_deeff8f2:


    jes "Oh…"


translate spanish snakebunny_8a7b7d6c:


    "¿Por qué puso esa expresión? ¿Dije algo mal?"


translate spanish snakebunny_b007eb96:


    jes "¡Jajaja! Qué cosita tan curiosa, ¿eh?"


translate spanish snakebunny_bbb3891f:


    "Empieza a cerrar el puño, luego comienza a sacar un trozo de tela desde su palma."


translate spanish snakebunny_e13e12a8:


    "A medida que tira de ella, la tela solo se hace más y más larga."


translate spanish snakebunny_f7392af4:


    mc "¡¿Cómo es eso posible?!"


translate spanish snakebunny_6b9b7aff:


    "Aprieta la tela con fuerza."


translate spanish snakebunny_b986bf3b:


    "¿Qué está haciendo ahora?"


translate spanish snakebunny_354dc1bc:


    "Cuando la abre de nuevo, un pequeño muñeco de conejo aparece de repente dentro."


translate spanish snakebunny_ecebd32f:


    mc "¡Oh! ¡Eso es increíble!"


translate spanish snakebunny_68885399:


    jes "Y ahora, el espectáculo de magia del bufón real ha llegado a su fin. Gracias por su atención."


translate spanish bunnysnake_bc84d5b1:


    jes "Cuando elijo su mano derecha, aparece un pequeño muñeco de conejo."


translate spanish bunnysnake_640c5bae:


    jes "Una excelente elección, Su Majestad."


translate spanish bunnysnake_bc7fc48c:


    jes "Un regalo de mí… para usted."


translate spanish bunnysnake_78dff35c:


    "Da un paso atrás."


translate spanish bunnysnake_5ae637bc:


    "¿Acaba de hacer un truco de magia?"


translate spanish bunnysnake_d9a9687a:


    mc "¡Oh! ¡Eso es genial! ¿Cómo lo hiciste?"


translate spanish bunnysnake_597f50e6:


    "Jestyn guarda silencio por un momento, antes de que su sonrisa regrese lentamente."


translate spanish bunnysnake_c87ad347:


    jes "Ese es un secreto de bufón, querid[poss!t]. Nunca podría decírtelo~"


translate spanish bunnysnake_1a1e1df0:


    "Dijo Jestyn con tono juguetón."


translate spanish bunnysnake_b2afd01b:


    mc "Entonces… ¿puedo ver más?"


translate spanish bunnysnake_deeff8f2:


    jes "Oh…"


translate spanish bunnysnake_8a7b7d6c:


    "¿Por qué puso esa expresión? ¿Dije algo mal?"


translate spanish bunnysnake_b007eb96:


    jes "¡Jajaja! Qué cosita tan curiosa, ¿eh?"


translate spanish bunnysnake_bbb3891f:


    "Empieza a cerrar el puño, luego comienza a sacar un trozo de tela desde su palma."


translate spanish bunnysnake_e13e12a8:


    "A medida que tira de ella, la tela solo se hace más y más larga."


translate spanish bunnysnake_f7392af4:


    mc "¡¿Cómo es eso posible?!"


translate spanish bunnysnake_6b9b7aff:


    "Aprieta la tela con fuerza."


translate spanish bunnysnake_b986bf3b:


    "¿Qué está haciendo ahora?"


translate spanish bunnysnake_8509cf99:


    "Cuando la abre de nuevo, un pequeño muñeco de serpiente aparece de repente dentro."


translate spanish bunnysnake_ecebd32f:


    mc "¡Oh! ¡Eso es increíble!"


translate spanish bunnysnake_68885399:


    jes "Y ahora, el espectáculo de magia del bufón real ha llegado a su fin. Gracias por su atención."


translate spanish agree_1d66e373:


    jes "Qué decisión tan firme, Su Majestad."


translate spanish agree_88549114:


    jes "El oro tiene una forma de hacer que las decisiones difíciles parezcan… más simples."


translate spanish agree_13c3b0b7:


    jes "Esperemos que la tierra resulte menos costosa de lo que parece."


translate spanish Refuse_27f4f767:


    jes "¿Oh?"


translate spanish Refuse_2e654457:


    jes "Rechazar tal generosidad… qué admirable."


translate spanish Refuse_cc9ede7b:


    jes "Solo cabe esperar que nuestros vecinos compartan la apreciación de Su Majestad por los principios."


translate spanish delay_db12c9a8:


    jes "Jeje… ¿Su Majestad, en serio?"


translate spanish delay_0a968d07:


    jes "Seguramente no pretende seguir posponiendo sus decisiones cada vez que surge un problema."


translate spanish delay_ca508555:


    jes "Como me enorgullezco de ser un hombre honesto, debo decir… que eso es terriblemente ingenuo. Y bastante lamentable."


translate spanish delay_315de719:


    jes "Quizá deberíamos reformularlo. En lugar de “tomarse su tiempo para decidir”… podríamos llamarlo por lo que realmente es: “huir de sus problemas”."


translate spanish delay_4cd35246:


    jes "No importa qué tan lejos corra, no importa qué tan rápido corra… el tiempo siempre correrá a su lado."


translate spanish delay_58244563:


    jes "Así que… tic tac, tic tac, Su Majestad~"


translate spanish delay_cb35ed05:


    jes "Por supuesto, Su Majestad."


translate spanish delay_a120d3c0:


    jes "Después de todo, una decisión no tomada sigue siendo una decisión."


translate spanish delay_82634f5a:


    jes "El tiempo, sin embargo, rara vez es tan paciente como quisiéramos."


translate spanish collar_e5aed65e:


    mc "¿Un collar?"


translate spanish collar_ffdc22c3:


    "En su mano aparece un collar rojo, con una campana dorada en el centro."


translate spanish collar_16429228:


    jes "Así es, Su Majestad."


translate spanish collar_894d6f7f:


    "Luego se quita la corbata y afloja el cuello de su camisa."


translate spanish collar_acafd5f8:


    "Confundid[poss!t], solo puedo permanecer sentad[poss!t], incapaz de moverme."


translate spanish collar_722aa7ad:


    "Pero en el momento en que se coloca el collar alrededor del cuello, empiezo a entender lo que pretende."


translate spanish collar_cc94c9be:


    "Una vez ajustado, coloca suavemente la correa en mi mano."


translate spanish collar_2cf97c0f:


    "La tomo."


translate spanish collar_e7f9ccd9:


    jes "Por favor…"


translate spanish collar_5ecd1880:


    "Su voz se vuelve más pesada."


translate spanish collar_ab6bad21:


    jes "Soy suyo para que me dé órdenes, Su Majestad… Haga conmigo lo que desee."


translate spanish collar_bab2099c:


    "¡¿Cómo terminaron así las cosas?!"


translate spanish collar_77b3c401:


    mc "J–Jestyn… esto…"


translate spanish collar_db6d0895:


    jes "Puede ordenarme cualquier cosa, Su Majestad."


translate spanish collar_0e2c9658:


    jes "Sentarme. Acostarme. Abrir la boca… Lo que usted ordene, lo obedeceré."


translate spanish collar_050160d9:


    jes "Por favor, relájese, Su Majestad. Y disfrute conmigo."


translate spanish collar_3f232bfb:


    jes "Lo entretendré."


translate spanish collar_2e9a1000:


    "Nunca he hecho algo así antes."


translate spanish collar_8d1ae5a1:


    "Pero… si dice que hará cualquier cosa… entonces, supongo… está bien."


translate spanish sit_6cea9129:


    "En el momento en que doy la orden, Jestyn se sienta obedientemente en el suelo del escenario."


translate spanish sit_a0a396a9:


    "Me mira directamente, esperando mi siguiente orden."


translate spanish sit_a6f8b666:


    "Decido tirar de su collar, provocando un jadeo sorprendido en él."


translate spanish sit_e175d71d:


    "Su sonrisa solo se ensancha."


translate spanish sit_108799bc:


    jes "Su Majestad…"


translate spanish sit_4e3164ad:


    mc "Acércate."


translate spanish sit_88d535aa:


    "Se arrastra hacia mí."


translate spanish sit_2d215e23:


    "No puedo creer que realmente esté haciendo esto."


translate spanish sit_afaf268f:


    "Pero, extrañamente, a pesar de que aún siento miedo… se siente emocionante."


translate spanish sit_2876310e:


    "Observar ese rostro que nunca he podido descifrar detrás de esa sonrisa constante cambiar lentamente a algo casi… adorable."


translate spanish sit_50bf0686:


    jes "Había asumido que no tenía experiencia, Su Majestad…"


translate spanish sit_88fca87a:


    jes "Sin embargo, por lo que estoy viendo ahora, parece alguien mucho más… acostumbrado a este tipo de cosas."


translate spanish sit_76fcfa43:


    jes "Con otros…"


translate spanish sit_12c554f6:


    "Por un breve instante, la calidez en su sonrisa vacila."


translate spanish sit_c49840cf:


    "Algo más oscuro se filtra, una emoción que no puedo nombrar del todo… aguda y repentina, antes de que la oculte de nuevo."


translate spanish sit_30a740cb:


    mc "Claro que no. Nunca he hecho algo así antes. Solo estoy siguiendo mis instintos."


translate spanish sit_f694b0af:


    jes "Jeje… ¿es así?"


translate spanish sit_949d98d1:


    "Por impulso, levanto la mano y paso suavemente mis dedos por su gorro."


translate spanish sit_3968d4e4:


    "Por un momento, se tensa. Solo un poco, como si le sorprendiera la delicadeza del gesto."


translate spanish sit_ea073ec7:


    "Luego, lentamente, se relaja."


translate spanish sit_8ac2c9f1:


    "Jestyn cierra los ojos y se inclina hacia mi toque, como si buscara más."


translate spanish sit_1b489dd2:


    "La sonrisa que lleva ahora es diferente a la habitual. Es más suave, desprotegida, casi vulnerable."


translate spanish sit_60f757ec:


    "… Parece que le gusta."


translate spanish sit_99ed04fd:


    jes "… Es usted una persona amable, Su Majestad."


translate spanish sit_2727f7ad:


    mc "¿Qué le hace pensar eso?"


translate spanish sit_40b7c6a1:


    jes "Esperaba que fuera brusco conmigo en esta situación."


translate spanish sit_5eb35cff:


    jes "Pero en cambio, eligió tocarme con suavidad… Se siente extraño. Pero ciertamente no me quejaré de ello."


translate spanish sit_cc6d22af:


    "¿Ser amable es realmente tan extraño?"


translate spanish sit_196664a8:


    "Me sobresalto cuando Jestyn de repente baja la cabeza hasta mi regazo."


translate spanish sit_07bdde05:


    "….."


translate spanish sit_103ed00e:


    "Por alguna razón, se siente como si hubiera ganado una extraña pequeña mascota."


translate spanish sit_8480bbe8:


    "El miedo y la confusión que sentía antes se desvanecen lentamente, reemplazados por algo inesperadamente reconfortante."


translate spanish sit_70f40038:


    jes "…."


translate spanish sit_20b28c47:


    jes "Es la primera vez que siento algo así, Su Majestad."


translate spanish sit_dbfe3407:


    mc "¿…Sentido qué?"


translate spanish sit_e0e5e63a:


    jes "No lo sé. Extrañamente, no logro ponerlo en palabras."


translate spanish sit_2569494c:


    jes "Para alguien a quien le encanta hablar, normalmente nunca me quedo sin palabras cuando se trata de expresar lo que siento… lo que pienso."


translate spanish sit_afd26ec3:


    jes "Pero esto… no lo sé. Se siente como algo parecido a la felicidad, tal vez. Aunque ni siquiera esa palabra parece del todo correcta."


translate spanish sit_c06d04cc:


    jes "¿Quizá Su Majestad me ha lanzado un hechizo?"


translate spanish sit_c0a88657:


    "Dejo escapar una pequeña risa ante su ridícula suposición."


translate spanish sit_18128a90:


    mc "No seas tonto."


translate spanish sit_79c32605:


    "El silencio se instala entre nosotros por un momento. Pero no es incómodo."


translate spanish sit_86ee8078:


    "Durante todo ese tiempo, sigo acariciando la cabeza de Jestyn."


translate spanish sit_c70e6936:


    "Esta extraña situación de alguna manera me hace sentir en paz… Incluso mi miserable vida nunca se había sentido así."


translate spanish sit_d05e83be:


    "Después de varios minutos en la misma posición, Jestyn finalmente chasquea los dedos y, en un instante, el collar alrededor de su cuello desaparece."


translate spanish lie_d56c4269:


    "En el momento en que doy la orden, Jestyn se acuesta obedientemente en el suelo del escenario."


translate spanish lie_850ab860:


    "Después de que se recuesta, empiezo a caminar hacia él."


translate spanish lie_b8c4b568:


    "Me mira desde abajo, esperando mi siguiente orden."


translate spanish lie_a6f8b666:


    "Decido tirar de su collar, provocando un jadeo sorprendido en él."


translate spanish lie_e175d71d:


    "Su sonrisa solo se ensancha."


translate spanish lie_108799bc:


    jes "Su Majestad…"


translate spanish lie_f54adde4:


    "Está bien… nunca he hecho algo así en mi vida. ¿Qué suele hacer la gente en situaciones como esta?"


translate spanish lie_e678444f:


    "He visto a personas pisar a sus parejas antes… ¿debería intentarlo?"


translate spanish lie_16cfddb0:


    "Armado con el poco conocimiento que recogí de internet, coloco cuidadosamente mi pie sobre su pecho."


translate spanish lie_ec795997:


    jes "Nnn…"


translate spanish lie_910c6ad9:


    "Sí pongo mi pie ahí, pero estoy segur[poss!t] de que puede notar que aún dudo."


translate spanish lie_287019d6:


    "No estoy ejerciendo presión real sobre él."


translate spanish lie_6f9e3eef:


    jes "Jeje… Su Majestad, es usted muy adorable."


translate spanish lie_cd2666c8:


    mc "Hm…?"


translate spanish lie_5300157c:


    jes "Está intentando ser brusc[poss!t]… pero parece que su corazón es demasiado gentil para eso."


translate spanish lie_658671f0:


    "Tal como pensé, lo notó."


translate spanish lie_625098f1:


    jes "Es muy dulce saber que no quiere lastimarme, Su Majestad… Pero tenga la seguridad de que estaré bien."


translate spanish lie_c42d3b38:


    jes "Así que, si desea ser brusc[poss!t] conmigo… por favor, no dude."


translate spanish lie_34b5a568:


    "Mi corazón empieza a latir con fuerza, el sudor humedece mi espalda."


translate spanish lie_4edac704:


    "¿Cómo se supone que voy a saber cuándo me he pasado… y cuándo no?"


translate spanish lie_98252d2e:


    "Percibiendo mi miedo e incertidumbre, Jestyn decide guiarme."


translate spanish lie_796ed025:


    jes "Concentre su fuerza en su pie, luego presiónelo lentamente contra mi pecho."


translate spanish lie_fed21080:


    "Sigo sus instrucciones."


translate spanish lie_a37f9832:


    "Cambio mi peso hacia el pie y presiono suavemente el pecho de Jestyn."


translate spanish lie_a568a0f2:


    jes "…Muy bien…"


translate spanish lie_92603e66:


    jes "¿Ve? Sigo perfectamente bien…"


translate spanish lie_8ce61eb8:


    "Asiento con la cabeza."


translate spanish lie_a9a4b134:


    jes "Ahora intente pisar con más fuerza, Su Majestad… solo una vez."


translate spanish lie_90b5f220:


    "Cuando piso su pecho, Jestyn deja escapar un suave sonido que hace que mi corazón lata aún más rápido."


translate spanish lie_3cdc56b9:


    "Esto… se siente extrañamente bien."


translate spanish lie_4310fc6a:


    jes "Ahora está aprendiendo, Su Majestad… Intente pisar mi pecho mientras tira de mi collar."


translate spanish lie_7aa9032c:


    "Presiono mi pie contra su pecho nuevamente mientras tiro de su collar."


translate spanish lie_c7e89d52:


    jes "Ah—"


translate spanish lie_5cd5fa89:


    "El rostro de Jestyn se enrojece aún más."


translate spanish lie_b13c6026:


    jes "¿Qué le parece su regalo hasta ahora, Su Majestad…? ¿Lo está disfrutando…?"


translate spanish lie_5f9b772e:


    "…."


translate spanish lie_fe9daad5:


    mc "S–sí… esto es agradable…"


translate spanish lie_f2dcf0de:


    "Quizá podría intentar algo más."


translate spanish lie_8c06c07f:


    "Esta vez, coloco mi mano sobre su pecho y la deslizo lentamente sobre él."


translate spanish lie_152be7c4:


    jes "Nh… oh… ya veo…"


translate spanish lie_1fb6601e:


    jes "De ser brusco a ser gentil… ¿me está recompensando por complacerl[poss!t], Su Majestad?"


translate spanish lie_e015665d:


    mc "…Puede verlo de esa manera."


translate spanish lie_fad5a13f:


    "Mi mano, que estaba sobre su pecho, se desliza lentamente hacia su cuello, hacia el collar."


translate spanish lie_77e4b7ea:


    "Empiezo a acariciar su cuello lentamente."


translate spanish lie_108799bc_1:


    jes "Su Majestad…"


translate spanish lie_64fa8269:


    "Eso es extraño…"


translate spanish lie_e3534c32:


    "Cuando pasé mi mano por su cuello, la textura no era dura como la superficie de una marioneta que imaginaba."


translate spanish lie_4cf27b1a:


    "Se sentía suave, como piel humana. Pero más fría."


translate spanish lie_1b3cc250:


    "¿Qué tipo de marioneta es realmente…?"


translate spanish lie_25b5e8f8:


    "Después de quedarme ahí un momento, mi mano sube hasta su mejilla."


translate spanish lie_4c8c3a2e:


    "Cada sonido que hace en respuesta a mi toque se siente extrañamente satisfactorio de escuchar."


translate spanish lie_71140198:


    "Sus ojos se ven nublados, su rostro enrojecido."


translate spanish lie_b4a72430:


    "Increíble… que una marioneta pueda sentir algo así."


translate spanish lie_4995b5a9:


    "Mi pulgar roza suavemente sus labios."


translate spanish lie_70f40038:


    jes "…."


translate spanish lie_451c7b35:


    jes "Su Majestad… nunca había sentido algo así antes…"


translate spanish lie_1b562e8f:


    mc "¿Te refieres a la sensación del BDSM?"


translate spanish lie_ef109917:


    jes "Jeje, no, no, no… eso lo he sentido muchas veces antes."


translate spanish lie_9464975f:


    jes "A lo que me refiero es a esta sensación… esa que ni siquiera puedo poner en palabras."


translate spanish lie_ea087d74:


    jes "Se siente… agradable. Pero no estoy seguro de que esa palabra sea la correcta para describir lo que siento ahora mismo."


translate spanish lie_49d1e513:


    jes "Dígame, Su Majestad… ¿acaso ha usado magia prohibida en mí?"


translate spanish lie_a4b25528:


    "Dejo escapar una risa confundida ante su ridícula suposición."


translate spanish lie_18128a90:


    mc "No seas tonto."


translate spanish lie_c70e6936:


    "Esta extraña situación de alguna manera me hace sentir en paz… Incluso mi miserable vida nunca se había sentido así."


translate spanish lie_440585cc:


    "Después de varios minutos, Jestyn finalmente chasquea los dedos y, en un instante, el collar alrededor de su cuello desaparece."


translate spanish bad_end_6735111c:


    jes "Muy bien. Informaré a nuestros vecinos de la voluntad de Su Majestad."


translate spanish bad_end_661a8003:


    jes "Y creo que, por ahora, los asuntos que Su Majestad debía resolver han llegado al final del programa de hoy."


translate spanish bad_end_093871f9:


    "Por fin… terminó. No sé si mi cerebro pueda soportar más cosas de este reino."


translate spanish bad_end_3911f608:


    jes "Debe estar cansad[poss!t], Su Majestad. ¿Qué tal si hacemos algo… relajante?"


translate spanish bad_end_c3877920:


    jes "¿Quizá un baile?"


translate spanish bad_end_a12ac849:


    "Jestyn me ofreció su mano, invitándome a bailar."


translate spanish bad_end_84e497be:


    mc "Pero nunca he bailado antes…"


translate spanish bad_end_4833ecfd:


    jes "Eso no será un problema, Su Majestad. Este baile es muy lento. No le causará ninguna dificultad."


translate spanish bad_end_d34a6d6a:


    "Dudé por un momento. Pero al ver esa expresión en su rostro, sentí que no podía negarme."


translate spanish bad_end_900966a3:


    mc "Está bien…"


translate spanish bad_end_c408cc1d:


    "En el momento en que tomé su mano, las luces del escenario se apagaron de repente."


translate spanish bad_end_19b3acff:


    "Y cuando volvieron a encenderse, sin darme cuenta, ya estaba en posición de baile con Jestyn."


translate spanish bad_end_243ba97a:


    "Los pasos de Jestyn eran tan lentos como había prometido."


translate spanish bad_end_a0e58515:


    "Y yo seguí su ritmo."


translate spanish bad_end_8424413b:


    "No dijimos una palabra. Solo la música de baile llenaba el silencio en el escenario."


translate spanish bad_end_e6bf0375:


    jes "Lo está haciendo bastante bien, Su Majestad."


translate spanish bad_end_66d44c0a:


    mc "…Solo lo estoy siguiendo."


translate spanish bad_end_b2c0340c:


    jes "Y eso es más que suficiente."


translate spanish bad_end_405dd147:


    "La sala volvió a quedar en silencio."


translate spanish bad_end_36e91ef5:


    jes "¿Sabe cómo se llama este baile, Su Majestad?"


translate spanish bad_end_da2d9e9d:


    mc "No lo creo."


translate spanish bad_end_dab30120:


    jes "Podría decirse que este es el baile más icónico del Reino de las Marionetas."


translate spanish bad_end_15d48f8a:


    jes "Al final de cada función, siempre bailamos este."


translate spanish bad_end_8e4b4abf:


    jes "Lo llamamos Danza Macabra."


translate spanish bad_end_dd55df2c:


    "Nuestros pasos se volvieron más perfectamente sincronizados después de que Jestyn dijera eso."


translate spanish bad_end_5f213e86:


    mc "Danza Macabra…"


translate spanish bad_end_a1524c15:


    mc "Nunca había oído hablar de ella. ¿Por qué se llama así?"


translate spanish bad_end_f62eac9a:


    "De repente, un fuerte mareo me invadió la cabeza."


translate spanish bad_end_0d4d6fde:


    "Mi cabeza… duele mucho."


translate spanish bad_end_dfadc1e1:


    "Siento como si algo dentro de mí estuviera siendo lentamente arrancado."


translate spanish bad_end_2188e88d:


    "Mis pasos vacilaron, y todo mi cuerpo se debilitó en un instante."


translate spanish bad_end_c4375ca6:


    "Pero el brazo de Jestyn me sostuvo, evitando que cayera."


translate spanish bad_end_e34e4811:


    "Todo mi cuerpo se volvió débil y comenzó a temblar."


translate spanish bad_end_5f6689ad:


    mc "J–Jestyn… ¿qué es—"


translate spanish bad_end_bbd50ba8:


    jes "Pasaron segundos… luego horas… días… semanas… meses… años…"


translate spanish bad_end_cfeb39ac:


    jes "Ha pasado tanto tiempo desde que todo aquello se desvaneció."


translate spanish bad_end_7d7d8357:


    jes "Y después de tanto…"


translate spanish bad_end_84c60eaf:


    jes "Parece que el destino aún no está de nuestro lado."


translate spanish bad_end_3a8cf506:


    jes "Al final, este destino sin rumbo nuestro debe continuar su camino."


translate spanish bad_end_07eb5fcf:


    jes "Porque, en última instancia… no eres digno."


translate spanish bad_end_8794e25a:


    jes "Tu mandato como [obj!t] [title!t] termina aquí. Ahora, es hora de que descanses en paz."


translate spanish bad_end_355059a8:


    jes "Cierra los ojos… y deja que este baile te guíe hacia la serenidad eterna."


translate spanish bad_end_eb515044:


    jes "Fin."


translate spanish cursed1_d7afdc3b:


    mc "Yo—"


translate spanish cursed1_fa8c385a:


    "De repente, mi cabeza duele muchísimo."


translate spanish cursed1_30eb29fd:


    "Todo a mi alrededor se vuelve borroso."


translate spanish cursed1_23adb90c:


    mc "{color=#FF2727}Mmmm… qué desafortunado. Mis pobres agricultores…{/color}"


translate spanish cursed1_7861c5d0:


    mc "{color=#FF2727}Como su reina, es natural que provea para ustedes. Nunca ignoraría sus dificultades.{/color}"


translate spanish cursed1_75ea4c4b:


    mc "{color=#FF2727}¿Dinero? ¿Semillas más finas de la más alta calidad? ¿Quizá comida para aliviar sus cargas?{/color}"


translate spanish cursed1_486300be:


    farm "O-oh… Su Majestad es demasiado generosa…"


translate spanish cursed1_91fc4504:


    mc "{color=#FF2727}Sin embargo…{/color}"


translate spanish cursed1_18f59c3b:


    mc "{color=#FF2727}Si voy a derramar mi generosidad sobre ustedes… ¿no deberían ofrecer algo a cambio?{/color}"


translate spanish cursed1_7914871d:


    mc "{color=#FF2727}De lo contrario sería terriblemente injusto, ¿no es así? Yo doy, y ustedes simplemente reciben.{/color}"


translate spanish cursed1_a6ddc768:


    mc "{color=#FF2727}No… si voy a bendecirlos con tal bondad, entonces espero que su lealtad… y su trabajo… reflejen su gratitud.{/color}"


translate spanish cursed1_4d38ab1b:


    farm "¡T–Tiene toda la razón, Su Majestad! ¡Me dedicaré por completo!"


translate spanish cursed1_70f40038:


    jes "…."


translate spanish cursed1_1b46e124:


    jes "Qué notable, Su Majestad."


translate spanish cursed1_f9fd318f:


    jes "Solo cabe esperar que sus acciones sean tan dulces como sus palabras."


translate spanish cursed1_ec969f39:


    jes "…¿En serio?"


translate spanish cursed1_329ddb6e:


    "{color=#FF2727}…….{/color}"


translate spanish cursed1_0fd4d656:


    "……"


translate spanish cursed1_42051be0:


    mc "S–…Sí… en efecto."


translate spanish cursed2_1ad94e56:


    mc "{color=#FF2727}¿Oh? ¿Comercio, dices?{/color}"


translate spanish cursed2_bae050fd:


    mc "{color=#FF2727}Esa es una propuesta bastante interesante.{/color}"


translate spanish cursed2_bc7c3c59:


    mc "{color=#FF2727}Muy bien. ¿Por qué no?{/color}"


translate spanish cursed2_f1c4eb89:


    mc "{color=#FF2727}Tomo esta decisión por el bien de mi pueblo.{/color}"


translate spanish cursed2_7e28d336:


    mc "{color=#FF2727}El comercio será mucho más conveniente para ellos. Y al mismo tiempo, podremos establecer lazos más fuertes con otro reino.{/color}"


translate spanish cursed2_c01f7d84:


    jes "Hm…? Sí, esa es ciertamente una decisión comprensible, Su Majestad."


translate spanish cursed2_97fd71fe:


    jes "Por sus palabras, parece estar profundamente preocupada por su pueblo."


translate spanish cursed2_a4f31376:


    jes "Mmm… pero, ¿qué hay de los ciudadanos que viven en la tierra que pretende vender, Su Majestad?"


translate spanish cursed2_8456d889:


    jes "Si se deshace de ella… ¿no significaría eso que deben abandonar sus hogares?"


translate spanish cursed2_b7c129b6:


    jes "Parece bastante contradictorio con lo que acaba de decir sobre preocuparse tanto por su gente."


translate spanish cursed2_eed8927c:


    jes "A menos que… ¿sea usted una mentirosa, Su Majestad~?"


translate spanish cursed2_968c8596:


    mc "{color=#FF2727}Jaja… Jestyn…{/color}"


translate spanish cursed2_d1032bef:


    mc "{color=#FF2727}¿Está cuestionando mi decisión?{/color}"


translate spanish cursed2_50611cc0:


    jes "……"


translate spanish cursed2_3ea684e4:


    jes "Oh, por supuesto que no, Su Majestad. Qué tonto de mi parte. Incluso pensar en cuestionar su juicio…"


translate spanish cursed2_6c7d49d5:


    jes "En efecto. Todo es por el bien de todo el reino."


translate spanish cursed2_372cd5aa:


    jes "Muy bien entonces. Informaré a nuestros vecinos de la voluntad de Su Majestad."


translate spanish cursed2_661a8003:


    jes "Y creo que, por ahora, los asuntos que Su Majestad debía resolver han llegado al final del programa de hoy."


translate spanish cursed2_917307e9:


    jes "Puede descansar ahora, Su Majestad~"


translate spanish cursed2_7af8e284:


    jes "¡Oh! Casi lo olvido, Su Majestad. Antes de eso, tengo un regalo para usted."


translate spanish cursed2_6a22b7be:


    mc "¿Eh…? ¿Qué regalo—?"


translate spanish cursed2_0a956b60:


    "Una cuerda se enrolló de repente alrededor de mi cuerpo después de que Jestyn chasqueara los dedos."


translate spanish cursed2_68492187:


    "Chasqueó los dedos una vez más. Un hacha apareció en su mano."


translate spanish cursed2_c9e9ed07:


    "El pánico se apoderó de mí al instante."


translate spanish cursed2_05e3f134:


    mc "¡¿Q–Qué estás haciendo?!"


translate spanish cursed2_534af6fb:


    "Sin responder a mi pregunta, Jestyn blandió el hacha hacia mi cuello."


translate spanish cursed2_84d35058:


    jes "Espero que tenga un buen sueño esta vez, [player_call]"


translate spanish handsome_d44e7d4f:


    "Su expresión irritada cambió instantáneamente a confusión y sorpresa."


translate spanish handsome_0ce78278:


    kni "¿Qué demonios acabas de decir?"


translate spanish handsome_a54ff068:


    mc "Solo estaba diciendo la verdad."


translate spanish handsome_9b5b6b19:


    "Sinceramente, no estaba seguro de si decir eso era una buena idea."


translate spanish handsome_4722190d:


    kni "Debe haber algo mal en tu cabeza. ¿De verdad estás diciendo la verdad?"


translate spanish handsome_36f5b714:


    "Oh, ¿acabo de lograr suavizarlo un poco?"


translate spanish handsome_81b5e682:


    mc "Por supuesto~. ¿Quién podría resistirse a un rostro tan apuesto?"


translate spanish handsome_7b7a20db:


    mc "Estoy segur[poss!t] de que cualquiera que te vea por primera vez se volvería completamente loco por ti, al cien por ciento."


translate spanish handsome_2740387a:


    "Sus labios se curvaron lentamente en una sonrisa."


translate spanish handsome_56e38707:


    kni "Jeh. En ese caso, mereces morir."


translate spanish handsome_9d469299:


    "Mierda."


translate spanish notreally_dd94f96d:


    mc "Bueno… eh, en realidad no…"


translate spanish notreally_492bf80b:


    kni "En ese caso, mereces morir."


translate spanish notreally_9d469299:


    "Mierda."


translate spanish juggle_cf7942b1:


    mc "¿Dónde aprendiste a hacer malabares?"


translate spanish juggle_2980266b:


    jes "No esperaba que Su Majestad mostrara tanto interés en los malabares."


translate spanish juggle_5311080f:


    jes "Hmmmm… déjame pensar un momento…"


translate spanish juggle_73ec2189:


    "Golpea suavemente su dedo índice mientras reflexiona."


translate spanish juggle_f75bae67:


    jes "Ah, sí… el Maestro Adam."


translate spanish juggle_6ebcf28f:


    mc "Eh… ¿Quién es ese?"


translate spanish juggle_1324166a:


    jes "Es quien me enseñó a interpretar correctamente el papel de un verdadero bufón real."


translate spanish juggle_21986bd3:


    jes "La persona que soy hoy existe gracias a él. Y naturalmente, eso incluye la forma adecuada de hacer malabares."


translate spanish juggle_2b3ce3e9:


    mc "Suena como alguien importante."


translate spanish juggle_40f5e215:


    jes "En efecto, lo era. Un caballero muy amable."

translate spanish strings:


    old "Check Jester puppet"
    new "Revisar bufón marioneta"


    old "Check Knight puppet"
    new "Revisar caballero marioneta"


    old "Check King puppet"
    new "Revisar rey marioneta"


    old "Check the next puppet"
    new "Revisar la siguiente marioneta"


    old "Keep silent"
    new "Guardar silencio"


    old "Who are you?"
    new "¿Quién eres?"


    old "Run"
    new "Correr"


    old "Left"
    new "Izquierda"


    old "Right"
    new "Derecha"


    old "Sit"
    new "Sentarse"


    old "Lie down"
    new "Acostarse"

    old "she"
    new "ella"

    old "her"
    new "la"

    old "her_"
    new "a"

    old "herself"
    new "sí misma"

    old "queen"
    new "reina"

    old "he"
    new "él"

    old "him"
    new "el"

    old "his"
    new "o"

    old "himself"
    new "sí mismo"

    old "king"
    new "rey"


    old "they"
    new "elle"

    old "them"
    new "le"

    old "their"
    new "e"

    old "themself"
    new "sí misme"

    old "ruler"
    new "gobernante"

    old "What is your name?"
    new "¿Cómo te llamas?"

    old "{size=70}{b}{color=#ff0000}WARNING{/color}{/b}{/size}\n\nThis game contains Mild swearing , Screen shaking effects, Manipulative behavior, \nToxic relationship dynamics, Jump scares, Obsessive behavior, Light BDSM, Suggestive content.\n\nPlayer discretion is advised."
    new "{size=70}{b}{color=#ff0000}ADVERTENCIA{/color}{/b}{/size}\n\nEste juego contiene lenguaje leve, efectos de sacudida de pantalla, comportamiento manipulador, \ndinámicas de relaciones tóxicas, sustos repentinos, comportamiento obsesivo, BDSM leve y contenido sugestivo.\n\nSe recomienda discreción del jugador."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
