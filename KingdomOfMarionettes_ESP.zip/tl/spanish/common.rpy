

translate spanish strings:


    old "Self-voicing disabled."
    new "Autonarración desactivada."


    old "Clipboard voicing enabled. "
    new "Narración del portapapeles activada."


    old "Self-voicing enabled. "
    new "Autonarración activada."


    old "bar"
    new "barra"


    old "selected"
    new "seleccionado"


    old "viewport"
    new "ventana visible"


    old "horizontal scroll"
    new "desplazamiento horizontal"


    old "vertical scroll"
    new "desplazamiento vertical"


    old "activate"
    new "activar"


    old "deactivate"
    new "desactivar"


    old "increase"
    new "aumentar"


    old "decrease"
    new "disminuir"


    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Menú de accesibilidad. Usa las flechas arriba y abajo para navegar, y enter para activar botones y barras."


    old "Font Override"
    new "Sustitución de fuente"


    old "Default"
    new "Predeterminado"


    old "DejaVu Sans"
    new "DejaVu Sans"


    old "Opendyslexic"
    new "Opendyslexic"


    old "Text Size Scaling"
    new "Escalado del tamaño de texto"


    old "Reset"
    new "Restablecer"


    old "Line Spacing Scaling"
    new "Escalado del espaciado de líneas"


    old "High Contrast Text"
    new "Texto de alto contraste"


    old "Enable"
    new "Activar"


    old "Disable"
    new "Desactivar"


    old "Self-Voicing"
    new "Autonarración"


    old "Self-voicing support is limited when using a touch screen."
    new "El soporte de autonarración es limitado cuando se usa una pantalla táctil."


    old "Off"
    new "Desactivado"


    old "Text-to-speech"
    new "Texto a voz"


    old "Clipboard"
    new "Portapapeles"


    old "Debug"
    new "Depuración"


    old "Self-Voicing Volume Drop"
    new "Reducción de volumen de autonarración"


    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Las opciones de este menú están destinadas a mejorar la accesibilidad. Puede que no funcionen con todos los juegos, y algunas combinaciones de opciones pueden hacer que el juego sea injugable. Esto no es un problema del juego ni del motor. Para obtener mejores resultados al cambiar fuentes, intenta mantener el tamaño del texto igual al original."


    old "{#weekday}Monday"
    new "{#weekday}Lunes"


    old "{#weekday}Tuesday"
    new "{#weekday}Martes"


    old "{#weekday}Wednesday"
    new "{#weekday}Miércoles"


    old "{#weekday}Thursday"
    new "{#weekday}Jueves"


    old "{#weekday}Friday"
    new "{#weekday}Viernes"


    old "{#weekday}Saturday"
    new "{#weekday}Sábado"


    old "{#weekday}Sunday"
    new "{#weekday}Domingo"


    old "{#weekday_short}Mon"
    new "{#weekday_short}Lun"


    old "{#weekday_short}Tue"
    new "{#weekday_short}Mar"


    old "{#weekday_short}Wed"
    new "{#weekday_short}Mié"


    old "{#weekday_short}Thu"
    new "{#weekday_short}Jue"


    old "{#weekday_short}Fri"
    new "{#weekday_short}Vie"


    old "{#weekday_short}Sat"
    new "{#weekday_short}Sáb"


    old "{#weekday_short}Sun"
    new "{#weekday_short}Dom"


    old "{#month}January"
    new "{#month}Enero"


    old "{#month}February"
    new "{#month}Febrero"


    old "{#month}March"
    new "{#month}Marzo"


    old "{#month}April"
    new "{#month}Abril"


    old "{#month}May"
    new "{#month}Mayo"


    old "{#month}June"
    new "{#month}Junio"


    old "{#month}July"
    new "{#month}Julio"


    old "{#month}August"
    new "{#month}Agosto"


    old "{#month}September"
    new "{#month}Septiembre"


    old "{#month}October"
    new "{#month}Octubre"


    old "{#month}November"
    new "{#month}Noviembre"


    old "{#month}December"
    new "{#month}Diciembre"


    old "{#month_short}Jan"
    new "{#month_short}Ene"


    old "{#month_short}Feb"
    new "{#month_short}Feb"


    old "{#month_short}Mar"
    new "{#month_short}Mar"


    old "{#month_short}Apr"
    new "{#month_short}Abr"


    old "{#month_short}May"
    new "{#month_short}May"


    old "{#month_short}Jun"
    new "{#month_short}Jun"


    old "{#month_short}Jul"
    new "{#month_short}Jul"


    old "{#month_short}Aug"
    new "{#month_short}Ago"


    old "{#month_short}Sep"
    new "{#month_short}Sep"


    old "{#month_short}Oct"
    new "{#month_short}Oct"


    old "{#month_short}Nov"
    new "{#month_short}Nov"


    old "{#month_short}Dec"
    new "{#month_short}Dic"


    old "%b %d, %H:%M"
    new "%b %d, %H:%M"


    old "Save slot %s: [text]"
    new "Ranura de guardado %s: [text]"


    old "Load slot %s: [text]"
    new "Cargar ranura %s: [text]"


    old "Delete slot [text]"
    new "Eliminar ranura [text]"


    old "File page auto"
    new "Página de archivos auto"


    old "File page quick"
    new "Página de archivos rápida"


    old "File page [text]"
    new "Página de archivos [text]"


    old "Next file page."
    new "Siguiente página de archivos."


    old "Previous file page."
    new "Página de archivos anterior."


    old "Quick save complete."
    new "Guardado rápido completado."


    old "Quick save."
    new "Guardado rápido."


    old "Quick load."
    new "Carga rápida."


    old "Language [text]"
    new "Idioma [text]"


    old "Open [text] directory."
    new "Abrir directorio [text]."


    old "The interactive director is not enabled here."
    new "El director interactivo no está habilitado aquí."


    old "⬆"
    new "⬆"


    old "⬇"
    new "⬇"


    old "Done"
    new "Hecho"


    old "(statement)"
    new "(sentencia)"


    old "(tag)"
    new "(etiqueta)"


    old "(attributes)"
    new "(atributos)"


    old "(transform)"
    new "(transformación)"


    old "(transition)"
    new "(transición)"


    old "(channel)"
    new "(canal)"


    old "(filename)"
    new "(nombre de archivo)"


    old "Change"
    new "Cambiar"


    old "Add"
    new "Agregar"


    old "Cancel"
    new "Cancelar"


    old "Remove"
    new "Eliminar"


    old "Statement:"
    new "Sentencia:"


    old "Tag:"
    new "Etiqueta:"


    old "Attributes:"
    new "Atributos:"


    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Haz clic para alternar atributo, clic derecho para alternar atributo negativo."


    old "Transforms:"
    new "Transformaciones:"


    old "Click to set transform, right click to add to transform list."
    new "Haz clic para establecer transformación, clic derecho para añadir a la lista de transformaciones."


    old "Customize director.transforms to add more transforms."
    new "Personaliza director.transforms para añadir más transformaciones."


    old "Behind:"
    new "Detrás:"


    old "Click to set, right click to add to behind list."
    new "Haz clic para establecer, clic derecho para añadir a la lista de “detrás”."


    old "Transition:"
    new "Transición:"


    old "Click to set."
    new "Haz clic para establecer."


    old "Customize director.transitions to add more transitions."
    new "Personaliza director.transitions para añadir más transiciones."


    old "Channel:"
    new "Canal:"


    old "Customize director.audio_channels to add more channels."
    new "Personaliza director.audio_channels para añadir más canales."


    old "Audio Filename:"
    new "Nombre de archivo de audio:"


    old "Are you sure?"
    new "¿Estás seguro?"


    old "Are you sure you want to delete this save?"
    new "¿Estás seguro de que deseas eliminar este guardado?"


    old "Are you sure you want to overwrite your save?"
    new "¿Estás seguro de que deseas sobrescribir tu guardado?"


    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Cargar hará que pierdas el progreso no guardado.\n¿Estás seguro de que deseas hacer esto?"


    old "Are you sure you want to quit?"
    new "¿Estás seguro de que deseas salir?"


    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "¿Estás seguro de que deseas volver al menú principal?\nEsto hará que pierdas el progreso no guardado."


    old "Are you sure you want to continue where you left off?"
    new "¿Estás seguro de que deseas continuar desde donde lo dejaste?"


    old "Are you sure you want to end the replay?"
    new "¿Estás seguro de que deseas terminar la repetición?"


    old "Are you sure you want to begin skipping?"
    new "¿Estás seguro de que deseas comenzar a omitir?"


    old "Are you sure you want to skip to the next choice?"
    new "¿Estás seguro de que deseas omitir hasta la siguiente elección?"


    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "¿Estás seguro de que deseas omitir diálogos no vistos hasta la siguiente elección?"


    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Este guardado fue creado en un dispositivo diferente. Archivos de guardado creados maliciosamente pueden dañar tu computadora. ¿Confías en el creador de este guardado y en cualquiera que haya podido modificar el archivo?"


    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "¿Confías en el dispositivo en el que se creó el guardado? Solo debes elegir sí si eres el único usuario del dispositivo."


    old "Failed to save screenshot as %s."
    new "No se pudo guardar la captura de pantalla como %s."


    old "Saved screenshot as %s."
    new "Captura de pantalla guardada como %s."


    old "Skip Mode"
    new "Modo de omisión"


    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Este programa contiene software libre bajo varias licencias, incluyendo la Licencia MIT y la Licencia Pública General Reducida de GNU. Una lista completa del software, incluyendo enlaces al código fuente completo, se puede encontrar {a=https://www.renpy.org/l/license}aquí{/a}"


    old "display"
    new "visualización"


    old "transitions"
    new "transiciones"


    old "skip transitions"
    new "omitir transiciones"


    old "video sprites"
    new "sprites de video"


    old "show empty window"
    new "mostrar ventana vacía"


    old "text speed"
    new "velocidad del texto"


    old "joystick"
    new "joystick"


    old "joystick..."
    new "joystick..."


    old "skip"
    new "omitir"


    old "skip unseen [text]"
    new "omitir texto no visto [text]"


    old "skip unseen text"
    new "omitir texto no visto"


    old "begin skipping"
    new "comenzar a omitir"


    old "after choices"
    new "después de elecciones"


    old "skip after choices"
    new "omitir después de elecciones"


    old "auto-forward time"
    new "tiempo de avance automático"


    old "auto-forward"
    new "avance automático"


    old "Auto forward"
    new "Avance automático"


    old "auto-forward after click"
    new "avance automático tras clic"


    old "automatic move"
    new "movimiento automático"


    old "wait for voice"
    new "esperar voz"


    old "voice sustain"
    new "mantener voz"


    old "self voicing"
    new "autonarración"


    old "self voicing enable"
    new "activar autonarración"


    old "self voicing disable"
    new "desactivar autonarración"


    old "self voicing volume drop"
    new "reducción de volumen de autonarración"


    old "clipboard voicing"
    new "narración del portapapeles"


    old "clipboard voicing enable"
    new "activar narración del portapapeles"


    old "clipboard voicing disable"
    new "desactivar narración del portapapeles"


    old "debug voicing"
    new "narración de depuración"


    old "debug voicing enable"
    new "activar narración de depuración"


    old "debug voicing disable"
    new "desactivar narración de depuración"


    old "emphasize audio"
    new "enfatizar audio"


    old "rollback side"
    new "lado de retroceso"


    old "gl powersave"
    new "ahorro de energía GL"


    old "gl framerate"
    new "frecuencia de cuadros GL"


    old "gl tearing"
    new "desgarro de imagen GL"


    old "font transform"
    new "transformación de fuente"


    old "font size"
    new "tamaño de fuente"


    old "font line spacing"
    new "espaciado de línea de fuente"


    old "system cursor"
    new "cursor del sistema"


    old "renderer menu"
    new "menú de renderizado"


    old "accessibility menu"
    new "menú de accesibilidad"


    old "high contrast text"
    new "texto de alto contraste"


    old "audio when minimized"
    new "audio minimizado"


    old "audio when unfocused"
    new "audio sin enfoque"


    old "web cache preload"
    new "precarga de caché web"


    old "voice after game menu"
    new "voz tras menú del juego"


    old "restore window position"
    new "restaurar posición de ventana"


    old "reset"
    new "restablecer"


    old "main volume"
    new "volumen principal"


    old "music volume"
    new "volumen de música"


    old "sound volume"
    new "volumen de sonido"


    old "voice volume"
    new "volumen de voz"


    old "mute main"
    new "silenciar principal"


    old "mute music"
    new "silenciar música"


    old "mute sound"
    new "silenciar sonido"


    old "mute voice"
    new "silenciar voz"


    old "mute all"
    new "silenciar todo"


    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Narración del portapapeles activada. Presiona 'shift+C' para desactivar."


    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "La autonarración diría \"[renpy.display.tts.last]\". Presiona 'alt+shift+V' para desactivar."


    old "Self-voicing enabled. Press 'v' to disable."
    new "Autonarración activada. Presiona 'v' para desactivar."


    old "Speech Bubble Editor"
    new "Editor de burbujas de diálogo"


    old "(hide)"
    new "(ocultar)"


    old "(clear retained bubbles)"
    new "(borrar burbujas retenidas)"


    old "Sync downloaded."
    new "Sincronización descargada."


    old "Could not connect to the Ren'Py Sync server."
    new "No se pudo conectar al servidor de sincronización de Ren'Py."


    old "The Ren'Py Sync server timed out."
    new "El servidor de sincronización de Ren'Py agotó el tiempo de espera."


    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Ocurrió un error desconocido al conectarse al servidor de sincronización de Ren'Py."


    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "El servidor de sincronización de Ren'Py no tiene una copia de esta sincronización. El ID puede ser inválido o haber expirado."


    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Por favor, introduce el ID de sincronización que generaste.\nNunca introduzcas un ID que no hayas creado tú mismo."


    old "The sync ID is not in the correct format."
    new "El ID de sincronización no tiene el formato correcto."


    old "The sync could not be decrypted."
    new "No se pudo descifrar la sincronización."


    old "The sync belongs to a different game."
    new "La sincronización pertenece a otro juego."


    old "The sync contains a file with an invalid name."
    new "La sincronización contiene un archivo con un nombre inválido."


    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Esto subirá tus guardados al {a=https://sync.renpy.org}Servidor de Sincronización de Ren'Py{/a}.\n¿Deseas continuar?"


    old "Enter Sync ID"
    new "Introducir ID de sincronización"


    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Esto contactará al {a=https://sync.renpy.org}Servidor de Sincronización de Ren'Py{/a}."


    old "Sync Success"
    new "Sincronización exitosa"


    old "The Sync ID is:"
    new "El ID de sincronización es:"


    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Puedes usar este ID para descargar tu guardado en otro dispositivo.\nEsta sincronización expirará en una hora.\nRen'Py Sync es soportado por {a=https://www.renpy.org/sponsors.html}los patrocinadores de Ren'Py{/a}."


    old "Continue"
    new "Continuar"


    old "Sync Error"
    new "Error de sincronización"


    old "Translation identifier: [identifier]"
    new "Identificador de traducción: [identifier]"


    old " translates [tl.filename]:[tl.linenumber]"
    new "traduce [tl.filename]:[tl.linenumber]"


    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Copiado al portapapeles.{/color}"


    old "Contacting App Store\nPlease Wait..."
    new "Contactando con la App Store\nPor favor espera..."


    old "No update methods found."
    new "No se encontraron métodos de actualización."


    old "Could not download file list: "
    new "No se pudo descargar la lista de archivos:"


    old "File list digest does not match."
    new "El resumen de la lista de archivos no coincide."


    old "An error is being simulated."
    new "Se está simulando un error."


    old "Either this project does not support updating, or the update status file was deleted."
    new "Este proyecto no admite actualizaciones o el archivo de estado fue eliminado."


    old "This account does not have permission to perform an update."
    new "Esta cuenta no tiene permiso para realizar una actualización."


    old "This account does not have permission to write the update log."
    new "Esta cuenta no tiene permiso para escribir el registro de actualización."


    old "Could not verify update signature."
    new "No se pudo verificar la firma de actualización."


    old "The update file was not downloaded."
    new "El archivo de actualización no fue descargado."


    old "The update file does not have the correct digest - it may have been corrupted."
    new "El archivo de actualización no tiene el resumen correcto; puede estar dañado."


    old "While unpacking {}, unknown type {}."
    new "Durante la extracción de {}, tipo desconocido {}."


    old "Updater"
    new "Actualizador"


    old "An error has occured:"
    new "Ha ocurrido un error:"


    old "Checking for updates."
    new "Buscando actualizaciones."


    old "This program is up to date."
    new "Este programa está actualizado."


    old "[u.version] is available. Do you want to install it?"
    new "[u.version] está disponible. ¿Deseas instalarlo?"


    old "Preparing to download the updates."
    new "Preparando la descarga de actualizaciones."


    old "Downloading the updates."
    new "Descargando las actualizaciones."


    old "Unpacking the updates."
    new "Extrayendo las actualizaciones."


    old "Finishing up."
    new "Finalizando."


    old "The updates have been installed. The program will restart."
    new "Las actualizaciones han sido instaladas. El programa se reiniciará."


    old "The updates have been installed."
    new "Las actualizaciones han sido instaladas."


    old "The updates were cancelled."
    new "Las actualizaciones fueron canceladas."


    old "Proceed"
    new "Proceder"


    old "Preparing to download the game data."
    new "Preparando la descarga de los datos del juego."


    old "Downloading the game data."
    new "Descargando los datos del juego."


    old "The game data has been downloaded."
    new "Los datos del juego han sido descargados."


    old "An error occured when trying to download game data:"
    new "Ocurrió un error al intentar descargar los datos del juego:"


    old "This game cannot be run until the game data has been downloaded."
    new "Este juego no puede ejecutarse hasta que los datos hayan sido descargados."


    old "Retry"
    new "Reintentar"


    old "Image [index] of [count] locked."
    new "Imagen [index] de [count] bloqueada."


    old "prev"
    new "anterior"


    old "next"
    new "siguiente"


    old "slideshow"
    new "presentación"


    old "return"
    new "volver"


    old "Renderer"
    new "Renderizador"


    old "Automatically Choose"
    new "Elegir automáticamente"


    old "Force GL Renderer"
    new "Forzar renderizador GL"


    old "Force ANGLE Renderer"
    new "Forzar renderizador ANGLE"


    old "Force GLES Renderer"
    new "Forzar renderizador GLES"


    old "Force GL2 Renderer"
    new "Forzar renderizador GL2"


    old "Force ANGLE2 Renderer"
    new "Forzar renderizador ANGLE2"


    old "Force GLES2 Renderer"
    new "Forzar renderizador GLES2"


    old "Enable (No Blocklist)"
    new "Habilitar (sin lista de bloqueo)"


    old "Powersave"
    new "Ahorro de energía"


    old "Framerate"
    new "Frecuencia de cuadros"


    old "Screen"
    new "Pantalla"


    old "60"
    new "60"


    old "30"
    new "30"


    old "Tearing"
    new "Desgarro de imagen"


    old "Changes will take effect the next time this program is run."
    new "Los cambios se aplicarán la próxima vez que se ejecute el programa."


    old "Performance Warning"
    new "Advertencia de rendimiento"


    old "This computer is using software rendering."
    new "Esta computadora está utilizando renderizado por software."


    old "This game requires use of GL2 that can't be initialised."
    new "Este juego requiere GL2 que no puede inicializarse."


    old "This computer has a problem displaying graphics: [problem]."
    new "Esta computadora tiene un problema al mostrar gráficos: [problem]."


    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Es posible que los controladores gráficos estén desactualizados o no funcionen correctamente. Esto puede causar gráficos lentos o incorrectos."


    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "El archivo {a=edit:1:log.txt}log.txt{/a} puede contener información para ayudarte a determinar qué está mal en tu computadora."


    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Más detalles sobre cómo solucionar esto pueden encontrarse en la {a=[url]}documentación{/a}."


    old "Continue, Show this warning again"
    new "Continuar, mostrar esta advertencia nuevamente"


    old "Continue, Don't show warning again"
    new "Continuar, no mostrar advertencia nuevamente"


    old "Change render options"
    new "Cambiar opciones de renderizado"


    old "Select Gamepad to Calibrate"
    new "Seleccionar gamepad para calibrar"


    old "No Gamepads Available"
    new "No hay gamepads disponibles"


    old "Calibrating [name] ([i]/[total])"
    new "Calibrando [name] ([i]/[total])"


    old "Press or move the '[control!s]' [kind]."
    new "Presiona o mueve '[control!s]' [kind]."


    old "Skip (A)"
    new "Omitir (A)"


    old "Back (B)"
    new "Atrás (B)"


    old "Open"
    new "Abrir"


    old "Opens the traceback.txt file in a text editor."
    new "Abre el archivo traceback.txt en un editor de texto."


    old "Copy BBCode"
    new "Copiar BBCode"


    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia el archivo traceback.txt al portapapeles como BBCode para foros como https://lemmasoft.renai.us/"


    old "Copy Markdown"
    new "Copiar Markdown"


    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia el archivo traceback.txt al portapapeles como Markdown para Discord."


    old "An exception has occurred."
    new "Ha ocurrido una excepción."


    old "Rollback"
    new "Retroceder"


    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Intenta volver a un momento anterior, permitiéndote guardar o elegir una opción diferente."


    old "Ignore"
    new "Ignorar"


    old "Ignores the exception, allowing you to continue."
    new "Ignora la excepción, permitiéndote continuar."


    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora la excepción, permitiéndote continuar. Esto a menudo conduce a errores adicionales."


    old "Reload"
    new "Recargar"


    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Recarga el juego desde el disco, guardando y restaurando el estado si es posible."


    old "Console"
    new "Consola"


    old "Opens a console to allow debugging the problem."
    new "Abre una consola para permitir depurar el problema."


    old "Quits the game."
    new "Sale del juego."


    old "Parsing the script failed."
    new "Error al analizar el script."
# Decompiled by unrpyc: https://github.com/CensoredUsername/unrpyc
