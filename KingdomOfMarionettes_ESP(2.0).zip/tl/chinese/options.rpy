﻿# TODO: Translation updated at 2026-03-04 11:36

translate chinese strings:

    # game/options.rpy:15
    old "Kingdom Of Marionettes"
    new "提线木偶王国"

