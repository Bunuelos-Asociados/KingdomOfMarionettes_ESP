﻿# TODO: Translation updated at 2026-03-04 11:36

# game/choice chapter 1.rpy:5
translate chinese q_clean_007736fc:

    # "Boss said I could clean it little by little. There’s no need to finish everything in one day."
    "老板说我可以慢慢收拾，没必要一天之内就全弄完。"

# game/choice chapter 1.rpy:6
translate chinese q_clean_9b49ffe9:

    # "In that case, I’ll start by cleaning the stage."
    "那就先从舞台开始打扫吧。"

# game/choice chapter 1.rpy:10
translate chinese q_clean_8529c83d:

    # "I head toward the storage room to gather some cleaning supplies."
    "我朝储藏室走去，打算拿些清洁用品。"

# game/choice chapter 1.rpy:14
translate chinese q_clean_ced0f145:

    # "God.... It's so dark in here. I can barely see anything"
    "天啊....这里也太黑了，我几乎什么都看不清。"

# game/choice chapter 1.rpy:16
translate chinese q_clean_518cf120:

    # "I tried to turn on the light, but of course it's broken. As expected"
    "我试着开灯，果然灯坏了。不出所料。"

# game/choice chapter 1.rpy:17
translate chinese q_clean_c0d8882e:

    # "I turn on my flash light"
    "我打开手电筒。"

# game/choice chapter 1.rpy:22
translate chinese q_clean_2883f898:

    # "Much better."
    "这下好多了。"

# game/choice chapter 1.rpy:23
translate chinese q_clean_09b91d84:

    # "The storage room itself is quite dirty. I’ll clean it another time."
    "储藏室本身也脏得不行，等下次我再收拾。"

# game/choice chapter 1.rpy:25
translate chinese q_clean_0565892b:

    # "I’m so focused on gathering the supplies that I flinch when my foot step into something."
    "我正专心收拾着清洁用品，脚下突然踩到什么，吓得我一哆嗦。"

# game/choice chapter 1.rpy:29
translate chinese q_clean_ff4925b4:

    # "When I look down, I see a red ball."
    "低头一看，是个红球。"

# game/choice chapter 1.rpy:30
translate chinese q_clean_40b51288:

    # "Oh. Just a ball. I don’t remember seeing a red ball earlier."
    "哦，只是个红球。我不记得之前见过这个。"

# game/choice chapter 1.rpy:31
translate chinese q_clean_e0c420d6:

    # "I must’ve just missed it."
    "大概是我刚才没注意到吧。"

# game/choice chapter 1.rpy:36
translate chinese q_clean_c8112e95:

    # "Once I’m sure I’ve gathered all the cleaning supplies, I head back toward the stage."
    "确认清洁用品都拿齐后，我便往舞台那边走去。"

# game/choice chapter 1.rpy:41
translate chinese q_clean_5f9b772e:

    # "...."
    "...."

# game/choice chapter 1.rpy:42
translate chinese q_clean_3e4d017f:

    # "I won’t lie, this corridor is pretty unsettling. Not just this corridor, either. This entire place feels creepy and dark."
    "说实话，这条走廊挺让人不安的。也不只是走廊，整个地方都阴森森的。"

# game/choice chapter 1.rpy:47
translate chinese q_clean_798a6618:

    # "Rusty doors are covered with layers of old newspapers. Cracked walls are smeared with graffiti left behind by vandals."
    "生锈的门上糊着一层层旧报纸，开裂的墙面上满是破坏者留下的涂鸦。"

# game/choice chapter 1.rpy:48
translate chinese q_clean_f5cb8c8d:

    # "Most of the lights are broken or dead. Only a few are still on and even those flicker. Dust and grime cling to every corner."
    "大多数灯不是坏了，就是早就不亮了。仅剩的几盏也在忽明忽暗地闪烁。灰尘和污垢附着在每个角落。"

# game/choice chapter 1.rpy:49
translate chinese q_clean_35210aef:

    # "Of course, that’s not surprising. This puppet theater has been closed for a very long time. If I remember correctly, Kingdom of Marionettes shut down around the year I was born."
    "当然，这也不奇怪。这家木偶剧院已经停业很久了。要是我没记错的话，“提线木偶王国”大概在我出生那年就关门了。"

# game/choice chapter 1.rpy:50
translate chinese q_clean_df28e148:

    # "Has no one really tried to take this place over all this time? It feels like such a waste to leave it abandoned. The place still looks so grand."
    "这么多年，真的就没人想接手这里吗？就这么荒着也太浪费了。明明还能看出它曾经很气派。"

# game/choice chapter 1.rpy:51
translate chinese q_clean_c65a501b:

    # "Maybe this place could be repurposed into a cinema...or a high end restaurant."
    "也许可以把这里改成电影院......或者高档餐厅。"

# game/choice chapter 1.rpy:52
translate chinese q_clean_ab9bfdd1:

    # "Or perhaps someone might even reopen this puppet theater. That would certainly be interesting."
    "又或者有人会让这家木偶剧院重新开张。那肯定会很有意思。"

# game/choice chapter 1.rpy:56
translate chinese q_clean_44e1d0c4:

    # "I start sweeping the stage floor, moving from one end to the other."
    "我开始清扫舞台地面，从一头扫到另一头。"

# game/choice chapter 1.rpy:57
translate chinese q_clean_cb669769:

    # "Just sweeping the stage floor alone is enough to exhaust me. The stage is enormous, and the thick layers of dust are stubborn and hard to sweep away."
    "只是扫舞台地面就够我受的。舞台大得夸张，灰尘又厚又顽固，怎么都扫不干净。"

# game/choice chapter 1.rpy:62
translate chinese q_clean_b2fb9f11:

    # "I look around me, then toward the audience seats."
    "我环顾四周，又看向观众席。"

# game/choice chapter 1.rpy:64
translate chinese q_clean_408f1ebc:

    # u "....This is going to take longer than I thought"
    u "......这比我想的还要花时间。"

# game/choice chapter 1.rpy:70
translate chinese q_clean_cb4478df:

    # "After cleaning the stage for what feels like two or three hours, I finally finish."
    "我花了差不多两三个小时打扫舞台，才终于收拾完。"

# game/choice chapter 1.rpy:72
translate chinese q_clean_19d2159a:

    # u "Well...at least the stage itself is done."
    u "唉......至少舞台这部分算是收拾好了。"

# game/choice chapter 1.rpy:74
translate chinese q_clean_7869af94:

    # "At this rate, I’ll probably need around two full days just to clean this area alone."
    "照这个速度，光这一片区域估计就得花上整整两天。"

# game/choice chapter 1.rpy:75
translate chinese q_clean_9511e2aa:

    # "My body is completely worn out after all the sweeping, mopping, cleaning the curtains, and everything else. I don’t have the strength to continue."
    "扫地、拖地、清理帘子......忙完这一通，我整个人都快散架了，实在没力气继续了。"

# game/choice chapter 1.rpy:76
translate chinese q_clean_ee0d93b6:

    # "It’s probably because I rarely exercise and live off instant noodles. No wonder my stamina is terrible. What can I do?"
    "大概是我平时不怎么运动，还总靠泡面凑合，难怪体力差成这样。我能怎么办呢？"

# game/choice chapter 1.rpy:77
translate chinese q_clean_22ba0d55:

    # "For now, I’ll stop cleaning."
    "先到这里吧。"

# game/choice chapter 1.rpy:89
translate chinese q_check_c9b76fbe:

    # u "According to boss, there are around twenty puppets in this theater. That’s quite a lot."
    u "老板说这家剧院里大概有二十个木偶，还真不少。"

# game/choice chapter 1.rpy:93
translate chinese q_check_850ba768:

    # "I walk toward the room where all the puppets are stored, located at the very end of the corridor."
    "我朝走廊尽头那间存放木偶的房间走去。"

# game/choice chapter 1.rpy:94
translate chinese q_check_b3aed74e:

    # "Seriously. who thought it was a good idea to place the puppet room at the end of such a dark hallway?"
    "说真的，谁会把木偶室设在这么黑的走廊尽头？"

# game/choice chapter 1.rpy:95
translate chinese q_check_a368bdaa:

    # "I must be so desperate for money that I feel like someone who actually enjoys walking into a haunted house."
    "我肯定是缺钱缺到发昏了，才会像那种爱逛鬼屋的人一样往里走。"

# game/choice chapter 1.rpy:96
translate chinese q_check_697ea20e:

    # "I grip the doorknob and take a deep breath before finally opening the door."
    "我握住门把手，深吸一口气，才终于把门打开。"

# game/choice chapter 1.rpy:103
translate chinese q_check_8f572daf:

    # u "...This is the puppet room? I didn’t get it wrong, did I?"
    u "......这就是木偶室？我没走错吧？"

# game/choice chapter 1.rpy:105
translate chinese q_check_c21d5803:

    # "If you ask me, it looks more like a prison."
    "要我说，这里更像牢房。"

# game/choice chapter 1.rpy:106
translate chinese q_check_5659b7ea:

    # "I was expecting to see a bunch of puppets hanging on the walls or something like that."
    "我原本还以为会看到一堆木偶挂在墙上之类的景象。"

# game/choice chapter 1.rpy:107
translate chinese q_check_b38fefda:

    # "But strangely enough, each puppet seems to have its own room."
    "但奇怪的是，每个木偶似乎都有自己单独的房间。"

# game/choice chapter 1.rpy:109
translate chinese q_check_d2a81a0e:

    # u "Alright. Time to start counting."
    u "好了，开始清点。"

# game/choice chapter 1.rpy:111
translate chinese q_check_84cadd21:

    # "I take out a piece of paper containing the list of puppets."
    "我拿出写有木偶名单的那张纸。"

# game/choice chapter 1.rpy:112
translate chinese q_check_22236f41:

    # "Who should i check first?"
    "先从哪个开始确认呢？"

# game/choice chapter 1.rpy:142
translate chinese jester_89be6b80:

    # u "Let's see the jester puppet."
    u "先去看弄臣木偶。"

# game/choice chapter 1.rpy:144
translate chinese jester_c256c017:

    # "I walk toward a door with the name “Jester” written on it and then i check through the viewing slot in the door"
    "我走到写着“Jester”的那扇门前，从门上的观察口往里看。"

# game/choice chapter 1.rpy:145
translate chinese jester_550046b3:

    # "The jester puppet’s room is decorated with striped patterns in various colors. Mostly black, red, and yellow."
    "弄臣木偶的房间用各种条纹装饰，颜色以黑、红、黄为主。"

# game/choice chapter 1.rpy:146
translate chinese jester_7c90aa6a:

    # "It’s filled with all kinds of acrobat props: balls, a unicycle, and many others."
    "房间里塞满了杂技道具：球、独轮车，还有其他一堆东西。"

# game/choice chapter 1.rpy:147
translate chinese jester_36ccba3a:

    # "As I look more closely, I finally spot the jester puppet standing in the corner of the room."
    "我凑近仔细看，终于在房间角落里看见了弄臣木偶。"

# game/choice chapter 1.rpy:148
translate chinese jester_f899971f:

    # "I can’t see its face since the puppet is slightly hunched over, but at least I know it’s there."
    "它微微弓着背，我看不清脸，但至少能确认它在里面。"

# game/choice chapter 1.rpy:149
translate chinese jester_af8c02e6:

    # "Jester puppet check."
    "弄臣木偶已确认。"

# game/choice chapter 1.rpy:154
translate chinese knight_2b9e7e38:

    # "I walk toward the door labeled “Knight.”"
    "我走向写着“Knight”的那扇门。"

# game/choice chapter 1.rpy:155
translate chinese knight_3a5d3464:

    # "The knight puppet’s room is neatly kept."
    "骑士木偶的房间收拾得很整洁。"

# game/choice chapter 1.rpy:156
translate chinese knight_90b56432:

    # "A sturdy, imposing shield is mounted on the wall, along with... various other shield decorations."
    "墙上挂着一面厚重又极具压迫感的盾牌，旁边还有......各种盾牌装饰。"

# game/choice chapter 1.rpy:157
translate chinese knight_e8b46306:

    # "There are quite a number of shields, all in different shapes and designs."
    "盾牌数量不少，形状和花纹各不相同。"

# game/choice chapter 1.rpy:158
translate chinese knight_f4a356a3:

    # "On the bed, I see a puppet sitting upright, a dark red cloak draped over its face."
    "床上坐着一个木偶，身子挺得笔直，深红色的披风遮住了它的脸。"

# game/choice chapter 1.rpy:159
translate chinese knight_ab31fa00:

    # "I’m certain it’s the knight puppet. Checked."
    "我确定那就是骑士木偶。确认无误。"

# game/choice chapter 1.rpy:164
translate chinese king_0cfd0c39:

    # "I walk toward the door labeled “King.”"
    "我走向写着“King”的那扇门。"

# game/choice chapter 1.rpy:165
translate chinese king_31aed451:

    # "When I look inside, the room is lavish."
    "我往里一看，房间布置得相当奢华。"

# game/choice chapter 1.rpy:166
translate chinese king_1e1a4741:

    # "There’s a king-sized bed with curtains, a comfortable-looking chaise lounge, and several paintings."
    "里面有一张带帘子的特大床，一张看起来很舒服的躺椅，还有好几幅画。"

# game/choice chapter 1.rpy:167
translate chinese king_f8c4285b:

    # "I examine every corner of the room, but I can’t find the king puppet anywhere."
    "我把房间每个角落都看了一遍，却怎么都找不到国王木偶。"

# game/choice chapter 1.rpy:168
translate chinese king_69585039:

    # "Oh no... is the king puppet missing?"
    "哦不......国王木偶不见了？"

# game/choice chapter 1.rpy:169
translate chinese king_095a9964:

    # "I check the puppet list I’m carrying, but I don’t see the king puppet’s name on it either."
    "我又看了看手上的木偶名单，上面也没有国王木偶的名字。"

# game/choice chapter 1.rpy:170
translate chinese king_63f1d603:

    # "I suppose there was never a king puppet to begin with. Or... has it been missing for a long time?"
    "也许从一开始就没有国王木偶。或者......它已经失踪很久了？"

# game/choice chapter 1.rpy:176
translate chinese after_check_1eaecb19:

    # "I’ve only checked two puppets so far. I’d better hurry and report the results to the boss."
    "我目前才检查了两个木偶，得赶紧把结果汇报给老板。"

# game/choice chapter 1.rpy:178
translate chinese after_check_0fd4d656:

    # "......"
    "......"

# game/choice chapter 1.rpy:179
translate chinese after_check_3928a113:

    # "......."
    "......."

# game/choice chapter 1.rpy:182
translate chinese after_check_2399eb56:

    # "After spending a few more minutes checking the puppets, I finally finish. Every puppet listed is present."
    "又花了几分钟把木偶都核对完，总算结束了。名单上的木偶一个不少。"

# game/choice chapter 1.rpy:192
translate chinese outer_gate_b34ae8e6:

    # "I check the camera at the outer gate. There’s nothing in there."
    "我看了外门的监控，画面里什么没有。"

# game/choice chapter 1.rpy:201
translate chinese corridor1_c72765eb:

    # "I check the camera at the corridor 1. There’s nothing in there."
    "我看了1号走廊的监控，画面里什么没有。"

# game/choice chapter 1.rpy:210
translate chinese theater_hall_268f0f81:

    # "I check the camera at the theater hall. There’s nothing in there."
    "我看了剧院大厅的监控，画面里什么没有。"

# game/choice chapter 1.rpy:219
translate chinese storage_60018e7d:

    # "I check the storage room camera. There’s nothing-"
    "我看了储藏室的监控，画面里什么都——"

# game/choice chapter 1.rpy:230
translate chinese storage_07bdde05:

    # "....."
    "....."

# game/choice chapter 1.rpy:231
translate chinese storage_ec12a37f:

    # "I take back what I said."
    "我收回刚才的话。"

# game/choice chapter 1.rpy:232
translate chinese storage_d1e5ea7b:

    # "Someone just passed through the storage room."
    "刚刚有个人影从储藏室里经过。"

# game/choice chapter 1.rpy:233
translate chinese storage_ec128e67:

    # "..... Was that a vandal?"
    "......那是来搞破坏的？"

# game/choice chapter 1.rpy:234
translate chinese storage_0d0b3bbd:

    # "No. That doesn’t make sense."
    "不，这不对劲。"

# game/choice chapter 1.rpy:236
translate chinese storage_660da02e:

    # u "How did they get inside?"
    u "那个人是怎么进来的？"

# game/choice chapter 1.rpy:242
translate chinese storage_2bf4407d:

    # "Damn it. I need to check it right now before those vandals do something that’ll make my job even harder."
    "该死。我得马上过去看看，免得再搞出什么事让我更难收拾。"

# game/choice chapter 1.rpy:244
translate chinese storage_827a69d5:

    # "I quickly grab a flashlight and a baton to defend myself, then rush out of the room toward the storage area."
    "我赶紧抄起手电筒和警棍防身，冲出房间，直奔储藏区。"

# game/choice chapter 1.rpy:250
translate chinese storage_8fae22bb:

    # "When I arrive at the storage room, I find nothing."
    "我赶到储藏室，却什么也没发现。"

# game/choice chapter 1.rpy:251
translate chinese storage_b32bb8cd:

    # "However, the storage door is open. proof that what I saw on the CCTV was real and not just my imagination."
    "然而，储藏室的门开着，这说明我在监控里看到的不是幻觉。"

# game/choice chapter 1.rpy:252
translate chinese storage_38ea61a0:

    # "I have a bad feeling. Whoever this person is, they’re somewhere in the corridor."
    "我心里发沉。不管那个人是谁，他一定还在走廊的某个地方。"

# game/choice chapter 1.rpy:253
translate chinese storage_d4986972:

    # "I grip my baton as tightly as I can and slowly step into the hallway."
    "我把警棍攥紧，慢慢踏进走廊。"

# game/choice chapter 1.rpy:254
translate chinese storage_07bdde05_1:

    # "....."
    "....."

# game/choice chapter 1.rpy:255
translate chinese storage_28fde3a8:

    # "It’s pitch dark... I’d better turn on the flashlight."
    "黑得伸手不见五指......我还是把手电打开吧。"

# game/choice chapter 1.rpy:260
translate chinese storage_75b742b1:

    # "Alright-"
    "好了——"

# game/choice chapter 1.rpy:261
translate chinese storage_0fd4d656:

    # "......"
    "......"

# game/choice chapter 1.rpy:262
translate chinese storage_fae4f937:

    # "What the hell is that...?"
    "那到底是什么......？"

# game/choice chapter 1.rpy:263
translate chinese storage_07384e83:

    # "After turning on the flashlight, I can finally see the dark path stretching out in front of me."
    "手电筒一亮，我终于看清前方那条黑暗的通道。"

# game/choice chapter 1.rpy:264
translate chinese storage_6ce9e3dc:

    # "But I can also see something else..."
    "但我还看见了别的东西......"

# game/choice chapter 1.rpy:265
translate chinese storage_ba16a89e:

    # "A tall figure standing at the far end of the corridor."
    "走廊尽头，站着一道高大的身影。"

# game/choice chapter 1.rpy:266
translate chinese storage_0ccefa30:

    # "The figure is draped in a red cloak, its edges torn and ragged. Its outfit resembles that of a knight."
    "那身影披着红色斗篷，边缘残破不堪。那身装束......像个骑士。"

# game/choice chapter 1.rpy:267
translate chinese storage_a20cefa7:

    # "..."
    "..."

# game/choice chapter 1.rpy:268
translate chinese storage_8eef97dc:

    # "No... this isn’t a vandal."
    "不......这不是来搞破坏的人。"

# game/choice chapter 1.rpy:269
translate chinese storage_69b1dd44:

    # "It’s the knight puppet I checked earlier..."
    "是我刚才检查过的骑士木偶......"

# game/choice chapter 1.rpy:270
translate chinese storage_764814f9:

    # "How could a puppet be standing here...?"
    "木偶怎么可能站在这里......？"

# game/choice chapter 1.rpy:271
translate chinese storage_6e05f8d5:

    # "There’s no way. Puppets don’t move..."
    "不可能。木偶不会动......"

# game/choice chapter 1.rpy:272
translate chinese storage_dacbdb3f:

    # "Maybe some vandals broke in and moved the knight puppet here. And because they noticed me, they put it back so they could escape as quickly as possible."
    "也许是有人闯了进来，把骑士木偶搬到这儿，后来又因为发现了我，才急着把它摆回去好尽快脱身。"

# game/choice chapter 1.rpy:273
translate chinese storage_67153a08:

    # "Yeah. That has to be it."
    "对......一定是这样。"

# game/choice chapter 1.rpy:274
translate chinese storage_48500d95:

    # "Before I can calm myself with all these possibilities, the puppet’s head moves and turns to look straight at me."
    "我还没来得及用这些可能性安慰自己，木偶的头就动了，缓缓转过来，看向我。"

# game/choice chapter 1.rpy:275
translate chinese storage_07bdde05_2:

    # "....."
    "....."

# game/choice chapter 1.rpy:276
translate chinese storage_ec12a37f_1:

    # "I take back what I said."
    "我收回刚才的话。"

# game/choice chapter 1.rpy:278
translate chinese storage_2ad222a5:

    # knipuppet "... Intruder...."
    knipuppet "......入侵者......"

# game/choice chapter 1.rpy:281
translate chinese storage_3dceb7a7:

    # "That puppet can talk"
    "那个木偶居然会说话。"

# game/choice chapter 1.rpy:282
translate chinese storage_7e9edd46:

    # "Calm down... calm down... don’t panic..."
    "冷静......冷静......别慌......"

# game/choice chapter 1.rpy:283
translate chinese storage_acbb964c:

    # "But what should i do in this situation??"
    "但这种情况我该怎么办？？"

# game/choice chapter 1.rpy:296
translate chinese keep_silent_c3af6791:

    # "I just stand there, frozen. I don’t know what to do. Even if I say something, I’m afraid it’ll only make things worse."
    "我僵在原地，脑子一片空白。就算开口，我也怕那样只会让情况更糟。"

# game/choice chapter 1.rpy:297
translate chinese keep_silent_3607f28a:

    # "I never imagined a situation where a puppet would speak to me."
    "我从没想过，会有木偶开口跟我说话。"

# game/choice chapter 1.rpy:302
translate chinese who_1c4c3699:

    # "He didn't say anything back"
    "他没有再说什么。"

# game/choice chapter 1.rpy:303
translate chinese who_3607f28a:

    # "I never imagined a situation where a puppet would speak to me."
    "我从没想过，会有木偶开口跟我说话。"

# game/choice chapter 1.rpy:311
translate chinese run_75016de9:

    # "Without a second thought, I spun around and ran straight toward my office."
    "我想都没想就转身，直奔办公室。"

# game/choice chapter 1.rpy:315
translate chinese run_b99f9743:

    # "Once I reached it, I locked the door as quickly as I could."
    "一到门口，我就用最快的速度把门锁上。"

# game/choice chapter 1.rpy:318
translate chinese run_87cb2fa2:

    # u "The puppet was really alive... it talked. Am I dreaming...?"
    u "那木偶真的活了......还会说话。我是在做梦吗......？"

# game/choice chapter 1.rpy:319
translate chinese run_26be82b4:

    # u "I feel like I’ve lost my mind... or maybe I already had..?"
    u "我感觉我快疯了......或者也许我早就疯了......？"

# game/choice chapter 1.rpy:321
translate chinese run_739e7b43:

    # "I tried to calm myself and slowly stepped backward. But keeping my eyes on the door"
    "我努力让自己冷静下来，慢慢往后退，眼睛却始终盯着门口。"

# game/choice chapter 1.rpy:322
translate chinese run_c2c42034:

    # "I braced myself for the puppet’s arrival at my office, but even after five minutes passed, I heard nothing."
    "我提心吊胆地等它追到办公室，但五分钟过去了，外面一点动静都没有。"

# game/choice chapter 1.rpy:323
translate chinese run_a42eff31:

    # "Did the puppet not follow me?"
    "它没跟过来？"

# game/choice chapter 1.rpy:328
translate chinese run_c0f35448:

    # "I was just about to feel relieved when suddenly, a hand covered my eyes."
    "我刚要松口气，突然，一只手捂住了我的眼睛。"

# game/choice chapter 1.rpy:329
translate chinese run_6576ac53:

    # "My entire body froze as I sensed someone standing behind me."
    "我感觉身后有人站着，顿时浑身发冷，僵在原地。"

# game/choice chapter 1.rpy:330
translate chinese run_5b99436a:

    # "Since when?!"
    "什么时候到我身后的？！"

# game/choice chapter 1.rpy:331
translate chinese run_a4e46cc5:

    # "I didn’t dare scream or struggle. I was far too afraid."
    "我不敢叫，也不敢挣扎。我害怕得要命。"

# game/choice chapter 1.rpy:333
translate chinese run_56db3b30:

    # who "Mm.. I expected you to scream. But it seems you’re a good child. Far better than I anticipated."
    who "嗯......我还以为你会尖叫呢。不过看起来，你是个乖孩子，比我想象中要好得多。"

# game/choice chapter 1.rpy:335
translate chinese run_92ca7c2f:

    # " A soft voice whispered right against my ear. It's high-pitched, oddly playful, almost childlike"
    "一个轻柔的声音贴着我的耳边低语。那声音偏尖，带着点古怪的玩闹感，几乎像个孩子。"

# game/choice chapter 1.rpy:337
translate chinese run_47c70280:

    # "Then I feel another hand slowly rest on my shoulder, making me flinch."
    "紧接着，另一只手缓缓搭在我肩上，我不由得一颤。"

# game/choice chapter 1.rpy:339
translate chinese run_87b5833c:

    # who "Easy now. The danger has passed. You may allow yourself to relax."
    who "放轻松。危险已经过去了，你可以稍微松口气。"

# game/choice chapter 1.rpy:340
translate chinese run_7434f661:

    # who "Why don’t you come with me for the time being? I assure you, I am not someone you need to fear."
    who "不如你暂时跟我走？我保证，我不是你该害怕的人。"

# game/choice chapter 1.rpy:341
translate chinese run_cd23c268:

    # who "After all, any guest who sets foot in this kingdom ought to be welcomed properly. Wouldn’t you agree?"
    who "毕竟，任何踏入这个王国的客人都该被好好欢迎。你说对吧？"

# game/choice chapter 1.rpy:343
translate chinese run_09805a88:

    # "Alright... whoever is standing behind me sounds friendly enough. Still, it’s probably best if I just go along with it."
    "好吧......不管身后是谁，至少听上去还算友善。现在还是先顺着他比较好。"

# game/choice chapter 1.rpy:344
translate chinese run_3b9dac57:

    # "I nod my head."
    "我点了点头。"

# game/choice chapter 1.rpy:346
translate chinese run_aa4a51a8:

    # who "Excellent, Now come with me."
    who "很好。现在跟我来。"

# game/choice chapter 1.rpy:358
translate chinese dicekek_cf8a8d55:

    # "Suddenly, in the blink of an eye, a hand clamps around my throat."
    "突然间，眨眼的功夫，一只手猛地掐住了我的喉咙。"

# game/choice chapter 1.rpy:362
translate chinese dicekek_81d2627a:

    # u "UGH-?!"
    u "呃——？！"

# game/choice chapter 1.rpy:367
translate chinese dicekek_a520c5f9:

    # "The knight puppet is right in front of me, choking me with terrifying speed."
    "骑士木偶站在我的面前，以骇人的速度掐住了我的脖子。"

# game/choice chapter 1.rpy:371
translate chinese dicekek_c77602ae:

    # knipuppet "Once again... an intruder..."
    knipuppet "又来了......入侵者......"

# game/choice chapter 1.rpy:372
translate chinese dicekek_ba39f550:

    # knipuppet "It seems more and more intruder have been coming to this kingdom lately."
    knipuppet "看来最近闯进这个王国的人越来越多了。"

# game/choice chapter 1.rpy:373
translate chinese dicekek_c9d66958:

    # knipuppet "How fortunate..."
    knipuppet "真是走运......"

# game/choice chapter 1.rpy:375
translate chinese dicekek_ad9b9c93:

    # "His grip tightens around my neck, cutting off my air."
    "他手上一收，我脖子被掐得更紧，呼吸瞬间被截断。"

# game/choice chapter 1.rpy:376
translate chinese dicekek_092dbe35:

    # "He’s going to kill me!"
    "他要杀了我！"

# game/choice chapter 1.rpy:377
translate chinese dicekek_0c70cc9f:

    # "I struggle with every strenght I have. punching his arm, kicking his legs, trying desperately to break free."
    "我拼尽全力挣扎，捶他的手臂、踢他的腿，绝望地想挣脱。"

# game/choice chapter 1.rpy:378
translate chinese dicekek_2ac20e83:

    # "But it’s useless. He is far stronger than me. He doesn’t even budge."
    "但都没用。他比我强壮太多，甚至连动都没动一下。"

# game/choice chapter 1.rpy:380
translate chinese dicekek_1c461bb5:

    # "My vision grows blurrier, sinking deeper into darkness."
    "视线越来越模糊，我的意识也一点点沉入黑暗。"

# game/choice chapter 1.rpy:381
translate chinese dicekek_604dcb18:

    # "Is this really how my life ends? Killed by a living puppet?"
    "难道我就要这样死去？死在一个活木偶手里？"

# game/choice chapter 1.rpy:388
translate chinese dicekek_1b3cfe4f:

    # "Just before my consciousness completely fades, a hand suddenly covers my eyes."
    "就在我快要彻底失去意识时，一只手突然捂住了我的眼睛。"

# game/choice chapter 1.rpy:390
translate chinese dicekek_82b66c7b:

    # knipuppet ".... What are you doing in here?"
    knipuppet "......你来这里做什么？"

# game/choice chapter 1.rpy:392
translate chinese dicekek_68005f19:

    # "Huh? Who is this behind me?? another puppet???"
    "哈？我身后是谁？？又一个木偶？？？"

# game/choice chapter 1.rpy:394
translate chinese dicekek_15d4cc7a:

    # who "Knighter, I believe I’ve mentioned this before. Wouldn’t it be better if any visitors who wander into our kingdom were entrusted to me?"
    who "Knighter，我想我之前提过。那些误闯进我们王国的访客由我来接手处理，不是更好吗？"

# game/choice chapter 1.rpy:395
translate chinese dicekek_acae9e6b:

    # kni "For what? So you can carry out that absurd plan of yours?"
    kni "为了什么？好让你执行你那荒唐的计划？"

# game/choice chapter 1.rpy:396
translate chinese dicekek_fab6c484:

    # who "My friend, you’re free to doubt me if you wish. I wouldn’t fault you for it. But I do need this visitor. You understand that much.. don’t you?"
    who "我的朋友，你想怀疑我也无妨，我不会怪你。但这个访客，我确实需要。至少这一点......你明白的，对吧？"

# game/choice chapter 1.rpy:398
translate chinese dicekek_9d5517c8:

    # "Suddenly, the corridor falls silent. I have no idea what’s happening."
    "走廊里突然安静下来。我完全不知道发生了什么。"

# game/choice chapter 1.rpy:399
translate chinese dicekek_60c8dd55:

    # "The knight puppet named Knighter snorts in irritation before abruptly releasing his grip from my throat."
    "那个名叫Knighter的骑士木偶不耐烦地哼了一声，随即松开了掐住我喉咙的手。"

# game/choice chapter 1.rpy:400
translate chinese dicekek_7bc2613a:

    # "I hear his footsteps fading away, a clear sign that he’s left."
    "我听见他的脚步声渐渐远去。很明显，他离开了。"

# game/choice chapter 1.rpy:401
translate chinese dicekek_a9f09942:

    # "Yet the hand covering my eyes doesn’t move, gently keeping my vision obscured."
    "捂着我眼睛的那只手依旧没动，轻轻遮住我的视线。"

# game/choice chapter 1.rpy:402
translate chinese dicekek_47c70280:

    # "Then I feel another hand slowly rest on my shoulder, making me flinch."
    "然后，我感觉到另一只手缓缓落在我肩上，我不由得一颤。"

# game/choice chapter 1.rpy:404
translate chinese dicekek_87b5833c:

    # who "Easy now. The danger has passed. You may allow yourself to relax."
    who "别紧张。危险已经过去了，你可以放松些。"

# game/choice chapter 1.rpy:405
translate chinese dicekek_7434f661:

    # who "Why don’t you come with me for the time being? I assure you, I am not someone you need to fear."
    who "不如你暂时跟我走？我向你保证，你不必害怕我。"

# game/choice chapter 1.rpy:406
translate chinese dicekek_cd23c268:

    # who "After all, any guest who sets foot in this kingdom ought to be welcomed properly. Wouldn’t you agree?"
    who "毕竟，任何踏入这个王国的客人，都该被好好招待。你说对吗？"

# game/choice chapter 1.rpy:408
translate chinese dicekek_09805a88:

    # "Alright... whoever is standing behind me sounds friendly enough. Still, it’s probably best if I just go along with it."
    "好吧......不管身后是谁，至少听起来还算友善。眼下我还是先配合比较好。"

# game/choice chapter 1.rpy:409
translate chinese dicekek_3b9dac57:

    # "I nod my head."
    "我点了点头。"

# game/choice chapter 1.rpy:411
translate chinese dicekek_aa4a51a8:

    # who "Excellent, Now come with me."
    who "很好。现在跟我来。"

# game/choice chapter 1.rpy:419
translate chinese ke_stage_b582c00f:

    # "The figure behind me guides me forward, leading me where they want while keeping my eyes covered."
    "身后那人扶着我往前走，捂着我的眼睛，将我带往他想带我去的地方。"

# game/choice chapter 1.rpy:420
translate chinese ke_stage_5f6ec595:

    # "After a while, he stop."
    "过了一会儿，他停下了。"

# game/choice chapter 1.rpy:422
translate chinese ke_stage_5b135711:

    # who "We’ve arrived. Now, please take a seat here and make yourself comfortable."
    who "我们到了。来，请在这里坐下，放轻松。"

# game/choice chapter 1.rpy:426
translate chinese ke_stage_e6257ec1:

    # "They gently guide me down into a seat."
    "他轻轻引导我坐下。"

# game/choice chapter 1.rpy:427
translate chinese ke_stage_79c0981a:

    # "Then, their hand moves away from my eyes, finally allowing me to see."
    "随后，他的手从我眼前移开，我终于能看见了。"

# game/choice chapter 1.rpy:428
translate chinese ke_stage_1a188bd4:

    # "This is... the theater hall..."
    "这里是......剧院大厅......"

# game/choice chapter 1.rpy:429
translate chinese ke_stage_b4c0bae0:

    # "I turn around, trying to see who has been guiding me all this time."
    "我转过身，想看看一路带着我的究竟是谁。"

# game/choice chapter 1.rpy:430
translate chinese ke_stage_8c1dee58:

    # "But there’s no one there."
    "但身后一个人也没有。"

# game/choice chapter 1.rpy:432
translate chinese ke_stage_d74acb68:

    # u "What? Where did that person go?"
    u "什么？那人去哪了？"

# game/choice chapter 1.rpy:440
translate chinese ke_stage_f8bdd8e4:

    # jespuppet "BOO!!"
    jespuppet "BOO！！"

# game/choice chapter 1.rpy:444
translate chinese ke_stage_2d2d5001:

    # u "AAARGH!!"
    u "啊——！！"

# game/choice chapter 1.rpy:446
translate chinese ke_stage_e950a86c:

    # "Still unprepared and struggling to process what was happening, I scream when without warning someone standing right in front of me."
    "我还没反应过来发生了什么，就发现有人毫无预兆地已经站在我面前，我顿时吓得尖叫出声。"

# game/choice chapter 1.rpy:451
translate chinese ke_stage_558d92b2:

    # "He gently covers my mouth, as if signaling that he won’t hurt me and keep me silent."
    "他轻轻捂住我的嘴，像是在示意自己不会伤害我，只是要我别出声。"

# game/choice chapter 1.rpy:455
translate chinese ke_stage_0e4a568f:

    # jespuppet "Shh..."
    jespuppet "嘘......"

# game/choice chapter 1.rpy:457
translate chinese ke_stage_825c63ab:

    # "I can feel my soul almost slipped from my body for a second"
    "那一瞬间，我感觉魂都快被吓飞了。"

# game/choice chapter 1.rpy:458
translate chinese ke_stage_88d43b28:

    # "Slowly, he pulls his hand away from my lips."
    "他慢慢把手从我唇边移开。"

# game/choice chapter 1.rpy:459
translate chinese ke_stage_bffbc981:

    # "The figure is dressed like a jester. Bells hang from the tips of its hood, and its outfit is colored red, black, white, and yellow."
    "那身影打扮得像个弄臣：兜帽尖端挂着铃铛，衣服是红、黑、白、黄的配色。"

# game/choice chapter 1.rpy:465
translate chinese ke_stage_a20cefa7:

    # "..."
    "..."

# game/choice chapter 1.rpy:469
translate chinese ke_stage_233f662e:

    # "Wait a second.. Isn't that-"
    "等等......那不是——"

# game/choice chapter 1.rpy:470
translate chinese ke_stage_c82304b6:

    # "He is... the jester puppet."
    "他是......弄臣木偶。"

# game/choice chapter 1.rpy:471
translate chinese ke_stage_6fd8ae18:

    # "...he... move on his own"
    "......他......自己在动。"

# game/choice chapter 1.rpy:472
translate chinese ke_stage_c32ace20:

    # "I remembered the list of duties I read before applying yesterday."
    "我想起昨天应聘前读到的那份职责清单。"

# game/choice chapter 1.rpy:473
translate chinese ke_stage_e167b255:

    # "Make sure none of the puppets are missing.... and walking around."
    "确保没有木偶失踪......也没有木偶在外面走动。"

# game/choice chapter 1.rpy:474
translate chinese ke_stage_817f648a:

    # "At that moment, I believed it after seeing knight puppet and jester puppet moving with my own eyes and mind"
    "直到这一刻，亲眼看到骑士木偶和弄臣木偶都会动，我才终于相信那上面写的都是真的。"

# game/choice chapter 1.rpy:475
translate chinese ke_stage_09fcc39a:

    # "... This isn’t a joke. They are alive."
    "......这不是玩笑。他们是活的。"

# game/choice chapter 1.rpy:486
translate chinese stage_94b9fe55:

    # "I check the camera at the stage. There’s noth-"
    "我查看舞台的监控。画面里没——"

# game/choice chapter 1.rpy:488
translate chinese stage_b84bd283:

    # "Wait a second... what the hell is that?"
    "等等......那到底是什么？"

# game/choice chapter 1.rpy:489
translate chinese stage_c1b70496:

    # "Through the CCTV feed, I can see a figure standing upright at the center of the stage."
    "透过监控画面，我看到舞台中央有个身影直挺挺地站着。"

# game/choice chapter 1.rpy:490
translate chinese stage_42d23433:

    # "It’s hard to make out in the darkness, but I’m certain someone is there."
    "黑暗里看不清细节，但我很确定那里有人。"

# game/choice chapter 1.rpy:491
translate chinese stage_d83ab720:

    # "Is it the vandals? How did they even get inside?"
    "是搞破坏的人吗？怎么进来的？"

# game/choice chapter 1.rpy:496
translate chinese stage_723bc5e7:

    # "Damn it. I need to check it right now—before those vandals do something that’ll make my job even harder."
    "该死。在搞出更麻烦的事之前，我最好立刻过去看看。"

# game/choice chapter 1.rpy:498
translate chinese stage_91a606e1:

    # "I quickly grab a flashlight and a baton to defend myself, then rush out of the room toward the theater hall."
    "我赶紧抄起手电筒和警棍防身，冲出房间，直奔剧院大厅。"

# game/choice chapter 1.rpy:502
translate chinese stage_07bdde05:

    # "....."
    "....."

# game/choice chapter 1.rpy:506
translate chinese stage_415559a8:

    # "I step into the theater hall and look toward the darkened stage."
    "我踏进剧院大厅，望向昏暗的舞台。"

# game/choice chapter 1.rpy:507
translate chinese stage_35da436d:

    # "It’s too dark to see anyone clearly. I’ll have to get closer."
    "太暗了，根本看不清。我得再靠近一点。"

# game/choice chapter 1.rpy:515
translate chinese stage_f8bdd8e4:

    # jespuppet "BOO!!"
    jespuppet "BOO！！"

# game/choice chapter 1.rpy:519
translate chinese stage_2d2d5001:

    # u "AAARGH!!"
    u "啊——！！"

# game/choice chapter 1.rpy:521
translate chinese stage_acf8eb8e:

    # "Still unprepared and struggling to process what was happening, I let out the loudest scream i have ever make when without warning the figure was already standing right in front of me."
    "我还没搞清楚状况，那身影就毫无预兆地出现在我面前。我发出了这辈子最大的一声尖叫。"

# game/choice chapter 1.rpy:526
translate chinese stage_c9bc9322:

    # "He gently covers my mouth, as if signaling that he won’t hurt me."
    "他轻轻捂住我的嘴，像是在示意自己不会伤害我，只是要我别出声。"

# game/choice chapter 1.rpy:530
translate chinese stage_0e4a568f:

    # jespuppet "Shh..."
    jespuppet "嘘......"

# game/choice chapter 1.rpy:532
translate chinese stage_825c63ab:

    # "I can feel my soul almost slipped from my body for a second"
    "那一瞬间，我感觉魂都快被吓飞了。"

# game/choice chapter 1.rpy:533
translate chinese stage_88d43b28:

    # "Slowly, he pulls his hand away from my lips."
    "他慢慢把手从我唇边移开。"

# game/choice chapter 1.rpy:534
translate chinese stage_bffbc981:

    # "The figure is dressed like a jester. Bells hang from the tips of its hood, and its outfit is colored red, black, white, and yellow."
    "那身影打扮得像个弄臣：兜帽尖端挂着铃铛，衣服是红、黑、白、黄的配色。"

# game/choice chapter 1.rpy:540
translate chinese stage_a20cefa7:

    # "..."
    "..."

# game/choice chapter 1.rpy:544
translate chinese stage_424f7eee:

    # "Wait a second.... isn't that-"
    "等等......那是——"

# game/choice chapter 1.rpy:545
translate chinese stage_25128f12:

    # "That's... the jester puppet that i check earlier."
    "那是......我之前检查过的弄臣木偶。"

# game/choice chapter 1.rpy:546
translate chinese stage_c8f7d405:

    # "He is... moving?! Moving on his own?!"
    "他在......动？！而且是自己在动？！"

# game/choice chapter 1.rpy:547
translate chinese stage_caf1c301:

    # "How can that's even possible?!"
    "这怎么可能？！"

# game/choice chapter 1.rpy:548
translate chinese stage_36477dbc:

    # "Suddenly, I remembered the list of duties I read before applying yesterday."
    "我突然想起昨天应聘前读到的那份职责清单。"

# game/choice chapter 1.rpy:549
translate chinese stage_4c151d0c:

    # "Make sure none of the puppets are missing... and walking around."
    "确保没有木偶失踪......也没有木偶在外面走动。"

# game/choice chapter 1.rpy:550
translate chinese stage_d376b6ab:

    # "At that moment, I believed it after seeing it with my own eyes and mind."
    "直到这一刻，亲眼所见，我才不得不信。"

# game/choice chapter 1.rpy:551
translate chinese stage_c6159c84:

    # "....This isn’t a joke. They are alive."
    "......这不是玩笑。他们是活的。"

# game/choice chapter 1.rpy:558
translate chinese money_9b08e166:

    # "Maybe I could give them money... that way they could buy the things they need."
    "也许我可以给他们一些钱......这样他们就能买到需要的东西。"

# game/choice chapter 1.rpy:559
translate chinese money_97ae167e:

    # mc "What if I give you some funds? I’ll provide whatever you need. Whether it’s to buy new seeds or to cover your daily needs."
    mc "要不我给你们拨点资金？你们需要什么我都可以提供。买新种子也好，日常开销也好。"

# game/choice chapter 1.rpy:560
translate chinese money_283791da:

    # nara "{color=#E0AE4B}Upon hearing the [title]’s decision to provide the farmers with as much funding as they needed, the farmer’s heart danced with joy.{/color}"
    nara "{color=#E0AE4B}听到一国之主决定按需为农夫提供资金，他顿时欣喜若狂。{/color}"

# game/choice chapter 1.rpy:562
translate chinese money_618ce9e7:

    # "Alright, that narrator’s voice, that coming from who knows where, was starting to make me uneasy."
    "说真的，那道不知从哪儿传来的旁白声，开始让我不安起来。"

# game/choice chapter 1.rpy:566
translate chinese money_436d3ea4:

    # farm "Oh, of course, Your Majesty! That sounds like a good idea. Thank you very much!"
    farm "哦，当然，陛下！这主意真是太好了。非常感谢您！"

# game/choice chapter 1.rpy:570
translate chinese money_ee3ef29a:

    # nara "{color=#E0AE4B}With a joyful heart, the farmer finally left the palace to deliver the good news.{/color}"
    nara "{color=#E0AE4B}农夫满心欢喜地离开了宫殿，去传达这个好消息。{/color}"

# game/choice chapter 1.rpy:572
translate chinese money_abbe3b80:

    # "The farmer puppet then stood up and left the stage."
    "农夫木偶随即起身，离开了舞台。"

# game/choice chapter 1.rpy:577
translate chinese money_54f54627:

    # "I could feel Jestyn’s gaze fixed on me."
    "我能感觉到Jestyn的目光一直落在我身上。"

# game/choice chapter 1.rpy:582
translate chinese money_f2905482:

    # jes "Oh, Your Majesty. such a truly wise and kind hearted decision."
    jes "哦，陛下。这真是个既明智又仁慈的决定。"

# game/choice chapter 1.rpy:583
translate chinese money_f1222d64:

    # jes "Providing the farmers with funds to meet their basic needs.It is not a bad idea at all."
    jes "给农夫提供资金，先满足基本生活所需。这主意一点也不差。"

# game/choice chapter 1.rpy:585
translate chinese money_510a1e83:

    # "He paused."
    "他顿了顿。"

# game/choice chapter 1.rpy:589
translate chinese money_2cd83f90:

    # jes "You’re so kind your majesty. and Kindness is a beautiful thing"
    jes "您真是太善良了，陛下。善良本是一件很美好的事。"

# game/choice chapter 1.rpy:590
translate chinese money_13dea7c0:

    # jes "But when given without limits... it turns into expectation."
    jes "但一旦毫无节制地给予......它就会变成理所当然的期待。"

# game/choice chapter 1.rpy:592
translate chinese money_a61e186e:

    # "He tilted his head."
    "他微微偏了偏头。"

# game/choice chapter 1.rpy:596
translate chinese money_e79aa23e:

    # jes "Tell me, how many coins does it take to feed a kingdom?"
    jes "告诉我，要供养一整个王国，需要多少金币？"

# game/choice chapter 1.rpy:597
translate chinese money_d27df0f0:

    # mc "Uhm... that’s..."
    mc "呃......这个......"

# game/choice chapter 1.rpy:601
translate chinese money_79861712:

    # jes "Ah, forgive me."
    jes "啊，请原谅我。"

# game/choice chapter 1.rpy:602
translate chinese money_173ff528:

    # jes "I forgot you are very generous."
    jes "我忘了，您一向慷慨。"

# game/choice chapter 1.rpy:606
translate chinese money_5d8ee5db:

    # "He smiled."
    "他笑了笑。"

# game/choice chapter 1.rpy:608
translate chinese money_d8235c83:

    # jes "The kingdom must be quite small...if generosity alone is enough to sustain it."
    jes "若仅凭慷慨就能支撑一个王国，那这王国想必小得很。"

# game/choice chapter 1.rpy:610
translate chinese money_631a098c:

    # "He is right..."
    "他说得没错......"

# game/choice chapter 1.rpy:611
translate chinese money_fecd91a3:

    # "Being a [title] is really hard..."
    "当个统治者真的很难......"

# game/choice chapter 1.rpy:612
translate chinese money_8ebdfdc5:

    # "I mean, I’m just a security guard, desperate for money just to survive."
    "说到底，我不过是个保安，拼命挣钱也只是为了活下去。"

# game/choice chapter 1.rpy:613
translate chinese money_e82a19a7:

    # "And now, all of a sudden, I’m being dragged into playing the role of a [title] by living puppets."
    "但现在，我却突然被一群活木偶拖进这场戏里，逼着我去扮演一个一国之主。"

# game/choice chapter 1.rpy:614
translate chinese money_9c6e8d8c:

    # "I’m really not that fit to be a leader."
    "我真的不太适合当领导者。"

# game/choice chapter 1.rpy:619
translate chinese channels_f6b65596:

    # "I don’t know much about farming, but I once read that drought can be handled by building water channels."
    "我不太懂农事，但我以前读到过，说是可以靠修水渠来应对干旱。"

# game/choice chapter 1.rpy:620
translate chinese channels_91942fe8:

    # "Mmm... I don’t think that’s a bad idea. Hopefully."
    "嗯......这主意应该不算差吧。希望没错。"

# game/choice chapter 1.rpy:622
translate chinese channels_1e7871e5:

    # mc "How about we build water channels? That way, the crops won’t dry out."
    mc "要不修建水渠？这样庄稼就不会旱死了。"

# game/choice chapter 1.rpy:623
translate chinese channels_59eec820:

    # nara "{color=#E0AE4B}Upon hearing the [title]’s decision to build the water channels, the farmer’s heart danced with joy.{/color}"
    nara "{color=#E0AE4B}听到一国之主决定修建水渠，农夫顿时欣喜若狂。{/color}"

# game/choice chapter 1.rpy:625
translate chinese channels_618ce9e7:

    # "Alright, that narrator’s voice, that coming from who knows where, was starting to make me uneasy."
    "说真的，那道不知从哪儿传来的旁白声，开始让我不安起来。"

# game/choice chapter 1.rpy:632
translate chinese channels_ebae100a:

    # "The farmer seemed to think for a moment, then nodded in agreement"
    "农夫似乎想了想，随后点头同意。"

# game/choice chapter 1.rpy:634
translate chinese channels_385c2411:

    # farm "Of course, Your Majesty. That is a good idea."
    farm "当然，陛下。这是个好主意。"

# game/choice chapter 1.rpy:636
translate chinese channels_808ee39d:

    # "I sigh with relief"
    "我松了口气。"

# game/choice chapter 1.rpy:638
translate chinese channels_cdee7ca5:

    # mc "Then I will provide the funds to build the channels as soon as possible."
    mc "那我会尽快拨款，安排修建水渠。"

# game/choice chapter 1.rpy:642
translate chinese channels_fcacb4d6:

    # farm "Very well, Your Majesty.Thank you very much."
    farm "明白了，陛下。非常感谢您。"

# game/choice chapter 1.rpy:643
translate chinese channels_ee3ef29a:

    # nara "{color=#E0AE4B}With a joyful heart, the farmer finally left the palace to deliver the good news.{/color}"
    nara "{color=#E0AE4B}农夫满心欢喜地离开了宫殿，去传达这个好消息。{/color}"

# game/choice chapter 1.rpy:645
translate chinese channels_abbe3b80:

    # "The farmer puppet then stood up and left the stage."
    "农夫木偶随即起身，离开了舞台。"

# game/choice chapter 1.rpy:649
translate chinese channels_d3df1e05:

    # "After that, the farmer stood up and walked off the stage."
    "之后，农夫起身走下了舞台。"

# game/choice chapter 1.rpy:650
translate chinese channels_54f54627:

    # "I could feel Jestyn’s gaze fixed on me."
    "我能感觉到Jestyn的目光一直落在我身上。"

# game/choice chapter 1.rpy:655
translate chinese channels_7fcb8644:

    # jes "A truly admirable choice, Your Majesty."
    jes "真是令人钦佩的选择，陛下。"

# game/choice chapter 1.rpy:656
translate chinese channels_e1111f9d:

    # jes "Water channels to fight drought. a solution that looks far into the future."
    jes "用水渠对抗干旱。这是着眼未来的方案。"

# game/choice chapter 1.rpy:657
translate chinese channels_61a603ca:

    # jes "You thought about the next season... and the season after that."
    jes "您想到了下个季节.....甚至下下季。"

# game/choice chapter 1.rpy:659
translate chinese channels_466d8ae9:

    # "He paused, smiling."
    "他笑着顿了顿。"

# game/choice chapter 1.rpy:663
translate chinese channels_51e307fc:

    # jes "Perhaps a little too far."
    jes "不过......也许想得有点太远了。"

# game/choice chapter 1.rpy:664
translate chinese channels_80f10282:

    # jes "Tell me, Your Majesty. what was the farmer’s problem right now?"
    jes "告诉我，陛下，农夫眼下真正的问题是什么？"

# game/choice chapter 1.rpy:666
translate chinese channels_5e9f4520:

    # "huh?"
    "啊？"

# game/choice chapter 1.rpy:667
translate chinese channels_625d0c5d:

    # "The drought caused the crops to fail, leaving them with no income to buy new seeds...and.."
    "干旱导致庄稼绝收，他们就没了收入去买新种子......连......"

# game/choice chapter 1.rpy:669
translate chinese channels_7777ddff:

    # mc "No money to meet their daily needs..."
    mc "日常开销都撑不住......"

# game/choice chapter 1.rpy:673
translate chinese channels_7d3aa4cc:

    # jes "Oh, excellent! You remembered! Five stars for vision!"
    jes "噢，真不错！您还记得！这份眼光，值得五颗星！"

# game/choice chapter 1.rpy:677
translate chinese channels_75a0ebbc:

    # jes "And yet... A hungry farmer cannot eat a future harvest."
    jes "但......饿着肚子的农夫，吃不了未来的收成。"

# game/choice chapter 1.rpy:679
translate chinese channels_3077e7bf:

    # "He chuckled softly."
    "他轻笑一声。"

# game/choice chapter 1.rpy:681
translate chinese channels_febb6fba:

    # jes "It seems you may need to do a little more than simply building water channels."
    jes "看来您要做的，恐怕不只是修水渠这么简单。"

# game/choice chapter 1.rpy:685
translate chinese channels_50bcfa87:

    # "Oh... he is right..."
    "......是啊，他说得对......"

# game/choice chapter 1.rpy:686
translate chinese channels_fecd91a3:

    # "Being a [title] is really hard..."
    "当个统治者真的很难......"

# game/choice chapter 1.rpy:687
translate chinese channels_8ebdfdc5:

    # "I mean, I’m just a security guard, desperate for money just to survive."
    "说到底，我不过是个保安，拼命挣钱也只是为了活下去。"

# game/choice chapter 1.rpy:688
translate chinese channels_800a9434:

    # "And now, all of a sudden, I’m being dragged into playing the role of a queen by living puppets."
    "现在却突然被一群活木偶拖进来，逼着我去扮演一国之主。"

# game/choice chapter 1.rpy:689
translate chinese channels_9c6e8d8c:

    # "I’m really not that fit to be a leader."
    "我真的不太适合当领导者。"

# game/choice chapter 1.rpy:696
translate chinese seeds_05418970:

    # "The crops failed during the dry season. If I remember correctly, there are plants that can survive dry conditions."
    "旱季一到，庄稼就歉收。要是我没记错，有些作物是耐旱的。"

# game/choice chapter 1.rpy:698
translate chinese seeds_f5412774:

    # mc "Are there any crops that can survive drought?"
    mc "有没有特别耐旱的作物？"

# game/choice chapter 1.rpy:699
translate chinese seeds_2b54f80a:

    # "The farmer fell silent, thinking."
    "农夫沉默了一会儿，像是在思索。"

# game/choice chapter 1.rpy:703
translate chinese seeds_8d8bbcc6:

    # farm "Ah! There are, Your Majesty. Tomatoes, corn, and root crops, for example."
    farm "啊！有的，陛下。比如番茄、玉米，还有根茎类作物。"

# game/choice chapter 1.rpy:704
translate chinese seeds_b6241d51:

    # mc "Then how about we switch to crops that can survive the dry season? I will provide the seeds you need."
    mc "那不如改种些能扛过旱季的作物？你们需要的种子，我来提供。"

# game/choice chapter 1.rpy:705
translate chinese seeds_d7ab5505:

    # nara "{color=#E0AE4B}Upon hearing the [title]’s decision to provide the new seeds for farmers, the farmer’s heart danced with joy.{/color}"
    nara "{color=#E0AE4B}听到[title]决定为农民提供新种子，农夫顿时欣喜若狂。{/color}"

# game/choice chapter 1.rpy:707
translate chinese seeds_618ce9e7:

    # "Alright, that narrator’s voice, that coming from who knows where, was starting to make me uneasy."
    "说真的，那道不知从哪儿传来的旁白声，开始让我不安起来。"

# game/choice chapter 1.rpy:714
translate chinese seeds_3a688fd4:

    # "The farmer nodded in agreement."
    "农夫点头表示赞同。"

# game/choice chapter 1.rpy:716
translate chinese seeds_629c7591:

    # farm "I understand, Your Majesty. Thank you for your help."
    farm "我明白了，陛下。感谢您的帮助。"

# game/choice chapter 1.rpy:717
translate chinese seeds_ee3ef29a:

    # nara "{color=#E0AE4B}With a joyful heart, the farmer finally left the palace to deliver the good news.{/color}"
    nara "{color=#E0AE4B}农夫满心欢喜地离开了宫殿，去传达这个好消息。{/color}"

# game/choice chapter 1.rpy:719
translate chinese seeds_abbe3b80:

    # "The farmer puppet then stood up and left the stage."
    "农夫木偶随即起身，离开了舞台。"

# game/choice chapter 1.rpy:723
translate chinese seeds_d3df1e05:

    # "After that, the farmer stood up and walked off the stage."
    "之后，农夫起身走下了舞台。"

# game/choice chapter 1.rpy:724
translate chinese seeds_54f54627:

    # "I could feel Jestyn’s gaze fixed on me."
    "我能感觉到Jestyn的目光一直落在我身上。"

# game/choice chapter 1.rpy:729
translate chinese seeds_934cc55f:

    # jes "Such a wise decision, Your Majesty."
    jes "这真是个明智的决定，陛下。"

# game/choice chapter 1.rpy:730
translate chinese seeds_211c6330:

    # jes "Choosing crops that can endure the harsh sunlight of the dry season, so the farmers no longer need to worry about their crops dying."
    jes "改种能熬过旱季烈日的作物，农民就不必再担心庄稼枯死了。"

# game/choice chapter 1.rpy:731
translate chinese seeds_25a9b9fe:

    # jes "Your way of thinking truly looks far ahead. You genuinely considered what their future might be like."
    jes "您的想法确实长远，是真正在为他们的未来考虑。"

# game/choice chapter 1.rpy:733
translate chinese seeds_510a1e83:

    # "He paused."
    "他顿了顿。"

# game/choice chapter 1.rpy:737
translate chinese seeds_1c64c52d:

    # jes "A brilliant plan for tomorrow... but what shall they eat tonight?"
    jes "明天的计划很漂亮......但他们今晚吃什么呢？"

# game/choice chapter 1.rpy:739
translate chinese seeds_4cb2462c:

    # "I freeze"
    "我僵住了。"

# game/choice chapter 1.rpy:741
translate chinese seeds_533ce45d:

    # jes "Do you remember what kind of problem the farmer had just now?"
    jes "还记得刚才农夫真正的问题是什么吗？"

# game/choice chapter 1.rpy:743
translate chinese seeds_5e9f4520:

    # "huh?"
    "啊？"

# game/choice chapter 1.rpy:744
translate chinese seeds_625d0c5d:

    # "The drought caused the crops to fail, leaving them with no income to buy new seeds...and.."
    "干旱导致庄稼绝收，他们就没了收入去买新种子......连......"

# game/choice chapter 1.rpy:746
translate chinese seeds_7777ddff:

    # mc "No money to meet their daily needs..."
    mc "日常开销都撑不住......"

# game/choice chapter 1.rpy:749
translate chinese seeds_7d3aa4cc:

    # jes "Oh, excellent! You remembered! Five stars for vision!"
    jes "噢噢，真不错！您还记得！这份眼光，值得五颗星！"

# game/choice chapter 1.rpy:751
translate chinese seeds_b2bb6ca5:

    # jes "Crops do not grow overnight, Your Majesty. I trust you are aware of that."
    jes "庄稼可不是一夜之间就能长出来的，陛下。您应该明白。"

# game/choice chapter 1.rpy:753
translate chinese seeds_3077e7bf:

    # "He chuckled softly."
    "他轻笑一声。"

# game/choice chapter 1.rpy:754
translate chinese seeds_823f0634:

    # "Oh..he is right..."
    "是啊......他说得对......"

# game/choice chapter 1.rpy:756
translate chinese seeds_12da887b:

    # jes "It seems you may need to do a little more than that."
    jes "看来您得做的，恐怕不止这些。"

# game/choice chapter 1.rpy:758
translate chinese seeds_50bcfa87:

    # "Oh... he is right..."
    "是啊......他说得对......"

# game/choice chapter 1.rpy:759
translate chinese seeds_fecd91a3:

    # "Being a [title] is really hard..."
    "当个统治者真的很难......"

# game/choice chapter 1.rpy:760
translate chinese seeds_8ebdfdc5:

    # "I mean, I’m just a security guard, desperate for money just to survive."
    "说到底，我不过是个保安，拼命挣钱也只是为了活下去。"

# game/choice chapter 1.rpy:761
translate chinese seeds_800a9434:

    # "And now, all of a sudden, I’m being dragged into playing the role of a queen by living puppets."
    "现在却突然被一群活木偶拖进来，逼着我去扮演一国之主。"

# game/choice chapter 1.rpy:762
translate chinese seeds_9c6e8d8c:

    # "I’m really not that fit to be a leader."
    "我真的不太适合当领导者。"

# game/choice chapter 1.rpy:767
translate chinese time_7ecb0508:

    # "What does a farmer need to prevent crop failure during the dry season..?"
    "要想在旱季不再歉收......农夫到底需要什么？"

# game/choice chapter 1.rpy:768
translate chinese time_313eb8ad:

    # "Money? Seeds?? But is that really enough to deal with this?"
    "钱？种子？？但光靠这些，真的够吗？"

# game/choice chapter 1.rpy:769
translate chinese time_3f0be528:

    # "Oh my god..."
    "天啊......"

# game/choice chapter 1.rpy:771
translate chinese time_5552f504:

    # mc "I’m sorry... I... need more time to think."
    mc "对不起......我......我需要再想想。"

# game/choice chapter 1.rpy:772
translate chinese time_c41d70d8:

    # nara "{color=#E0AE4B}Hearing the [title]’s words, the farmer tried to understand that such decisions could not be made in haste. Even so, his heart remained uneasy{/color}"
    nara "{color=#E0AE4B}听到一国之主这么说，农夫也明白这件事不能急着做决定。尽管如此，他心里还是有些不踏实。{/color}"

# game/choice chapter 1.rpy:774
translate chinese time_618ce9e7:

    # "Alright, that narrator’s voice, that coming from who knows where, was starting to make me uneasy."
    "说真的，那道不知从哪儿传来的旁白声，开始让我不安起来。"

# game/choice chapter 1.rpy:779
translate chinese time_ac1bd28d:

    # "The farmer nodded in understanding."
    "农夫点点头，表示理解。"

# game/choice chapter 1.rpy:783
translate chinese time_4c65c579:

    # farm "Very well, Your Majesty. Please, we ask for your help..."
    farm "好吧，陛下。求您了......请帮帮我们......"

# game/choice chapter 1.rpy:787
translate chinese time_be39b031:

    # "After that, the farmer puppet left the stage."
    "说完，农夫木偶离开了舞台。"

# game/choice chapter 1.rpy:789
translate chinese time_3702aefd:

    # nara "{color=#E0AE4B}From the corner of the room, the jester watched the [title] with a sharp gaze, his usual smile still fixed upon his face.{/color}"
    nara "{color=#E0AE4B}房间角落里，Jestyn正用锐利的目光盯着，脸上仍挂着他那副惯常的笑。{/color}"

# game/choice chapter 1.rpy:790
translate chinese time_cd5e6247:

    # nara "{color=#E0AE4B}It seemed the jester wished to offer a few words to the [title].{/color}"
    nara "{color=#E0AE4B}看起来，Jestyn似乎想对他的陛下说些什么。{/color}"

# game/choice chapter 1.rpy:792
translate chinese time_54f54627:

    # "I could feel Jestyn’s gaze fixed on me."
    "我能感觉到Jestyn的目光一直落在我身上。"

# game/choice chapter 1.rpy:797
translate chinese time_cacbe634:

    # jes "More time, Your Majesty?"
    jes "还要更多时间吗，陛下？"

# game/choice chapter 1.rpy:799
translate chinese time_14688fd9:

    # "He smiled, amused."
    "他带着几分玩味地笑了。"

# game/choice chapter 1.rpy:803
translate chinese time_fd6e3b5c:

    # jes "How charming."
    jes "真可爱。"

# game/choice chapter 1.rpy:804
translate chinese time_a889852b:

    # jes "Very well, take all the time you need."
    jes "也好，您尽管慢慢想。"

# game/choice chapter 1.rpy:805
translate chinese time_de9cb362:

    # jes "Just remember..."
    jes "但请记住......"

# game/choice chapter 1.rpy:807
translate chinese time_6878d401:

    # "He leaned in slightly."
    "他微微凑近。"

# game/choice chapter 1.rpy:809
translate chinese time_792809bf:

    # jes "The dry season is not known for its patience. Nor are hungry people"
    jes "旱季可没有什么耐心，饥饿的人更不会有。"

# game/choice chapter 1.rpy:811
translate chinese time_50bcfa87:

    # "Oh... he is right..."
    "是啊......他说得对......"

# game/choice chapter 1.rpy:812
translate chinese time_fecd91a3:

    # "Being a [title] is really hard..."
    "当个统治者真的很难......"

# game/choice chapter 1.rpy:813
translate chinese time_8ebdfdc5:

    # "I mean, I’m just a security guard, desperate for money just to survive."
    "说到底，我不过是个保安，拼命挣钱也只是为了活下去。"

# game/choice chapter 1.rpy:814
translate chinese time_800a9434:

    # "And now, all of a sudden, I’m being dragged into playing the role of a queen by living puppets."
    "现在却突然被一群活木偶拖进来，逼着我去扮演一国之主。"

# game/choice chapter 1.rpy:815
translate chinese time_9c6e8d8c:

    # "I’m really not that fit to be a leader."
    "我真的不太适合当领导者。"

# game/choice chapter 1.rpy:820
translate chinese yourselves_5f9b772e:

    # "...."
    "...."

# game/choice chapter 1.rpy:821
translate chinese yourselves_9373dc2d:

    # "This is stupid."
    "这太荒唐了。"

# game/choice chapter 1.rpy:822
translate chinese yourselves_72bbf181:

    # "I’m not a [title]. I’m just a security guard."
    "我不是一国之主。我就只是个保安。"

# game/choice chapter 1.rpy:823
translate chinese yourselves_e40328e6:

    # "I want to go home."
    "我想回家。"

# game/choice chapter 1.rpy:825
translate chinese yourselves_2297ff89:

    # mc "I think you can solve your problem on your own."
    mc "我觉得你们可以自己解决这个问题。"

# game/choice chapter 1.rpy:826
translate chinese yourselves_4b6ef1a4:

    # mc "I don’t understand farming, and as a farmer, you should know better what to do."
    mc "我不懂农事，而你是农夫，应该比我更清楚该怎么做。"

# game/choice chapter 1.rpy:831
translate chinese yourselves_7426e176:

    # farm ".....Your Majesty....i beg you..."
    farm "......陛下......求您垂怜......"

# game/choice chapter 1.rpy:836
translate chinese yourselves_8aa21722:

    # farm "I BEG YOU!!!"
    farm "求您开恩啊！！！"

# game/choice chapter 1.rpy:840
translate chinese yourselves_01cea383:

    # "The puppet hold my shoulder tightly"
    "那木偶死死抓住我的肩膀。"

# game/choice chapter 1.rpy:841
translate chinese yourselves_69eb1ab6:

    # "Really really tight"
    "手指越收越紧。"

# game/choice chapter 1.rpy:843
translate chinese yourselves_fee87583:

    # farm "{color=#FF2727}{cps=220}not again{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}不要再这样了{/cps}{/color}"

# game/choice chapter 1.rpy:850
translate chinese yourselves_fcbf8c3d:

    # farm "{color=#FF2727}{cps=220}NOT AGAIN!!{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}不要再这样了！！{/cps}{/color}"

# game/choice chapter 1.rpy:851
translate chinese yourselves_a8e541b2:

    # "W–what... is this..?"
    "这——这......怎么回事......？"

# game/choice chapter 1.rpy:852
translate chinese yourselves_078dff8c:

    # "Suddenly, Suddenly, my head began to throb violently, as if it were being twisted."
    "突然间，我的头猛地抽痛起来，像是被人硬生生拧着。"

# game/choice chapter 1.rpy:853
translate chinese yourselves_7c1bc812:

    # "My vision blurred. Yet through the haze, I saw something. something I couldn’t even begin to understand."
    "我的视线一阵模糊。但在那片模糊里，我看见了什么。某种我根本无法理解的东西。"

# game/choice chapter 1.rpy:856
translate chinese yourselves_606f26f5:

    # farm "{color=#FF2727}{cps=220}YOU WON'T LEAVE ME LIKE HE DID WON'T YOU?!{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}您不会像他那样丢下我，对不对？！{/cps}{/color}"

# game/choice chapter 1.rpy:858
translate chinese yourselves_cfc71ebb:

    # farm "{color=#FF2727}{cps=220}DON'T LEAVE ME!!{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}别丢下我！！{/cps}{/color}"

# game/choice chapter 1.rpy:864
translate chinese yourselves_642fb35c:

    # jes "Ooopsyy~"
    jes "哎呀呀~"

# game/choice chapter 1.rpy:868
translate chinese yourselves_4ca1c9a7:

    # "Jestyn took hold of his shoulder and pulled him away from me."
    "Jestyn抓住他的肩膀，把他从我身边拉开。"

# game/choice chapter 1.rpy:874
translate chinese yourselves_23809793:

    # jes "Didn’t you hear what [poss] Majesty said, my dear farmer friend?"
    jes "我亲爱的农夫朋友，陛下刚才说的话，你没听见吗？"

# game/choice chapter 1.rpy:875
translate chinese yourselves_9ec360c0:

    # jes "[poss] Majesty said you may find your own way out. At the very least, [poss] Majesty believes in your abilities!"
    jes "陛下说了，你可以自己想办法。至少，陛下相信你有这个能耐！"

# game/choice chapter 1.rpy:876
translate chinese yourselves_20ca5cc2:

    # jes "To be granted trust by Her Majesty herself is as though you’ve been blessed by the Fairy Mother’s miracle. You should feel honored."
    jes "能得到陛下亲口赐下的信任，简直像是受到了仙女教母的奇迹祝福一样。你该感到荣幸。"

# game/choice chapter 1.rpy:877
translate chinese yourselves_8de16e70:

    # jes "Now, it would be best for you to return and think carefully about what you must do. Do you understand, my friend?"
    jes "现在，你最好回去，仔细想清楚自己该做什么。明白了吗，我的朋友？"

# game/choice chapter 1.rpy:878
translate chinese yourselves_73880861:

    # farm "I... I understand... please forgive my insolence, Your Majesty."
    farm "我......我明白了......请原谅我无礼，陛下。"

# game/choice chapter 1.rpy:883
translate chinese yourselves_860a1e6b:

    # nara "{color=#E0AE4B}With a heavy heart, the farmer finally left the kingdom.{/color}"
    nara "{color=#E0AE4B}农夫怀着沉重的心情，最终离开了王国。{/color}"

# game/choice chapter 1.rpy:884
translate chinese yourselves_dc6f9e94:

    # nara "{color=#E0AE4B}Upon hearing [poss] Majesty’s decision earlier, Jestyn merely wore his usual smile.{/color}"
    nara "{color=#E0AE4B}听到陛下先前的决定，Jestyn只是照旧挂着那抹笑。{/color}"

# game/choice chapter 1.rpy:886
translate chinese yourselves_b172629f:

    # "I could feel Jestyn’s sharp gaze directed at me."
    "我能感觉到Jestyn锐利的目光落在我身上。"

# game/choice chapter 1.rpy:890
translate chinese yourselves_70f40038:

    # jes "...."
    jes "...."

# game/choice chapter 1.rpy:894
translate chinese yourselves_8f599295:

    # jes "Pffft... {size= 15}not very different, hm?{/size}"
    jes "噗......{size=15}也没什么区别嘛？{/size}"

# game/choice chapter 1.rpy:895
translate chinese yourselves_6046db3b:

    # mc "Huh? Did you say something?"
    mc "嗯？你说什么？"

# game/choice chapter 1.rpy:900
translate chinese yourselves_456a66bd:

    # jes "No, no, no. I didn’t say anything, Your Majesty."
    jes "没有没有，陛下。我什么都没说。"

# game/choice chapter 1.rpy:901
translate chinese yourselves_b6a39c97:

    # jes "You are not wrong. All the power is in your hands."
    jes "您说得没错，权力确实都在您手里。"

# game/choice chapter 1.rpy:902
translate chinese yourselves_43d17dc6:

    # jes "You may do anything you wish with that power."
    jes "您想怎么使用这份权力，都随您。"

# game/choice chapter 1.rpy:906
translate chinese yourselves_fdb0e29e:

    # "Even though Jestyn said so, I could see his smile sharpen."
    "虽然Jestyn这么说，可我看得出来，他脸上的笑意变得更尖锐了。"

# game/choice chapter 1.rpy:909
translate chinese yourselves_0b6fbd6f:

    # jes "Hmm...though, to be perfectly honest, it’s rather disappointing… if you were to ask me."
    jes "嗯......不过，说句实话，要是问我的看法，这还真挺让人失望的......"

# game/choice chapter 1.rpy:916
translate chinese teach_a8068edd:

    # mc "Well as the jester who good at juggling, why don't you just teach me?"
    mc "弄臣不是很会杂耍吗？你为什么不教教我呢？"

# game/choice chapter 1.rpy:918
translate chinese teach_1c3b3e2c:

    # "He freezes for a moment."
    "他愣了一下。"

# game/choice chapter 1.rpy:920
translate chinese teach_9b495d15:

    # jes "Teach you? You mean... teach you how to juggle?"
    jes "教你？你是说......教你怎么杂耍？"

# game/choice chapter 1.rpy:921
translate chinese teach_6fd4a9b4:

    # mc "Yes. at the very least, I want to try to not drop them right away."
    mc "对。至少......让我别一上来就全掉了。"

# game/choice chapter 1.rpy:923
translate chinese teach_0263f09b:

    # "Truthfully, I am already exhausted. But I feel like I cannot stop here."
    "说真的，我已经筋疲力尽了。但我总觉得不能就这样停下。"

# game/choice chapter 1.rpy:925
translate chinese teach_58e954d7:

    # "Jestyn’s surprised expression slowly turns into a wide smile."
    "Jestyn脸上的惊讶慢慢化作一个大大的笑。"

# game/choice chapter 1.rpy:927
translate chinese teach_4f006298:

    # jes "How interesting, Very well, then."
    jes "有意思。好吧，那就来吧。"

# game/choice chapter 1.rpy:930
translate chinese teach_8bf8d88c:

    # "He picks up the balls that had fallen and hands them back to me."
    "他把掉在地上的球捡起，递回到我手里。"

# game/choice chapter 1.rpy:932
translate chinese teach_eacef35b:

    # jes "Go on, give it a try."
    jes "来，试试。"

# game/choice chapter 1.rpy:934
translate chinese teach_b34a0dec:

    # "I brace myself and start tossing the balls, but Jestyn’s gaze makes me nervous."
    "我深吸一口气，开始抛球。但Jestyn的目光盯得我发毛。"

# game/choice chapter 1.rpy:935
translate chinese teach_4fae875f:

    # "Even so, I throw them into the air."
    "尽管如此，我还是把球抛向空中。"

# game/choice chapter 1.rpy:937
translate chinese teach_0ed3c7cd:

    # "Jestyn lets out a soft laugh as he watches my attempt."
    "Jestyn看着我笨拙的尝试，低低笑了一声。"

# game/choice chapter 1.rpy:939
translate chinese teach_e0860bcf:

    # jes "Your majesty, it can hardly be called juggling if you do it that slowly."
    jes "陛下，您这么慢，实在很难称得上是杂耍。"

# game/choice chapter 1.rpy:940
translate chinese teach_d965a6a7:

    # mc "Oh, come on! I’m learning here!"
    mc "拜托！我正在学！"

# game/choice chapter 1.rpy:943
translate chinese teach_ec065d5c:

    # "He snaps his fingers, and suddenly more balls appear in his hand."
    "他打了个响指，手里突然又多了几颗球。"

# game/choice chapter 1.rpy:944
translate chinese teach_daa28512:

    # "He begins juggling as well. Though it feels less like practice and more like showing off."
    "他也开始杂耍起来。但那看着不像教学，倒更像是在炫技。"

# game/choice chapter 1.rpy:945
translate chinese teach_5faeebe1:

    # "He performs trick after trick with ease, while I... continue tossing the balls slowly, what I insist on calling ‘juggling.’"
    "他轻轻松松地耍出一个又一个花样，而我......还在慢吞吞地抛着球，硬说这也算“杂耍”。"

# game/choice chapter 1.rpy:946
translate chinese teach_ffdb6aa0:

    # "The way he teases me is genuinely irritating."
    "他这样故意捉弄我，真的让人火大。"

# game/choice chapter 1.rpy:947
translate chinese teach_e097e94f:

    # "When I try to speed up, a few balls nearly slip from my hands, and some fall to the floor."
    "我一加快动作，几颗球就差点从手里滑出去，另外还有几颗直接掉到了地上。"

# game/choice chapter 1.rpy:950
translate chinese teach_658c6e28:

    # jes "Hahahaha! Come now, just accept it you simply can’t do it your majesty."
    jes "哈哈哈哈！认了吧，陛下，您就是做不到。"

# game/choice chapter 1.rpy:952
translate chinese teach_d7f95ee5:

    # mc "But i asked you to teach me. Not mocking me. I don't feel like you teach me something about juggling"
    mc "我是让你教我，不是让你笑话我。我一点也没感觉你在教我杂耍。"

# game/choice chapter 1.rpy:953
translate chinese teach_89d9c769:

    # jes "I do my dear, i teach you through experience"
    jes "我当然是在教你，亲爱的。我这是在让您从实践中学习。"

# game/choice chapter 1.rpy:954
translate chinese teach_54057719:

    # mc "I don't think that is how it works..."
    mc "我不觉得教学是这么回事......"

# game/choice chapter 1.rpy:955
translate chinese teach_59761f3d:

    # jes "Ah, but what a truly remarkable enthusiasm for learning, dear. Such dedication surely deserves... a gift."
    jes "啊，不过您这股求学的热情还真是难得，亲爱的。如此认真，当然值得......一份礼物。"

# game/choice chapter 1.rpy:957
translate chinese teach_75dac18b:

    # "Jestyn suddenly tosses a single ball toward me, startling me and causing all of my balls to fall."
    "Jestyn突然朝我抛来一颗球，吓得我一慌，手里的球瞬间全掉了。"

# game/choice chapter 1.rpy:958
translate chinese teach_d9c47830:

    # "As I try to catch it, the ball suddenly vanishes into thin air."
    "我刚想去接，那颗球却突然凭空消失了。"

# game/choice chapter 1.rpy:961
translate chinese teach_7b26cc90:

    # jes "Oh? It seems your catching skills are just as dreadful, your majesty"
    jes "哦？看来您接球功夫也一样惨不忍睹呢，陛下。"

# game/choice chapter 1.rpy:962
translate chinese teach_ccdac953:

    # jes "Allow me. I shall catch it for you."
    jes "让我来吧。我替您接住。"

# game/choice chapter 1.rpy:964
translate chinese teach_4a05fb50:

    # "His arm reaches out, stopping just behind my ear."
    "他伸出手，指尖停在我耳后。"

# game/choice chapter 1.rpy:968
translate chinese teach_562d842e:

    # jes "Care to guess where the ball is?"
    jes "要猜猜球在哪儿吗？"

# game/choice chapter 1.rpy:980
translate chinese snakebunny_9bb39788:

    # jes "When I choose his left hand, a small snake doll appears."
    jes "当我选中他的左手时，一只小蛇玩偶出现了。"

# game/choice chapter 1.rpy:981
translate chinese snakebunny_640c5bae:

    # jes "An excellent choice, Your Majesty."
    jes "您选得真好，陛下。"

# game/choice chapter 1.rpy:982
translate chinese snakebunny_bc7fc48c:

    # jes "A gift from me... to you."
    jes "这礼物是我……送给您的。"

# game/choice chapter 1.rpy:985
translate chinese snakebunny_78dff35c:

    # "He takes a step back."
    "他向后退了一步。"

# game/choice chapter 1.rpy:986
translate chinese snakebunny_5ae637bc:

    # "Did he just do a magic trick?!"
    "他刚才是在变魔术吗？！"

# game/choice chapter 1.rpy:988
translate chinese snakebunny_d9a9687a:

    # mc "Oh! That’s so cool! How did you do that?!"
    mc "哇！太酷了！你怎么做到的？！"

# game/choice chapter 1.rpy:991
translate chinese snakebunny_597f50e6:

    # "Jestyn fell silent for a moment, before his smile slowly returned."
    "Jestyn沉默了片刻，脸上的笑意才慢慢重新浮现。"

# game/choice chapter 1.rpy:993
translate chinese snakebunny_c87ad347:

    # jes "That is a jester’s secret, my dear. I could never tell you~"
    jes "这可是弄臣的秘密呀，亲爱的。我怎么能告诉您呢~"

# game/choice chapter 1.rpy:995
translate chinese snakebunny_1a1e1df0:

    # "Jestyn said teasingly"
    "Jestyn逗弄似的说道。"

# game/choice chapter 1.rpy:997
translate chinese snakebunny_b2afd01b:

    # mc "Then... Can i see more?."
    mc "那......我还能再看几个吗？"

# game/choice chapter 1.rpy:999
translate chinese snakebunny_deeff8f2:

    # jes "Oh..."
    jes "哦......"

# game/choice chapter 1.rpy:1001
translate chinese snakebunny_8a7b7d6c:

    # "Why did he make that expression? Did I say something wrong?"
    "他怎么露出这种表情？我说错什么了吗？"

# game/choice chapter 1.rpy:1004
translate chinese snakebunny_b007eb96:

    # jes "Hahaha! Such a curious little thing, hm?"
    jes "哈哈哈！还真是个好奇的小家伙，嗯？"

# game/choice chapter 1.rpy:1007
translate chinese snakebunny_bbb3891f:

    # "He start to clenched his hand, then began pulling a piece of cloth from his palm."
    "他先攥紧拳头，随后从掌心里慢慢抽出一条布带。"

# game/choice chapter 1.rpy:1008
translate chinese snakebunny_e13e12a8:

    # "As he pulled, the cloth only grew longer and longer."
    "随着他不断往外抽，那条布带也越变越长。"

# game/choice chapter 1.rpy:1011
translate chinese snakebunny_f7392af4:

    # mc "How is that possible?!"
    mc "这怎么可能？！"

# game/choice chapter 1.rpy:1013
translate chinese snakebunny_6b9b7aff:

    # "He squeezed the cloth tightly."
    "他把那块布紧紧攥在手里。"

# game/choice chapter 1.rpy:1014
translate chinese snakebunny_b986bf3b:

    # "What is he doing now?"
    "他现在又想做什么？"

# game/choice chapter 1.rpy:1016
translate chinese snakebunny_354dc1bc:

    # "When he opened it again, a small rabbit doll suddenly appeared inside."
    "等他再张开手时，里面突然出现了一只小兔子玩偶。"

# game/choice chapter 1.rpy:1018
translate chinese snakebunny_ecebd32f:

    # mc "Oh! that's amazing!"
    mc "哇！太厉害了！"

# game/choice chapter 1.rpy:1021
translate chinese snakebunny_68885399:

    # jes "And now, the royal jester’s magic show has come to an end. Thank you for your attention."
    jes "那么，宫廷弄臣的魔术表演到此结束。感谢您的观赏。"

# game/choice chapter 1.rpy:1028
translate chinese bunnysnake_bc84d5b1:

    # jes "When I choose his right hand, a small bunny doll appears."
    jes "当我选中他的右手时，一只小兔子玩偶出现了。"

# game/choice chapter 1.rpy:1029
translate chinese bunnysnake_640c5bae:

    # jes "An excellent choice, Your Majesty."
    jes "您选得真好，陛下。"

# game/choice chapter 1.rpy:1030
translate chinese bunnysnake_bc7fc48c:

    # jes "A gift from me... to you."
    jes "这礼物是我......送给您的。"

# game/choice chapter 1.rpy:1033
translate chinese bunnysnake_78dff35c:

    # "He takes a step back."
    "他向后退了一步。"

# game/choice chapter 1.rpy:1034
translate chinese bunnysnake_5ae637bc:

    # "Did he just do a magic trick?!"
    "他刚才是在变魔术？！"

# game/choice chapter 1.rpy:1036
translate chinese bunnysnake_d9a9687a:

    # mc "Oh! That’s so cool! How did you do that?!"
    mc "哇，太酷了！你怎么做到的？！"

# game/choice chapter 1.rpy:1039
translate chinese bunnysnake_597f50e6:

    # "Jestyn fell silent for a moment, before his smile slowly returned."
    "estyn沉默了片刻，脸上的笑意才慢慢重新浮现。"

# game/choice chapter 1.rpy:1041
translate chinese bunnysnake_c87ad347:

    # jes "That is a jester’s secret, my dear. I could never tell you~"
    jes "这可是弄臣的秘密呀，亲爱的。我怎么能告诉您呢~"

# game/choice chapter 1.rpy:1043
translate chinese bunnysnake_1a1e1df0:

    # "Jestyn said teasingly"
    "Jestyn逗弄似的说道。"

# game/choice chapter 1.rpy:1045
translate chinese bunnysnake_b2afd01b:

    # mc "Then... Can i see more?."
    mc "那......还能再看几个吗？"

# game/choice chapter 1.rpy:1047
translate chinese bunnysnake_deeff8f2:

    # jes "Oh..."
    jes "哦......"

# game/choice chapter 1.rpy:1049
translate chinese bunnysnake_8a7b7d6c:

    # "Why did he make that expression? Did I say something wrong?"
    "他怎么露出这种表情？我说错什么了吗？"

# game/choice chapter 1.rpy:1052
translate chinese bunnysnake_b007eb96:

    # jes "Hahaha! Such a curious little thing, hm?"
    jes "哈哈哈！还真是个好奇的小家伙，嗯？"

# game/choice chapter 1.rpy:1055
translate chinese bunnysnake_bbb3891f:

    # "He start to clenched his hand, then began pulling a piece of cloth from his palm."
    "他先攥紧拳头，随后从掌心里慢慢抽出一条布带。"

# game/choice chapter 1.rpy:1056
translate chinese bunnysnake_e13e12a8:

    # "As he pulled, the cloth only grew longer and longer."
    "随着他不断往外抽，那条布带也越变越长。"

# game/choice chapter 1.rpy:1058
translate chinese bunnysnake_f7392af4:

    # mc "How is that possible?!"
    mc "这怎么可能？！"

# game/choice chapter 1.rpy:1061
translate chinese bunnysnake_6b9b7aff:

    # "He squeezed the cloth tightly."
    "他把那块布紧紧攥在手里。"

# game/choice chapter 1.rpy:1062
translate chinese bunnysnake_b986bf3b:

    # "What is he doing now?"
    "他现在又想做什么？"

# game/choice chapter 1.rpy:1064
translate chinese bunnysnake_8509cf99:

    # "When he opened it again, a small snake doll suddenly appeared inside."
    "等他再摊开手时，里面竟突然多出一只小蛇玩偶。"

# game/choice chapter 1.rpy:1066
translate chinese bunnysnake_ecebd32f:

    # mc "Oh! that's amazing!"
    mc "哇！太厉害了！"

# game/choice chapter 1.rpy:1069
translate chinese bunnysnake_68885399:

    # jes "And now, the royal jester’s magic show has come to an end. Thank you for your attention."
    jes "那么，宫廷弄臣的魔术表演到此结束。感谢您的观赏。"

# game/choice chapter 1.rpy:1077
translate chinese agree_1d66e373:

    # jes "How decisive, Your Majesty."
    jes "真是果断啊，陛下。"

# game/choice chapter 1.rpy:1078
translate chinese agree_88549114:

    # jes "Gold has a way of making difficult choices appear... simpler."
    jes "黄金总有办法让艰难的抉择看起来......简单一些。"

# game/choice chapter 1.rpy:1080
translate chinese agree_13c3b0b7:

    # jes "Let us hope the land proves less costly than it seems."
    jes "但愿那片土地最终付出的代价，不会比表面看起来更高。"

# game/choice chapter 1.rpy:1086
translate chinese Refuse_27f4f767:

    # jes "Oh?"
    jes "哦？"

# game/choice chapter 1.rpy:1087
translate chinese Refuse_2e654457:

    # jes "To turn down such generosity... how admirable."
    jes "竟能拒绝这般慷慨......真令人钦佩。"

# game/choice chapter 1.rpy:1089
translate chinese Refuse_cc9ede7b:

    # jes "One can only hope our neighbors share Your Majesty’s appreciation for principles."
    jes "只希望我们的邻国，也能像陛下一样理解原则。"

# game/choice chapter 1.rpy:1096
translate chinese delay_db12c9a8:

    # jes "Hehe...Your Majesty, truly?"
    jes "呵呵......陛下，当真？"

# game/choice chapter 1.rpy:1097
translate chinese delay_0a968d07:

    # jes "Surely you don’t intend to keep postponing your decisions whenever a problem arises?"
    jes "您总不会打算每次一出问题，就把决定一拖再拖吧？"

# game/choice chapter 1.rpy:1099
translate chinese delay_ca508555:

    # jes "Since I pride myself on being an honest man, I must say...that is terribly naïve. And rather pitiful."
    jes "既然我自诩为人坦诚，那我就直说了......这想法天真得可怕，也相当可怜。"

# game/choice chapter 1.rpy:1100
translate chinese delay_315de719:

    # jes "Perhaps we should revise the wording. Instead of 'taking your time to decide'... we might call it what it truly is, 'running away from your problems'"
    jes "或许我们该换个说法。与其称之为“慢慢再做决定”......不如叫它真正的名字，“逃避问题”。"

# game/choice chapter 1.rpy:1101
translate chinese delay_4cd35246:

    # jes "No matter how far you run, no matter how fast you run... time will always run alongside you."
    jes "无论您跑得多远、跑得多快......时间都会始终与您并行。"

# game/choice chapter 1.rpy:1103
translate chinese delay_58244563:

    # jes "So... tick tock, tick tock, Your Majesty~"
    jes "所以......滴答，滴答，时间可不会等您哦，陛下~"

# game/choice chapter 1.rpy:1109
translate chinese delay_cb35ed05:

    # jes "Of course, Your Majesty."
    jes "当然，陛下。"

# game/choice chapter 1.rpy:1111
translate chinese delay_a120d3c0:

    # jes "After all, a choice left undecided is still a choice."
    jes "毕竟，迟迟不做决定，本身也是一种选择。"

# game/choice chapter 1.rpy:1113
translate chinese delay_82634f5a:

    # jes "Time, however, is rarely as patient as we wish it to be."
    jes "只不过，时间很少会像我们希望的那样有耐心。"

# game/choice chapter 1.rpy:1119
translate chinese collar_e5aed65e:

    # mc "A collar?"
    mc "项圈？"

# game/choice chapter 1.rpy:1121
translate chinese collar_ffdc22c3:

    # "In his hand appears a red collar, with a golden bell at its center."
    "他手中凭空出现了一只红色项圈，中央还缀着一枚金色铃铛。"

# game/choice chapter 1.rpy:1123
translate chinese collar_16429228:

    # jes "That is correct, Your Majesty."
    jes "没错，陛下。"

# game/choice chapter 1.rpy:1128
translate chinese collar_894d6f7f:

    # "He then removes his tie and loosens his collar."
    "接着，他摘下领带，松开了衣领。"

# game/choice chapter 1.rpy:1129
translate chinese collar_acafd5f8:

    # "Confused, I can only remain seated, unable to move."
    "我满头雾水，只能坐在原地，动也动不了。"

# game/choice chapter 1.rpy:1131
translate chinese collar_722aa7ad:

    # "Yet the moment he places the collar around his neck, I begin to understand what he intends."
    "但当他将项圈套上自己脖子的那一刻，我便明白了他的意图。"

# game/choice chapter 1.rpy:1132
translate chinese collar_cc94c9be:

    # "Once it is fastened, he gently places the leash into my hand."
    "扣好之后，他把牵引绳放进我手里。"

# game/choice chapter 1.rpy:1133
translate chinese collar_2cf97c0f:

    # "I take it."
    "我接了过来。"

# game/choice chapter 1.rpy:1136
translate chinese collar_e7f9ccd9:

    # jes "Please..."
    jes "请......"

# game/choice chapter 1.rpy:1139
translate chinese collar_5ecd1880:

    # "His voice grows heavy."
    "他的声音沉了下去。"

# game/choice chapter 1.rpy:1143
translate chinese collar_ab6bad21:

    # jes "I am yours to command, Your Majesty... Do with me whatever you wish."
    jes "我任您差遣，陛下......您想对我怎样都可以。"

# game/choice chapter 1.rpy:1145
translate chinese collar_bab2099c:

    # "How did things end up like this?!"
    "事情怎么会变成这样？！"

# game/choice chapter 1.rpy:1147
translate chinese collar_77b3c401:

    # mc "J–Jestyn... this..."
    mc "J、Jestyn......这......"

# game/choice chapter 1.rpy:1149
translate chinese collar_db6d0895:

    # jes "You may command me to do anything, Your Majesty."
    jes "您可以命令我做任何事，陛下。"

# game/choice chapter 1.rpy:1151
translate chinese collar_0e2c9658:

    # jes "Sit. Lie down. Open my mouth... Whatever you order, I shall obey."
    jes "坐下。趴下。张开嘴......您下什么命令，我都会服从。"

# game/choice chapter 1.rpy:1152
translate chinese collar_050160d9:

    # jes "Please, relax yourself, Your Majesty. And enjoy yourself with me."
    jes "请放松些，陛下......也请尽情享受我带给您的乐趣。"

# game/choice chapter 1.rpy:1154
translate chinese collar_3f232bfb:

    # jes "I will entertain you."
    jes "我会让您尽兴的。"

# game/choice chapter 1.rpy:1156
translate chinese collar_2e9a1000:

    # "I’ve never done anything like this before."
    "我从没做过这种事。"

# game/choice chapter 1.rpy:1157
translate chinese collar_8d1ae5a1:

    # "But... if he says he’ll do anything... then, I suppose... fine."
    "不过......既然他说什么都愿意......那我想......好吧。"

# game/choice chapter 1.rpy:1169
translate chinese sit_6cea9129:

    # "The moment I give the order, Jestyn obediently sits on the stage floor."
    "我一开口，Jestyn便顺从地坐在舞台地板上。"

# game/choice chapter 1.rpy:1170
translate chinese sit_a0a396a9:

    # "He looks stright at me, waiting for my next command."
    "他直直地看着我，等着我下一道命令。"

# game/choice chapter 1.rpy:1176
translate chinese sit_a6f8b666:

    # "I decide to tug on his collar, drawing a surprised gasp from him."
    "我扯了扯他的项圈，他顿时倒抽一口气。"

# game/choice chapter 1.rpy:1177
translate chinese sit_e175d71d:

    # "His smile only widens."
    "他的笑却更深了。"

# game/choice chapter 1.rpy:1180
translate chinese sit_108799bc:

    # jes "Your Majesty..."
    jes "陛下......"

# game/choice chapter 1.rpy:1181
translate chinese sit_4e3164ad:

    # mc "Come closer."
    mc "靠近点。"

# game/choice chapter 1.rpy:1185
translate chinese sit_88d535aa:

    # "He crawls toward me."
    "他朝我爬了过来。"

# game/choice chapter 1.rpy:1188
translate chinese sit_2d215e23:

    # "I can’t believe I’m really doing this."
    "我简直不敢相信，我真的在做这种事。"

# game/choice chapter 1.rpy:1189
translate chinese sit_afaf268f:

    # "But strangely despite me still feel scared... it feels exciting."
    "但诡异的是，害怕归害怕......我却又莫名觉得兴奋。"

# game/choice chapter 1.rpy:1190
translate chinese sit_2876310e:

    # "Watching the face I’ve never been able to read behind that constant smile slowly shift into something almost... adorable."
    "看着那张总挂着笑、我却从未看透的脸，慢慢变得几乎......有点可爱。"

# game/choice chapter 1.rpy:1193
translate chinese sit_50bf0686:

    # jes "I had assumed you were inexperienced, Your Majesty..."
    jes "我原以为您没什么经验，陛下......"

# game/choice chapter 1.rpy:1195
translate chinese sit_88fca87a:

    # jes "Yet from what I am witnessing now, you resemble someone who is far more... accustomed to such things."
    jes "可就我现在所见，您倒像是对这种事......相当习惯。"

# game/choice chapter 1.rpy:1197
translate chinese sit_76fcfa43:

    # jes "With others..."
    jes "和别人也......"

# game/choice chapter 1.rpy:1199
translate chinese sit_12c554f6:

    # "For just a fleeting second, the warmth in his smile falters."
    "只一瞬间，他笑容里的温度微微褪去。"

# game/choice chapter 1.rpy:1200
translate chinese sit_c49840cf:

    # "Something darker slips through, an emotion I can’t quite name. sharp and sudden, before he masks it again."
    "某种更阴沉的情绪一闪而过，我说不清那是什么。尖锐又突兀。随即又被他重新藏好。"

# game/choice chapter 1.rpy:1202
translate chinese sit_30a740cb:

    # mc "Of course not. I’ve never done anything like this before. I’m only following my instincts."
    mc "当然不是。我从来没做过这种事......我只是在遵循本能。"

# game/choice chapter 1.rpy:1206
translate chinese sit_f694b0af:

    # jes "Hehe... is that so?"
    jes "呵呵......是吗？"

# game/choice chapter 1.rpy:1209
translate chinese sit_949d98d1:

    # "On impulse, I lift my hand and gently run my fingers through his hood."
    "一时冲动，我抬起手，指尖拂过他的兜帽。"

# game/choice chapter 1.rpy:1212
translate chinese sit_3968d4e4:

    # "For a moment, he stiffens. Just slightly as if caught off guard by the tenderness of the gesture."
    "他微微一僵，像是被这份温柔打了个措手不及。"

# game/choice chapter 1.rpy:1214
translate chinese sit_ea073ec7:

    # "Then, slowly, he relaxes."
    "随后，他才慢慢放松下来。"

# game/choice chapter 1.rpy:1216
translate chinese sit_8ac2c9f1:

    # "Jestyn closes his eyes and leans into my touch, as though seeking more of it."
    "Jestyn闭上眼，顺着我的触碰靠过来，仿佛还想要更多。"

# game/choice chapter 1.rpy:1217
translate chinese sit_1b489dd2:

    # "The smile he wears now is different from his usual one. It's softer, unguarded, almost vulnerable."
    "他此刻的笑与往常不同，更柔和、更不设防，甚至近乎脆弱。"

# game/choice chapter 1.rpy:1218
translate chinese sit_60f757ec:

    # ".... It seems he likes it."
    "......看来他很喜欢。"

# game/choice chapter 1.rpy:1219
translate chinese sit_99ed04fd:

    # jes "...You are a kind person, Your Majesty."
    jes "......您是个温柔的人，陛下。"

# game/choice chapter 1.rpy:1220
translate chinese sit_2727f7ad:

    # mc "What makes you think that?"
    mc "你怎么会这么想？"

# game/choice chapter 1.rpy:1222
translate chinese sit_40b7c6a1:

    # jes "I had expected you to be rough with me in this situation."
    jes "我原以为在这种情况下，您会对我更粗暴些。"

# game/choice chapter 1.rpy:1223
translate chinese sit_5eb35cff:

    # jes "But instead, you chose to touch me gently... It feels strange. But I certainly will not complain about that."
    jes "但您却选择温柔地碰我......感觉很奇怪。不过我当然不会抱怨。"

# game/choice chapter 1.rpy:1225
translate chinese sit_cc6d22af:

    # "Is being gentle really that strange?"
    "温柔......真的这么奇怪吗？"

# game/choice chapter 1.rpy:1229
translate chinese sit_196664a8:

    # "I’m startled when Jestyn suddenly lowers his head into my lap."
    "Jestyn突然把头靠进我膝上，我吓了一跳。"

# game/choice chapter 1.rpy:1230
translate chinese sit_07bdde05:

    # "....."
    "....."

# game/choice chapter 1.rpy:1231
translate chinese sit_103ed00e:

    # "For some reason, it feels as though I’ve gained a strange little pet."
    "说不清为什么，我感觉自己好像得了只古怪的小宠物。"

# game/choice chapter 1.rpy:1232
translate chinese sit_8480bbe8:

    # "The fear and confusion I felt earlier slowly melt away, replaced by something unexpectedly calming."
    "先前的恐惧与困惑渐渐消融，取而代之的，是一种出乎意料的安宁。"

# game/choice chapter 1.rpy:1234
translate chinese sit_70f40038:

    # jes "...."
    jes "......"

# game/choice chapter 1.rpy:1235
translate chinese sit_20b28c47:

    # jes "This is the first time I’ve ever felt something like this, Your Majesty."
    jes "这是我第一次有这样的感觉，陛下。"

# game/choice chapter 1.rpy:1236
translate chinese sit_dbfe3407:

    # mc "? Felt what?"
    mc "？什么感觉？"

# game/choice chapter 1.rpy:1238
translate chinese sit_e0e5e63a:

    # jes "I don’t know. Strangely, I can’t seem to put it into words."
    jes "我不知道。奇怪的是，我说不出来。"

# game/choice chapter 1.rpy:1239
translate chinese sit_2569494c:

    # jes "For someone who loves talking, I’m usually never at a loss when it comes to expressing what I feel... what I think."
    jes "我明明这么爱说话，平时无论是表达感受，还是说出想法......都从不会词穷。"

# game/choice chapter 1.rpy:1241
translate chinese sit_afd26ec3:

    # jes "But this... I don’t know. It feels something like happiness, perhaps. yet even that word doesn’t quite seem right."
    jes "但这个......我也说不上来。或许有点像“幸福”吧，可连这个词似乎都不够贴切。"

# game/choice chapter 1.rpy:1242
translate chinese sit_c06d04cc:

    # jes "Perhaps Your Majesty has cast a spell on me?"
    jes "也许......是陛下对我施了咒？"

# game/choice chapter 1.rpy:1244
translate chinese sit_c0a88657:

    # "I let out a small laugh at his ridiculous speculation."
    "我被他荒唐的猜测逗得轻笑了一声。"

# game/choice chapter 1.rpy:1246
translate chinese sit_18128a90:

    # mc "Don’t be silly."
    mc "别傻了。"

# game/choice chapter 1.rpy:1249
translate chinese sit_79c32605:

    # "Silence settles around us for a while. But it isn’t awkward."
    "我们安静了片刻，却并不尴尬。"

# game/choice chapter 1.rpy:1250
translate chinese sit_86ee8078:

    # "Throughout it, I continue stroking Jestyn’s head."
    "我始终轻轻抚着Jestyn的头。"

# game/choice chapter 1.rpy:1251
translate chinese sit_c70e6936:

    # "This strange situation somehow makes me feel at ease... Even my miserable life has never felt quite like this."
    "这古怪的情境竟让我感到安心......就连我那糟糕的人生里，也从未有过这样的时刻。"

# game/choice chapter 1.rpy:1254
translate chinese sit_d05e83be:

    # "After several minutes in the same position, Jestyn finally snaps his fingers and in an instant, the collar around his neck vanishes."
    "就这样维持了几分钟后，Jestyn终于打了个响指。一瞬间，他脖子上的项圈消失无踪。"

# game/choice chapter 1.rpy:1260
translate chinese lie_d56c4269:

    # "The moment I give the order, Jestyn obediently lie down on the stage floor."
    "我一声令下，Jestyn便乖顺地躺在舞台地板上。"

# game/choice chapter 1.rpy:1261
translate chinese lie_850ab860:

    # "After he lies down, I begin to walk toward him."
    "他躺下后，我朝他走去。"

# game/choice chapter 1.rpy:1265
translate chinese lie_b8c4b568:

    # "He looks up at me from below, waiting for my next command."
    "他从下方仰望着我，等待我的下一道命令。"

# game/choice chapter 1.rpy:1266
translate chinese lie_a6f8b666:

    # "I decide to tug on his collar, drawing a surprised gasp from him."
    "我扯了扯他的项圈，他顿时倒抽一口气。"

# game/choice chapter 1.rpy:1267
translate chinese lie_e175d71d:

    # "His smile only widens."
    "他的笑意更深了。"

# game/choice chapter 1.rpy:1269
translate chinese lie_108799bc:

    # jes "Your Majesty..."
    jes "陛下......"

# game/choice chapter 1.rpy:1271
translate chinese lie_f54adde4:

    # "Alright.... I’ve never done anything like this in my life. What do people usually do in situations like this?"
    "好吧......我这辈子从没做过这种事。一般这种时候，别人都会怎么做？"

# game/choice chapter 1.rpy:1272
translate chinese lie_e678444f:

    # "I’ve seen people step on their partners before... should I try that?"
    "我见过有人会踩在伴侣身上......我也要试试吗？"

# game/choice chapter 1.rpy:1273
translate chinese lie_16cfddb0:

    # "Armed with the little knowledge I picked up from the internet, I carefully place my foot on his chest."
    "凭着我从网上学来的那点皮毛，我小心翼翼地把脚踩在他胸口。"

# game/choice chapter 1.rpy:1279
translate chinese lie_ec795997:

    # jes "Nnn.."
    jes "嗯......"

# game/choice chapter 1.rpy:1281
translate chinese lie_910c6ad9:

    # "I do place my foot there, but I’m certain he can tell I’m still hesitant."
    "我确实踩上去了，但我敢肯定他看得出来我还在犹豫。"

# game/choice chapter 1.rpy:1282
translate chinese lie_287019d6:

    # "I’m not putting any real pressure on him."
    "我根本没怎么用力。"

# game/choice chapter 1.rpy:1285
translate chinese lie_6f9e3eef:

    # jes "Hehe.. Your Majesty, you’re very adoreable."
    jes "呵呵......陛下，您真可爱。"

# game/choice chapter 1.rpy:1286
translate chinese lie_cd2666c8:

    # mc "Hm...?"
    mc "嗯......？"

# game/choice chapter 1.rpy:1287
translate chinese lie_5300157c:

    # jes "You’re trying to be rough... but it seems your heart is far too gentle for that."
    jes "您想装得凶一点......可您的心太软了，做不到。"

# game/choice chapter 1.rpy:1289
translate chinese lie_658671f0:

    # "Just as I thought, he noticed."
    "果然，他看出来了。"

# game/choice chapter 1.rpy:1291
translate chinese lie_625098f1:

    # jes "It’s very sweet, knowing you don’t want to hurt me, Your Majesty... But rest assured, I’ll be just fine."
    jes "知道您不想伤到我，这很贴心，陛下......请放心，我没事的。"

# game/choice chapter 1.rpy:1292
translate chinese lie_c42d3b38:

    # jes "So, if you wish to be rough with me... please don’t hesitate."
    jes "所以，如果您想对我粗暴一点......请别犹豫。"

# game/choice chapter 1.rpy:1294
translate chinese lie_34b5a568:

    # "My heart starts pounding, sweat dampening my back."
    "我的心跳得厉害，后背也渗出汗来。"

# game/choice chapter 1.rpy:1295
translate chinese lie_4edac704:

    # "How am I supposed to know when I’ve gone too far... and when I haven’t?"
    "我怎么知道什么时候算过头......什么时候又不算？"

# game/choice chapter 1.rpy:1296
translate chinese lie_98252d2e:

    # "Sensing my fear and uncertainty, Jestyn decides to guide me instead."
    "Jestyn察觉到我的恐惧与不安，便决定引导我。"

# game/choice chapter 1.rpy:1299
translate chinese lie_796ed025:

    # jes "Focus your strength in your foot, then slowly press it against my chest."
    jes "把力道集中在脚上，然后慢慢往我胸口压下去。"

# game/choice chapter 1.rpy:1301
translate chinese lie_fed21080:

    # "I follow his instructions."
    "我照他说的做。"

# game/choice chapter 1.rpy:1302
translate chinese lie_a37f9832:

    # "I shift my weight into my foot and gently press down on Jestyn’s chest."
    "我把重心压到脚上，轻轻向下按在Jestyn的胸口上。"

# game/choice chapter 1.rpy:1305
translate chinese lie_a568a0f2:

    # jes "... Very good..."
    jes "......很好......"

# game/choice chapter 1.rpy:1306
translate chinese lie_92603e66:

    # jes "See? I’m still perfectly fine..."
    jes "看吧？我还是好好的......"

# game/choice chapter 1.rpy:1308
translate chinese lie_8ce61eb8:

    # "I nod."
    "我点点头。"

# game/choice chapter 1.rpy:1310
translate chinese lie_a9a4b134:

    # jes "Now try stomping down, Your Majesty... just once."
    jes "现在试着跺一下，陛下......就一次。"

# game/choice chapter 1.rpy:1315
translate chinese lie_90b5f220:

    # "When I stomp my foot against his chest, Jestyn lets out a soft sound that instantly makes my heart pound even harder."
    "我一脚跺在他胸口，Jestyn轻轻哼了一声，我的心跳瞬间更乱。"

# game/choice chapter 1.rpy:1317
translate chinese lie_3cdc56b9:

    # "This... strangely feels good."
    "这......竟莫名让人觉得舒服。"

# game/choice chapter 1.rpy:1319
translate chinese lie_4310fc6a:

    # jes "Now you’re learning, Your Majesty... Try stepping on my chest while tugging on my collar."
    jes "您开始上手了，陛下......试着一边踩我胸口，一边拉我的项圈。"

# game/choice chapter 1.rpy:1321
translate chinese lie_7aa9032c:

    # "I press my foot against his chest again while tugging on his collar."
    "我再次把脚压在他胸口，同时扯住他的项圈。"

# game/choice chapter 1.rpy:1326
translate chinese lie_c7e89d52:

    # jes "Ah—!"
    jes "啊——！"

# game/choice chapter 1.rpy:1329
translate chinese lie_5cd5fa89:

    # "Jestyn’s face grows even redder."
    "Jestyn的脸更红了。"

# game/choice chapter 1.rpy:1332
translate chinese lie_b13c6026:

    # jes "How is your gift so far, Your Majesty...? Are you enjoying it...?"
    jes "到目前为止，陛下觉得这份礼物如何......？您喜欢吗......？"

# game/choice chapter 1.rpy:1334
translate chinese lie_5f9b772e:

    # "...."
    "......"

# game/choice chapter 1.rpy:1336
translate chinese lie_fe9daad5:

    # mc "Y-yeah... this is nice..."
    mc "嗯、嗯......还不错......"

# game/choice chapter 1.rpy:1338
translate chinese lie_f2dcf0de:

    # "Maybe I could try something else."
    "也许......我还能试点别的。"

# game/choice chapter 1.rpy:1345
translate chinese lie_8c06c07f:

    # "This time, I place my hand on his chest and slowly run it over him instead."
    "这一次，我把手放在他胸口，改为缓缓抚过他。"

# game/choice chapter 1.rpy:1347
translate chinese lie_152be7c4:

    # jes "Nh... oh.. I see.."
    jes "嗯......哦......我明白了......"

# game/choice chapter 1.rpy:1348
translate chinese lie_1fb6601e:

    # jes "From being rough to being gentle... Are you rewarding me for pleasing you, Your Majesty?"
    jes "从粗暴变得温柔......陛下这是因为我取悦了您，所以在奖励我吗？"

# game/choice chapter 1.rpy:1349
translate chinese lie_e015665d:

    # mc "...You can think of it that way."
    mc "......你可以这么理解。"

# game/choice chapter 1.rpy:1352
translate chinese lie_fad5a13f:

    # "My hand, which was resting on his chest, slowly moves up to his neck to the collar around it."
    "我原本放在他胸口的手，缓缓往上移到他颈间的项圈。"

# game/choice chapter 1.rpy:1353
translate chinese lie_77e4b7ea:

    # "I begin stroking his neck slowly."
    "我开始慢慢抚摸他的脖颈。"

# game/choice chapter 1.rpy:1355
translate chinese lie_108799bc_1:

    # jes "Your Majesty..."
    jes "陛下......"

# game/choice chapter 1.rpy:1357
translate chinese lie_64fa8269:

    # "That’s strange..."
    "真奇怪......"

# game/choice chapter 1.rpy:1358
translate chinese lie_e3534c32:

    # "When I brushed my hand along his neck, the texture wasn’t hard like the surface of a puppet I had imagined."
    "我手指掠过他的颈侧时，触感并不像我想象中木偶那样坚硬。"

# game/choice chapter 1.rpy:1359
translate chinese lie_4cf27b1a:

    # "It felt soft just like human skin. But colder."
    "反而像人的皮肤一样柔软......只是更冷点。"

# game/choice chapter 1.rpy:1360
translate chinese lie_1b3cc250:

    # "What kind of puppet is he, really...?"
    "他到底是什么样的木偶......？"

# game/choice chapter 1.rpy:1363
translate chinese lie_25b5e8f8:

    # "After lingering there for a moment, my hand moves upward to his cheek."
    "我在那儿停了一会儿，手又向上移到他的脸颊。"

# game/choice chapter 1.rpy:1364
translate chinese lie_4c8c3a2e:

    # "Every sound he makes in response to my touch feels strangely satisfying to hear."
    "他因我的触碰而发出的每一点声音，听起来都让人莫名满足。"

# game/choice chapter 1.rpy:1365
translate chinese lie_71140198:

    # "His eyes look hazy, his face flushed."
    "他眼神迷离，脸颊泛红。"

# game/choice chapter 1.rpy:1366
translate chinese lie_b4a72430:

    # "Incredible... that a puppet can feel something like this."
    "真不可思议......木偶竟也能有这种反应。"

# game/choice chapter 1.rpy:1368
translate chinese lie_4995b5a9:

    # "My thumb gently brushes over his lips."
    "我的拇指轻轻掠过他的嘴唇。"

# game/choice chapter 1.rpy:1370
translate chinese lie_70f40038:

    # jes "...."
    jes "......"

# game/choice chapter 1.rpy:1371
translate chinese lie_451c7b35:

    # jes "Your Majesty... I’ve never felt anything like this before..."
    jes "陛下......我从未有过这样的感觉......"

# game/choice chapter 1.rpy:1372
translate chinese lie_1b562e8f:

    # mc "You mean the feeling of BDSM?"
    mc "你是说BDSM的感觉？"

# game/choice chapter 1.rpy:1374
translate chinese lie_ef109917:

    # jes "Hehe, no, no, no... I’ve felt that plenty of times before."
    jes "呵呵，不不不......那种感觉我早就体验过很多次了。"

# game/choice chapter 1.rpy:1375
translate chinese lie_9464975f:

    # jes "What I mean is this feeling... The one I can’t even put into words."
    jes "我说的是这种......连我自己都说不出来的感觉。"

# game/choice chapter 1.rpy:1376
translate chinese lie_ea087d74:

    # jes "It feels... pleasant. But I’m not certain that word is quite right to describe what I’m feeling right now."
    jes "它......很愉悦。可我也不确定，“愉悦”是不是足以形容我此刻的感受。"

# game/choice chapter 1.rpy:1377
translate chinese lie_49d1e513:

    # jes "Tell me, Your Majesty... Have you perhaps used forbidden magic on me?"
    jes "告诉我，陛下......您该不会对我用了什么禁忌魔法吧？"

# game/choice chapter 1.rpy:1379
translate chinese lie_a4b25528:

    # "I let out a confused laugh at his ridiculous speculation."
    "我被他离谱的猜测弄得哭笑不得。"

# game/choice chapter 1.rpy:1381
translate chinese lie_18128a90:

    # mc "Don’t be silly."
    mc "别闹了。"

# game/choice chapter 1.rpy:1385
translate chinese lie_c70e6936:

    # "This strange situation somehow makes me feel at ease... Even my miserable life has never felt quite like this."
    "这种古怪的处境竟让我感到安心......就连我那糟糕的人生里，也从未有过这样的感觉。"

# game/choice chapter 1.rpy:1389
translate chinese lie_440585cc:

    # "After several minutes, Jestyn finally snaps his fingers and in an instant, the collar around his neck vanishes."
    "又过了几分钟，Jestyn终于打了个响指。一瞬间，他脖子上的项圈消失无踪。"

# game/choice chapter 1.rpy:1397
translate chinese bad_end_6735111c:

    # jes "Very well. I shall inform our neighbors of Your Majesty’s will."
    jes "很好。我会把陛下的意志转告给邻国。"

# game/choice chapter 1.rpy:1398
translate chinese bad_end_661a8003:

    # jes "And I believe that, for now, the matters Your Majesty was required to resolve have reached the end of today’s program."
    jes "我想，至少目前为止，陛下今日需要处理的事务已经到此结束。"

# game/choice chapter 1.rpy:1400
translate chinese bad_end_093871f9:

    # "Finally..... it ends. I don't know if my brain can handle these kingdom things anymore"
    "终于......结束了。我真不知道自己的脑子还能不能撑得住这些王国事务。"

# game/choice chapter 1.rpy:1402
translate chinese bad_end_3911f608:

    # jes "You must be tired, Your Majesty. How about we do something... calming?"
    jes "您一定累了，陛下。不如我们做点......能让您平静下来的事？"

# game/choice chapter 1.rpy:1404
translate chinese bad_end_c3877920:

    # jes "Perhaps a dance?"
    jes "比如跳支舞？"

# game/choice chapter 1.rpy:1408
translate chinese bad_end_a12ac849:

    # "Jestyn offered his hand, inviting me to dance."
    "Jestyn向我伸出手，邀我共舞。"

# game/choice chapter 1.rpy:1410
translate chinese bad_end_84e497be:

    # mc "But I’ve never danced before... "
    mc "但我从没有跳过舞......"

# game/choice chapter 1.rpy:1411
translate chinese bad_end_4833ecfd:

    # jes "That won’t be a problem, Your Majesty. This dance is very slow. It won’t trouble you at all."
    jes "这不成问题，陛下。这支舞很慢，一点也不会为难您。"

# game/choice chapter 1.rpy:1413
translate chinese bad_end_d34a6d6a:

    # "I hesitated for a moment. But seeing that expression on his face, I felt I couldn’t refuse."
    "我犹豫了片刻，可看见他脸上的表情，我又觉得无法拒绝。"

# game/choice chapter 1.rpy:1415
translate chinese bad_end_900966a3:

    # mc "Alright.."
    mc "好吧......"

# game/choice chapter 1.rpy:1419
translate chinese bad_end_c408cc1d:

    # "The moment I took his hand, the stage lights suddenly went out."
    "我一握住他的手，舞台灯光便突然熄灭。"

# game/choice chapter 1.rpy:1422
translate chinese bad_end_19b3acff:

    # "And when they came back on, without realizing it, I was already in a dancing position with Jestyn."
    "等灯光再亮起时，不知不觉间，我已经和Jestyn摆好了起舞的姿势。"

# game/choice chapter 1.rpy:1423
translate chinese bad_end_243ba97a:

    # "Jestyn’s steps were as slow as he had promised."
    "Jestyn的舞步果然如他所言般缓慢。"

# game/choice chapter 1.rpy:1424
translate chinese bad_end_a0e58515:

    # "And I followed his rhythm."
    "我跟着他的节奏走。"

# game/choice chapter 1.rpy:1425
translate chinese bad_end_8424413b:

    # "We didn’t say a word. Only the dance music filled the silence on the stage."
    "我们一句话也没说，舞台上的寂静只剩舞曲回荡。"

# game/choice chapter 1.rpy:1427
translate chinese bad_end_e6bf0375:

    # jes "You’re doing quite well, Your Majesty."
    jes "您跳得很好，陛下。"

# game/choice chapter 1.rpy:1428
translate chinese bad_end_66d44c0a:

    # mc "... I’m just following you."
    mc "......我只是跟着你。"

# game/choice chapter 1.rpy:1429
translate chinese bad_end_b2c0340c:

    # jes "And that is more than enough."
    jes "这样就足够了。"

# game/choice chapter 1.rpy:1431
translate chinese bad_end_405dd147:

    # "The room fell silent once again."
    "房间再次安静下来。"

# game/choice chapter 1.rpy:1433
translate chinese bad_end_36e91ef5:

    # jes "Do you know the name of this dance, Your Majesty?"
    jes "您知道这支舞叫什么吗，陛下？"

# game/choice chapter 1.rpy:1434
translate chinese bad_end_da2d9e9d:

    # mc "I don’t think so."
    mc "我不知道。"

# game/choice chapter 1.rpy:1435
translate chinese bad_end_dab30120:

    # jes "You could say this is the most iconic dance in the Kingdom of Marionettes."
    jes "可以说，这是提线木偶王国最具代表性的一支舞。"

# game/choice chapter 1.rpy:1436
translate chinese bad_end_15d48f8a:

    # jes "At the end of every performance, we always dance this one."
    jes "每一场演出结束，我们都会跳它。"

# game/choice chapter 1.rpy:1438
translate chinese bad_end_8e4b4abf:

    # jes "We call it Danse Macabre."
    jes "我们称它为死亡之舞（Danse Macabre）。"

# game/choice chapter 1.rpy:1440
translate chinese bad_end_dd55df2c:

    # "Our steps grew more perfectly synchronized after Jestyn said that."
    "Jestyn说完后，我们的步伐变得更加严丝合缝。"

# game/choice chapter 1.rpy:1442
translate chinese bad_end_5f213e86:

    # mc "Danse Macabre..."
    mc "死亡之舞....."

# game/choice chapter 1.rpy:1443
translate chinese bad_end_a1524c15:

    # mc "I’ve never heard of it before. Why is it called that?"
    mc "我从没听过。为什么叫这个名字？"

# game/choice chapter 1.rpy:1445
translate chinese bad_end_f62eac9a:

    # "Suddenly, a sharp dizziness washed over my head."
    "突然，一阵强烈的眩晕袭来。"

# game/choice chapter 1.rpy:1446
translate chinese bad_end_0d4d6fde:

    # "My head.. it hurts so much."
    "我的头......疼得厉害。"

# game/choice chapter 1.rpy:1447
translate chinese bad_end_dfadc1e1:

    # "I feel as though something inside me is being slowly pulled out."
    "我只觉得体内有什么正被慢慢抽离。"

# game/choice chapter 1.rpy:1449
translate chinese bad_end_2188e88d:

    # "My steps faltered, and my entire body weakened in an instant."
    "我脚下一乱，整个人一下子失了力气。"

# game/choice chapter 1.rpy:1451
translate chinese bad_end_c4375ca6:

    # "But Jestyn’s arm caught me, keeping me from falling."
    "但Jestyn的手臂扶住了我，没让我倒下。"

# game/choice chapter 1.rpy:1452
translate chinese bad_end_e34e4811:

    # "My whole body become weak and trembled."
    "我浑身发软，止不住地发抖。"

# game/choice chapter 1.rpy:1455
translate chinese bad_end_5f6689ad:

    # mc "J–Jestyn... what is—"
    mc "J、Jestyn......你在——"

# game/choice chapter 1.rpy:1459
translate chinese bad_end_bbd50ba8:

    # jes "Seconds passed... then hours... days... weeks... months... years..."
    jes "时间一秒一秒流逝......继而是数小时......数日......数周......数月......数年......"

# game/choice chapter 1.rpy:1460
translate chinese bad_end_cfeb39ac:

    # jes "It has been so very long since all of that faded away."
    jes "自从那一切都成了过去，已经过了很久。"

# game/choice chapter 1.rpy:1461
translate chinese bad_end_7d7d8357:

    # jes "And after so long...."
    jes "而在那么久之后......"

# game/choice chapter 1.rpy:1463
translate chinese bad_end_84c60eaf:

    # jes "It seems, fate has not yet chosen our side."
    jes "看来，命运仍未选择站在我们这边。"

# game/choice chapter 1.rpy:1464
translate chinese bad_end_3a8cf506:

    # jes "In the end, this aimless fate of ours must continue on its path."
    jes "最终，我们这无所归依的命运，仍得继续沿着它的轨迹前行。"

# game/choice chapter 1.rpy:1467
translate chinese bad_end_07eb5fcf:

    # jes "Because, ultimately... you are unworthy."
    jes "因为归根结底......您不配。"

# game/choice chapter 1.rpy:1468
translate chinese bad_end_8794e25a:

    # jes "Your reign as [title] ends here. Now, it is time for you to rest peacefully."
    jes "您作为一国之主的统治到此为止。现在，您该安息了。"

# game/choice chapter 1.rpy:1469
translate chinese bad_end_355059a8:

    # jes "Close your eyes... and let this dance guide you into eternal serenity."
    jes "闭上眼睛吧......让这支舞会引领您走向永恒的宁静。"

# game/choice chapter 1.rpy:1472
translate chinese bad_end_eb515044:

    # jes "Fin."
    jes "全剧终。"

# game/choice chapter 1.rpy:1480
translate chinese cursed1_d7afdc3b:

    # mc "I-"
    mc "我——"

# game/choice chapter 1.rpy:1483
translate chinese cursed1_fa8c385a:

    # "Suddenly, My head feels so hurt"
    "突然间，我的头痛得厉害。"

# game/choice chapter 1.rpy:1484
translate chinese cursed1_30eb29fd:

    # "Everything around me become blur"
    "周围的一切都变得模糊。"

# game/choice chapter 1.rpy:1491
translate chinese cursed1_23adb90c:

    # mc "{color=#FF2727}Mmmm.... how unfortunate. My poor farmers...{/color}"
    mc "{color=#FF2727}嗯......真不幸。可怜的农夫们......{/color}"

# game/choice chapter 1.rpy:1492
translate chinese cursed1_7861c5d0:

    # mc "{color=#FF2727}As your queen, it is only natural that I provide for you. I would never ignore your hardships.{/color}"
    mc "{color=#FF2727}作为你们的女王，为你们提供所需是理所当然。我绝不会对你们的困境视而不见。{/color}"

# game/choice chapter 1.rpy:1493
translate chinese cursed1_75ea4c4b:

    # mc "{color=#FF2727}Money? Finer seeds of the highest quality? Perhaps food to ease your burdens?{/color}"
    mc "{color=#FF2727}想要钱？最上等的优质种子？还是些粮食，好减轻你们的负担？{/color}"

# game/choice chapter 1.rpy:1495
translate chinese cursed1_486300be:

    # farm "O-oh... Your Majesty is far too gracious.."
    farm "啊、啊......陛下实在太仁慈了......"

# game/choice chapter 1.rpy:1496
translate chinese cursed1_91fc4504:

    # mc "{color=#FF2727}However...{/color}"
    mc "{color=#FF2727}不过......{/color}"

# game/choice chapter 1.rpy:1497
translate chinese cursed1_18f59c3b:

    # mc "{color=#FF2727}If I am to pour my generosity upon you... shouldn’t you offer something in return?{/color}"
    mc "{color=#FF2727}若我将恩惠倾注于你们......你们不也该回报些什么吗？{/color}"

# game/choice chapter 1.rpy:1498
translate chinese cursed1_7914871d:

    # mc "{color=#FF2727}It would be terribly unfair otherwise, wouldn’t it? I give, and you simply receive?{/color}"
    mc "{color=#FF2727}不然岂不是太不公平了？我给，你们就只管收？{/color}"

# game/choice chapter 1.rpy:1499
translate chinese cursed1_a6ddc768:

    # mc "{color=#FF2727}No... if I am to bless you with such kindness, then I expect your loyalty... and your labor... to reflect your gratitude.{/color}"
    mc "{color=#FF2727}不......既然我赐予你们这份恩典，那么我会要你们的忠诚......以及你们的劳作......来体现你们的感恩。{/color}"

# game/choice chapter 1.rpy:1501
translate chinese cursed1_4d38ab1b:

    # farm "Y-You are absolutely right, Your Majesty! I will devote myself entirely!"
    farm "您、您说得太对了，陛下！我愿意倾尽所有效忠！"

# game/choice chapter 1.rpy:1506
translate chinese cursed1_70f40038:

    # jes "...."
    jes "......"

# game/choice chapter 1.rpy:1507
translate chinese cursed1_1b46e124:

    # jes "How remarkable, Your Majesty."
    jes "真是令人赞叹，陛下。"

# game/choice chapter 1.rpy:1508
translate chinese cursed1_f9fd318f:

    # jes "One can only hope your actions prove as sweet as your words."
    jes "但愿您的行动，能和您的言辞一样甜美。"

# game/choice chapter 1.rpy:1511
translate chinese cursed1_ec969f39:

    # jes "...Indeed?"
    jes "......当真如此？"

# game/choice chapter 1.rpy:1513
translate chinese cursed1_329ddb6e:

    # "{color=#FF2727}.......{/color}"
    "{color=#FF2727}.......{/color}"

# game/choice chapter 1.rpy:1515
translate chinese cursed1_0fd4d656:

    # "......"
    "......"

# game/choice chapter 1.rpy:1517
translate chinese cursed1_42051be0:

    # mc "Y-...Yes.... Indeed."
    mc "嗯、......没错......当真如此。"

# game/choice chapter 1.rpy:1524
translate chinese cursed2_1ad94e56:

    # mc "{color=#FF2727}Oh? For trade, you say?{/color}"
    mc "{color=#FF2727}哦？你说通商？{/color}"

# game/choice chapter 1.rpy:1525
translate chinese cursed2_bae050fd:

    # mc "{color=#FF2727}That is quite an interesting offer.{/color}"
    mc "{color=#FF2727}这提议挺有意思。{/color}"

# game/choice chapter 1.rpy:1526
translate chinese cursed2_bc7c3c59:

    # mc "{color=#FF2727}Very well. Why not?{/color}"
    mc "{color=#FF2727}也好。为什么不呢？{/color}"

# game/choice chapter 1.rpy:1527
translate chinese cursed2_f1c4eb89:

    # mc "{color=#FF2727}I make this decision for the sake of my people.{/color}"
    mc "{color=#FF2727}我做这个决定，是为了我的子民。{/color}"

# game/choice chapter 1.rpy:1528
translate chinese cursed2_7e28d336:

    # mc "{color=#FF2727}Trade will become far more convenient for them. And at the same time, we may establish stronger ties with another kingdom.{/color}"
    mc "{color=#FF2727}通商会让他们更便利；同时，我们也能与另一个王国建立更紧密的联系。{/color}"

# game/choice chapter 1.rpy:1532
translate chinese cursed2_c01f7d84:

    # jes "Hm...? Yes, that is certainly an understandable decision, Your Majesty."
    jes "嗯......？是的，这当然是个可以理解的决定，陛下。"

# game/choice chapter 1.rpy:1533
translate chinese cursed2_97fd71fe:

    # jes "From your words, you appear deeply concerned for your people."
    jes "听您这番话，您似乎十分关心您的子民。"

# game/choice chapter 1.rpy:1535
translate chinese cursed2_a4f31376:

    # jes "Mmm... but what of the citizens who reside upon the land you intend to sell, Your Majesty?"
    jes "唔......但陛下打算卖掉的那片土地上居住的子民，又该怎么安置呢？"

# game/choice chapter 1.rpy:1536
translate chinese cursed2_8456d889:

    # jes "If you part with it... would that not mean they must abandon their homes?"
    jes "若您将其割让出去......岂不是意味着他们必须离开家园？"

# game/choice chapter 1.rpy:1537
translate chinese cursed2_b7c129b6:

    # jes "It does seem rather contradictory to what you just said about caring so dearly for your people."
    jes "这听起来，的确与您方才所说“如此爱民”的话有些矛盾。"

# game/choice chapter 1.rpy:1539
translate chinese cursed2_eed8927c:

    # jes "Unless... you are a liar, Your Majesty~?"
    jes "除非......您在说谎，陛下~？"

# game/choice chapter 1.rpy:1540
translate chinese cursed2_968c8596:

    # mc "{color=#FF2727}Haha... Jestyn..{/color}"
    mc "{color=#FF2727}哈哈......Jestyn......{/color}"

# game/choice chapter 1.rpy:1541
translate chinese cursed2_d1032bef:

    # mc "{color=#FF2727}Are you questioning my decision?{/color}"
    mc "{color=#FF2727}你是在质疑我的决定吗？{/color}"

# game/choice chapter 1.rpy:1543
translate chinese cursed2_50611cc0:

    # jes "......."
    jes "......."

# game/choice chapter 1.rpy:1545
translate chinese cursed2_3ea684e4:

    # jes "Oh, of course not, Your Majesty. How foolish of me. To even think of questioning your judgment..."
    jes "哦，当然不是，陛下。是我愚蠢了，竟会生出质疑您判断的念头......"

# game/choice chapter 1.rpy:1547
translate chinese cursed2_6c7d49d5:

    # jes "Indeed. This is all for the good of the entire kingdom."
    jes "没错。这一切都是为了整个王国的利益。"

# game/choice chapter 1.rpy:1550
translate chinese cursed2_372cd5aa:

    # jes "Very well then. I shall inform our neighbors of Your Majesty’s will."
    jes "那么就这样。我会把陛下的意志转告给邻国。"

# game/choice chapter 1.rpy:1551
translate chinese cursed2_661a8003:

    # jes "And I believe that, for now, the matters Your Majesty was required to resolve have reached the end of today’s program."
    jes "我想，至少目前为止，陛下今日需要处理的事务已到此结束。"

# game/choice chapter 1.rpy:1552
translate chinese cursed2_917307e9:

    # jes "You may rest your head now your majesty~"
    jes "您现在可以歇一下了，陛下~"

# game/choice chapter 1.rpy:1555
translate chinese cursed2_7af8e284:

    # jes "Oh! I nearly forgot, Your Majesty. Before that, I have a gift for you."
    jes "哦！我差点忘了，陛下。在那之前，我还有一份礼物要送您。"

# game/choice chapter 1.rpy:1557
translate chinese cursed2_6a22b7be:

    # mc "Huh..? What gift-"
    mc "啊......？什么礼物——"

# game/choice chapter 1.rpy:1562
translate chinese cursed2_0a956b60:

    # "A rope suddenly coiled around my body after Jestyn snapped his fingers."
    "Jestyn打了个响指，一条绳索突然缠住了我的身体。"

# game/choice chapter 1.rpy:1565
translate chinese cursed2_68492187:

    # "He snapped his fingers once more. An axe appeared in his hand."
    "他又打了个响指，一把斧头出现在他手中。"

# game/choice chapter 1.rpy:1566
translate chinese cursed2_c9e9ed07:

    # "Panic seized me instantly."
    "恐慌瞬间攫住了我。"

# game/choice chapter 1.rpy:1568
translate chinese cursed2_05e3f134:

    # mc "W-What are you doing?!"
    mc "你、你要做什么？！"

# game/choice chapter 1.rpy:1577
translate chinese cursed2_534af6fb:

    # "Without answering my question, Jestyn swung the axe toward my neck."
    "Jestyn没有回答，只是挥斧朝我的脖颈砍来。"

# game/choice chapter 1.rpy:1588
translate chinese cursed2_84d35058:

    # jes "Hope you Have a nice dream this time, [player_call]"
    jes "希望这一次，您能做个好梦，[player_call]。"

# game/choice chapter 1.rpy:1601
translate chinese handsome_d44e7d4f:

    # "His irritated expression instantly shifted into confusion and shock."
    "他原本不耐烦的神色瞬间转为困惑与震惊。"

# game/choice chapter 1.rpy:1603
translate chinese handsome_0ce78278:

    # kni "What the hell did you just say?"
    kni "你刚刚说什么？"

# game/choice chapter 1.rpy:1604
translate chinese handsome_a54ff068:

    # mc "I was only telling the truth."
    mc "我只是说实话。"

# game/choice chapter 1.rpy:1606
translate chinese handsome_9b5b6b19:

    # "Honestly, I wasn’t sure if saying that was a good idea."
    "说真的，我也不确定这么说是不是好主意。"

# game/choice chapter 1.rpy:1608
translate chinese handsome_4722190d:

    # kni "There must be something wrong with your head. Are you truly speaking the truth?"
    kni "你脑子肯定有问题。你真的是这么想的？"

# game/choice chapter 1.rpy:1610
translate chinese handsome_36f5b714:

    # "Oh, did I just manage to soften him a little?"
    "哦......我这是把他哄软了一点？"

# game/choice chapter 1.rpy:1612
translate chinese handsome_81b5e682:

    # mc "Of course~. Who could possibly resist such a handsome face?"
    mc "当然~ 谁能抵挡得了这么一张帅脸？"

# game/choice chapter 1.rpy:1613
translate chinese handsome_7b7a20db:

    # mc "I’m certain that anyone who lays eyes on you for the first time would be driven completely crazy over you one hundred percent."
    mc "我敢肯定，任何人第一次见到你，都会百分之百为你疯狂。"

# game/choice chapter 1.rpy:1615
translate chinese handsome_2740387a:

    # "His lips slowly curled into a grin."
    "他的嘴角慢慢勾起。"

# game/choice chapter 1.rpy:1617
translate chinese handsome_56e38707:

    # kni "Heh. In that case you deserve to die."
    kni "呵。那你更该死。"

# game/choice chapter 1.rpy:1619
translate chinese handsome_9d469299:

    # "Fuck."
    "可恶。"

# game/choice chapter 1.rpy:1624
translate chinese notreally_dd94f96d:

    # mc "Well... uh actually not really..."
    mc "呃......其实也没有......"

# game/choice chapter 1.rpy:1625
translate chinese notreally_492bf80b:

    # kni "In that case you deserve to die."
    kni "那你更该死。"

# game/choice chapter 1.rpy:1627
translate chinese notreally_9d469299:

    # "Fuck."
    "靠。"

# game/choice chapter 1.rpy:1633
translate chinese juggle_cf7942b1:

    # mc "Where did you learn to juggle?"
    mc "你是从哪学会杂耍的？"

# game/choice chapter 1.rpy:1634
translate chinese juggle_2980266b:

    # jes "I didn’t expect Your Majesty to take such an interest in juggling."
    jes "没想到陛下会对杂耍这么感兴趣。"

# game/choice chapter 1.rpy:1635
translate chinese juggle_5311080f:

    # jes "Hmmmm... let me think for a moment...."
    jes "唔......让我想想......"

# game/choice chapter 1.rpy:1637
translate chinese juggle_73ec2189:

    # "He taps his index finger lightly as he ponders."
    "他一边思索，一边用食指点了点。"

# game/choice chapter 1.rpy:1639
translate chinese juggle_f75bae67:

    # jes "Ah, yes... Master Adam."
    jes "啊，对了......Adam师傅。"

# game/choice chapter 1.rpy:1640
translate chinese juggle_6ebcf28f:

    # mc "Uh... who’s that?"
    mc "呃......他是谁？"

# game/choice chapter 1.rpy:1641
translate chinese juggle_1324166a:

    # jes "He is the one who taught me how to properly perform the role of a true royal jester."
    jes "他教会了我怎样才算真正胜任一名宫廷弄臣。"

# game/choice chapter 1.rpy:1642
translate chinese juggle_21986bd3:

    # jes "The person I am today exists because of him. And naturally, that includes the proper way to juggle."
    jes "我之所以能成为现在的我，全是因为他，当然也包括杂耍该怎么耍。"

# game/choice chapter 1.rpy:1643
translate chinese juggle_2b3ce3e9:

    # mc "He sounds like someone important."
    mc "听起来他对你很重要。"

# game/choice chapter 1.rpy:1644
translate chinese juggle_40f5e215:

    # jes "Indeed, he was. A most kind gentleman."
    jes "的确。他确实很重要，是位非常和善的绅士。"

translate chinese strings:

    # game/choice chapter 1.rpy:126
    old "Check Jester puppet"
    new "查看弄臣木偶"

    # game/choice chapter 1.rpy:130
    old "Check Knight puppet"
    new "查看骑士木偶"

    # game/choice chapter 1.rpy:134
    old "Check King puppet"
    new "查看国王木偶"

    # game/choice chapter 1.rpy:138
    old "Check the next puppet"
    new "查看下一个木偶"

    # game/choice chapter 1.rpy:286
    old "Keep silent"
    new "保持沉默"

    # game/choice chapter 1.rpy:289
    old "Who are you?"
    new "你是谁？"

    # game/choice chapter 1.rpy:292
    old "Run"
    new "跑"

    # game/choice chapter 1.rpy:972
    old "Left"
    new "左边"

    # game/choice chapter 1.rpy:975
    old "Right"
    new "右边"

    # game/choice chapter 1.rpy:1161
    old "Sit"
    new "坐下"

    # game/choice chapter 1.rpy:1164
    old "Lie down"
    new "躺下"

