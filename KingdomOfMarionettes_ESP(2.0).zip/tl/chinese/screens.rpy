﻿translate chinese strings:

    # game/screens.rpy:251
    old "Back"
    new "回退"

    # game/screens.rpy:252
    old "History"
    new "历史"

    # game/screens.rpy:253
    old "Skip"
    new "快进"

    # game/screens.rpy:254
    old "Auto"
    new "自动"

    # game/screens.rpy:255
    old "Save"
    new "保存"

    # game/screens.rpy:256
    old "Q.Save"
    new "快存"

    # game/screens.rpy:257
    old "Q.Load"
    new "快读"

    # game/screens.rpy:258
    old "Prefs"
    new "设置"

    # game/screens.rpy:299
    old "Start"
    new "开始游戏"

    # game/screens.rpy:307
    old "Load"
    new "读取游戏"

    # game/screens.rpy:309
    old "Preferences"
    new "设置"

    # game/screens.rpy:313
    old "End Replay"
    new "结束回放"

    # game/screens.rpy:317
    old "Main Menu"
    new "标题菜单"

    # game/screens.rpy:319
    old "About"
    new "关于"

    # game/screens.rpy:324
    old "Help"
    new "帮助"

    # game/screens.rpy:330
    old "Quit"
    new "退出"

    # game/screens.rpy:488
    old "Return"
    new "返回"

    # game/screens.rpy:572
    old "Version [config.version!t]\n"
    new "版本 [config.version!t]\n"

    # game/screens.rpy:578
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "引擎：{a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]\n\n[renpy.license!t]"

    # game/screens.rpy:614
    old "Page {}"
    new "第 {} 页"

    # game/screens.rpy:614
    old "Automatic saves"
    new "自动存档"

    # game/screens.rpy:614
    old "Quick saves"
    new "快速存档"

    # game/screens.rpy:656
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%Y-%m-%d %H:%M"

    # game/screens.rpy:656
    old "empty slot"
    new "空存档位"

    # game/screens.rpy:676
    old "<"
    new ""

    # game/screens.rpy:680
    old "{#auto_page}A"
    new ""

    # game/screens.rpy:683
    old "{#quick_page}Q"
    new ""

    # game/screens.rpy:689
    old ">"
    new ""

    # game/screens.rpy:694
    old "Upload Sync"
    new "上传同步"

    # game/screens.rpy:698
    old "Download Sync"
    new "下载同步"

    # game/screens.rpy:757
    old "Display"
    new "显示"

    # game/screens.rpy:758
    old "Window"
    new "窗口"

    # game/screens.rpy:759
    old "Fullscreen"
    new "全屏"

    # game/screens.rpy:764
    old "Unseen Text"
    new "未读文本"

    # game/screens.rpy:765
    old "After Choices"
    new "选项后继续"

    # game/screens.rpy:766
    old "Transitions"
    new "忽略转场"

    # game/screens.rpy:779
    old "Text Speed"
    new "文字速度"

    # game/screens.rpy:783
    old "Auto-Forward Time"
    new "自动前进时间"

    # game/screens.rpy:790
    old "Music Volume"
    new "音乐音量"

    # game/screens.rpy:797
    old "Sound Volume"
    new "音效音量"

    # game/screens.rpy:803
    old "Test"
    new "测试"

    # game/screens.rpy:807
    old "Voice Volume"
    new "语音音量"

    # game/screens.rpy:818
    old "Mute All"
    new "全部静音"

    # game/screens.rpy:937
    old "The dialogue history is empty."
    new "尚无对话历史记录。"

    # game/screens.rpy:1005
    old "Keyboard"
    new "键盘"

    # game/screens.rpy:1006
    old "Mouse"
    new "鼠标"

    # game/screens.rpy:1009
    old "Gamepad"
    new "手柄"

    # game/screens.rpy:1022
    old "Enter"
    new "回车"

    # game/screens.rpy:1023
    old "Advances dialogue and activates the interface."
    new "推进对话并激活界面。"

    # game/screens.rpy:1026
    old "Space"
    new "空格"

    # game/screens.rpy:1027
    old "Advances dialogue without selecting choices."
    new "在没有选择的情况下推进对话。"

    # game/screens.rpy:1030
    old "Arrow Keys"
    new "方向键"

    # game/screens.rpy:1031
    old "Navigate the interface."
    new "导航界面。"

    # game/screens.rpy:1034
    old "Escape"
    new "Esc"

    # game/screens.rpy:1035
    old "Accesses the game menu."
    new "访问游戏菜单。"

    # game/screens.rpy:1038
    old "Ctrl"
    new "键盘"

    # game/screens.rpy:1039
    old "Skips dialogue while held down."
    new "按住时快进对话。"

    # game/screens.rpy:1042
    old "Tab"
    new ""

    # game/screens.rpy:1043
    old "Toggles dialogue skipping."
    new "切换对话快进。"

    # game/screens.rpy:1046
    old "Page Up"
    new "上一页"

    # game/screens.rpy:1047
    old "Rolls back to earlier dialogue."
    new "回退至先前的对话。"

    # game/screens.rpy:1050
    old "Page Down"
    new "下一页"

    # game/screens.rpy:1051
    old "Rolls forward to later dialogue."
    new "向前至后来的对话。"

    # game/screens.rpy:1055
    old "Hides the user interface."
    new "隐藏用户界面。"

    # game/screens.rpy:1059
    old "Takes a screenshot."
    new "截图。"

    # game/screens.rpy:1063
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "切换辅助{a=https://doc.renpy.cn/zh-CN/self_voicing.html}机器朗读{/a}。"

    # game/screens.rpy:1067
    old "Opens the accessibility menu."
    new "打开无障碍菜单。"

    # game/screens.rpy:1073
    old "Left Click"
    new "左键点击"

    # game/screens.rpy:1077
    old "Middle Click"
    new "中键点击"

    # game/screens.rpy:1081
    old "Right Click"
    new "右键点击"

    # game/screens.rpy:1085
    old "Mouse Wheel Up"
    new "鼠标滚轮上"

    # game/screens.rpy:1089
    old "Mouse Wheel Down"
    new "鼠标滚轮下"

    # game/screens.rpy:1096
    old "Right Trigger\nA/Bottom Button"
    new "右扳机键\nA/底键"

    # game/screens.rpy:1100
    old "Left Trigger\nLeft Shoulder"
    new "左扳机键\n左肩键"

    # game/screens.rpy:1104
    old "Right Shoulder"
    new "右肩键"

    # game/screens.rpy:1108
    old "D-Pad, Sticks"
    new "十字键，摇杆"

    # game/screens.rpy:1112
    old "Start, Guide, B/Right Button"
    new "开始，向导，B/右键"

    # game/screens.rpy:1116
    old "Y/Top Button"
    new "Y/顶键"

    # game/screens.rpy:1119
    old "Calibrate"
    new "校准"

    # game/screens.rpy:1184
    old "Yes"
    new "确定"

    # game/screens.rpy:1185
    old "No"
    new "取消"

    # game/screens.rpy:1231
    old "Skipping"
    new "正在快进"

    # game/screens.rpy:1543
    old "Menu"
    new "菜单"

