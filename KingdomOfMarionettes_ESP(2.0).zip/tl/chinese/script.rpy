﻿# TODO: Translation updated at 2026-03-04 11:36

# game/script.rpy:39
translate chinese start_8cba0c84:

    # "Who would’ve thought I’d end up trapped in a situation this strange?"
    "谁能想到我最后会被困在这么奇怪的处境里？"

# game/script.rpy:40
translate chinese start_9ece5d1e:

    # "It all started because I was desperately looking for a job."
    "这一切都要从我走投无路找工作开始说起。"

# game/script.rpy:41
translate chinese start_866fca32:

    # "Of course I was desperate. My savings were running low, and I still had countless living expenses plus debt to pay."
    "我当然很着急。存款快见底了，生活开销一大堆，还有债等着还。"

# game/script.rpy:42
translate chinese start_aaed3db5:

    # "I applied to all kinds of places, but it felt like luck absolutely hated me"
    "我到处投简历，但感觉运气就是在跟我作对。"

# game/script.rpy:43
translate chinese start_0c268043:

    # "In a situation like this, I no longer cared what kind of job it was, as long as it paid. Cleaning toilets, catching bears...I’d do anything."
    "到这份上，只要能拿到钱，什么活我都不挑。刷马桶、抓熊......我都行。"

# game/script.rpy:47
translate chinese start_1715a48e:

    # "That’s when I found this job online..."
    "就在这时，我在网上看见了这份招聘..."

# game/script.rpy:48
translate chinese start_62e8aaa8:

    # "A security position at an abandoned theater. Seriously, why would a place that no longer operates even need a security guard?"
    "一座废弃剧院的保安。说真的，一个早就不营业的地方要保安干嘛？"

# game/script.rpy:49
translate chinese start_518151f5:

    # "Kingdom of Marionettes. I’d heard this place used to be famous for its puppet performances long ago."
    "提线木偶王国。我听说这里很久以前靠木偶表演出过名。"

# game/script.rpy:50
translate chinese start_d79b2a65:

    # "Oh. Only three duties. Duty number one: keep the theater safe from vandals. Hmm.... I could probably manage that."
    "哦，这份工作的职责一共就三条。第一，防止有人来搞破坏。嗯......这个我能应付。"

# game/script.rpy:51
translate chinese start_3d379df2:

    # "Duty number two: clean the theater. That’s technically outside a security guard’s job, but whatever as long as it pays."
    "第二，打扫剧院。严格来说，这不算保安该干的事，不过只要给钱，我无所谓。"

# game/script.rpy:52
translate chinese start_7d1d2bbf:

    # "Duty number three: make sure none of the puppets are missing and walking around."
    "第三，确保没有木偶失踪，也别让它们跑到外面乱晃。"

# game/script.rpy:53
translate chinese start_5f9b772e:

    # "...."
    "...."

# game/script.rpy:54
translate chinese start_2e251073:

    # "Hmm. Maybe I’m so sleep-deprived that I misread it."
    "嗯。也许是我太缺觉，把字看岔了。"

# game/script.rpy:59
translate chinese start_51aac7de:

    # "Make sure none of the puppets are missing...and walking around."
    "确保没有木偶失踪......也别让它们跑到外面乱晃。"

# game/script.rpy:60
translate chinese start_0ec8e943:

    # "W–wait. Walking around?? Make sure there are no puppets walking around?? What does that even mean?!"
    "等、等等。走动？？还要确保没有木偶在外面走来走去？？这到底什么意思？！"

# game/script.rpy:61
translate chinese start_f403a2a7:

    # "Hahaha... maybe they meant making sure no one steals the puppets. Yeah. That has to be it. Whoever wrote this must be joking."
    "哈、哈哈......也许是说别让人把木偶偷走吧。对，一定是这样。写这条的人肯定在开玩笑。"

# game/script.rpy:66
translate chinese start_c3d87f84:

    # "Alright then. Let’s do this."
    "行，那就开始吧。"

# game/script.rpy:73
translate chinese start_715f3a0c:

    # "Here it is.... after all this time, I finally got a job."
    "就是这里......折腾这么久，我总算有份工作了。"

# game/script.rpy:74
translate chinese start_af32477a:

    # "Strangely enough, this job didn’t require an interview."
    "奇怪的是，这份工作居然不需要面试。"

# game/script.rpy:75
translate chinese start_5879a4bf:

    # "When I contacted them yesterday, everything was settled almost immediately."
    "我昨天联系对方，事情几乎立刻就定了。"

# game/script.rpy:76
translate chinese start_ab106452:

    # "I almost thought this was a scam, but thankfully, it wasn’t."
    "我一度以为是骗局，幸好不是。"

# game/script.rpy:77
translate chinese start_e097aece:

    # "Alright. I have three tasks. First, keep the place safe from vandals. Fortunately, there hasn’t been any sign of trouble so far."
    "好，三项任务。第一，防止有人来搞破坏。好在目前还没出什么事。"

# game/script.rpy:78
translate chinese start_bdaa902b:

    # "That only leaves cleaning the theater and making sure all the puppets are accounted for."
    "那就只剩打扫剧院，以及确认木偶一个都不少。"

# game/script.rpy:108
translate chinese rest_56ca1470:

    # "I head straight back to my room and report to the boss."
    "我回到房间，立刻跟老板汇报了一下。"

# game/script.rpy:109
translate chinese rest_8ab3cee1:

    # "All of my tasks are finished. Now all that’s left is to stand guard."
    "该做的任务都完成了，接下来只要继续值守就好。"

# game/script.rpy:110
translate chinese rest_28cb0594:

    # "Being a security guard doesn’t seem so bad. I get paid just for keeping watch."
    "当保安好像也没那么差，光守着就能领工资。"

# game/script.rpy:111
translate chinese rest_2c46a105:

    # "The pay isn’t great, but better than nothing."
    "钱不多，但总比没有强。"

# game/script.rpy:113
translate chinese rest_27e93ae7:

    # u "What should I do while I’m on watch...?"
    u "值班的时候我该做点什么......？"

# game/script.rpy:114
translate chinese rest_ebe1d624:

    # u "I’m so tired... but I can’t afford to fall asleep."
    u "好困......但我不能睡着。"

# game/script.rpy:116
translate chinese rest_945d4661:

    # "I take out my phone and start browsing the internet."
    "我掏出手机，开始刷网页。"

# game/script.rpy:117
translate chinese rest_b8f03606:

    # "My knowledge about this theater is still pretty limited and my curiosity gets the better of me, so I decide to look up some information online."
    "我对这家剧院了解不多，好奇心又压不住，索性上网查了查。"

# game/script.rpy:118
translate chinese rest_991d8857:

    # "Kingdom of Marionettes. A puppet theater that tells the story of the everyday lives of puppets in a kingdom."
    "提线木偶王国：讲述王国里木偶们日常生活的木偶剧。"

# game/script.rpy:119
translate chinese rest_4a83d812:

    # "No wonder the puppets I saw earlier were dressed in outfits from a royal era"
    "难怪我先前看到的木偶都穿着王室时代那种衣服。"

# game/script.rpy:120
translate chinese rest_ca8ea766:

    # "Kingdom of Marionettes was known for its amusing and mesmerizing performances, enhanced by the puppet’s charming designs."
    "据说提线木偶王国是凭着有趣又迷人的演出打出名气的，再加上木偶设计讨喜，自然更受欢迎。"

# game/script.rpy:122
translate chinese rest_c77259cb:

    # "Was this place really that famous back then? They even sold merchandise and all kinds of stuff."
    "当年真的火到这种程度吗？居然还有周边，而且品类不少。"

# game/script.rpy:123
translate chinese rest_bb8e8b8a:

    # "There was even a poll for favorite characters. That’s kind of cute"
    "甚至还有人气角色投票，感觉还蛮可爱的。"

# game/script.rpy:124
translate chinese rest_9ddf8fdc:

    # "First place went to the jester. People really do like odd characters huh."
    "第一名是jester。大家还真喜欢这种怪角色。"

# game/script.rpy:125
translate chinese rest_e0d2acba:

    # "Second place was the knight, and third was the wizard."
    "第二名是knight，第三名是wizard。"

# game/script.rpy:126
translate chinese rest_5d396cc2:

    # "I end up getting completely absorbed in all this information about the theater, and before I realize it, I’ve been scrolling for half an hour."
    "我看得入迷，不知不觉就刷了半小时。"

# game/script.rpy:128
translate chinese rest_6da0153b:

    # u "Oh crap. I need to check the CCTV."
    u "啊糟了，我得去看监控。"

# game/script.rpy:164
translate chinese performance_2e984f22:

    # jespuppet "Mmmm..."
    jespuppet "嗯......"

# game/script.rpy:170
translate chinese performance_52c6096a:

    # "The puppet then snaps his fingers, and in an instant, he disappears from in front of me."
    "木偶打了个响指，转眼就从我面前消失了。"

# game/script.rpy:171
translate chinese performance_32ef791c:

    # "W–what...? Where did he go now??"
    "什、什么......？他又去哪了？？"

# game/script.rpy:180
translate chinese performance_28c03380:

    # jespuppet "A hand so small and soft. like cotton... liiiike a kitten’s paw."
    jespuppet "手小小的，软软的，像棉花......也像小猫软乎乎的肉垫。"

# game/script.rpy:185
translate chinese performance_92e087b5:

    # "He caressing my arm gently with his puppet hand"
    "他用木偶手抚过我的手臂。"

# game/script.rpy:187
translate chinese performance_14d553fd:

    # jespuppet "A form so small... so easily broken... yet somehow brimming with warmth and movement...."
    jespuppet "这样小的躯体......轻易就会碎......却又充满温度与生机......"

# game/script.rpy:188
translate chinese performance_854a6ec0:

    # jespuppet "A vessel that reacts, trembles, and changes so beautifully....."
    jespuppet "会回应、会颤动、会变化，美得惊人的容器......"

# game/script.rpy:192
translate chinese performance_49562cdd:

    # jespuppet "And that face.... always shifting, always telling stories without meaning to....."
    jespuppet "还有那张脸......不停变换，不经意间就把故事说尽......"

# game/script.rpy:196
translate chinese performance_0fd4d656:

    # "......"
    "......"

# game/script.rpy:197
translate chinese performance_2fa81cee:

    # "Is he... examining me???"
    "他是在......打量我？？"

# game/script.rpy:199
translate chinese performance_bccc696a:

    # jespuppet "You're really are huuuuman"
    jespuppet "你真的是人类。"

# game/script.rpy:200
translate chinese performance_69941a63:

    # u "Y-yes...I’m human...."
    u "是、是的......我是人类......"

# game/script.rpy:202
translate chinese performance_8f13a297:

    # "I reply in a nervous voice, laced with fear."
    "我带着恐惧，小心翼翼地回答。"

# game/script.rpy:206
translate chinese performance_269b7f47:

    # jespuppet "Seconds passed... then hours... days... weeks... months... years..."
    jespuppet "时间一秒一秒流逝......继而是数小时......数日......数周......数月......数年......"

# game/script.rpy:207
translate chinese performance_b886c43e:

    # jespuppet "It has been so very long since all of that faded away."
    jespuppet "自从那一切都成了过去，已经过了很久。"

# game/script.rpy:211
translate chinese performance_e9ca8105:

    # jespuppet "A kingdom that was once so lively, so magnificent, so full of joy... has now been reduced to silence."
    jespuppet "曾经热闹、辉煌、满是欢笑的王国......如今只剩寂静。"

# game/script.rpy:215
translate chinese performance_815c1411:

    # jespuppet "A kingdom that was once led by a ruler, one who guided us all toward our purpose, toward our lives, has now vanished."
    jespuppet "曾经由一位统治者引领的王国，那位曾带领我们走向使命、指引我们人生方向的人，如今也不见了。"

# game/script.rpy:216
translate chinese performance_71afbde2:

    # jespuppet "Like fledgling birds abandoned by their parent before they were ever ready to fly, we were left to be guided by confusion... by despair..."
    jespuppet "就像还没学会飞就被遗弃的雏鸟，我们只能任由迷惘......任由绝望牵着走......"

# game/script.rpy:221
translate chinese performance_be92aa84:

    # jespuppet "We move without direction or destination, not knowing where we are meant to go..."
    jespuppet "我们漫无目的地走着，没有方向，也没有归处，不知道该去哪里......"

# game/script.rpy:222
translate chinese performance_20a833f9:

    # jespuppet "And yet...we believe. That someday... a new light will appear to guide us."
    jespuppet "可即便如此......我们仍然相信，总有一天......会有新的光出现，指引我们。"

# game/script.rpy:227
translate chinese performance_8e276719:

    # jespuppet "A leader who will give us life once more and lead us toward the lives we were always meant to live..."
    jespuppet "会有再次赋予我们生命意义的引领者......带我们走向本该属于我们的生活......"

# game/script.rpy:232
translate chinese performance_906a604e:

    # jespuppet "We waited... and we hoped. Hoped... and waited. Round and round, over and over until the two became indistinguishable, as though they were never meant to be apart."
    jespuppet "我们在等待中......怀抱希望。也在希望中......继续等待。周而复始，直到等待与希望再也分不清彼此，仿佛从来就不该分开。"

# game/script.rpy:233
translate chinese performance_7db42dc6:

    # jespuppet "And so, that circle endured. It lingered through the passage of time... until now. Uuuuntil this very day, which quietly dares to call itself a turning point."
    jespuppet "于是，这个循环就在岁月流逝中延续......至今。直——到今天，这个悄然被称作“转折点”的日子。"

# game/script.rpy:238
translate chinese performance_347fdeee:

    # jespuppet "Will this circle continue its gentle, merciless dance, unbroken, unchanged?"
    jespuppet "这轮回还会继续踏着那温柔却无情的舞步，周而复始地运转下去吗？"

# game/script.rpy:239
translate chinese performance_fcf1079e:

    # jespuppet "Or will it, at last, begin to crack... to fracture... and finally shatter, granting us release from the loop we call life?"
    jespuppet "还是说，它终会出现裂痕......逐渐崩裂......最终粉碎，让我们从这名为“生命”的轮回中解脱？"

# game/script.rpy:241
translate chinese performance_0fd4d656_1:

    # "......"
    "......"

# game/script.rpy:242
translate chinese performance_1084310d:

    # "err...What is he talking about so sudden? I don't understand. Is he telling me a fairy tale?"
    "呃......他怎么突然说这些？我听不懂。他是在给我讲童话吗？"

# game/script.rpy:248
translate chinese performance_461954a5:

    # jespuppet "A kingdom... a place never far removed from politics, a realm steeped in tension, where seriousness lurks beneath its lavish, glittering surface."
    jespuppet "在这样的王国里......权谋从不缺席，气氛总是紧绷得让人喘不过气。它表面奢华耀眼，内里却沉淀着挥之不去的肃穆。"

# game/script.rpy:249
translate chinese performance_2c4d81b0:

    # jespuppet "Like ice, bitterly cold, it requires at least a touch of warmth. no... perhaps half of that warmth to keep its balance."
    jespuppet "这个地方冷得像冰，刺骨而沉寂，必须有一点温度......哪怕只是微不足道的一丝，才能勉强维持平衡。"

# game/script.rpy:254
translate chinese performance_1e2492ef:

    # jespuppet "And that is precisely why I am here. To soften the air, to deliver laughter, to carry joy wherever it dares to fade."
    jespuppet "所以我才会留在这里，稍稍化开这份冷意，把笑声和快乐送到那些几乎被遗忘的角落。"

# game/script.rpy:255
translate chinese performance_cad34bcc:

    # jespuppet "Now... can you guess who I am?"
    jespuppet "那么......你猜猜我是谁？"

# game/script.rpy:257
translate chinese performance_092283e8:

    # "Th-This person... no, this puppet... seems to really enjoy talking..."
    "这、这家伙......不，这木偶......也太爱说了......"

# game/script.rpy:259
translate chinese performance_a4075a92:

    # u "Uh... you’re a...jester?"
    u "呃......你是......弄臣？"

# game/script.rpy:263
translate chinese performance_3310f055:

    # jespuppet "Ding, ding, ding! Correct!"
    jespuppet "叮、叮、叮！答对啦！"

# game/script.rpy:267
translate chinese performance_1a52fa9d:

    # jes "Though to be precise, jester is merely my role. Allow me to properly introduce myself to you sweet human. My name is Jestyn. You may call me Jestyn"
    jes "不过，准确来说，弄臣只是我的身份。还是让我正式向你介绍一下自己吧，亲爱的人类。我是Jestyn，你可以直接这么叫我。"

# game/script.rpy:268
translate chinese performance_446cde29:

    # jes "though some prefer Jes, Jesy, Tyn-Tyn and quite a few other variations, I’m afraid."
    jes "然，也有人喜欢叫我Jes、Jesy、Tyn-Tyn......还有不少别的昵称。"

# game/script.rpy:269
translate chinese performance_ad2cd72e:

    # jes "Now that I have offered you my name, allow me, just this once to ask for yours in return."
    jes "既然我已经自报家门，也让我知道你的名字吧？"

# game/script.rpy:273
translate chinese performance_9051201a:

    # jes "[player_call]....what a lovely name for such a lovely soul."
    jes "[player_call]......真是个好听的名字，和你可爱的灵魂很相称。"

# game/script.rpy:274
translate chinese performance_5b8aa077:

    # jes "And your pronoun is?"
    jes "你希望我用什么代词称呼你？"

# game/script.rpy:277
translate chinese performance_09cd3e7f:

    # jes "Understood"
    jes "明白了。"

# game/script.rpy:284
translate chinese performance_fa21c7df:

    # jes "But tell me... what brings you to this kingdom, I wonder? Are you perhaps carrying out a duty for the crown?"
    jes "我很好奇......你为什么会来到这个王国？莫非是在为王室办事？"

# game/script.rpy:286
translate chinese performance_48d18b2c:

    # "He keeps referring to this theater as a kingdom. It’s starting to confuse me."
    "他一直把这座剧院叫作王国，弄得我都有些糊涂了。"

# game/script.rpy:287
translate chinese performance_f7ef9773:

    # "Also, the way he speak is really strange"
    "而且他说话的方式也很奇怪。"

# game/script.rpy:288
translate chinese performance_3bd8f634:

    # "But... whatever. I’ll play along for now. I just want to get out of here as soon as possible."
    "不过......算了。还是先顺着他的话演下去吧，只要能尽快离开这里就好。"

# game/script.rpy:290
translate chinese performance_664a72de:

    # mc "I–I’m just a security guard. My job is to watch over this theater... and do a bit of cleaning on the side."
    mc "我、我只是个保安，负责这家剧院的安保......偶尔也做些清洁工作。"

# game/script.rpy:292
translate chinese performance_a175816a:

    # "I hope my answer satisfies him."
    "希望这回答能让他满意。"

# game/script.rpy:296
translate chinese performance_33c8f8bd:

    # "But suddenly, he starts laughing, and I have no idea why. Is my answer really that amusing to him?"
    "但他突然笑了起来，我完全不知道他为什么笑。我说的有那么好笑吗？"

# game/script.rpy:300
translate chinese performance_20da2bb0:

    # jes "Ah... a guardian, is it? Such a nooooble calling. A protector of the kingdom, one who stands firm, fighting on until the very last drop of blood."
    jes "啊......守护者，是吗？多么崇——高的使命啊。作为王国的守护者，屹立不倒，战至最后一刻。"

# game/script.rpy:301
translate chinese performance_d8bc5de1:

    # jes "And yet... regrettably, you cannot become a guardian here."
    jes "可即便如此......在这里你无法成为守护者。"

# game/script.rpy:302
translate chinese performance_519eacf2:

    # mc "W-What do you mean?"
    mc "什、什么意思？"

# game/script.rpy:306
translate chinese performance_90c9f9b2:

    # jes "You see, we already have a knight who serves as this kingdom’s shield. His name is Knighter. And we have no intention of welcoming another."
    jes "你要知道，我们已经有一位骑士，作为这个王国的盾。他叫Knighter，我们不会再迎来第二位。"

# game/script.rpy:307
translate chinese performance_34356624:

    # jes "One knight is more than sufficient."
    jes "一个骑士，就足够了。"

# game/script.rpy:309
translate chinese performance_d8a0138b:

    # "Is he... talking about roles in this theater?"
    "他这是......在说剧院里的角色吗？"

# game/script.rpy:311
translate chinese performance_e985e405:

    # mc "Oh... then I’ll just be a cleaner, I guess..."
    mc "哦......那我当个清洁工也行......"

# game/script.rpy:315
translate chinese performance_8a9f02b8:

    # jes "We already have plenty of maids here, and I don’t think it would be possible for us to add another."
    jes "这里的女仆已经够多了，恐怕没法再添一个。"

# game/script.rpy:316
translate chinese performance_4cfdcb02:

    # mc "Alright then. I suppose I’ll just be no one."
    mc "行吧。那我就当个不起眼的小角色。"

# game/script.rpy:320
translate chinese performance_4d4e6485:

    # jes "Oh no, no... everyone who comes here must have a role of their own."
    jes "哦不不不......来到这里的人，都必须有自己的角色。"

# game/script.rpy:321
translate chinese performance_f0711c5e:

    # jes "And the role that currently stands vacant... Is the king, the queen, the ruler of the kingdom"
    jes "而如今空缺的那个角色......是国王和王后，也就是这个王国的统治者。"

# game/script.rpy:322
translate chinese performance_f9ed36da:

    # mc "A-Alright... uh... but why is only the position of king empty?? What happened to the previous king?"
    mc "好、好吧......但为什么只有国王的位置是空的？？之前的国王怎么了？"

# game/script.rpy:324
translate chinese performance_dc20a6b6:

    # "When I checked the puppets earlier, there was a room labeled 'The King'. So the king puppet must have existed."
    "我刚才查看那些木偶时，明明看到有一间房标着“King”。这么说来，国王木偶应该是存在过的。"

# game/script.rpy:328
translate chinese performance_b2b283fa:

    # jes "Sadly, he passed away."
    jes "很遗憾，他去世了。"

# game/script.rpy:329
translate chinese performance_ce801f57:

    # mc "Oh... I’m sorry. My condolences."
    mc "哦.......抱歉。请节哀。"

# game/script.rpy:332
translate chinese performance_2f036b9a:

    # jes "It’s alright, my dear. That is simply how life is. people coooome and go. It is part of a cycle you cannot escape. I believe humans understand that very much"
    jes "没关系，亲爱的。人生就是如此，有人来，也有人离开。这是你无法逃开的循环，我想人类对此最有体会。"

# game/script.rpy:334
translate chinese performance_5bf47951:

    # "He then clapped his hands."
    "随后，他拍了拍手。"

# game/script.rpy:338
translate chinese performance_d94e3c51:

    # jes "It has been a very long time since the king passed. This kingdom has grown terribly dark... filled with silence, without direction or joy."
    jes "国王离世已经很久了。这个王国也因此变得格外阴沉......只剩寂静，失去了方向，也失去了欢乐。"

# game/script.rpy:339
translate chinese performance_1f957725:

    # jes "And I must admit... it has grown rather boring in here."
    jes "我也不得不承认......这里实在是无聊透了。"

# game/script.rpy:340
translate chinese performance_c6da68e6:

    # jes "But now that I have met such a sweet human before me, why don’t you indulge me in a little game, Your majesty?"
    jes "不过，既然我遇见了您这么可爱的人类。陛下，可愿赏脸陪我玩个小游戏？"

# game/script.rpy:341
translate chinese performance_6c977b5a:

    # mc "..... Your majesty? me?"
    mc "......陛下？我？"

# game/script.rpy:345
translate chinese performance_e6d429b2:

    # "His smile widened."
    "他笑得更灿烂了。"

# game/script.rpy:349
translate chinese performance_9bc84d96:

    # jes "Yes. Let us play a bit of acting. You shall pretend to be the [title], and I.. will be your jester."
    jes "对。我们来演一出戏。您扮演统治者，而我......则是侍奉你的弄臣。"

# game/script.rpy:353
translate chinese performance_fc5d52a4:

    # jes "Oh, do forgive me. I have been a jester from the very beginning. How foolish of me."
    jes "哦，请原谅我。我本来就是个弄臣。瞧我说的，真是糊涂。"

# game/script.rpy:356
translate chinese performance_91abef26:

    # "Jestyn then snapped his fingers and before i knew it, He had moved into the stage"
    "Jestyn打了个响指，我还没反应过来，他就已经走上了舞台。"

# game/script.rpy:367
translate chinese performance_1a9aa838:

    # jes "Now then... shall we allow the performance to begin?"
    jes "那么......演出可以开始了吧？"

# game/script.rpy:368
translate chinese performance_98e1e946:

    # mc "W-wait, wait! I’ve never acted before! I don’t even know how—"
    mc "等、等等！我从没演过！我连怎么演都——"

# game/script.rpy:369
translate chinese performance_f38844b3:

    # jes "Oh no, my dear... Simply live, as though you have always been the ruler of this kingdom."
    jes "哦不，亲爱的......您只需要活得像这个王国的统治者，就好像您一直都是如此。"

# game/script.rpy:374
translate chinese performance_e84b7420:

    # "Jestyn snapped his fingers again"
    "Jestyn又打了个响指。"

# game/script.rpy:381
translate chinese performance_5afda8b6:

    # "And in an instant, I found myself already on the stage. seated upon a plush throne, a crown resting atop my head."
    "转眼间，我已坐在舞台上的柔软王座上，头顶还多了一顶王冠。"

# game/script.rpy:387
translate chinese performance_bf5bf7f9:

    # mc "Wha— what?!"
    mc "什——什么？！"

# game/script.rpy:388
translate chinese performance_88a957a0:

    # nara "{color=#E0AE4B}One day, beneath the scorching summer sun, the kingdom was struck by trouble once more. The farmers were filled with sorrow as the relentless heat of summer scorched the land.{/color}"
    nara "{color=#E0AE4B}某一天，在盛夏灼人的烈阳下，王国再度陷入困境。盛夏的热浪无情炙烤着大地，农夫们愁苦不堪。{/color}"

# game/script.rpy:389
translate chinese performance_51554ab9:

    # nara "{color=#E0AE4B}Crops withered and failed under the drought, leaving the fields barren. As a result, the farmers suffered great losses, with no harvest left to sell.{/color}"
    nara "{color=#E0AE4B}旱灾之下，庄稼枯萎，几乎颗粒无收，田地一片贫瘠。农夫们损失惨重，几乎没有收成可卖。{/color}"

# game/script.rpy:390
translate chinese performance_8364a461:

    # nara "{color=#E0AE4B}In the end, the farmers brought their plight before [poss] Majesty, hoping [subj] might receive aid and relief.{/color}"
    nara "{color=#E0AE4B}最终，农夫们将自己的苦况呈到陛下面前，希望一国之主能赐予援助与救济。{/color}"

# game/script.rpy:392
translate chinese performance_c231e200:

    # "I looked around, trying to find the source of the voice that sounded like a narrator."
    "我环顾四周，想找出那道像旁白一样的声音从哪里传来。"

# game/script.rpy:394
translate chinese performance_6aa45380:

    # nara "{color=#E0AE4B}Within the kingdom, [poss] Majesty sat upon [poss] throne, [poss] expression clouded with confusion, when Jestyn the royal jester appeared before [poss] to relay the troubles faced by the farmers{/color}"
    nara "{color=#E0AE4B}王宫之中，陛下端坐在王座上，神情满是困惑。就在这时，宫廷弄臣Jestyn出现在其面前，禀报了农夫们所遭遇的困境。{/color}"

# game/script.rpy:399
translate chinese performance_01422283:

    # jes "Good evening, Your majesty."
    jes "晚上好，陛下。"

# game/script.rpy:401
translate chinese performance_a64afe78:

    # "Jestyn appear and bowed before me with utmost reverence."
    "Jestyn现身，以极为恭敬的姿态向我躬身行礼。"

# game/script.rpy:406
translate chinese performance_e9042124:

    # jes "What a truuuuly beautiful day today is."
    jes "今天可真是个无——比美好的日子。"

# game/script.rpy:407
translate chinese performance_af5db24b:

    # jes "A day just as fitting to tend to the little troubles stirring within the kingdom... Wouldn’t you agree, Your Majesty?"
    jes "也正适合处理王国里那些小小的波澜......您说是不是，陛下？"

# game/script.rpy:408
translate chinese performance_f95a4fa4:

    # mc "Troubles... in the kingdom?"
    mc "麻烦......王国内出了状况？"

# game/script.rpy:409
translate chinese performance_4874d63f:

    # jes "Indeed, Your Majesty."
    jes "正是如此，陛下。"

# game/script.rpy:413
translate chinese performance_f9c09460:

    # jes "As of late, the townsfolk have begun to voice their worries. The harvests have failed, brought low by the relentless drought of the dry season."
    jes "近来，镇民们纷纷诉说心中的忧虑。旱季久旱不雨，收成也因此尽数落空。"

# game/script.rpy:414
translate chinese performance_05d74c2d:

    # jes "And as one might expect, such misfortune has left them... quite lacking in means."
    jes "也正如所料，这场不幸让他们......几乎失去了维持生计的办法。"

# game/script.rpy:420
translate chinese performance_9f21f0aa:

    # jes "Please come in dear guest"
    jes "请进吧，亲爱的来客。"

# game/script.rpy:421
translate chinese performance_d534aa3a:

    # nara "{color=#E0AE4B}A man who worked as a farmer then entered, after Jestyn granted the man permission to enter.{/color}"
    nara "{color=#E0AE4B}得到Jestyn的允许后，一名农夫走了进来。{/color}"

# game/script.rpy:423
translate chinese performance_e943668d:

    # "Suddenly, a puppet dressed as a farmer stepped forward and knelt before me."
    "忽然，一个打扮成农夫的木偶走上前来，在我面前跪下。"

# game/script.rpy:427
translate chinese performance_b64f7501:

    # farm "Greetings, Your Majesty. Please forgive my boldness, but we come before you to humbly seek your aid."
    farm "陛下安好。恕我冒昧，我们此次觐见，只为恳求您的援助。"

# game/script.rpy:428
translate chinese performance_9ae10a62:

    # farm "Due to the failed harvests, we no longer have the means to replace the crops that withered, nor do we have the funds to meet our daily needs.."
    farm "收成尽毁，我们既无力重新播种，也无钱维持日常所需......"

# game/script.rpy:429
translate chinese performance_9d72adad:

    # farm "Thus, we beg you... to grant us your guidance."
    farm "因此，我们恳求您......为我们指一条生路。"

# game/script.rpy:431
translate chinese performance_972b6338:

    # "Having been dragged into the role of a [title] without warning, confusion washed over me."
    "我毫无预兆地被塞进了一国之主这个位置，困惑顿时涌上心头。"

# game/script.rpy:432
translate chinese performance_595efd78:

    # "My own troubles were far from resolved, and now I was expected to find a way to save the farmers as well?!"
    "我自己的麻烦都还没解决，现在竟还要我想办法救农夫？！"

# game/script.rpy:434
translate chinese performance_ec04fee4:

    # mc "U-um..."
    mc "呃......"

# game/script.rpy:436
translate chinese performance_15a64d5d:

    # "What am I supposed to do...?"
    "我该怎么办......？"

# game/script.rpy:491
translate chinese problem2_e3bea3c4:

    # mc "..... Is it finished?"
    mc "......结束了吗？"

# game/script.rpy:494
translate chinese problem2_70f8e564:

    # jes "Finished?"
    jes "结束？"

# game/script.rpy:496
translate chinese problem2_fb4c14c0:

    # jes "If governing a kingdom were that simple, Your Majesty, I fear we would have far fewer queens."
    jes "陛下，若治理王国真有这么简单，恐怕这世上就不会有那么多焦头烂额的君主了。"

# game/script.rpy:498
translate chinese problem2_4e766586:

    # "There’s still more..."
    "还有......"

# game/script.rpy:503
translate chinese problem2_a7674f73:

    # nara "{color=#E0AE4B}The day passed slowly within the kingdom. And without [poss] Majesty realizing it, the time that had once shown nine in the morning had already advanced to one in the afternoon.{/color}"
    nara "{color=#E0AE4B}时间在王国中缓缓流逝。陛下还未察觉，时针已从早上九点悄然走到下午一点。{/color}"

# game/script.rpy:504
translate chinese problem2_a95fab49:

    # nara "{color=#E0AE4B}At that very moment, a formal letter from another kingdom suddenly arrived.{/color}"
    nara "{color=#E0AE4B}就在此时，另一王国的正式来函突然送达。{/color}"

# game/script.rpy:505
translate chinese problem2_a5e90a9f:

    # nara "{color=#E0AE4B}Upon learning of this, the butler promptly took the letter and set out to deliver it to [poss] Majesty.{/color}"
    nara "{color=#E0AE4B}宫廷管家得知后，立刻取了信，前去呈交给陛下。{/color}"

# game/script.rpy:512
translate chinese problem2_007b68af:

    # "Suddenly, a butler-dressed puppet approached Jestyn and handed him a parchment scroll."
    "突然，一个身着管家服饰的木偶走近Jestyn，递给他一卷羊皮纸。"

# game/script.rpy:516
translate chinese problem2_9ad1e23c:

    # "Jestyn read it for a moment. His expression turned focused, before his eyes shifted toward me and that wide smile returned to his face."
    "Jestyn读了片刻，神情随之凝重。随后他抬眼看向我，那副夸张的笑容又回到了脸上。"

# game/script.rpy:520
translate chinese problem2_65c94ba0:

    # jes "Your Majesty, we have received a most astonishing and rather intriguing request from a neighboring kingdom."
    jes "陛下，我们收到了邻国一份令人震惊、也颇耐人寻味的请求。"

# game/script.rpy:524
translate chinese problem2_33b6191e:

    # "It is all written here, in ink, upon this scroll."
    "都已白纸黑字写在这卷文书上。"

# game/script.rpy:528
translate chinese problem2_ebec001e:

    # jes "In short, they wish to purchase a small piece of land along our border, under the pretense of facilitating trade."
    jes "简而言之，他们打着“便利贸易”的名义，想买下我们边境的一小块土地。"

# game/script.rpy:531
translate chinese problem2_e32448da:

    # jes "Should Your Majesty agree to this arrangement, they are prepared to offer compensation in gold coins. an amount I am quite certain would give Your Majesty a heart attack on the spot~"
    jes "若陛下同意，他们愿以金币作为补偿，数额之大，我敢说足以让陛下当场心悸不已呢～"

# game/script.rpy:532
translate chinese problem2_f70a91f0:

    # jes "So then.... what will you do, Your Majesty?"
    jes "那么......您打算如何裁决，陛下？"

# game/script.rpy:534
translate chinese problem2_445e6ea5:

    # "Oh no... this is starting to sound complicated. What should I do?"
    "哦不......这听起来越来越复杂了。我该怎么办？"

# game/script.rpy:576
translate chinese after_acting_372cd5aa:

    # jes "Very well then. I shall inform our neighbors of Your Majesty’s will."
    jes "很好。那么我会将陛下的旨意告知邻国。"

# game/script.rpy:577
translate chinese after_acting_661a8003:

    # jes "And I believe that, for now, the matters Your Majesty was required to resolve have reached the end of today’s program."
    jes "我想，至少目前，陛下今日需要处理的事务已到此为止。"

# game/script.rpy:578
translate chinese after_acting_917307e9:

    # jes "You may rest your head now your majesty~"
    jes "陛下现在可以好好歇一歇了～"

# game/script.rpy:580
translate chinese after_acting_093871f9:

    # "Finally..... it ends. I don't know if my brain can handle these kingdom things anymore"
    "终于......结束了。我真不知道自己的脑子还能不能再应付这些王国大事。"

# game/script.rpy:583
translate chinese after_acting_e6132cd8:

    # "Before i finally able to let myself relax, my phone rang."
    "我还没来得及真正放松，手机就响了。"

# game/script.rpy:584
translate chinese after_acting_7578997d:

    # "Oh no... it has to be my debt collector."
    "糟了......肯定是催债的。"

# game/script.rpy:586
translate chinese after_acting_acb0e640:

    # "I really don’t want to deal with this right now. I don’t have the money to pay."
    "我现在真的不想面对这些。我没钱还。"

# game/script.rpy:587
translate chinese after_acting_21ad1c53:

    # "But I don’t really have a choice..."
    "但我也没得选......"

# game/script.rpy:590
translate chinese after_acting_4e85cb4d:

    # mc "Hello?"
    mc "你好？"

# game/script.rpy:591
translate chinese after_acting_83e04508:

    # debt "[player_call]! You know why I’m calling, don’t you?"
    debt "[player_call]！你知道我为什么打来吧？"

# game/script.rpy:592
translate chinese after_acting_5a64fdcd:

    # mc "Of course...."
    mc "当然......"

# game/script.rpy:593
translate chinese after_acting_d0d55219:

    # debt "So?"
    debt "所以？"

# game/script.rpy:594
translate chinese after_acting_fe5086ae:

    # mc "I’m sorry... I can’t pay it right now."
    mc "对不起......我现在还不了。"

# game/script.rpy:595
translate chinese after_acting_18aa1915:

    # mc "But I just got a job again. You just need to wait until payday."
    mc "我刚重新找到工作。只要等到发薪日就好了。"

# game/script.rpy:597
translate chinese after_acting_7c7d602e:

    # debt "Haaah... fine. But remember, you’ve already delayed this for five months."
    debt "唉......行吧。但你记着，你已经拖了五个月。"

# game/script.rpy:598
translate chinese after_acting_cc837eb4:

    # mc "I know... I know... thank you for your understanding..."
    mc "我知道......我知道......谢谢你通融......"

# game/script.rpy:601
translate chinese after_acting_17c0a825:

    # "Moments after ending the call, I leaned my body against my seat, needing a brief rest."
    "挂断电话没多久，我就靠在座位上，想稍微歇一歇。"

# game/script.rpy:602
translate chinese after_acting_3345f35d:

    # "I have to pay it within a month..."
    "我得在一个月内还上......"

# game/script.rpy:604
translate chinese after_acting_a63b6d6b:

    # "I ran my fingers through my hair in frustration, before remembering that Jestyn was still standing in front of me."
    "我烦躁地抓了抓头发，这才想起Jestyn还站在我面前。"

# game/script.rpy:606
translate chinese after_acting_9e566277:

    # mc "Oh— sorry, Jestyn. That was just a personal matter—"
    mc "啊——抱歉，Jestyn。刚才只是点私事——"

# game/script.rpy:612
translate chinese after_acting_4dda5812:

    # "Suddenly, Jestyn’s hand gently closed around my shoulder. He looked at me with that wide smile of his."
    "Jestyn的手突然扣住我的肩。挂着那副夸张的笑容看着我。"

# game/script.rpy:614
translate chinese after_acting_a32261d7:

    # jes "Your Majesty, your personal matters are the kingdom’s matters."
    jes "陛下，您的私事，也是王国的事。"

# game/script.rpy:615
translate chinese after_acting_d24de394:

    # jes "And that makes them my concern as well, as the kingdom’s jester."
    jes "而作为王国的弄臣，这同样是我该关心的。"

# game/script.rpy:618
translate chinese after_acting_be56e838:

    # jes "From what I observed in your conversation through that technology just now, it seems Your Majesty is in debt... to another kingdom, am I correct?"
    jes "从陛下方才借助那项技术进行的谈话来看，您似乎负债在身......欠的，是另一个王国，对吗？"

# game/script.rpy:619
translate chinese after_acting_2b35b6fe:

    # mc "..."
    mc "......"

# game/script.rpy:620
translate chinese after_acting_07f99d29:

    # mc "Yeah...."
    mc "嗯......"

# game/script.rpy:622
translate chinese after_acting_fbbe8638:

    # "His hand on my shoulder gently kneaded the tension away. Instantly, I felt myself relax."
    "他搭在我肩上的手缓缓揉按，仿佛把我身上的紧绷一点点揉散。我立刻放松了些。"

# game/script.rpy:625
translate chinese after_acting_3a4a6a82:

    # jes "You may tell me your troubles, Your Majesty."
    jes "您可以把烦恼告诉我，陛下。"

# game/script.rpy:626
translate chinese after_acting_ddf56c7b:

    # jes "After all, I am your most loyal and only jester..."
    jes "毕竟，我是您最忠诚、也是唯一的弄臣......"

# game/script.rpy:629
translate chinese after_acting_0fd4d656:

    # "......"
    "......"

# game/script.rpy:632
translate chinese after_acting_0acac695:

    # mc "... I’ve been thinking about the kingdom’s finances for a long time now. They’ve been dwindling more and more."
    mc "......我已经为王国的财政发愁很久了。国库也越来越空了。"

# game/script.rpy:635
translate chinese after_acting_164f9f77:

    # jes "Oh my~"
    jes "天呐～"

# game/script.rpy:636
translate chinese after_acting_e0fe2d11:

    # mc "Yeah... back then I..... you could say I formed a sort of friendship with the ruler of another kingdom."
    mc "嗯......那时候我......也可以说，我和另一个王国的统治者成了某种朋友。"

# game/script.rpy:637
translate chinese after_acting_2ea7ab35:

    # mc "That kingdom needed help because they were facing a similar problem."
    mc "他们也遇到了类似的问题，所以需要帮助。"

# game/script.rpy:638
translate chinese after_acting_eea581d9:

    # mc "But In the end, that kingdom was only exploiting me and then they betrayed me."
    mc "但到头来，他们只是利用我，最后还背叛了我。"

# game/script.rpy:639
translate chinese after_acting_45f2d9f0:

    # mc "So... I had to borrow funds from other kingdoms. And now... our kingdom is burdened with considerable debt."
    mc "所以......我只能向其他王国借钱。现在......我们的王国背上了一大笔债。"

# game/script.rpy:640
translate chinese after_acting_a9d7652c:

    # mc "I’ve been trying to find other sources of income just to keep things stable."
    mc "我一直在找别的收入来源，只求先把局面稳住。"

# game/script.rpy:643
translate chinese after_acting_f35ef482:

    # "After I explained all my troubles through full of metaphors, Jestyn said nothing for a while."
    "我用满是隐喻的话把烦恼说完后，Jestyn沉默了好一会。"

# game/script.rpy:644
translate chinese after_acting_3d1a6ef7:

    # "Silence wrapped itself around the air between us."
    "沉默笼罩在我们之间。"

# game/script.rpy:647
translate chinese after_acting_ed5ba8b5:

    # jes "Do you know why the lion is honored as the king of the forest, Your Majesty?"
    jes "陛下，您知道为什么狮子会被尊为森林之王吗？"

# game/script.rpy:650
translate chinese after_acting_d1dd8d04:

    # "For a second, i feel confused by his sudden question about lion"
    "他突然提起狮子，我不由得愣了一下。"

# game/script.rpy:653
translate chinese after_acting_5fe678b3:

    # mc "Um... because they’re majestic?"
    mc "呃......因为它们很威风？"

# game/script.rpy:654
translate chinese after_acting_ff7db947:

    # jes "Indeed. They are majestic. They are fearsome. They are resilient, apex predators, standing at the very top."
    jes "没错。它们威严、凶猛、坚韧，是立于食物链顶端的掠食者。"

# game/script.rpy:655
translate chinese after_acting_8a60221d:

    # jes "Now, imagine a rabbit. Why is the rabbit never called the king of the forest?"
    jes "那么，再想想兔子。为什么兔子从来不被称作森林之王？"

# game/script.rpy:656
translate chinese after_acting_732e8b36:

    # mc "Because... rabbits are too gentle? Small? Not frightening enough?"
    mc "因为......兔子太温和？太弱小？不够吓人？"

# game/script.rpy:657
translate chinese after_acting_7f9f0b7b:

    # jes "Gentle."
    jes "温和。"

# game/script.rpy:659
translate chinese after_acting_26030657:

    # jes "far too hesitant.. and, ah tragically human."
    jes "太过犹豫......而且，啊，悲哀得像个人类。"

# game/script.rpy:660
translate chinese after_acting_0c515d6e:

    # jes "And most importantly... trusting others a little too easily."
    jes "最重要的是......太容易相信别人。"

# game/script.rpy:661
translate chinese after_acting_ed23a5fd:

    # jes "very noble qualities... for a suffering soul. Less so for a [title]."
    jes "这些品质对一颗受苦的灵魂来说......很高尚。但对一位一国之主而言，就没那么合适了。"

# game/script.rpy:663
translate chinese after_acting_2669f073:

    # jes "You thought that by helping others, they would like you. That they would smile at you, stand beside you, and call you a friend."
    jes "您以为只要帮助别人，他们就会喜欢您，会对您微笑，站在您身边，称您为朋友。"

# game/script.rpy:664
translate chinese after_acting_12293362:

    # jes "And then BOOM! What a delightful surprise! You have been fooled! Tricked! Played like a lovely little tune! Hahahahahaha!"
    jes "然后——BOOM！多么愉快的惊喜！您被耍了！被骗了！被人像拨弄一支可爱的小曲那样玩弄于股掌之间！哈哈哈哈哈！"

# game/script.rpy:667
translate chinese after_acting_b3646884:

    # "He laugh maniacly"
    "他癫狂地大笑起来。"

# game/script.rpy:670
translate chinese after_acting_b62ffb44:

    # jes "Isn’t that just perfectly ironic?"
    jes "这难道不是再讽刺不过了吗？"

# game/script.rpy:673
translate chinese after_acting_0fc512df:

    # "Jestyn spoke with a smile, each laugh delicate and polite... yet every word felt like a sharp blade pressed against my chest."
    "Jestyn含笑开口，每一声轻笑都显得温和而有礼......但他说出的每一个字，都像利刃般抵在我胸口。"

# game/script.rpy:674
translate chinese after_acting_3c32a577:

    # "I once read that a jester’s task in a kingdom... is to entertain. And part of that... is revealing truth through jest."
    "我曾读到过，宫廷弄臣在宫廷中的职责......是取悦众人。而其中一部分......便是用玩笑揭开真相。"

# game/script.rpy:687
translate chinese funny_8d463535:

    # "I see it now. yes, i must follow the game"
    "我现在明白了。是的......我得把这场游戏继续玩下去。"

# game/script.rpy:690
translate chinese funny_f004a6f1:

    # mc "Hahahaha! you're... not wrong jestyn"
    mc "哈哈哈哈！你......说得也没错，Jestyn。"

# game/script.rpy:697
translate chinese annoying_444727e3:

    # "But the way he said that..."
    "但他那语气......"

# game/script.rpy:698
translate chinese annoying_8ea1f22a:

    # "His words piercing deadly throught my heart"
    "像是要把我的心生生刺穿。"

# game/script.rpy:699
translate chinese annoying_b7842494:

    # "I won't lie, that's so annoying"
    "说实话，这感觉真让人恼火。"

# game/script.rpy:707
translate chinese advice_14e3cae9:

    # jes "You see, Your Majesty, the rules of this world are not some sweet little fable where kindness is always repaid in kind. I believe you already know it"
    jes "您瞧，陛下，这世上的规则并不是那种付出善意就一定会收获善意的甜美童话。我想您早就明白了。"

# game/script.rpy:708
translate chinese advice_aceede3e:

    # jes "Sometimes the game is far simpler than that. Sometimes, the rule is merely eat... or be eaten."
    jes "有时候，游戏远比那更简单。规则不过是吃掉别人......或者被别人吞噬。"

# game/script.rpy:709
translate chinese advice_5a4a31da:

    # mc "Do you mean I should become a lion?"
    mc "你的意思是我得成为狮子？"

# game/script.rpy:711
translate chinese advice_b805fab8:

    # jes "Oh no, no, Your Majesty. That won’t be necessary. Why?, the look on your face alone, so deprived of sleep is already quite terrifying."
    jes "哦不不，陛下，没那个必要。怎么说呢？您这一脸严重睡眠不足的样子，光是看着就已经很吓人了。"

# game/script.rpy:713
translate chinese advice_520b089f:

    # "He laughs mockingly as he watches me frowned"
    "见我皱眉，他带着几分嘲弄的意味笑出了声。"

# game/script.rpy:715
translate chinese advice_1b24106c:

    # jes "Hehe, forgive me, Your Majesty. I was only joking. I am not telling you to become a lion."
    jes "呵呵，恕我失礼，陛下。我只是开个玩笑，并不是要您真去当狮子。"

# game/script.rpy:717
translate chinese advice_f2e1bab4:

    # jes "Have you ever considered... combining a rabbit and a lion?"
    jes "您有没有想过......把兔子和狮子融为一体？"

# game/script.rpy:718
translate chinese advice_b8a4300d:

    # mc "Uh...wouldn’t that look like some kind of mutant?"
    mc "呃......那听起来不就是个变异怪物吗？"

# game/script.rpy:720
translate chinese advice_b39d6b88:

    # jes "Not that sort of combination, Your Majesty..."
    jes "不是那种结合，陛下......"

# game/script.rpy:722
translate chinese advice_f34bf4fe:

    # "He waves a finger lightly."
    "他轻轻晃了晃手指。"

# game/script.rpy:725
translate chinese advice_ca0b66f8:

    # jes "The appearance of a rabbit, yet the heart of a lion. Like a wolf beneath sheep’s clothing if you ask me."
    jes "外表是兔子，心却是狮子。要我说，这就像披着羊皮的狼。"

# game/script.rpy:727
translate chinese advice_16187254:

    # "He pause"
    "他顿了顿。"

# game/script.rpy:729
translate chinese advice_54063081:

    # jes "And also... trust only those around you whom you truly know."
    jes "还有......只相信那些您真正了解、而且就在您身边的人。"

# game/script.rpy:730
translate chinese advice_df231ede:

    # jes "Those who will remain loyal to you, no matter what. Difficult? Yes. But that is simply the truth."
    jes "去相信那些无论发生什么都会对您保持忠诚的人。这很难？没错，但事实如此。"

# game/script.rpy:733
translate chinese advice_6a7308d5:

    # jes "And after that... perhaps,those loyal to you may even help you destroy the ones who have hurt you"
    jes "再之后......也许那些忠于您的人，甚至会帮您毁掉那些曾伤害过您的人。"

# game/script.rpy:734
translate chinese advice_e2419ffb:

    # jes "{color=#FF2727}Just for you.{/color}"
    jes "{color=#FF2727}只是为了您。{/color}"

# game/script.rpy:737
translate chinese advice_47adc674:

    # jes "You do understand what I mean, do you not, Your Majesty?"
    jes "您明白我的意思，对吗，陛下？"

# game/script.rpy:739
translate chinese advice_2f85c766:

    # "His words leave me lost in thought."
    "他的话让我陷入沉思。"

# game/script.rpy:740
translate chinese advice_d8581df8:

    # "Now that I think about it... I really am a people pleaser."
    "现在想来......我好像的确是个总想取悦别人的人。"

# game/script.rpy:742
translate chinese advice_3cc35a6d:

    # mc "I understand... but changing that isn’t easy."
    mc "我明白......但要改掉这种习惯，并不容易。"

# game/script.rpy:744
translate chinese advice_e13b0076:

    # "Jestyn lets out a soft chuckle. His eyes narrow as his smile slowly widens."
    "Jestyn低笑一声，眼睛微微眯起，笑意一点点加深。"

# game/script.rpy:746
translate chinese advice_bab18eb3:

    # jes "Quite right, Your Majesty... and that is precisely why."
    jes "正是如此，陛下......也正因如此。"

# game/script.rpy:748
translate chinese advice_64883bc1:

    # jes "Perhaps instead of asking what more you can give... you should ask yourself what you are still refusing to take."
    jes "也许您该换个问法：别再问自己还能给予什么......而是问问自己，究竟还有什么是您不肯去争取的。"

# game/script.rpy:753
translate chinese advice_891258a4:

    # "Jestyn steps away from me, giving me space to ponder the meaning of his words."
    "Jestyn往后退开，给我留出空间去咀嚼他话里的意思。"

# game/script.rpy:754
translate chinese advice_4c28949b:

    # "His words are always hard to understand..."
    "他的话总是让人难以捉摸......"

# game/script.rpy:756
translate chinese advice_9e9daed2:

    # "He clapped his hands, snapping me out of my thoughts."
    "他拍了拍手，将我从思绪里拽了出来。"

# game/script.rpy:758
translate chinese advice_f3ef196f:

    # jes "Now... allow me to present you with intertaintment. You must be tired working all day yes, your majesty?"
    jes "那么......请允许我为您献上一点消遣。忙了一整天，您一定累了吧，陛下？"

# game/script.rpy:759
translate chinese advice_62999dc6:

    # jes "Much as I adore that expression of yours, like a bat awakened in broad daylight. I would still rather not seeing you forever wearing a face so utterly devoid of joy..."
    jes "虽然我很喜欢您这副模样，活像只在大白天被惊醒的蝙蝠，但我还是不想总见您露出这样一张毫无喜色的脸......"

# game/script.rpy:761
translate chinese advice_3bdcf7c5:

    # "He chuckles softly. It leaves me with far too little to laugh at."
    "他轻笑了一声，可我一点也笑不出来。"

# game/script.rpy:763
translate chinese advice_1d738662:

    # jes "I shall make you smile once more. Melting the chill of your life with the fire of delight I bring."
    jes "我会让您再次露出笑容。用我带来的欢愉之火，融去您生活中的寒意。"

# game/script.rpy:765
translate chinese advice_767cd509:

    # jes "Allow me~"
    jes "容我献丑~"

# game/script.rpy:767
translate chinese advice_1d7cf93b:

    # "Jestyn snapped his fingers. In an instant something appears on his hands"
    "Jestyn打了个响指。转瞬间，他手里多出一样东西。"

# game/script.rpy:768
translate chinese advice_0a0d80da:

    # "It was a small rectangular object, wrapped in a layer of gold and tied neatly with a red ribbon."
    "那是个小小的长方形物件，外面裹着金色包装纸，还用红丝带系得整整齐齐。"

# game/script.rpy:771
translate chinese advice_def0ad19:

    # mc "What is it?"
    mc "这是什么？"

# game/script.rpy:775
translate chinese advice_31a87d5e:

    # "Jestyn then handed it to me, allowing me to open it myself."
    "Jestyn把它递给我，让我自己拆开。"

# game/script.rpy:777
translate chinese advice_eabac4e2:

    # mc "Chocolate?"
    mc "巧克力？"

# game/script.rpy:779
translate chinese advice_f033135f:

    # jes "Indeed, Your Majesty. Everyone loves chocolate. Who doesn’t? So I do hope you’ll like it."
    jes "正是，陛下。人人都爱巧克力，不是吗？所以我想，您应该也会喜欢。"

# game/script.rpy:780
translate chinese advice_4cd27f3c:

    # jes "And it’s not just any ordinary chocolate."
    jes "而且这可不是普通的巧克力。"

# game/script.rpy:782
translate chinese advice_f7a516c1:

    # jes "I crafted every step of it with all my heart. carefully, gently, and with the utmost devotion."
    jes "我在每一道工序上都倾注了心意，小心翼翼、温柔，且怀着最虔诚的热忱。"

# game/script.rpy:784
translate chinese advice_d916d371:

    # jes "So I hope you’ll savor my handmade chocolate and not forget the color of its wrapping, Your Majesty~"
    jes "所以，我希望您能细细品尝我亲手做的巧克力，也别忘了它包装纸的颜色，陛下~"

# game/script.rpy:797
translate chinese eatchocolate_3697085d:

    # "Well... since it was already given to me, I couldn’t refuse. I didn’t have the heart to."
    "嗯......既然都递到我手里了，我也实在狠不下心拒绝。"

# game/script.rpy:798
translate chinese eatchocolate_ba8cabbe:

    # "I broke off a piece of the chocolate and put it into my mouth."
    "我掰下一小块，放进嘴里。"

# game/script.rpy:799
translate chinese eatchocolate_f185d9cc:

    # "The moment it touched my tongue, I could feel it melting."
    "巧克力一碰到舌尖，我就感觉它开始融化。"

# game/script.rpy:800
translate chinese eatchocolate_cd55feb8:

    # "But at the same time, I saw Jestyn’s smile sharpen and that was when I felt it."
    "与此同时，我看见Jestyn的笑意变得锋利。也就在那一瞬，我察觉到了。"

# game/script.rpy:802
translate chinese eatchocolate_4b1aad94:

    # mc "Uph—?!"
    mc "唔——？！"

# game/script.rpy:804
translate chinese eatchocolate_a8c586c7:

    # "A burning sensation spread across my tongue."
    "灼烧般的辣意在舌尖蔓延开来。"

# game/script.rpy:806
translate chinese eatchocolate_69ebc829:

    # jes "Oh dear, it seems someone forgot the color of the wrapping~"
    jes "噢天哪，看起来有人把包装纸的颜色给忘了呢~"

# game/script.rpy:808
translate chinese eatchocolate_8f5595d0:

    # "Jestyn chuckled softly at my face turning red from the heat."
    "Jestyn看着我被辣得脸颊发红，低声笑了起来。"

# game/script.rpy:810
translate chinese eatchocolate_90893ba6:

    # mc "W–what kind of chocolate is this?!"
    mc "这、这到底是什么巧克力？！"

# game/script.rpy:811
translate chinese eatchocolate_44960690:

    # jes "Hehe. It’s chocolate, of course. But I find the usual ingredients rather dull. Nothing new. How boring."
    jes "呵呵，它就是普通的巧克力。只不过我觉得常见的配料太无趣了，没新意，真无聊。"

# game/script.rpy:814
translate chinese eatchocolate_70eaca9d:

    # jes "And then! A brilliant idea struck me. Why not add something new to the recipe?"
    jes "然后！我灵光一闪，为什么不往配方里加点新东西呢？"

# game/script.rpy:815
translate chinese eatchocolate_2f9e35fe:

    # jes "So I added chili powder."
    jes "于是，我加了辣椒粉。"

# game/script.rpy:817
translate chinese eatchocolate_9bbcefec:

    # "I stared at him, completely speechless. What kind of thinking is that?!"
    "我瞪着他，彻底无语了。这是什么莫名其妙的思路？！"

# game/script.rpy:820
translate chinese eatchocolate_e9a00209:

    # jes "Poor you, Your Majesty. But that flustered, reddened expression of yours is simply adorable."
    jes "可怜的陛下。不过您这副慌乱又红扑扑的样子，实在可爱。"

# game/script.rpy:822
translate chinese eatchocolate_0e55d190:

    # "Jestyn then handed me a glass of water to drink."
    "Jestyn随即递来一杯水。"

# game/script.rpy:823
translate chinese eatchocolate_0534be04:

    # "How did I fall for his prank so easily?"
    "我怎么就这么轻易上了他的当？"

# game/script.rpy:828
translate chinese donteat_5d8ce5a8:

    # "I stared at the chocolate for a moment."
    "我盯着巧克力看了片刻。"

# game/script.rpy:829
translate chinese donteat_0260f83c:

    # "I didn’t want to refuse someone’s gift... but my instincts told me something was off."
    "我不想拒绝别人的礼物......但直觉告诉我，这里面有猫腻。"

# game/script.rpy:830
translate chinese donteat_278c7e29:

    # "........."
    "........."

# game/script.rpy:832
translate chinese donteat_17f2ebd7:

    # mc "Jestyn?"
    mc "Jestyn？"

# game/script.rpy:833
translate chinese donteat_32797f5c:

    # jes "Yes, Your Majesty?"
    jes "怎么了，陛下？"

# game/script.rpy:834
translate chinese donteat_098db61c:

    # mc "This isn’t ordinary chocolate, is it?"
    mc "这不是普通的巧克力吧？"

# game/script.rpy:836
translate chinese donteat_9809117e:

    # "His smile didn’t fade in the slightest as he looked back at me."
    "他回望着我，笑容丝毫未减。"

# game/script.rpy:838
translate chinese donteat_77c8fcdd:

    # jes "Oh? And what makes you say that, Your Majesty?"
    jes "哦？陛下为什么这么想？"

# game/script.rpy:840
translate chinese donteat_c9725607:

    # jes "Ah... to be honest, it pains my heart that you would accuse me so. I gave you that chocolate sincerely."
    jes "啊......说实话，您这样指责我，实在让我心痛。我可是怀着真心把巧克力送给您的。"

# game/script.rpy:842
translate chinese donteat_90b3aaad:

    # "His smile slowly faded, replaced by the expression of someone deeply wounded."
    "他的笑慢慢淡去，取而代之的是一副深受伤害的神情。"

# game/script.rpy:852
translate chinese donteat2_95213de5:

    # mc "Don’t lie to me."
    mc "别骗我。"

# game/script.rpy:853
translate chinese donteat2_8b2d262f:

    # mc "There’s something in this chocolate, isn’t there? I won’t be fooled."
    mc "这巧克力里加了东西，对吧？我不会被你糊弄的。"

# game/script.rpy:855
translate chinese donteat2_3f2af826:

    # jes "....."
    jes "......"

# game/script.rpy:857
translate chinese donteat2_68fc2657:

    # jes "Pfft... khuhu..."
    jes "噗......呵呵......"

# game/script.rpy:859
translate chinese donteat2_7a0c2c91:

    # "Jestyn let out a soft laugh. And with that alone, everything was proven."
    "Jestyn轻笑了一声。只是这一声，就足以证明一切。"

# game/script.rpy:861
translate chinese donteat2_f6bbaa0f:

    # jes "Heheheheh... ahahahahaha!"
    jes "呵呵呵......啊哈哈哈哈哈！"

# game/script.rpy:863
translate chinese donteat2_f62305b9:

    # jes "Ahh... so someone didn’t forget the color of the wrapping after all."
    jes "啊......原来你没忘包装纸的颜色。"

# game/script.rpy:864
translate chinese donteat2_52551e79:

    # jes "You’re sharper than you look, Your Majesty..."
    jes "您比看起来要敏锐得多，陛下......"

# game/script.rpy:866
translate chinese donteat2_79b789ab:

    # jes "Yes. I added something to the chocolate."
    jes "是的。我在巧克力里加了点东西。"

# game/script.rpy:868
translate chinese donteat2_1df16ba6:

    # "I dropped the chocolate onto the floor."
    "我把巧克力丢到地上。"

# game/script.rpy:870
translate chinese donteat2_6f68c9a6:

    # mc "T-then what did you put in it?! Don’t tell me it’s poison. Are you trying to kill me?!"
    mc "那、那你加的到底是什么？！别告诉我是毒药。你想杀了我吗？！"

# game/script.rpy:872
translate chinese donteat2_e05a60ec:

    # jes "Poison?! AHAHAHAHAHAHA!"
    jes "毒药？！啊哈哈哈哈哈！"

# game/script.rpy:874
translate chinese donteat2_96c92fd7:

    # jes "Oh, Your Majesty, I’m not that cruel. It was merely a prank. And I would never do something so merciless for the sake of a joke."
    jes "哦，陛下，我没那么残忍。只是个玩笑而已。我也绝不会为了取乐做出那种无情的事。"

# game/script.rpy:878
translate chinese donteat2_08e2742c:

    # jes "It’s chocolate, of course. But I find the usual ingredients rather dull. Nothing new. How boring."
    jes "它就是普通的巧克力。只不过我觉得常见的配料太无趣了，没新意，真无聊。"

# game/script.rpy:879
translate chinese donteat2_70eaca9d:

    # jes "And then! A brilliant idea struck me. Why not add something new to the recipe?"
    jes "然后！我灵光一闪，为什么不往配方里加点新东西呢？"

# game/script.rpy:880
translate chinese donteat2_2f9e35fe:

    # jes "So I added chili powder."
    jes "于是，我加了辣椒粉。"

# game/script.rpy:883
translate chinese donteat2_9bbcefec:

    # "I stared at him, completely speechless. What kind of thinking is that?!"
    "我瞪着他，彻底无语了。这是什么莫名其妙的思路？！"

# game/script.rpy:891
translate chinese freakymomen_65855918:

    # jes "Hehehe. Please forgive me, Your Majesty. I’ll give you a proper intertainment this time. I promise this isn’t another prank."
    jes "呵呵呵。请原谅我，陛下。这一次，我会为您献上真正的表演。我保证，这次不会再是恶作剧了。"

# game/script.rpy:893
translate chinese freakymomen_9524c3a6:

    # "Jestyn snapped his fingers."
    "Jestyn打了个响指。"

# game/script.rpy:909
translate chinese balls_ef621327:

    # mc "... balls?"
    mc "......球？"

# game/script.rpy:910
translate chinese balls_95449cd9:

    # jes "Correct"
    jes "正是。"

# game/script.rpy:916
translate chinese balls_8524ccab:

    # "Without waiting any longer, He began to juggling with remarkable skill."
    "他不再耽搁，立刻以娴熟得惊人的手法抛接起来。"

# game/script.rpy:917
translate chinese balls_d78cf6b9:

    # "The balls flew from one hand to another, mixed with a few flashy tricks. It was obvious he had done this countless times before."
    "球在他两手间来回飞舞，其间还穿插着几下花哨的动作。显然，这套把戏他早已练过无数次。"

# game/script.rpy:918
translate chinese balls_1a48c3f4:

    # "Then, his gaze shifted toward me."
    "随后，他的目光转向了我。"

# game/script.rpy:920
translate chinese balls_9f05f094:

    # jes "You must continue my juggling your majesty!"
    jes "陛下，接下来请您继续抛接这些球！"

# game/script.rpy:921
translate chinese balls_3fb0e546:

    # mc "Wait what-"
    mc "等、等等——"

# game/script.rpy:923
translate chinese balls_3f766e70:

    # "Before I could finish my sentence, Jestyn tossed all the balls toward me."
    "我话还没说完，Jestyn就把所有球一股脑抛向我。"

# game/script.rpy:924
translate chinese balls_d8cf2bd5:

    # "No matter how hard I tried, it was hopeless. The balls slipped from my hands and hit the floor before I could even keep them in the air."
    "我再怎么努力也无济于事。球从我手里接连滑落，根本没能在空中停住，便噼里啪啦地砸到了地上。"

# game/script.rpy:925
translate chinese balls_b69104d7:

    # "Seeing my pathetic attempt, Jestyn burst into laughter."
    "看见我这狼狈的样子，Jestyn忍不住大笑。"

# game/script.rpy:927
translate chinese balls_3ce7a169:

    # jes "Truly your majesty? You cannot even catch them, let alone juggle."
    jes "恕我直言，陛下，您连球都接不住，更别提杂耍了。"

# game/script.rpy:928
translate chinese balls_3b768363:

    # mc "Of course not! I’ve never done this before!"
    mc "那还用说！我又没做过这种事！"

# game/script.rpy:930
translate chinese balls_32a85459:

    # "The balls rolled across the stage, scattering at my feet."
    "球在台上滚得到处都是，散落在我脚边。"

# game/script.rpy:933
translate chinese balls_4faa5ed5:

    # jes "Ah ah ah! Do not look so defeated already, your majesty"
    jes "啊 啊 啊！别这么快就一脸沮丧嘛，陛下。"

# game/script.rpy:934
translate chinese balls_da52edfd:

    # jes "here I thought humans were quite good at catching things. Opportunities, promises, responsibilities."
    jes "我本以为人类很会接东西呢。机会也好，承诺也好，责任也好。"

# game/script.rpy:936
translate chinese balls_ddc21682:

    # "He chuckles softly, as if he had just told a harmless joke."
    "他低笑，仿佛只是说了个无伤大雅的笑话。"

# game/script.rpy:938
translate chinese balls_81f3ccdb:

    # mc "You threw them at me without warning..."
    mc "你一声招呼都不打就扔给我......"

# game/script.rpy:940
translate chinese balls_1da73b32:

    # jes "Did I?"
    jes "是吗？"

# game/script.rpy:942
translate chinese balls_42d168c2:

    # "He tilts his head, the bells on his hood chiming faintly."
    "他歪了歪头，兜帽上的铃铛发出细碎的叮当声。"

# game/script.rpy:944
translate chinese balls_97bfd332:

    # jes "My apologies then. Sometimes, I forget that not everyone enjoys surprises as much as I do."
    jes "那就请您见谅了。有时候我总会忘记，不是每个人都像我一样喜欢惊喜。"

# game/script.rpy:947
translate chinese balls_d7fbe90a:

    # "He bent down and picked up one of the fallen balls, spinning it lightly on his palm."
    "他弯下腰捡起一颗球，在掌心里转了转。"

# game/script.rpy:950
translate chinese balls_7c2ed117:

    # jes "Tell me, what do you think juggling is your majesty?"
    jes "告诉我，陛下，您觉得杂耍是什么？"

# game/script.rpy:951
translate chinese balls_d44ced45:

    # mc "Uh... throwing things? Trying not to drop them?"
    mc "呃......把东西抛起来？尽量别让它们掉下来？"

# game/script.rpy:953
translate chinese balls_7bf63dbf:

    # jes "Hoho... an honest answer. I like that."
    jes "呵呵......很诚实的回答。我喜欢。"

# game/script.rpy:955
translate chinese balls_78579f7a:

    # jes "Juggling is balance. Timing. Knowing which ball to catch first and which one you must allow to fall."
    jes "杂耍讲究平衡，讲究时机，讲究分清该先接住哪一颗，也讲究明白哪一颗必须放手让它落下。"

# game/script.rpy:956
translate chinese balls_f11d3722:

    # "He casually tosses the ball into the air, catching it with ease."
    "他随手将球抛起，又轻而易举地接住。"

# game/script.rpy:958
translate chinese balls_18837d02:

    # "Then he lets the ball slips from his fingers and hits the stage with a dull sound. then he stares back at me"
    "接着他故意松开手指，任由球从指间滑落，坠在舞台上，发出沉闷的声响。随后，他抬眼看向我。"

# game/script.rpy:965
translate chinese home_b2dbb149:

    # jes "I believe your time in this kingdom has now come to an end."
    jes "我想，您在这个王国的逗留，如今该结束了。"

# game/script.rpy:967
translate chinese home_28fa5188:

    # "I am confused by what he means, but when I glance at my watch, it reads 5:30 a.m."
    "我没明白他的意思，但当我低头看向手表时，上面显示着清晨五点半。"

# game/script.rpy:969
translate chinese home_ab05c1c8:

    # mc "Oh... my shift is over."
    mc "哦......我这班结束了。"

# game/script.rpy:971
translate chinese home_3f1bdbf6:

    # "He takes my hand and presses a kiss to the back of it."
    "他牵起我的手，在手背上落下一吻。"

# game/script.rpy:972
translate chinese home_8079daff:

    # "His lips feel cold, yet the sensation sends heat racing through my body and straight to my heart."
    "他的唇很冷，但那触感却像火一样窜过我的全身，直烧到心口。"

# game/script.rpy:974
translate chinese home_42a2cc2b:

    # jes "Then, until we meet again,"
    jes "那么，后会有期，"

# game/script.rpy:976
translate chinese home_1632ba7e:

    # jes "sweet human..."
    jes "惹人怜爱的人类......"

# game/script.rpy:978
translate chinese home_3cdae3c3:

    # "After saying that, Jestyn walks toward the dark side of the stage and disappears."
    "说完，Jestyn 朝舞台的暗处走去，身影随即消失。"

# game/script.rpy:981
translate chinese home_9342fca3:

    # "I finally return to my small, miserable apartment."
    "我终于回到了那间狭小而寒酸的公寓。"

# game/script.rpy:982
translate chinese home_f52f2dbb:

    # "And what happened today was truly something...."
    "而今天发生的一切，简直难以形容......"

# game/script.rpy:983
translate chinese home_3df4b499:

    # "Living puppets... and being treated like some kind of [title]"
    "活木偶......还有我被当成某种一国之主来对待。"

# game/script.rpy:984
translate chinese home_4e207e4e:

    # "What a strange day. I feels like i'm going crazy"
    "真是怪得离谱的一天。我感觉自己快要疯了。"

# game/script.rpy:985
translate chinese home_5ef7297b:

    # "Should I go back again tomorrow? These whole situation feels so creepy..."
    "明天还要再去吗？这整件事都透着一股说不出的诡异......"

# game/script.rpy:986
translate chinese home_07bdde05:

    # "....."
    "......"

# game/script.rpy:987
translate chinese home_aeb9b1ae:

    # "... Of course I have to go. My debt won't be paid by itself. I need the money. Looking for another job would be far too difficult for me right now."
    "......我当然得去。债不会自己还清，我需要这笔钱。以我现在的状况来说想再找一份工作实在太难了。"

# game/script.rpy:988
translate chinese home_9f059fed:

    # "I don’t know what will happen to me later"
    "我不知道之后会发生什么。"

# game/script.rpy:989
translate chinese home_71178961:

    # "For now, I’d better get some sleep. I’m utterly exhausted."
    "不过现在，我最好先睡一觉。我已经筋疲力尽。"

# game/script.rpy:990
translate chinese home_a20cefa7:

    # "..."
    "..."

# game/script.rpy:991
translate chinese home_5f9b772e:

    # "...."
    "...."

# game/script.rpy:992
translate chinese home_0fd4d656:

    # "......"
    "......"

# game/script.rpy:1001
translate chinese home_bbd50ba8:

    # jes "Seconds passed... then hours... days... weeks... months... years..."
    jes "时间一秒一秒流逝......继而是数小时......数日......数周......数月......数年......"

# game/script.rpy:1002
translate chinese home_cfeb39ac:

    # jes "It has been so very long since all of that faded away."
    jes "自从那一切都成了过去，已经过了很久。"

# game/script.rpy:1003
translate chinese home_5554f270:

    # jes "And after so long.... I’ve finally found you..."
    jes "而在漫长等待之后......我终于找到您了......"

# game/script.rpy:1005
translate chinese home_d4bb94ed:

    # jes "My [title]"
    jes "我的陛下。"

# game/script.rpy:1006
translate chinese home_4b236792:

    # jes "Your Majesty... I truly thank you for today. You’ve made me so unbearably happy..."
    jes "陛下......我真心感谢您今天的一切。您让我快乐得几乎难以承受......"

# game/script.rpy:1008
translate chinese home_d12460ef:

    # jes "Ah... but... you will come again tonight, won’t you...?"
    jes "啊......可是......今晚您还会来，对吗......？"

# game/script.rpy:1009
translate chinese home_dc48b27e:

    # jes "Of course... of course you will. There are still so many things we can do together. I simply couldn’t bear it if you didn’t."
    jes "当然......您当然会来。我们还有那么多事情可以一起做。要是您不来......我真的受不了。"

# game/script.rpy:1012
translate chinese home_77ea8a7d:

    # jes "I’ll teach you juggling. You said you wanted me to, didn’t you? Then I’ll teach you everything. every trick, every motion, until your hands move exactly the way mine do."
    jes "我会教您杂耍。您说过想让我教您，不是吗？那我就全教给您，每个把戏、每个动作，直到您的双手能像我的一样灵巧。"

# game/script.rpy:1013
translate chinese home_91c7b2d2:

    # jes "Then I’ll show you magic tricks... ones I promise will steal your breath away. Oh, and there are so many puppets waiting for you to meet... to arrange...to belong where you want them. And then...and then..."
    jes "然后我会给您看魔术......我保证，会让您惊得喘不过气。哦，还有那么多木偶等着您去见.....去摆布.....去放到您想让它们待的地方。然后.....然后....."

# game/script.rpy:1016
translate chinese home_53ae36ac:

    # jes "We can play again like we did earlier, Your Majesty. I am your loyal jester, kneeling before my master like a devoted hound."
    jes "我们还能像之前那样再玩一次，陛下。我会做您忠诚的弄臣，像一条虔诚的猎犬般跪在主人面前。"

# game/script.rpy:1017
translate chinese home_c3fcfba9:

    # jes "Oh, you have no idea how that feeling made my heart race.. how it made me feel as though I belonged to you.. yes.. I belong to you, [title] [player_call]"
    jes "哦，您根本不知道那感觉让我心跳得多快......让我觉得自己仿佛属于您......是的......我属于您，陛下，[player_call]。"

# game/script.rpy:1020
translate chinese home_3b7654bf:

    # jes "We can dine together, sleep together, sing together, dance together... always together.. and then... and then... "
    jes "我们可以一起用餐、一起入睡、一起歌唱、一起起舞......永远在一起......然后......然后......"

# game/script.rpy:1022
translate chinese home_a1abeaae:

    # jes "Oh, sweet tart and cream, there are simply too many things we could do that I hardly know where to begin... as long as you never leave my side."
    jes "哦，我的甜挞奶油，我们能做的事多得让我都不知从何说起......只要您永远别离开我身边。"

# game/script.rpy:1023
translate chinese home_555bdd3f:

    # jes "Truly... what have you done to me, Your Majesty... I’m beginning to believe you’re a sorcerer of terrifying power. Even Wizzy, the royal mage, couldn’t twist a heart like this..."
    jes "说真的......您到底对我做了什么，陛下......我都开始相信您是个拥有可怕力量的术士了。就连Wizzy那位王室法师，也不可能把一颗心扭曲成这样......"

# game/script.rpy:1026
translate chinese home_3523e422:

    # jes "I feel as though I’ve been caught in your web… wrapped tightly, unable to escape... simply waiting to be devoured by you.. and yet..I don’t think I want to struggle at all."
    jes "我感觉自己像是落入了您的网......被紧紧缠住，无法逃脱......只等着被您吞噬......可即便如此......我也一点都不想挣扎。"

# game/script.rpy:1028
translate chinese home_067bdf0d:

    # jes "I scarcely recognize myself anymore, Your Majesty... but somehow, I don’t wish to go back."
    jes "我几乎快不认识现在的自己，陛下......可不知为何，我也不想回到从前"

# game/script.rpy:1029
translate chinese home_86f0ef77:

    # jes "The kingdom needs you.. I need you."
    jes "王国需要您......我也需要您。"

# game/script.rpy:1032
translate chinese home_45e4e473:

    # jes "No. I want you... I crave you... My [title], [player_call]... "
    jes "不，我想要您......我渴求您......我的陛下，[player_call]......"

# game/script.rpy:1033
translate chinese home_8e8701f7:

    # jes "I’ve never felt anything this overwhelming before... I want to stay by your side, watch you breathe, carve your image into my mind, touch you.. and perhaps.. sink even deeper into you, until there’s nothing left but us..."
    jes "我从未体会过如此汹涌的情感......我想留在您身边，看着您呼吸，把您的模样刻进脑海，触碰您......也许......更深地融入您，直到世上只剩下我们......"

# game/script.rpy:1034
translate chinese home_6ee728d3:

    # jes "Ah— no, no, no. How improper of me. A mere jester touching his [title] so boldly.. but if you were to grant me permission, I would cherish every inch of you with the utmost devotion."
    jes "啊——不、不、不，我太失礼了。区区弄臣竟敢如此大胆触碰自己的陛下......可若您愿意准许，我必将以最虔诚的心，珍惜您的每一寸。"

# game/script.rpy:1035
translate chinese home_a1e6d275:

    # jes "Oh, My [title], I can hardly endure the wait to see you again... I wish time would rush forward... and yet freeze completely when I am with you. If only I could bend time itself. Just for you."
    jes "我的陛下，我几乎无法忍受等待再次见到您......我希望时间飞快向前......却又希望与您相伴时时间彻底凝固。若我能扭曲时间本身就好了，只为您。"

# game/script.rpy:1036
translate chinese home_d3bd5717:

    # jes "I’ll take my leave now, My [title]... may your dreams be filled with me... "
    jes "我就先告退了，我的陛下......愿您的梦里满是我......"

# game/script.rpy:1038
translate chinese home_6ebbd0f1:

    # jes "[player_call]"
    jes "[player_call]"

translate chinese strings:

    # game/script.rpy:87
    old "Cleaning up"
    new "打扫收拾"

    # game/script.rpy:93
    old "Checking puppets"
    new "检查木偶"

    # game/script.rpy:99
    old "All done"
    new "都弄完了"

    # game/script.rpy:139
    old "Check outer gate"
    new "检查外门"

    # game/script.rpy:142
    old "Check corridor 1"
    new "检查1号走廊"

    # game/script.rpy:145
    old "Check theater hall"
    new "检查剧院大厅"

    # game/script.rpy:148
    old "Check storage"
    new "检查储藏室"

    # game/script.rpy:152
    old "Check stage"
    new "检查舞台"

    # game/script.rpy:441
    old "Give them money"
    new "给他们钱"

    # game/script.rpy:451
    old "Build water channels"
    new "修建水渠"

    # game/script.rpy:461
    old "Give them new seeds"
    new "给他们新种子"

    # game/script.rpy:471
    old "I need time to think"
    new "我需要时间想想"

    # game/script.rpy:481
    old "You should find a solution yourselves"
    new "你们自己想办法解决"

    # game/script.rpy:539
    old "Agree"
    new "同意"

    # game/script.rpy:548
    old "Refuse"
    new "拒绝"

    # game/script.rpy:557
    old "Delay"
    new "先拖一拖"

    # game/script.rpy:677
    old "Laugh with it"
    new "跟着笑"

    # game/script.rpy:682
    old "That's annoying"
    new "真烦人"

    # game/script.rpy:787
    old "Eat"
    new "吃"

    # game/script.rpy:791
    old "Don't eat"
    new "不吃"

    # game/script.rpy:844
    old "Trust him"
    new "信他"

    # game/script.rpy:848
    old "Don't trust him"
    new "不信他"

    # game/script.rpy:896
    old "Balls"
    new "球"

    # game/script.rpy:900
    old "Collar"
    new "项圈"

