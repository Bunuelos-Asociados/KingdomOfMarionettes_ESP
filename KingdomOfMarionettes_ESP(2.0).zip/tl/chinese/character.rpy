﻿# TODO: Translation updated at 2026-03-04 11:36

# game/character.rpy:35
translate chinese ask_player_name_f1b999d0:

    # jes "Oh, sweet tart and cream. We share the same name! What a truly marvelous miracle."
    jes "哦，甜挞奶油。我们竟然同名！这还真是个奇妙的巧合。"

# game/character.rpy:37
translate chinese ask_player_name_9ea78486:

    # jes "Mmm... in that case, calling you by your name would be rather troublesome. It would feel strange to be calling myself."
    jes "嗯......既然这样，直接叫你的名字就有点不方便了，听起来像在叫我自己。"

# game/character.rpy:38
translate chinese ask_player_name_5c49eeec:

    # jes "So instead, I shall bestow upon you a nickname. Sweety! Doesn’t it sound delightful? Sweet, just like a strawberry tart."
    jes "我还是给你起个昵称吧。甜心！是不是很可爱？听起来就和草莓挞一样甜。"

# game/character.rpy:40
translate chinese ask_player_name_5d49a77b:

    # jes "And what’s more, it even shares the same ending letters. sweeTY, JesTYn. Don’t I sound like a genius?"
    jes "更妙的是，连结尾的字母都对上了。sweeTY，JesTYn。我是不是很天才？"

# game/character.rpy:41
translate chinese ask_player_name_95d15ecd:

    # mc "Um... actually, it’s missing an 'N'."
    mc "呃......其实还少了个“N”。"

# game/character.rpy:43
translate chinese ask_player_name_b2120850:

    # jes "Then Sweetyn."
    jes "那就叫Sweetyn。"

# game/character.rpy:44
translate chinese ask_player_name_dcb6e45a:

    # "... I suppose that will do."
    "......行吧，就这样吧。"

# game/character.rpy:53
translate chinese ask_player_name_39b7cb58:

    # jes "...What? Knighter?? Pffft Ahhhahahahahhahaa!! ohhh!, are the heavens and earth trying to play a joke on me?!"
    jes "......什么？Knighter？？噗——啊哈哈哈哈！！哦！！天地万物之主是要拿我寻开心吗？！"

# game/character.rpy:55
translate chinese ask_player_name_4bd194ca:

    # jes "It’s certainly a bold and heroic sounding name, I’ll grant you that. But I simply can’t allow you to keep it."
    jes "我承认，这名字听着确实勇敢又有英雄气概。不过我可不能让你继续用。"

# game/character.rpy:56
translate chinese ask_player_name_4374fe19:

    # jes "If the grumpy master were to find out... oh, I dread to imagine how many pieces you’d end up in"
    jes "要是那位暴躁的主人发现了......哦，我都不敢想你会被拆成多少块。"

# game/character.rpy:58
translate chinese ask_player_name_2ce068df:

    # jes "So I suggest you choose another name."
    jes "所以我建议你换个名字。"

# game/character.rpy:62
translate chinese ask_player_name_8e28f667:

    # mc "But my name truly is Knighter..."
    mc "可我真的就叫Knighter......"

# game/character.rpy:64
translate chinese ask_player_name_89c76285:

    # jes "And I am telling you that you may no longer use that name."
    jes "但我现在告诉你，你以后不准再用这个名字。"

# game/character.rpy:65
translate chinese ask_player_name_cbd182b0:

    # jes "Or as I stated a few seconds ago... you would become nothing more than scattered fragments in the blink of an eye."
    jes "否则就像我刚才说的那样......眨眼之间，你就只剩一地碎片。"

# game/character.rpy:67
translate chinese ask_player_name_888f0c8a:

    # jes "So I strongly suggest you choose a new name. Immediately."
    jes "因此，我强烈建议你立刻改个新名字。马上。"

# game/character.rpy:72
translate chinese ask_player_name_447bf2f1:

    # jes "Hmm... I find myself wondering, sweet human."
    jes "嗯......我倒想问问你啊，惹人怜爱的人类。"

# game/character.rpy:73
translate chinese ask_player_name_339d8616:

    # jes "Is it that your ears fail to function and did not hear what I said earlier, or are you simply stubborn? There is hardly any difference."
    jes "是你耳朵不好使，没听见我刚才说的话？还是你就是倔？反正也没什么不同。"

# game/character.rpy:75
translate chinese ask_player_name_8a79e23c:

    # jos "Very well. Since you insist on being so obstinate, I shall give you a name myself."
    jes "好吧。既然你坚持这么固执，那我就亲自给你起名。"

# game/character.rpy:77
translate chinese ask_player_name_9fccd482:

    # jos "From this moment on, your name shall be... Stubbornelle."
    jes "从这一刻起，你的名字就是......Stubbornelle。"

# game/character.rpy:78
translate chinese ask_player_name_0f4cd710:

    # mc "But—"
    mc "可是——"

# game/character.rpy:80
translate chinese ask_player_name_babbb6eb:

    # jos "Tatatatat~ No complaints."
    jes "哒哒哒哒哒~ 抗议无效。"

# game/character.rpy:88
translate chinese ask_player_name_759260e6:

    # jos "Oh my goodness! Wizzy? Did I hear that correctly?"
    jes "天哪！Wizzy？我没听错吧？"

# game/character.rpy:90
translate chinese ask_player_name_5686fc26:

    # jos "How adorable. Just wait until Wizzy, the royal mage, hears about this."
    jes "太可爱了。等王室法师Wizzy听到这事吧。"

# game/character.rpy:92
translate chinese ask_player_name_14e6ddf6:

    # jes "I’m absolutely certain, one thousand and one percent that his heart will shine like a star when he learns he has a brand new twin."
    jes "我敢一千零一分肯定，他知道自己多了个崭新的双胞胎时，心都会亮得像星星一样。"

# game/character.rpy:101
translate chinese ask_player_name_1acc92f3:

    # "{color=#FF2727}......{/color}"
    "{color=#FF2727}......{/color}"

# game/character.rpy:102
translate chinese ask_player_name_a49f3494:

    # "{color=#FF2727}oh..... really...?{/color}"
    "{color=#FF2727}哦......是吗......{/color}"

# game/character.rpy:103
translate chinese ask_player_name_5345f543:

    # "{color=#FF2727}ha....haha....{/color}"
    "{color=#FF2727}哈......哈哈......{/color}"

# game/character.rpy:106
translate chinese ask_player_name_9d05eb66:

    # "{color=#FF2727}{cps=220}HAHAHAHAHHAHAHHAHAHAHAHAHAHAHHAHHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHA HAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHHAHAHAHAH AHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHA HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAH{/cps}{/color}"
    "{color=#FF2727}{cps=220}哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈{/cps}{/color}"

# game/character.rpy:108
translate chinese ask_player_name_0fd4d656:

    # "......"
    "......"

# game/character.rpy:109
translate chinese ask_player_name_278c7e29:

    # "........."
    "........."

# game/character.rpy:115
translate chinese ask_player_name_2f4f0bc8:

    # jes "Ah... it's really an honour to be meeting you [player_call]"
    jes "啊......能见到你，真是我的荣幸，[player_call]。"

translate chinese strings:

    # game/character.rpy:1
    old "Jestyn"
    new "Jestyn"

    # game/character.rpy:3
    old "Jester puppet"
    new "弄臣木偶"

    # game/character.rpy:5
    old "Knighter"
    new "Knighter"

    # game/character.rpy:7
    old "Knight puppet"
    new "骑士木偶"

    # game/character.rpy:9
    old "???"
    new "？？？"

    # game/character.rpy:11
    old "You"
    new "你"

    # game/character.rpy:13
    old "Farmer"
    new "农夫"

    # game/character.rpy:15
    old "Debt collector"
    new "讨债人"

    # game/character.rpy:17
    old "Narrator"
    new "旁白"

    # game/character.rpy:130
    old "She / Her"
    new "她/她"

    # game/character.rpy:137
    old "He / Him"
    new "他/他"

    # game/character.rpy:144
    old "They / Them"
    new "TA/TA"

