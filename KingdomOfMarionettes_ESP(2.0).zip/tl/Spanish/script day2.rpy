# TODO: Translation updated at 2026-11-09 22:40

# game/script day2.rpy:29
translate Spanish kom_day2_d41d8cd9:

    # voice "CROWNUS01_DAY2.ogg"
    voice "CROWNUS01_DAY2.ogg"

# game/script day2.rpy:34
translate Spanish kom_day2_d41d8cd9_1:

    # voice "CROWNUS02_DAY2.ogg"
    voice "CROWNUS02_DAY2.ogg"

# game/script day2.rpy:39
translate Spanish kom_day2_d41d8cd9_2:

    # voice "CROWNUS03_DAY2.ogg"
    voice "CROWNUS03_DAY2.ogg"

# game/script day2.rpy:44
translate Spanish kom_day2_d41d8cd9_3:

    # voice "CROWNUS04_DAY2.ogg"
    voice "CROWNUS04_DAY2.ogg"

# game/script day2.rpy:49
translate Spanish kom_day2_d41d8cd9_4:

    # voice "CROWNUS05_DAY2.ogg"
    voice "CROWNUS05_DAY2.ogg"

# game/script day2.rpy:64
translate Spanish kom_day2_8f5a0cdc:

    # "I slowly opened my eyes. The first thing I saw was the ceiling above my bed."
    "Abrí los ojos lentamente. Lo primero que vi fue el techo sobre mi cama."

# game/script day2.rpy:65
translate Spanish kom_day2_9841eaf4:

    # "Ugh... I feel like shit..."
    "Ugh... Me siento como una mierda..."

# game/script day2.rpy:66
translate Spanish kom_day2_461400bf:

    # "What time is it now..."
    "¿Qué hora es ya...?"

# game/script day2.rpy:67
translate Spanish kom_day2_b2fdec16:

    # "I fumbled around on my mattress, trying to figure out where I had left my phone last night."
    "Tanteé el colchón tratando de recordar dónde había dejado el teléfono anoche."

# game/script day2.rpy:68
translate Spanish kom_day2_44a837bc:

    # "When I finally found it and checked the screen, it was already 4 PM."
    "Cuando por fin lo encontré y miré la pantalla, ya eran las 4 p. m."

# game/script day2.rpy:69
translate Spanish kom_day2_5e68b3c1:

    # "Thank goodness I didn't oversleep. I still have enough time to get ready..."
    "Menos mal que no dormí de más. Todavía tengo tiempo de sobra para arreglarme..."

# game/script day2.rpy:70
translate Spanish kom_day2_11dc2429:

    # "I tossed my phone back onto the bed and spent a moment staring blankly at the ceiling, gathering enough willpower to function."
    "Lancé el teléfono de vuelta a la cama y me quedé un momento mirando el techo sin ver, reuniendo la fuerza de voluntad necesaria para funcionar."

# game/script day2.rpy:71
translate Spanish kom_day2_41323821:

    # "Eventually, I dragged myself out of my ridiculously comfortable bed and started getting ready for work."
    "Al final me arrastré fuera de mi cama ridículamente cómoda y empecé a prepararme para el trabajo."

# game/script day2.rpy:75
translate Spanish kom_day2_ef40ff71:

    # "After spending roughly an hour getting ready, I decided to head out a little early and stop by the convenience store."
    "Después de pasar más o menos una hora arreglándome, decidí salir un poco antes y pasar por la tienda de conveniencia."

# game/script day2.rpy:76
translate Spanish kom_day2_de5eee75:

    # "I needed some snacks to survive my shift."
    "Necesitaba algunos snacks para sobrevivir a mi turno."

# game/script day2.rpy:77
translate Spanish kom_day2_3f4319b6:

    # "Originally, I was planning to buy groceries for the month too. Last I checked, my fridge was almost as empty as my wallet."
    "En un principio pensaba comprar también la despensa del mes. La última vez que revisé, mi nevera estaba casi tan vacía como mi cartera."

# game/script day2.rpy:78
translate Spanish kom_day2_6b344f1d:

    # "But oddly enough, when I checked after my shower earlier, it was packed with food."
    "Pero, curiosamente, cuando la revisé después de la ducha, estaba llena de comida."

# game/script day2.rpy:79
translate Spanish kom_day2_204bb929:

    # "Did I forget that I already had groceries?"
    "¿Se me había olvidado que ya había hecho las compras?"

# game/script day2.rpy:80
translate Spanish kom_day2_4213add0:

    # "No. I distinctly remember my fridge being practically barren. So... did I somehow forget that I'd gone grocery shopping yesterday?"
    "No. Recuerdo perfectamente que mi nevera estaba prácticamente vacía. Entonces... ¿se me habrá olvidado que ayer fui al supermercado?"

# game/script day2.rpy:81
translate Spanish kom_day2_9d5531c2:

    # "Ah, I don't know. I'm too tired to remember."
    "Ah, no sé. Estoy demasiado cansad[letra] para acordarme."

# game/script day2.rpy:86
translate Spanish kom_day2_dba5a1a7:

    # "I eventually arrived at the convenience store I frequented, mostly because it was only a short walk from my apartment."
    "Por fin llegué a la tienda de conveniencia a la que siempre iba, sobre todo porque quedaba a un corto paseo de mi apartamento."

# game/script day2.rpy:87
translate Spanish kom_day2_9bf7fe68:

    # "At this point, I knew the layout better than some of the employees probably did."
    "A estas alturas, probablemente conocía la distribución de la tienda mejor que algunos de los empleados."

# game/script day2.rpy:89
translate Spanish kom_day2_80524753:

    # mc "Hmm... milk and a couple of chocolate bars."
    mc "Mmm... leche y un par de barras de chocolate."

# game/script day2.rpy:90
translate Spanish kom_day2_88927b95:

    # mc "Though a soda sounds tempting. Maybe some chips too."
    mc "Aunque una gaseosa suena tentadora. Quizás también unas papas fritas."

# game/script day2.rpy:92
translate Spanish kom_day2_0a229e20:

    # "After a brief internal debate, I made my choices and joined the line at the register."
    "Tras un breve debate interno, elegí lo que iba a comprar y me puse en la fila para pagar."

# game/script day2.rpy:93
translate Spanish kom_day2_33737c61:

    # "The store was busier than usual today. Then again, that wasn't exactly uncommon."
    "La tienda estaba más llena que de costumbre. Aunque, bueno, eso tampoco era raro."

# game/script day2.rpy:94
translate Spanish kom_day2_23284d66:

    # "With nothing else to do while waiting, I casually looked around the store."
    "Sin nada más que hacer mientras esperaba, eché un vistazo a la tienda."

# game/script day2.rpy:113
translate Spanish tothetheater_day2_c0b46a38:

    # "After waiting for a while, it was finally my turn to pay."
    "Después de esperar un rato, por fin me tocó pagar."

# game/script day2.rpy:114
translate Spanish tothetheater_day2_de87c4c9:

    # "I paid for my snacks and headed straight for the theater."
    "Pagué mis snacks y me fui directo al teatro."

# game/script day2.rpy:115
translate Spanish tothetheater_day2_59b3834d:

    # "The theater wasn't exactly far from my apartment, but it wasn't close either."
    "El teatro no quedaba exactamente lejos de mi apartamento, pero tampoco cerca."

# game/script day2.rpy:119
translate Spanish tothetheater_day2_cf38f323:

    # "So, like usual, I took public transportation."
    "Así que, como de costumbre, tomé el transporte público."

# game/script day2.rpy:120
translate Spanish tothetheater_day2_d96e6a51:

    # "...Here I am. Back again."
    "...Aquí estoy. De vuelta otra vez."

# game/script day2.rpy:121
translate Spanish tothetheater_day2_fd6cd951:

    # "I still don't know whether what I saw yesterday was a dream or not."
    "Sigo sin saber si lo que vi ayer fue un sueño o no."

# game/script day2.rpy:122
translate Spanish tothetheater_day2_e5b09b9a:

    # "I can hardly believe that the puppets in this theater are alive."
    "Apenas puedo creer que los títeres de este teatro estén vivos."

# game/script day2.rpy:123
translate Spanish tothetheater_day2_bf15b064:

    # "Well, at least that jester puppet is. Jestyn. He's the only one I saw moving yesterday."
    "Bueno, al menos ese títere bufón está vivo. Jestyn. Es el único que vi moverse ayer."

# game/script day2.rpy:124
translate Spanish tothetheater_day2_410cd31f:

    # "Honestly, it's a miracle I'm still sane."
    "La verdad, es un milagro que todavía conserve la cordura."

# game/script day2.rpy:125
translate Spanish tothetheater_day2_09166910:

    # "Or maybe I'm not."
    "O quizá no."

# game/script day2.rpy:126
translate Spanish tothetheater_day2_65b5e557:

    # "Either way, what happened yesterday felt far too real. At this point, it feels more like I'm the one in denial."
    "Sea como sea, lo que pasó ayer pareció demasiado real. A estas alturas, parece más bien que soy yo quien se niega a aceptar lo ocurrido."

# game/script day2.rpy:127
translate Spanish tothetheater_day2_9082a73e:

    # "Well, at least I'm getting paid."
    "Bueno, al menos me están pagando."

# game/script day2.rpy:128
translate Spanish tothetheater_day2_9a03ba8e:

    # "What isn't worth putting up with in this economy, right?"
    "¿Qué no vale la pena aguantar en esta economía, verdad?"

# game/script day2.rpy:129
translate Spanish tothetheater_day2_af1a019f:

    # "Alright then. Time to start the day."
    "Muy bien. Hora de empezar el día."

# game/script day2.rpy:130
translate Spanish tothetheater_day2_3c22994a:

    # "Here's hoping today is at least a little less insane than yesterday."
    "Ojalá hoy sea al menos un poco menos demencial que ayer."

# game/script day2.rpy:132
translate Spanish tothetheater_day2_c9509e21:

    # "With a nervous feeling twisting in my stomach, I slowly pushed open the theater's massive entrance doors. They looked less like theater doors and more like the gates of a royal castle."
    "Con los nervios revolviéndome el estómago, empujé lentamente las enormes puertas de entrada del teatro. Parecían más las puertas de un castillo real que las de un teatro."

# game/script day2.rpy:135
translate Spanish tothetheater_day2_f8522752:

    # "I stepped inside."
    "Entré."

# game/script day2.rpy:139
translate Spanish tothetheater_day2_9281476b:

    # mc "AAAAAAHHHHHHHHHHH!!!"
    mc "¡¡¡AAAAAAHHHHHHHHHHH!!!"

# game/script day2.rpy:141
translate Spanish tothetheater_day2_3c1d965a:

    # mc "WHAT?!"
    mc "¡¿QUÉ?!"

# game/script day2.rpy:147
translate Spanish tothetheater_day2_27c614db:

    # jes "Seconds passed....then hours... days... weeks... months... years... It has been so very long since all of that faded away."
    jes "Pasaron segundos... luego horas... días... semanas... meses... años... Hace muchísimo tiempo que todo aquello se desvaneció."

# game/script day2.rpy:148
translate Spanish tothetheater_day2_288021fa:

    # jes "They came and went, one after another... yet the cold of the night never once wavered."
    jes "Llegaron y se fueron, uno tras otro... y aun así el frío de la noche nunca cedió."

# game/script day2.rpy:149
translate Spanish tothetheater_day2_11a15cdc:

    # jes "Just when we believed the last glimmer of light had been swallowed by the merciless dark... there appeared a tiny spark."
    jes "Justo cuando creíamos que el último destello de luz había sido tragado por la oscuridad despiadada... apareció una pequeña chispa."

# game/script day2.rpy:153
translate Spanish tothetheater_day2_d6940a74:

    # "With every step as graceful as a dancer's, Jestyn drew closer, continuing his tale as though he were narrating a fairy tale."
    "Con pasos tan elegantes como los de un bailarín, Jestyn se acercó mientras continuaba su relato, como si estuviera narrando un cuento de hadas."

# game/script day2.rpy:158
translate Spanish tothetheater_day2_a0900412:

    # jes "Lost amidst the shadows, wandering without purpose... and yet- oh, how bright and adorable it was."
    jes "Perdido entre las sombras, vagando sin rumbo... y sin embargo, ay, qué brillante y adorable era."

# game/script day2.rpy:159
translate Spanish tothetheater_day2_d9fca2f1:

    # jes "With the expression of a bewildered fool, it gazed upon gazing upon the most handsome, enchanting, and utterly marvelous jester in all the realm."
    jes "Con la expresión de un necio desconcertado, se quedó contemplando al bufón más apuesto, encantador y absolutamente maravilloso de todo el reino."

# game/script day2.rpy:160
translate Spanish tothetheater_day2_0a0b62d1:

    # mc ".........."
    mc ".........."

# game/script day2.rpy:161
translate Spanish tothetheater_day2_17015124:

    # mc "Are you done, Jestyn?"
    mc "¿Ya terminaste, Jestyn?"

# game/script day2.rpy:165
translate Spanish tothetheater_day2_d269c16b:

    # jes "Beautiful, magnificent, sexy, irresistible, breathtaking-"
    jes "Hermos[letra], magnífic[letra], sexy, irresistible, deslumbrante-"

# game/script day2.rpy:166
translate Spanish tothetheater_day2_ce719769:

    # mc "You seriously can't stop talking about yourself for one second, can you?"
    mc "De verdad no puedes dejar de hablar de ti mismo ni por un segundo, ¿cierto?"

# game/script day2.rpy:170
translate Spanish tothetheater_day2_47040b98:

    # "A faint blush spread across Jestyn's cheeks as he giggled and lightly bit the tip of his finger."
    "Un leve rubor cubrió las mejillas de Jestyn mientras soltaba una risita y se mordía suavemente la punta del dedo."

# game/script day2.rpy:172
translate Spanish tothetheater_day2_b8f81d59:

    # jes "Then be the one to silence me."
    jes "Entonces sé tú quien me haga callar."

# game/script day2.rpy:186
translate Spanish timetowork_day2_c4550509:

    # "He took a step back, giving me some space."
    "Dio un paso atrás, dándome algo de espacio."

# game/script day2.rpy:191
translate Spanish timetowork_day2_f6d0f824:

    # voice "JESTYN01_DAY2.ogg"
    # jes "Ah! My sincerest apologies for my rudeness, Your Majesty."
    voice "JESTYN01_DAY2.ogg"
    jes "¡Ah! Mis más sinceras disculpas por mi grosería, Su Majestad."

# game/script day2.rpy:194
translate Spanish timetowork_day2_4d37e24a:

    # voice "JESTYN01_2_DAY2.ogg"
    # jes "I was simply... very, very, very, very, veeeeeery happy to see you again."
    voice "JESTYN01_2_DAY2.ogg"
    jes "Es que estaba... muy, muy, muy, muy, muuuuuuy feliz de volver a verle."

# game/script day2.rpy:196
translate Spanish timetowork_day2_b6faf766:

    # mc "But we only stopped talking for a few hours..."
    mc "Pero solo dejamos de hablar unas pocas horas..."

# game/script day2.rpy:200
translate Spanish timetowork_day2_18af1d8e:

    # jes "That is precisely the issue!"
    jes "¡Ese es precisamente el problema!"

# game/script day2.rpy:201
translate Spanish timetowork_day2_7fe11467:

    # jes "A few hours is an eternity when one is deprived of Your Majesty's company!"
    jes "¡Unas pocas horas son una eternidad cuando uno se ve privado de la compañía de Su Majestad!"

# game/script day2.rpy:202
translate Spanish timetowork_day2_d0d0abbc:

    # jes "Why, I was this close to marching straight to your home just to see you again!"
    jes "¡Vaya, estuve a punto de marchar directo a su casa solo para verle otra vez!"

# game/script day2.rpy:204
translate Spanish timetowork_day2_b7fb6515:

    # "He spoke with such confidence that it almost sounded like he actually knew where I lived."
    "Habló con tanta confianza que casi sonaba como si de verdad supiera dónde vivía."

# game/script day2.rpy:207
translate Spanish timetowork_day2_970a721f:

    # jes "But oh! Fate has reunited us at last! And now we may resume our delightful conversations~"
    jes "¡Pero ah! ¡El destino nos ha reunido por fin! Y ahora podemos retomar nuestras deliciosas conversaciones~"

# game/script day2.rpy:210
translate Spanish timetowork_day2_1502085c:

    # jes "Now then, Your Majesty~"
    jes "Y ahora bien, Su Majestad~"

# game/script day2.rpy:211
translate Spanish timetowork_day2_871b88b7:

    # jes "How shall you spend your second day ruling this kingdom?"
    jes "¿Cómo pasará su segundo día gobernando este reino?"

# game/script day2.rpy:213
translate Spanish timetowork_day2_687f78fc:

    # "How was I going to spend today...?"
    "¿Cómo iba a pasar hoy...?"

# game/script day2.rpy:215
translate Spanish timetowork_day2_2f2831e2:

    # mc "Well, I guess I'll just do my job like usual..."
    mc "Bueno, supongo que simplemente haré mi trabajo como siempre..."

# game/script day2.rpy:218
translate Spanish timetowork_day2_86588996:

    # jes "OH! Sweet tarts and cream! Your Majesty! You've forgotten something!"
    jes "¡OH! ¡Por todas las tartaletas y la nata! ¡Su Majestad! ¡Ha olvidado algo!"

# game/script day2.rpy:219
translate Spanish timetowork_day2_ecf9927a:

    # mc "Huh??? What?"
    mc "¿¿¿Eh??? ¿Qué?"

# game/script day2.rpy:222
translate Spanish timetowork_day2_b6e2c63c:

    # "Jestyn snapped his fingers, and in an instant, a crown appeared in his hand."
    "Jestyn chasqueó los dedos y, en un instante, una corona apareció en su mano."

# game/script day2.rpy:223
translate Spanish timetowork_day2_9b404e4e:

    # "The crown from yesterday..."
    "La corona de ayer..."

# game/script day2.rpy:224
translate Spanish timetowork_day2_806a7f52:

    # "Jestyn gently placed the crown atop my head."
    "Jestyn colocó con delicadeza la corona sobre mi cabeza."

# game/script day2.rpy:227
translate Spanish timetowork_day2_a156b903:

    # jes "Ah... Much better..."
    jes "Ah... Mucho mejor..."

# game/script day2.rpy:230
translate Spanish timetowork_day2_90352680:

    # jes "HUZZAAAHHH!!! All hail [poss] Majesty!"
    jes "¡¡¡VIVAAAAAA!!! ¡Salve a Su Majestad!"

# game/script day2.rpy:233
translate Spanish timetowork_day2_e1f17ae0:

    # "Jestyn erupted into cheers in unison, while I was still trying to process everything that had just happened."
    "Jestyn estalló en vítores al unísono, mientras yo seguía intentando procesar todo lo que acababa de pasar."

# game/script day2.rpy:234
translate Spanish timetowork_day2_dfb3e820:

    # "Once Jestyn had finished making a spectacle of how much he'd missed me, he began shooing the other puppets back to their rooms."
    "Una vez que Jestyn terminó de hacer todo un espectáculo de lo mucho que me había extrañado, empezó a mandar a los otros títeres de vuelta a sus habitaciones."

# game/script day2.rpy:237
translate Spanish timetowork_day2_9ac83b38:

    # "I quickly made my way to my office to drop off my bag before getting to work."
    "Me apresuré a mi oficina para dejar mi bolso antes de ponerme a trabajar."

# game/script day2.rpy:238
translate Spanish timetowork_day2_a40a55e2:

    # "And, of course, Jestyn followed right behind me."
    "Y, por supuesto, Jestyn me siguió pisándome los talones."

# game/script day2.rpy:239
translate Spanish timetowork_day2_9ef4f12b:

    # "Even with him walking behind me, I could feel his intense gaze fixed on my back."
    "Aunque caminaba detrás de mí, podía sentir su intensa mirada clavada en mi espalda."

# game/script day2.rpy:240
translate Spanish timetowork_day2_c3601ae7:

    # "Ok, now first things first, cleaning the theater. Since I already took care of the stage yesterday, I think I'll clean the corridor today."
    "Bien, primero lo primero: limpiar el teatro. Como ayer ya me encargué del escenario, creo que hoy limpiaré el pasillo."

# game/script day2.rpy:243
translate Spanish timetowork_day2_7917774b:

    # "I headed into the storage room to grab the cleaning supplies."
    "Entré al almacén a buscar los artículos de limpieza."

# game/script day2.rpy:246
translate Spanish timetowork_day2_5b9d646c:

    # "Ah... broom... bucket... mop..."
    "Ah... escoba... balde... trapeador..."

# game/script day2.rpy:247
translate Spanish timetowork_day2_d558ef9b:

    # "...Huh?"
    "...¿Eh?"

# game/script day2.rpy:248
translate Spanish timetowork_day2_ccdbf73b:

    # "Where are they?"
    "¿Dónde están?"

# game/script day2.rpy:249
translate Spanish timetowork_day2_03df3296:

    # "Where did all my cleaning supplies go?"
    "¿Adónde fueron a parar todos mis artículos de limpieza?"

# game/script day2.rpy:250
translate Spanish timetowork_day2_3173e0ca:

    # "I put everything back where it belonged yesterday, didn't I?"
    "Ayer lo puse todo de vuelta en su lugar, ¿no?"

# game/script day2.rpy:251
translate Spanish timetowork_day2_59460ee5:

    # "Or did I for- OOF-!"
    "¿O me olvi- ¡UF-!"

# game/script day2.rpy:252
translate Spanish timetowork_day2_1e33ba21:

    # "I spun around and immediately walked face first into Jestyn's chest."
    "Me giré de golpe y choqué de cara contra el pecho de Jestyn."

# game/script day2.rpy:253
translate Spanish timetowork_day2_da13c0f7:

    # "This puppet had been following me the entire time?!"
    "¡¿Este títere me había estado siguiendo todo el tiempo?!"

# game/script day2.rpy:255
translate Spanish timetowork_day2_cd816593:

    # mc "Ugh, Jestyn... why are you still following me?"
    mc "Ugh, Jestyn... ¿por qué sigues siguiéndome?"

# game/script day2.rpy:258
translate Spanish timetowork_day2_27b4917e:

    # jes "Your Majesty, you wound me."
    jes "Su Majestad, me hiere."

# game/script day2.rpy:259
translate Spanish timetowork_day2_8008c67c:

    # jes "Did you truly expect me to abandon you for something as trivial as a trip to the storage room?"
    jes "¿De veras pensó que abandonaría a Su Majestad por algo tan trivial como una visita al almacén?"

# game/script day2.rpy:260
translate Spanish timetowork_day2_eb84a1a1:

    # mc "...Yes?"
    mc "...¿Sí?"

# game/script day2.rpy:263
translate Spanish timetowork_day2_0d459d86:

    # jes "Perish the thought."
    jes "Ni lo piense."

# game/script day2.rpy:264
translate Spanish timetowork_day2_32020c65:

    # jes "I shall follow you wherever you go."
    jes "Iré tras usted adondequiera que vaya."

# game/script day2.rpy:267
translate Spanish timetowork_day2_e139533a:

    # jes "Without."
    jes "Sin."

# game/script day2.rpy:269
translate Spanish timetowork_day2_e9cfc0ff:

    # jes "A."
    jes "Una."

# game/script day2.rpy:271
translate Spanish timetowork_day2_8b048bb3:

    # jes "Single."
    jes "Sola."

# game/script day2.rpy:273
translate Spanish timetowork_day2_a4d654da:

    # jes "Exception, darling~"
    jes "Excepción, cariño~"

# game/script day2.rpy:274
translate Spanish timetowork_day2_124c7c45:

    # mc "Okay, I'm just looking for some cleaning supplies and then I'll head back-"
    mc "Está bien, solo estoy buscando unos artículos de limpieza y luego volveré-"

# game/script day2.rpy:277
translate Spanish timetowork_day2_4da1476b:

    # "Suddenly, Jestyn appeared behind me and placed his hands on my shoulders."
    "De repente, Jestyn apareció detrás de mí y puso las manos sobre mis hombros."

# game/script day2.rpy:282
translate Spanish timetowork_day2_35e3f154:

    # "The abrupt movement nearly made me jump."
    "El movimiento brusco casi me hizo saltar."

# game/script day2.rpy:285
translate Spanish timetowork_day2_1e521083:

    # jes "Tsk, tsk, tsk~"
    jes "Tsk, tsk, tsk~"

# game/script day2.rpy:286
translate Spanish timetowork_day2_8153b1cb:

    # jes "Hark! It seems you've forgotten something, Your Majesty."
    jes "¡Escuche! Parece que ha olvidado algo, Su Majestad."

# game/script day2.rpy:287
translate Spanish timetowork_day2_f6529ddc:

    # jes "You said you were going to clean the kingdom, yes?"
    jes "Dijo que iba a limpiar el reino, ¿sí?"

# game/script day2.rpy:291
translate Spanish timetowork_day2_de25d4b4:

    # jes "Pfft...This is the first time I've ever heard of a ruler so willingly setting aside their royal status to do the work of their own servants."
    jes "Pfft... Es la primera vez que oigo de un gobernante que deja de lado voluntariamente su estatus real para hacer el trabajo de sus propios sirvientes."

# game/script day2.rpy:293
translate Spanish timetowork_day2_90d60d89:

    # "I had forgotten that Jestyn viewed me as the [title] of this place."
    "Había olvidado que Jestyn me veía como [arti] [title!t] de este lugar."

# game/script day2.rpy:294
translate Spanish timetowork_day2_7d1eb36d:

    # "But my position as a security guard was a lot more important right now."
    "Pero mi puesto como guardia de seguridad era mucho más importante en este momento."

# game/script day2.rpy:295
translate Spanish timetowork_day2_b73fafb8:

    # "If I didn't do my job, I wouldn't get paid."
    "Si no hacía mi trabajo, no me pagarían."

# game/script day2.rpy:296
translate Spanish timetowork_day2_f8b03f5a:

    # "Or worse, I'd get fired."
    "O peor, me despedirían."

# game/script day2.rpy:297
translate Spanish timetowork_day2_1d217c43:

    # "And I happened to be quite fond of having money to stay alive."
    "Y resulta que me gusta bastante tener dinero para seguir con vida."

# game/script day2.rpy:299
translate Spanish timetowork_day2_112ce5d8:

    # mc "What's wrong with that? Did you forget that I'm not just your [title] here?"
    mc "¿Qué tiene de malo? ¿Olvidaste que aquí no soy solo tu [title!t]?"

# game/script day2.rpy:300
translate Spanish timetowork_day2_6c8706ec:

    # jes "Ah, certainly not~"
    jes "Ah, claro que no~"

# game/script day2.rpy:301
translate Spanish timetowork_day2_46ee3f8d:

    # jes "I am fully aware that Your Majesty has all manner of human responsibilities to tend to."
    jes "Soy plenamente consciente de que Su Majestad tiene todo tipo de responsabilidades humanas que atender."

# game/script day2.rpy:304
translate Spanish timetowork_day2_f1089190:

    # jes "Mundane little things such as employment, income, and the tragic necessity of remaining alive."
    jes "Minucias mundanas como el empleo, los ingresos y la trágica necesidad de seguir con vida."

# game/script day2.rpy:305
translate Spanish timetowork_day2_7b173e56:

    # jes "On the contrary, Your Majesty."
    jes "Al contrario, Su Majestad."

# game/script day2.rpy:306
translate Spanish timetowork_day2_a65e59a2:

    # jes "Why should a [title] waste their precious energy scrubbing floors when they have loyal maids at their disposal?"
    jes "¿Por qué habría [arti_2] [title!t] de malgastar su preciosa energía fregando suelos teniendo leales doncellas a su disposición?"

# game/script day2.rpy:307
translate Spanish timetowork_day2_05500ff6:

    # mc "Huh?"
    mc "¿Eh?"

# game/script day2.rpy:310
translate Spanish timetowork_day2_4d55d3ac:

    # "With a flourish, Jestyn snapped his fingers."
    "Con un ademán teatral, Jestyn chasqueó los dedos."

# game/script day2.rpy:313
translate Spanish timetowork_day2_9f2eda0f:

    # jes "Ladies~!"
    jes "¡Señoritas~!"

# game/script day2.rpy:321
translate Spanish timetowork_day2_1abfbad4:

    # maid "YES, JESTYN!"
    maid "¡SÍ, JESTYN!"

# game/script day2.rpy:324
translate Spanish timetowork_day2_733462b1:

    # "I startled as three maid puppets appeared seemingly out of nowhere."
    "Me sobresalté cuando tres títeres doncellas aparecieron de la nada."

# game/script day2.rpy:326
translate Spanish timetowork_day2_25cbc61d:

    # jes "May I present the esteemed Maid Sisters. Maidelyn, Maidy, and Maidra!"
    jes "Permítame presentarle a las distinguidas Hermanas Doncellas. ¡Maidelyn, Maidy y Maidra!"

# game/script day2.rpy:327
translate Spanish timetowork_day2_cebf8aae:

    # jes "My ladies, this is our beloved new [title], [player_call]."
    jes "Mis damas, les presento a nuestr[letra] querid[letra] nuev[letra] [title!t], [player_call]."

# game/script day2.rpy:329
translate Spanish timetowork_day2_a8464f86:

    # "The three maids gracefully bowed their heads after the introduction."
    "Las tres doncellas inclinaron la cabeza con elegancia tras la presentación."

# game/script day2.rpy:333
translate Spanish timetowork_day2_ae92f50e:

    # maidy "OH! It's truly an honor to meet you, Your Majesty [player_call]! I'm Maidy!!"
    maidy "¡OH! ¡Es un verdadero honor conocerle, Su Majestad [player_call]! ¡¡Soy Maidy!!"

# game/script day2.rpy:334
translate Spanish timetowork_day2_a26d078f:

    # maidy "Jestyn told us a little bit about you, and now I finally get to meet you in person!"
    maidy "¡Jestyn nos contó un poquito sobre usted, y ahora por fin puedo conocerle en persona!"

# game/script day2.rpy:336
translate Spanish timetowork_day2_88a4ffe3:

    # maidy "...To be honest..."
    maidy "...Para ser sincera..."

# game/script day2.rpy:337
translate Spanish timetowork_day2_7bb2c87e:

    # maidy "I was expecting you to be cute."
    maidy "Esperaba que fuera lind[letra]."

# game/script day2.rpy:339
translate Spanish timetowork_day2_d14df933:

    # "The sudden change in her tone made me nervous."
    "El repentino cambio en su tono me puso nervios[letra]."

# game/script day2.rpy:341
translate Spanish timetowork_day2_d7febe0b:

    # mc "Um... sorry for disappointing you..."
    mc "Eh... perdón por decepcionarte..."

# game/script day2.rpy:344
translate Spanish timetowork_day2_9f3df4be:

    # maidy "YES! YOU'RE NOT CUTE!"
    maidy "¡SÍ! ¡NO ES LIND[letra]!"

# game/script day2.rpy:347
translate Spanish timetowork_day2_f3fd6a24:

    # maidy "YOU'RE SUPER-DUPER CUUUUUUTEEEEEE!!!"
    maidy "¡ES SÚPER-HIPER LIIIIIINDD[letra]!!!"

# game/script day2.rpy:350
translate Spanish timetowork_day2_a4aaba30:

    # "Okay, at least I managed to exceed her expectations. I think."
    "Bien, al menos logré superar sus expectativas. Creo."

# game/script day2.rpy:352
translate Spanish timetowork_day2_768a5e19:

    # maidy "Maidelyn! [poss] majesty is super-duper cute, right?! You agree with me, don't you?!?!"
    maidy "¡Maidelyn! ¿¡Verdad que Su Majestad es súper-hiper lind[letra]?! ¿¡Estás de acuerdo conmigo, cierto?!?!"

# game/script day2.rpy:354
translate Spanish timetowork_day2_c4ece1d2:

    # maidelyn "Indeed. I do."
    maidelyn "En efecto. Estoy de acuerdo."

# game/script day2.rpy:355
translate Spanish timetowork_day2_1e783c65:

    # maidy "What about you, Maidra?! [poss] majesty is super-duper cute too, riiiiight?!?!?!"
    maidy "¡¿Y tú, Maidra?! ¿¡Su Majestad también es súper-hiper lind[letra], verdaaaad?!?!?!"

# game/script day2.rpy:357
translate Spanish timetowork_day2_971ef235:

    # maidra "Tsk. You're so loud. Shut up already."
    maidra "Tsk. Qué ruidosa eres. Cállate ya."

# game/script day2.rpy:359
translate Spanish timetowork_day2_249cac2b:

    # maidy "Hmph! You're no fun!!"
    maidy "¡Hmph! ¡Qué aburrida!!"

# game/script day2.rpy:361
translate Spanish timetowork_day2_cacf3109:

    # maidelyn "Ladies, that is quite enough."
    maidelyn "Señoritas, ya es suficiente."

# game/script day2.rpy:362
translate Spanish timetowork_day2_4b1c92f8:

    # maidelyn "[poss] Majesty is before us. Kindly conduct yourselves with a measure of dignity."
    maidelyn "Su Majestad está ante nosotras. Compórtense con un poco de dignidad, por favor."

# game/script day2.rpy:364
translate Spanish timetowork_day2_18875c39:

    # "The reminder immediately brought the other two maids to attention."
    "El recordatorio puso de inmediato firmes a las otras dos doncellas."

# game/script day2.rpy:369
translate Spanish timetowork_day2_2842e585:

    # maidelyn "My deepest apologies for our discourtesy, Your Majesty."
    maidelyn "Mis más profundas disculpas por nuestra descortesía, Su Majestad."

# game/script day2.rpy:371
translate Spanish timetowork_day2_187bf078:

    # "Maidelyn placed a hand over her heart and bowed her head respectfully."
    "Maidelyn se llevó una mano al corazón e inclinó la cabeza con respeto."

# game/script day2.rpy:373
translate Spanish timetowork_day2_806fe121:

    # maidelyn "Please allow us to introduce ourselves. I am Maidelyn."
    maidelyn "Permítanos presentarnos. Soy Maidelyn."

# game/script day2.rpy:375
translate Spanish timetowork_day2_71b041fd:

    # maidy "I'm Maidyyyyy~!"
    maidy "¡Soy Maidyyyyy~!"

# game/script day2.rpy:378
translate Spanish timetowork_day2_f3aec99a:

    # maidra "Maidra."
    maidra "Maidra."

# game/script day2.rpy:380
translate Spanish timetowork_day2_3d6d5b6b:

    # "Well, that told me quite a bit already."
    "Bueno, eso ya me dijo bastante."

# game/script day2.rpy:381
translate Spanish timetowork_day2_c1ca456f:

    # "Maidelyn seemed to be the composed one."
    "Maidelyn parecía ser la serena."

# game/script day2.rpy:382
translate Spanish timetowork_day2_2494c1c7:

    # "Maidy was definitely the bubbly, energetic one."
    "Maidy definitivamente era la alegre y enérgica."

# game/script day2.rpy:383
translate Spanish timetowork_day2_9a3e93d5:

    # "And Maidra..."
    "Y Maidra..."

# game/script day2.rpy:384
translate Spanish timetowork_day2_f1817ca2:

    # "Let's just say she looked like she'd rather punch someone than have a polite conversation."
    "Digamos que parecía preferir golpear a alguien antes que tener una conversación cortés."

# game/script day2.rpy:385
translate Spanish timetowork_day2_c23e3f72:

    # "Definitely the tomboy of the group."
    "Sin duda, la marimacho del grupo."

# game/script day2.rpy:387
translate Spanish timetowork_day2_920bf978:

    # maidelyn "As you can see, Your Majesty, now that you are our [title], that makes us your maids."
    maidelyn "Como puede ver, Su Majestad, ahora que es nuestr[letra] [title!t], eso nos convierte en sus doncellas."

# game/script day2.rpy:389
translate Spanish timetowork_day2_ae2d0334:

    # maidy "Yeah!"
    maidy "¡Sí!"

# game/script day2.rpy:391
translate Spanish timetowork_day2_e6430860:

    # maidelyn "In other words, there is no need for you to clean the kingdom yourself."
    maidelyn "En otras palabras, no hace falta que limpie el reino usted mism[letra]."

# game/script day2.rpy:392
translate Spanish timetowork_day2_10436462:

    # maidelyn "Please allow us to take over your human duties."
    maidelyn "Permítanos encargarnos de sus deberes humanos."

# game/script day2.rpy:395
translate Spanish timetowork_day2_2aa4ca3b:

    # maidy "YEAH!!"
    maidy "¡¡SÍÍÍ!!"

# game/script day2.rpy:400
translate Spanish timetowork_day2_fa9f3633:

    # maidelyn "Shush!"
    maidelyn "¡Shhh!"

# game/script day2.rpy:403
translate Spanish timetowork_day2_2d716725:

    # "I stared blankly at them for a moment."
    "Me quedé mirándolas en blanco un momento."

# game/script day2.rpy:404
translate Spanish timetowork_day2_67aaa788:

    # "What?"
    "¿Qué?"

# game/script day2.rpy:405
translate Spanish timetowork_day2_219f97bc:

    # "They were going to clean the theater for me?"
    "¿Iban a limpiar el teatro por mí?"

# game/script day2.rpy:411
translate Spanish timetowork_day2_16429228:

    # jes "That is correct, Your Majesty."
    jes "Así es, Su Majestad."

# game/script day2.rpy:413
translate Spanish timetowork_day2_1403b2e5:

    # jes "Now then, ladies, please assist our beloved [title]."
    jes "Ahora bien, señoritas, ayuden a nuestr[letra] querid[letra] [title!t]."

# game/script day2.rpy:417
translate Spanish timetowork_day2_4e23874b:

    # "Without a second thought, the maids pulled out the very cleaning supplies I'd been searching for and immediately got to work."
    "Sin pensarlo dos veces, las doncellas sacaron precisamente los artículos de limpieza que yo había estado buscando y se pusieron manos a la obra de inmediato."

# game/script day2.rpy:418
translate Spanish timetowork_day2_a20cefa7:

    # "..."
    "..."

# game/script day2.rpy:419
translate Spanish timetowork_day2_2ff26e3d:

    # "Had they planned this from the beginning?"
    "¿Lo habían planeado desde el principio?"

# game/script day2.rpy:420
translate Spanish timetowork_day2_d924392a:

    # "They knew I was going to clean the theater today..."
    "Sabían que hoy iba a limpiar el teatro..."

# game/script day2.rpy:421
translate Spanish timetowork_day2_cca4b0c0:

    # "Jestyn's attention returned to me."
    "La atención de Jestyn volvió a mí."

# game/script day2.rpy:424
translate Spanish timetowork_day2_54c2cf9c:

    # jes "Now then, I believe one of your other duties is checking on the puppets, is it not?"
    jes "Ahora bien, creo que otro de sus deberes es revisar a los títeres, ¿no es así?"

# game/script day2.rpy:425
translate Spanish timetowork_day2_0f82aebb:

    # mc "Oh... right."
    mc "Oh... cierto."

# game/script day2.rpy:426
translate Spanish timetowork_day2_319991ef:

    # jes "In that case, why not use this opportunity to become acquainted with your subjects?"
    jes "En ese caso, ¿por qué no aprovechar la ocasión para conocer a sus súbditos?"

# game/script day2.rpy:427
translate Spanish timetowork_day2_5e523656:

    # jes "As a [title], you should at least get to know the citizens of your kingdom, shouldn't you?"
    jes "Como [title!t], al menos debería conocer a los ciudadanos de su reino, ¿no le parece?"

# game/script day2.rpy:429
translate Spanish timetowork_day2_c21e9ef4:

    # "He gently guided my attention toward the maids working nearby. It was obvious what he wanted me to do."
    "Con delicadeza dirigió mi atención hacia las doncellas que trabajaban cerca. Era obvio lo que quería que hiciera."

# game/script day2.rpy:432
translate Spanish timetowork_day2_4fd156e0:

    # jes "Give it a try."
    jes "Inténtelo."

# game/script day2.rpy:434
translate Spanish timetowork_day2_333b743a:

    # jes "I'll be right behind you."
    jes "Estaré justo detrás de usted."

# game/script day2.rpy:452
translate Spanish otherpuppet_day2_947e980f:

    # "After talking with the maids, Jestyn guided me toward the puppet room."
    "Tras hablar con las doncellas, Jestyn me guio hacia la sala de los títeres."

# game/script day2.rpy:455
translate Spanish otherpuppet_day2_d3642f27:

    # jes "Now that You've met the maids, allow me to introduce you to some of the other puppets."
    jes "Ahora que ha conocido a las doncellas, permítame presentarle a algunos de los otros títeres."

# game/script day2.rpy:456
translate Spanish otherpuppet_day2_09b5cdbb:

    # mc "Do I really have to get acquainted with every single puppet?"
    mc "¿De verdad tengo que conocer a todos y cada uno de los títeres?"

# game/script day2.rpy:457
translate Spanish otherpuppet_day2_4e7bbafc:

    # jes "Why, yes. Of course."
    jes "Pues sí. Por supuesto."

# game/script day2.rpy:458
translate Spanish otherpuppet_day2_30d985cc:

    # jes "As I've said before, it's important for a ruler to know their subjects."
    jes "Como ya le he dicho, es importante que un gobernante conozca a sus súbditos."

# game/script day2.rpy:461
translate Spanish otherpuppet_day2_9c8aea11:

    # "He paused for a moment. His gaze dropped to the floor before he continued."
    "Hizo una pausa. Su mirada cayó al suelo antes de continuar."

# game/script day2.rpy:464
translate Spanish otherpuppet_day2_49a9e55a:

    # jes "Though, naturally, I understand. There are quite a lot of puppets in this kingdom."
    jes "Aunque, naturalmente, lo entiendo. Hay muchísimos títeres en este reino."

# game/script day2.rpy:465
translate Spanish otherpuppet_day2_ad9c889f:

    # jes "So if Your Majesty only manages to get acquainted with five of them, I suppose that would be acceptable."
    jes "Así que si Su Majestad solo logra conocer a cinco de ellos, supongo que sería aceptable."

# game/script day2.rpy:467
translate Spanish otherpuppet_day2_c7de8174:

    # "Five?"
    "¿Cinco?"

# game/script day2.rpy:468
translate Spanish otherpuppet_day2_6cf0b78f:

    # "I'd expected him to tell me to meet at least half of the puppets. Five sounded surprisingly manageable."
    "Esperaba que me dijera que conociera al menos a la mitad de los títeres. Cinco sonaba sorprendentemente manejable."

# game/script day2.rpy:472
translate Spanish otherpuppet_day2_8422619c:

    # "We entered the puppet quarters, and everything looked exactly the same as it had the last time I was here."
    "Entramos a los aposentos de los títeres y todo se veía exactamente igual que la última vez que estuve aquí."

# game/script day2.rpy:475
translate Spanish otherpuppet_day2_8a5dd54e:

    # mc "When I checked yesterday, none of the puppets seemed to move at all."
    mc "Cuando revisé ayer, ninguno de los títeres parecía moverse en absoluto."

# game/script day2.rpy:476
translate Spanish otherpuppet_day2_ece93b06:

    # mc "Were they asleep or something?"
    mc "¿Estaban dormidos o algo así?"

# game/script day2.rpy:479
translate Spanish otherpuppet_day2_08a4e452:

    # jes "Ah, that was by my command."
    jes "Ah, eso fue por orden mía."

# game/script day2.rpy:480
translate Spanish otherpuppet_day2_b0a1059a:

    # mc "Why?!"
    mc "¡¿Por qué?!"

# game/script day2.rpy:483
translate Spanish otherpuppet_day2_0b14cc1f:

    # jes "Hehe, because you had come to the kingdom."
    jes "Jeje, porque usted había llegado al reino."

# game/script day2.rpy:484
translate Spanish otherpuppet_day2_08ab0dfb:

    # jes "I wanted to test you. And I didn't want you to see the puppets moving before I began the performance."
    jes "Quería ponerle a prueba. Y no quería que viera a los títeres moverse antes de que yo comenzara la función."

# game/script day2.rpy:485
translate Spanish otherpuppet_day2_7544706e:

    # jes "But now they're free to move about as they please."
    jes "Pero ahora son libres de moverse a su antojo."

# game/script day2.rpy:486
translate Spanish otherpuppet_day2_70cabc9f:

    # mc "Mmm... but I still haven't seen any puppets wandering around. Besides you and the maids, that is."
    mc "Mmm... pero todavía no he visto a ningún títere deambulando. Aparte de ti y de las doncellas, claro."

# game/script day2.rpy:487
translate Spanish otherpuppet_day2_1f5ffcc8:

    # mc "And the maids only showed up because you called them."
    mc "Y las doncellas solo aparecieron porque tú las llamaste."

# game/script day2.rpy:489
translate Spanish otherpuppet_day2_ad19dff1:

    # "He chuckled."
    "Soltó una risita."

# game/script day2.rpy:492
translate Spanish otherpuppet_day2_1e87e9ad:

    # jes "Most of us puppets spend our time in our rooms."
    jes "La mayoría de los títeres pasamos el tiempo en nuestras habitaciones."

# game/script day2.rpy:493
translate Spanish otherpuppet_day2_c0f6de6b:

    # jes "So if you haven't seen anyone wandering about, it's simply because they're all occupied with their own affairs."
    jes "Así que si no ha visto a nadie deambulando, es simplemente porque todos están ocupados con sus propios asuntos."

# game/script day2.rpy:496
translate Spanish otherpuppet_day2_65279b3d:

    # "Jestyn stepped in front of me."
    "Jestyn se puso frente a mí."

# game/script day2.rpy:497
translate Spanish otherpuppet_day2_f5e66e24:

    # "Then he spread his arms wide, each hand gesturing toward a different hallway lined with puppet rooms."
    "Luego extendió los brazos, cada mano señalando un pasillo distinto lleno de cuartos de títeres."

# game/script day2.rpy:500
translate Spanish otherpuppet_day2_04266081:

    # jes "Now then, let us become acquainted with a few more residents of the kingdom."
    jes "Ahora bien, conozcamos a algunos habitantes más del reino."

# game/script day2.rpy:501
translate Spanish otherpuppet_day2_46d9991d:

    # jes "I would recommend meeting Knighter and Wizzy."
    jes "Le recomendaría conocer a Knighter y a Wizzy."

# game/script day2.rpy:502
translate Spanish otherpuppet_day2_a4eb76c7:

    # jes "Wizzy is our wizard puppet. He's gentle and kind."
    jes "Wizzy es nuestro títere mago. Es bondadoso y amable."

# game/script day2.rpy:505
translate Spanish otherpuppet_day2_23d5793c:

    # jes "And Knighter is our knight puppet. He's rather hot headed.....but perfectly safe, I assure you."
    jes "Y Knighter es nuestro títere caballero. Es bastante impulsivo... pero no representa ningún peligro, se lo aseguro."

# game/script day2.rpy:507
translate Spanish otherpuppet_day2_1dc28099:

    # "That did not reassure me at all."
    "Eso no me tranquilizó ni un poco."

# game/script day2.rpy:510
translate Spanish otherpuppet_day2_280dec07:

    # jes "Now then, Your Majesty. Who would you like to meet first?"
    jes "Ahora bien, Su Majestad. ¿A quién le gustaría conocer primero?"

# game/script day2.rpy:559
translate Spanish repeat_route_2c6b2c91:

    # mc "So... who am I meeting next?"
    mc "Entonces... ¿a quién conoceré ahora?"

# game/script day2.rpy:562
translate Spanish repeat_route_5a409a74:

    # "Jestyn fell silent, his gaze drifting toward the puppet rooms I hadn't visited yet."
    "Jestyn guardó silencio y dirigió la mirada hacia las habitaciones de los títeres que aún no había visitado."

# game/script day2.rpy:563
translate Spanish repeat_route_172ba7e9:

    # "He narrowed his eyes in thought before looking back at me."
    "Entrecerró los ojos, pensativo, antes de volver a mirarme."

# game/script day2.rpy:566
translate Spanish repeat_route_7524d268:

    # jes "I think that's enough for today, Your Majesty."
    jes "Creo que ya es suficiente por hoy, Su Majestad."

# game/script day2.rpy:567
translate Spanish repeat_route_3e5f4191:

    # mc "What? Really?? We've only met the maids, Wizzy, Knighter-"
    mc "¿Qué? ¿En serio?? Solo hemos conocido a las doncellas, a Wizzy, a Knighter-"

# game/script day2.rpy:568
translate Spanish repeat_route_b59a0715:

    # jes "And that's more than enough."
    jes "Y eso es más que suficiente."

# game/script day2.rpy:573
translate Spanish repeat_route_538b37a3:

    # "Jestyn cut me off by snapping his fingers."
    "Jestyn me interrumpió chasqueando los dedos."

# game/script day2.rpy:575
translate Spanish repeat_route_5fe51c52:

    # "And in an instant I was back in my office, with Jestyn following behind me."
    "Y en un instante estaba de vuelta en mi oficina, con Jestyn siguiéndome detrás."

# game/script day2.rpy:578
translate Spanish repeat_route_10b8f5d3:

    # jes "Are you hungry, Your Majesty? You haven't eaten a single thing since this morning."
    jes "¿Tiene hambre, Su Majestad? No ha comido nada desde la mañana."

# game/script day2.rpy:580
translate Spanish repeat_route_717b8501:

    # "Before I could answer, my stomach beat me to it."
    "Antes de que pudiera responder, mi estómago se me adelantó."

# game/script day2.rpy:583
translate Spanish repeat_route_0bd2f542:

    # jes "Pfft..."
    jes "Pfft..."

# game/script day2.rpy:584
translate Spanish repeat_route_2213dfc1:

    # jes "No need to be embarrassed, Your Majesty. I know just how tragically broke you are."
    jes "No hay por qué avergonzarse, Su Majestad. Sé que está trágicamente en la ruina."

# game/script day2.rpy:586
translate Spanish repeat_route_592407eb:

    # "Asshole."
    "Cabrón."

# game/script day2.rpy:588
translate Spanish repeat_route_665ca65a:

    # jes "Please wait here. I'll be right back."
    jes "Por favor, espere aquí. Vuelvo enseguida."

# game/script day2.rpy:592
translate Spanish repeat_route_755daac1:

    # "With a snap of his fingers, Jestyn vanished from the room."
    "Con un chasquido de dedos, Jestyn desapareció de la habitación."

# game/script day2.rpy:593
translate Spanish repeat_route_696cbb92:

    # "Where did he go now...."
    "¿Adónde habrá ido ahora...?"

# game/script day2.rpy:594
translate Spanish repeat_route_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:595
translate Spanish repeat_route_9723eacd:

    # "Alright, while waiting for Jestyn to come back, what am I supposed to do now...?"
    "Bueno, mientras espero que Jestyn vuelva, ¿qué se supone que haga ahora...?"

# game/script day2.rpy:596
translate Spanish repeat_route_600b235f:

    # "Oh, right... Maybe I'll check the CCTV. I haven't done that task."
    "Ah, cierto... Quizá revise las cámaras. Todavía no he hecho esa tarea."

# game/script day2.rpy:639
translate Spanish outergate_day2_7708ee67:

    # "I check the camera at the outer gate. Looks fin-"
    "Reviso la cámara de la puerta exterior. Todo bi-"

# game/script day2.rpy:644
translate Spanish outergate_day2_1f9d47b7:

    # jes "BOOOOO!!!"
    jes "¡¡¡BUUUUU!!!"

# game/script day2.rpy:646
translate Spanish outergate_day2_dce82ad1:

    # mc "AAAAAAHHHHHHHH!!!!!"
    mc "¡¡¡AAAAAAHHHHHHHH!!!!!"

# game/script day2.rpy:648
translate Spanish outergate_day2_8fee2665:

    # "Jestyn's face suddenly popped up on my monitor. I nearly jumped out of my skin."
    "El rostro de Jestyn apareció de pronto en mi monitor. Casi me salgo de mi propia piel del susto."

# game/script day2.rpy:649
translate Spanish outergate_day2_08e17806:

    # "Damn it... This puppet is messing with me again."
    "Maldita sea... Este títere se está burlando de mí otra vez."

# game/script day2.rpy:651
translate Spanish outergate_day2_762f8a5f:

    # mc "JESTYN!"
    mc "¡JESTYN!"

# game/script day2.rpy:652
translate Spanish outergate_day2_bae07223:

    # mc "STOP DOING THAT!!"
    mc "¡¡DEJA DE HACER ESO!!"

# game/script day2.rpy:654
translate Spanish outergate_day2_c0ccd7a3:

    # "Jestyn simply laughed before disappearing from the screen again."
    "Jestyn simplemente rio antes de desaparecer de la pantalla otra vez."

# game/script day2.rpy:656
translate Spanish outergate_day2_7a0ea2d0:

    # "Seriously..."
    "En serio..."

# game/script day2.rpy:659
translate Spanish outergate_day2_0ed6b8a7:

    # "I check the camera at the outer gate. Looks fine."
    "Reviso la cámara de la puerta exterior. Todo bien."

# game/script day2.rpy:672
translate Spanish corridor1_day2_7708ee67:

    # "I check the camera at the outer gate. Looks fin-"
    "Reviso la cámara de la puerta exterior. Todo bi-"

# game/script day2.rpy:677
translate Spanish corridor1_day2_1f9d47b7:

    # jes "BOOOOO!!!"
    jes "¡¡¡BUUUUU!!!"

# game/script day2.rpy:679
translate Spanish corridor1_day2_dce82ad1:

    # mc "AAAAAAHHHHHHHH!!!!!"
    mc "¡¡¡AAAAAAHHHHHHHH!!!!!"

# game/script day2.rpy:681
translate Spanish corridor1_day2_8fee2665:

    # "Jestyn's face suddenly popped up on my monitor. I nearly jumped out of my skin."
    "El rostro de Jestyn apareció de pronto en mi monitor. Casi me salgo de mi propia piel del susto."

# game/script day2.rpy:682
translate Spanish corridor1_day2_08e17806:

    # "Damn it... This puppet is messing with me again."
    "Maldita sea... Este títere se está burlando de mí otra vez."

# game/script day2.rpy:684
translate Spanish corridor1_day2_762f8a5f:

    # mc "JESTYN!"
    mc "¡JESTYN!"

# game/script day2.rpy:685
translate Spanish corridor1_day2_bae07223:

    # mc "STOP DOING THAT!!"
    mc "¡¡DEJA DE HACER ESO!!"

# game/script day2.rpy:687
translate Spanish corridor1_day2_c0ccd7a3:

    # "Jestyn simply laughed before disappearing from the screen again."
    "Jestyn simplemente rio antes de desaparecer de la pantalla otra vez."

# game/script day2.rpy:689
translate Spanish corridor1_day2_7a0ea2d0:

    # "Seriously..."
    "En serio..."

# game/script day2.rpy:692
translate Spanish corridor1_day2_7287fdf3:

    # "I check the camera at the corridor 1. Looks fine."
    "Reviso la cámara del pasillo 1. Todo bien."

# game/script day2.rpy:705
translate Spanish theaterhall_day2_7708ee67:

    # "I check the camera at the outer gate. Looks fin-"
    "Reviso la cámara de la puerta exterior. Todo bi-"

# game/script day2.rpy:711
translate Spanish theaterhall_day2_1f9d47b7:

    # jes "BOOOOO!!!"
    jes "¡¡¡BUUUUU!!!"

# game/script day2.rpy:713
translate Spanish theaterhall_day2_dce82ad1:

    # mc "AAAAAAHHHHHHHH!!!!!"
    mc "¡¡¡AAAAAAHHHHHHHH!!!!!"

# game/script day2.rpy:715
translate Spanish theaterhall_day2_8fee2665:

    # "Jestyn's face suddenly popped up on my monitor. I nearly jumped out of my skin."
    "El rostro de Jestyn apareció de pronto en mi monitor. Casi me salgo de mi propia piel del susto."

# game/script day2.rpy:716
translate Spanish theaterhall_day2_08e17806:

    # "Damn it... This puppet is messing with me again."
    "Maldita sea... Este títere se está burlando de mí otra vez."

# game/script day2.rpy:718
translate Spanish theaterhall_day2_762f8a5f:

    # mc "JESTYN!"
    mc "¡JESTYN!"

# game/script day2.rpy:719
translate Spanish theaterhall_day2_bae07223:

    # mc "STOP DOING THAT!!"
    mc "¡¡DEJA DE HACER ESO!!"

# game/script day2.rpy:721
translate Spanish theaterhall_day2_c0ccd7a3:

    # "Jestyn simply laughed before disappearing from the screen again."
    "Jestyn simplemente rio antes de desaparecer de la pantalla otra vez."

# game/script day2.rpy:723
translate Spanish theaterhall_day2_7a0ea2d0:

    # "Seriously..."
    "En serio..."

# game/script day2.rpy:726
translate Spanish theaterhall_day2_b4689149:

    # "I check the camera at the theater hall. Looks fine."
    "Reviso la cámara del salón del teatro. Todo bien."

# game/script day2.rpy:739
translate Spanish storage_day2_7708ee67:

    # "I check the camera at the outer gate. Looks fin-"
    "Reviso la cámara de la puerta exterior. Todo bi-"

# game/script day2.rpy:745
translate Spanish storage_day2_1f9d47b7:

    # jes "BOOOOO!!!"
    jes "¡¡¡BUUUUU!!!"

# game/script day2.rpy:747
translate Spanish storage_day2_dce82ad1:

    # mc "AAAAAAHHHHHHHH!!!!!"
    mc "¡¡¡AAAAAAHHHHHHHH!!!!!"

# game/script day2.rpy:749
translate Spanish storage_day2_8fee2665:

    # "Jestyn's face suddenly popped up on my monitor. I nearly jumped out of my skin."
    "El rostro de Jestyn apareció de pronto en mi monitor. Casi me salgo de mi propia piel del susto."

# game/script day2.rpy:750
translate Spanish storage_day2_08e17806:

    # "Damn it... This puppet is messing with me again."
    "Maldita sea... Este títere se está burlando de mí otra vez."

# game/script day2.rpy:752
translate Spanish storage_day2_762f8a5f:

    # mc "JESTYN!"
    mc "¡JESTYN!"

# game/script day2.rpy:753
translate Spanish storage_day2_bae07223:

    # mc "STOP DOING THAT!!"
    mc "¡¡DEJA DE HACER ESO!!"

# game/script day2.rpy:755
translate Spanish storage_day2_c0ccd7a3:

    # "Jestyn simply laughed before disappearing from the screen again."
    "Jestyn simplemente rio antes de desaparecer de la pantalla otra vez."

# game/script day2.rpy:757
translate Spanish storage_day2_7a0ea2d0:

    # "Seriously..."
    "En serio..."

# game/script day2.rpy:760
translate Spanish storage_day2_cb5e7fcf:

    # "I check the camera at the storage. Looks fine."
    "Reviso la cámara del almacén. Todo bien."

# game/script day2.rpy:773
translate Spanish stage_day2_7708ee67:

    # "I check the camera at the outer gate. Looks fin-"
    "Reviso la cámara de la puerta exterior. Todo bi-"

# game/script day2.rpy:779
translate Spanish stage_day2_1f9d47b7:

    # jes "BOOOOO!!!"
    jes "¡¡¡BUUUUU!!!"

# game/script day2.rpy:781
translate Spanish stage_day2_dce82ad1:

    # mc "AAAAAAHHHHHHHH!!!!!"
    mc "¡¡¡AAAAAAHHHHHHHH!!!!!"

# game/script day2.rpy:783
translate Spanish stage_day2_8fee2665:

    # "Jestyn's face suddenly popped up on my monitor. I nearly jumped out of my skin."
    "El rostro de Jestyn apareció de pronto en mi monitor. Casi me salgo de mi propia piel del susto."

# game/script day2.rpy:784
translate Spanish stage_day2_08e17806:

    # "Damn it... This puppet is messing with me again."
    "Maldita sea... Este títere se está burlando de mí otra vez."

# game/script day2.rpy:786
translate Spanish stage_day2_762f8a5f:

    # mc "JESTYN!"
    mc "¡JESTYN!"

# game/script day2.rpy:787
translate Spanish stage_day2_bae07223:

    # mc "STOP DOING THAT!!"
    mc "¡¡DEJA DE HACER ESO!!"

# game/script day2.rpy:789
translate Spanish stage_day2_c0ccd7a3:

    # "Jestyn simply laughed before disappearing from the screen again."
    "Jestyn simplemente rio antes de desaparecer de la pantalla otra vez."

# game/script day2.rpy:791
translate Spanish stage_day2_7a0ea2d0:

    # "Seriously..."
    "En serio..."

# game/script day2.rpy:794
translate Spanish stage_day2_703b9b8b:

    # "I check the camera at the stage. Looks fine."
    "Reviso la cámara del escenario. Todo bien."

# game/script day2.rpy:805
translate Spanish dinner_day2_e8325c43:

    # "I think everything's settled down now."
    "Creo que ya todo se calmó."

# game/script day2.rpy:806
translate Spanish dinner_day2_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:807
translate Spanish dinner_day2_3eb67a38:

    # "I wonder where Jestyn went this time..."
    "Me pregunto adónde habrá ido Jestyn esta vez..."

# game/script day2.rpy:809
translate Spanish dinner_day2_1a783e36:

    # mc "At first, I thought he went to get food..."
    mc "Al principio pensé que había ido por comida..."

# game/script day2.rpy:815
translate Spanish dinner_day2_b0ba6367:

    # jes "I did."
    jes "Así fue."

# game/script day2.rpy:817
translate Spanish dinner_day2_d5a03c44:

    # mc "JESTYN, STOP APPEARING OUT OF NOWHERE LIKE THAT!!"
    mc "¡JESTYN, DEJA DE APARECER DE LA NADA ASÍ!!"

# game/script day2.rpy:821
translate Spanish dinner_day2_f7386ee4:

    # jes "Hehe... My sincerest apologies, Your Majesty~ But how could I possibly resist? Your reactions are far too delightful. A poor jester simply can't help but ask for an encore."
    jes "Jeje... Mis más sinceras disculpas, Su Majestad~ Pero ¿cómo podría resistirme? Sus reacciones son demasiado deliciosas. Un pobre bufón no puede evitar pedir un bis."

# game/script day2.rpy:822
translate Spanish dinner_day2_b83737b6:

    # mc "Seriously. You're actually going to give me a heart attack."
    mc "En serio. Me vas a provocar un infarto."

# game/script day2.rpy:825
translate Spanish dinner_day2_4ecfaea2:

    # jes "Ahh... Please don't say such dreadful things. Even the thought of Your Majesty collapsing makes my heart ache."
    jes "Ahh... Por favor, no diga cosas tan terribles. Incluso pensar que Su Majestad se desplome me parte el corazón."

# game/script day2.rpy:826
translate Spanish dinner_day2_f14584e8:

    # jes "Very well. I'll refrain from startling you again."
    jes "Muy bien. Me abstendré de sobresaltarle otra vez."

# game/script day2.rpy:828
translate Spanish dinner_day2_89eda0f7:

    # jes "Perhaps."
    jes "Quizás."

# game/script day2.rpy:831
translate Spanish dinner_day2_3a14ce79:

    # "I let out a long sigh. What was I even expecting from this puppet...?"
    "Solté un largo suspiro. ¿Qué esperaba yo de este títere...?"

# game/script day2.rpy:832
translate Spanish dinner_day2_093bd797:

    # "Then my eyes fell on what he was carrying."
    "Entonces mis ojos se posaron en lo que llevaba en las manos."

# game/script day2.rpy:833
translate Spanish dinner_day2_0fd4d656_1:

    # "......"
    "......"

# game/script day2.rpy:835
translate Spanish dinner_day2_401147ec:

    # mc "Jestyn... This is..."
    mc "Jestyn... Esto es..."

# game/script day2.rpy:838
translate Spanish dinner_day2_36ae058d:

    # jes "Hm? Ah, yes. Your dinner, Your Majesty."
    jes "¿Hm? Ah, sí. Su cena, Su Majestad."

# game/script day2.rpy:839
translate Spanish dinner_day2_007eb616:

    # mc "Yeah, I can see that, but..."
    mc "Sí, ya lo veo, pero..."

# game/script day2.rpy:840
translate Spanish dinner_day2_2e305fba:

    # mc "Isn't this... a little too fancy??"
    mc "¿No es esto... un poco demasiado elegante??"

# game/script day2.rpy:843
translate Spanish dinner_day2_d416cd8c:

    # "Jestyn let out a proud little laugh."
    "Jestyn soltó una orgullosa risita."

# game/script day2.rpy:845
translate Spanish dinner_day2_d461dffa:

    # jes "Naturally. Nothing less than the finest cuisine is worthy of Your Majesty."
    jes "Naturalmente. Nada menos que la mejor cocina es digna de Su Majestad."

# game/script day2.rpy:847
translate Spanish dinner_day2_ccd49713:

    # "I stared at the feast in Jestyn's hands."
    "Me quedé mirando el festín en las manos de Jestyn."

# game/script day2.rpy:848
translate Spanish dinner_day2_638059a5:

    # "There were all kinds of luxurious dishes, some I'd never even heard of, let alone seen before."
    "Había todo tipo de platillos lujosos, algunos de los que ni siquiera había oído hablar, mucho menos visto."

# game/script day2.rpy:849
translate Spanish dinner_day2_6393a3f8:

    # "There was fresh bread served with a bowl of creamy soup, what looked like a perfectly cooked steak, and even a rich chocolate cake for dessert."
    "Había pan fresco servido con un tazón de sopa cremosa, lo que parecía un filete perfectamente cocido e incluso un rico pastel de chocolate de postre."

# game/script day2.rpy:850
translate Spanish dinner_day2_fdb44cdb:

    # "...Wow. My instant noodle brain was definitely not equipped to process a meal this fancy."
    "...Vaya. Mi cerebro de fideos instantáneos definitivamente no estaba preparado para procesar una comida tan elegante."

# game/script day2.rpy:853
translate Spanish dinner_day2_5770e413:

    # jes "Besides, I know Your Majesty has lived a tragically impoverished life. The very least I can do is let you experience a proper royal feast."
    jes "Además, sé que Su Majestad ha vivido una vida trágicamente miserable. Lo mínimo que puedo hacer es dejarle experimentar un verdadero banquete real."

# game/script day2.rpy:854
translate Spanish dinner_day2_68010212:

    # mc "Wow. How incredibly kind of you."
    mc "Vaya. Qué increíblemente amable de tu parte."

# game/script day2.rpy:855
translate Spanish dinner_day2_64c98a52:

    # mc "But... where did you even get all of this????"
    mc "Pero... ¿de dónde sacaste todo esto????"

# game/script day2.rpy:858
translate Spanish dinner_day2_df43f98a:

    # jes "A five-star restaurant, of course."
    jes "De un restaurante de cinco estrellas, por supuesto."

# game/script day2.rpy:860
translate Spanish dinner_day2_a639c813:

    # "...Okay. This puppet actually left the theater just to get dinner."
    "...Bien. Este títere de verdad salió del teatro solo para conseguir la cena."

# game/script day2.rpy:862
translate Spanish dinner_day2_0ddd0eb6:

    # mc "And? How did you even pay for all this? Even if you had money, this looks ridiculously expensive."
    mc "¿Y? ¿Cómo pagaste todo esto? Aunque tuvieras dinero, esto parece ridículamente caro."

# game/script day2.rpy:865
translate Spanish dinner_day2_64e4b9a5:

    # jes "Why do you sound so suspicious, Your Majesty? Of course I have the money! More than enough, in fact!"
    jes "¿Por qué suena tan suspicaz, Su Majestad? ¡Por supuesto que tengo el dinero! ¡Más que suficiente, de hecho!"

# game/script day2.rpy:867
translate Spanish dinner_day2_9df39eee:

    # jes "Hmph. To think Your Majesty would doubt this humble jester so."
    jes "Hmph. Pensar que Su Majestad dudaría así de este humilde bufón."

# game/script day2.rpy:868
translate Spanish dinner_day2_36ffa458:

    # mc "Then where did you get the money?"
    mc "Entonces, ¿de dónde sacaste el dinero?"

# game/script day2.rpy:869
translate Spanish dinner_day2_86a04db7:

    # jes "...The bank."
    jes "...Del banco."

# game/script day2.rpy:870
translate Spanish dinner_day2_cd6801cb:

    # mc "And... you have a credit card?"
    mc "Y... ¿tienes tarjeta de crédito?"

# game/script day2.rpy:873
translate Spanish dinner_day2_88056451:

    # jes "......"
    jes "......"

# game/script day2.rpy:874
translate Spanish dinner_day2_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:875
translate Spanish dinner_day2_0c360815:

    # mc "Jestyn, you-"
    mc "Jestyn, tú-"

# game/script day2.rpy:879
translate Spanish dinner_day2_4bbe7c93:

    # jes "Ah! Would you look at that? It's already ten o'clock! Time for Your Majesty's dinner!"
    jes "¡Ah! ¡Fíjese qué hora es! ¡Ya son las diez! ¡Hora de la cena de Su Majestad!"

# game/script day2.rpy:882
translate Spanish dinner_day2_d6728bd2:

    # "Jestyn set the tray down on the table before gesturing for me to sit on the bed."
    "Jestyn dejó la bandeja sobre la mesa antes de indicarme con un gesto que me sentara en la cama."

# game/script day2.rpy:883
translate Spanish dinner_day2_e0c0ee3f:

    # "He picked up a basket of buttered bread along with a bowl of creamy soup."
    "Tomó una cesta de pan con mantequilla junto con un tazón de sopa cremosa."

# game/script day2.rpy:884
translate Spanish dinner_day2_ab9279b7:

    # "Then he sat down beside me."
    "Luego se sentó a mi lado."

# game/script day2.rpy:888
translate Spanish dinner_day2_88ee2eb1:

    # jes "Here we are, Your Majesty. Every proper feast begins with an appetizer."
    jes "Aquí tiene, Su Majestad. Todo banquete que se precie comienza con un aperitivo."

# game/script day2.rpy:889
translate Spanish dinner_day2_9acd33df:

    # jes "So, allow this humble jester to present buttered bread with a rich cream soup. I do hope it pleases Your Majesty's palate."
    jes "“Así pues, permita que este humilde bufón le presente pan con mantequilla y una rica sopa cremosa. Espero sinceramente que complazca el paladar de Su Majestad."

# game/script day2.rpy:892
translate Spanish dinner_day2_bd1803b6:

    # "I picked up a piece of bread and took a bite."
    "Tomé un trozo de pan y le di un mordisco."

# game/script day2.rpy:893
translate Spanish dinner_day2_828c18c9:

    # "It was incredible. The crust was perfectly crisp, while the inside was soft and fluffy."
    "Era increíble. La corteza estaba perfectamente crujiente, mientras que el interior era suave y esponjoso."

# game/script day2.rpy:894
translate Spanish dinner_day2_6ae484ef:

    # "I'd never tasted bread this good before."
    "Nunca había probado un pan tan bueno."

# game/script day2.rpy:897
translate Spanish dinner_day2_8fcf0abc:

    # jes "It seems Your Majesty approves. Now, try dipping the bread into the soup."
    jes "Parece que Su Majestad lo aprueba. Ahora, pruebe a mojar el pan en la sopa."

# game/script day2.rpy:899
translate Spanish dinner_day2_9d94342f:

    # "I did as he suggested, dipping the bread into the creamy soup before taking another bite."
    "Hice lo que sugirió, mojando el pan en la sopa cremosa antes de darle otro mordisco."

# game/script day2.rpy:900
translate Spanish dinner_day2_408fbc3f:

    # "It tasted even better than before. The soft, buttery bread paired perfectly with the rich, velvety soup, making every bite unbelievably satisfying."
    "Sabía aún mejor que antes. El pan suave y mantecoso combinaba a la perfección con la sopa rica y aterciopelada, haciendo que cada bocado fuera increíblemente satisfactorio."

# game/script day2.rpy:903
translate Spanish dinner_day2_ec5ef123:

    # "...Only then did I realize that Jestyn had been watching me the entire time."
    "...Solo entonces me di cuenta de que Jestyn me había estado observando todo el tiempo."

# game/script day2.rpy:905
translate Spanish dinner_day2_bc48048d:

    # mc "Why are you looking at me like that?"
    mc "¿Por qué me miras así?"

# game/script day2.rpy:907
translate Spanish dinner_day2_d39eae57:

    # "He simply smiled."
    "Simplemente sonrió."

# game/script day2.rpy:910
translate Spanish dinner_day2_dcea26ec:

    # jes "Oh, it's nothing, Your Majesty. Am I not allowed to admire Your Majesty while you dine?"
    jes "Oh, no es nada, Su Majestad. ¿Acaso no me está permitido admirar a Su Majestad mientras cena?"

# game/script day2.rpy:911
translate Spanish dinner_day2_3b21f354_1:

    # mc "......"
    mc "......"

# game/script day2.rpy:912
translate Spanish dinner_day2_165d3869:

    # mc "If you're hungry... we can share."
    mc "Si tienes hambre... podemos compartir."

# game/script day2.rpy:915
translate Spanish dinner_day2_18f9487a:

    # "Jestyn fell silent for a moment."
    "Jestyn guardó silencio un momento."

# game/script day2.rpy:918
translate Spanish dinner_day2_0265b377:

    # jes "I'm not hungry, Your Majesty. I don't need to eat."
    jes "No tengo hambre, Su Majestad. No necesito comer."

# game/script day2.rpy:920
translate Spanish dinner_day2_1581be24:

    # "...Right. He's a puppet. That actually made sense."
    "...Cierto. Es un títere. Eso en realidad tenía sentido."

# game/script day2.rpy:923
translate Spanish dinner_day2_9c31ab45:

    # jes "We can eat human food if we wish, and we can even taste it. But it simply does nothing for us."
    jes "Podemos comer comida humana si así lo deseamos, e incluso podemos saborearla. Pero simplemente no nos hace nada."

# game/script day2.rpy:924
translate Spanish dinner_day2_55423040:

    # mc "I see... Then, would you-"
    mc "Ya veo... Entonces, ¿te gustaría-"

# game/script day2.rpy:927
translate Spanish dinner_day2_68131239:

    # jes "There's no need, Your Majesty~ You're the one who's hungry. That's all that matters."
    jes "No hace falta, Su Majestad~ Usted es quien tiene hambre. Eso es lo único que importa."

# game/script day2.rpy:928
translate Spanish dinner_day2_ce59a351:

    # mc "What if I make it an order? It feels weird eating all by myself."
    mc "¿Y si lo convierto en una orden? Se siente raro comer sol[letra]."

# game/script day2.rpy:931
translate Spanish dinner_day2_ffccff44:

    # "Jestyn's eyes widened in surprise before a faint blush spread across his cheeks."
    "Los ojos de Jestyn se abrieron de sorpresa antes de que un leve rubor se extendiera por sus mejillas."

# game/script day2.rpy:934
translate Spanish dinner_day2_0ffcfbcf:

    # jes "...Your Majesty is far too kind... Showing such concern for a lowly jester..."
    jes "...Su Majestad es demasiado amable... Mostrar tal preocupación por un humilde bufón..."

# game/script day2.rpy:937
translate Spanish dinner_day2_2d667700:

    # jes "Very well, very well~ What chance does this humble jester have against an order from the Crown?"
    jes "Muy bien, muy bien~ ¿Qué oportunidad tiene este humilde bufón frente a una orden de la Corona?"

# game/script day2.rpy:939
translate Spanish dinner_day2_5c4b2565:

    # "He picked up a piece of bread and took a bite."
    "Tomó un trozo de pan y le dio un mordisco."

# game/script day2.rpy:941
translate Spanish dinner_day2_68e4d470:

    # mc "Good, isn't it?"
    mc "Está bueno, ¿verdad?"

# game/script day2.rpy:944
translate Spanish dinner_day2_c057540d:

    # jes "Indeed. It's quite delicious."
    jes "En efecto. Es bastante delicioso."

# game/script day2.rpy:946
translate Spanish dinner_day2_0fd4d656_2:

    # "......"
    "......"

# game/script day2.rpy:948
translate Spanish dinner_day2_b323639a:

    # mc "You know... this kind of feels like a date."
    mc "Sabes... esto se siente un poco como una cita."

# game/script day2.rpy:952
translate Spanish dinner_day2_ded9571f:

    # "Jestyn immediately stopped chewing and stared at me with wide eyes."
    "Jestyn dejó de masticar de inmediato y me miró con los ojos como platos."

# game/script day2.rpy:955
translate Spanish dinner_day2_2f0a32d9:

    # mc "U-Uh... Jestyn?"
    mc "E-Eh... ¿Jestyn?"

# game/script day2.rpy:958
translate Spanish dinner_day2_47b740ea:

    # jes "......D...."
    jes "......C...."

# game/script day2.rpy:959
translate Spanish dinner_day2_8872ad7e:

    # jes ".... Date....? D-Did you just say date, Your Majesty..?"
    jes ".... ¿Ci... cita....? ¿A-Acaba de decir cita, Su Majestad..?"

# game/script day2.rpy:960
translate Spanish dinner_day2_be3a08ed:

    # mc "Did I say something wr-"
    mc "¿Dije algo mal-"

# game/script day2.rpy:961
translate Spanish dinner_day2_c1e253b2:

    # jes "No. No, no... Quite the opposite."
    jes "No. No, no... Todo lo contrario."

# game/script day2.rpy:962
translate Spanish dinner_day2_8f5cb00d:

    # jes "I just realized something..."
    jes "Acabo de darme cuenta de algo..."

# game/script day2.rpy:964
translate Spanish dinner_day2_1fa7c1fe:

    # "A wide grin spread across his face, and the blush on his cheeks deepened."
    "Una amplia sonrisa se dibujó en su rostro, y el rubor de sus mejillas se intensificó."

# game/script day2.rpy:967
translate Spanish dinner_day2_3d13b8f2:

    # jes "You're right... It DOES feel like a date. Almost."
    jes "Tiene razón... SÍ se siente como una cita. Casi."

# game/script day2.rpy:970
translate Spanish dinner_day2_03e81c46:

    # "He cleared his throat and promptly rose from the bed."
    "Se aclaró la garganta y se levantó de la cama de inmediato."

# game/script day2.rpy:973
translate Spanish dinner_day2_84dc2f86:

    # jes "Forgive me, Your Majesty, but this simply won't do."
    jes "Perdóneme, Su Majestad, pero esto simplemente no puede ser."

# game/script day2.rpy:976
translate Spanish dinner_day2_c04b35c0:

    # jes "I have to make this date even better!"
    jes "¡Tengo que hacer que esta cita sea aún mejor!"

# game/script day2.rpy:977
translate Spanish dinner_day2_ecd9d879:

    # mc "Wait, that's not what I mea-"
    mc "Espera, no es lo que quise deci-"

# game/script day2.rpy:981
translate Spanish dinner_day2_14a936c7:

    # "I couldn't even finish my sentence before Jestyn snapped his fingers and vanished."
    "Ni siquiera pude terminar la frase antes de que Jestyn chasqueara los dedos y desapareciera."

# game/script day2.rpy:983
translate Spanish dinner_day2_6407e891:

    # mc "Huh? Where did he go?"
    mc "¿Eh? ¿Adónde fue?"

# game/script day2.rpy:985
translate Spanish dinner_day2_e2071021:

    # "I waited for a while, quietly enjoying my bread."
    "Esperé un rato, disfrutando tranquilamente de mi pan."

# game/script day2.rpy:986
translate Spanish dinner_day2_47c04984:

    # "Seconds passed. Then minutes. And after several more minutes, Jestyn still hadn't returned."
    "Pasaron segundos. Luego minutos. Y tras varios minutos más, Jestyn seguía sin volver."

# game/script day2.rpy:988
translate Spanish dinner_day2_0120ac94:

    # mc "Where did he even go...? At this rate, I'm really going to eat all the bread by myself."
    mc "¿Adónde habrá ido...? A este paso, de verdad me voy a comer todo el pan yo sol[letra]."

# game/script day2.rpy:990
translate Spanish dinner_day2_88140fd3:

    # "Since I was still hungry, I reached for another piece of bread and-"
    "Como todavía tenía hambre, alcancé otro trozo de pan y-"

# game/script day2.rpy:996
translate Spanish dinner_day2_91047a3a:

    # ".........."
    ".........."

# game/script day2.rpy:998
translate Spanish dinner_day2_92731130:

    # "What the-"
    "¿Qué dem-"

# game/script day2.rpy:1000
translate Spanish dinner_day2_51902a10:

    # mc "Huh?! Where am I?!"
    mc "¡¿Eh?! ¡¿Dónde estoy?!"

# game/script day2.rpy:1002
translate Spanish dinner_day2_954520c0:

    # "In the blink of an eye, I found myself somewhere else, seated at a chair before a table that had been modestly decorated."
    "En un abrir y cerrar de ojos me encontré en otro lugar, sentad[letra] en una silla frente a una mesa decorada con modestia."

# game/script day2.rpy:1003
translate Spanish dinner_day2_cefe0f59:

    # "A red flower. What looked like a rose rested at the center of the table, with a scented candle placed beside it."
    "Una flor roja. Lo que parecía una rosa reposaba en el centro de la mesa, con una vela aromática a su lado."

# game/script day2.rpy:1004
translate Spanish dinner_day2_7570d83f:

    # "A white tablecloth trimmed with elegant gold patterns covered the table."
    "Un mantel blanco con elegantes bordes dorados cubría la mesa."

# game/script day2.rpy:1005
translate Spanish dinner_day2_c1cc138e:

    # "... There's only one person who'd do something like this."
    "... Solo hay una persona que haría algo así."

# game/script day2.rpy:1007
translate Spanish dinner_day2_19003725:

    # mc "Jestyn? Are you there?"
    mc "¿Jestyn? ¿Estás ahí?"

# game/script day2.rpy:1009
translate Spanish dinner_day2_0fd4d656_3:

    # "......"
    "......"

# game/script day2.rpy:1012
translate Spanish dinner_day2_9d1737cb:

    # "The sound of approaching footsteps grew closer as I called Jestyn's name."
    "El sonido de pasos se acercaba mientras yo llamaba a Jestyn."

# game/script day2.rpy:1015
translate Spanish dinner_day2_1d6c4192:

    # "A hand slowly brushed against mine, startling me. I nearly pulled my hand away on instinct."
    "Una mano rozó lentamente la mía, sobresaltándome. Casi retiré la mano por instinto."

# game/script day2.rpy:1018
translate Spanish dinner_day2_c2580288:

    # "But then the hand gently took mine. And a second later, I felt soft lips press a kiss against the back of my hand."
    "Pero entonces la mano tomó la mía con delicadeza. Y un segundo después, sentí unos labios suaves besar el dorso de mi mano."

# game/script day2.rpy:1019
translate Spanish dinner_day2_b9dfcc1d:

    # "I'd be lying if I said I wasn't flustered."
    "Mentiría si dijera que no estaba alterad[letra]."

# game/script day2.rpy:1020
translate Spanish dinner_day2_c5933757:

    # "In the darkness, I strained my eyes, trying to make out who was kissing my hand."
    "En la oscuridad, forcé la vista tratando de distinguir quién me besaba la mano."

# game/script day2.rpy:1021
translate Spanish dinner_day2_5fbb73a2:

    # "And finally... I saw someone."
    "Y por fin... vi a alguien."

# game/script day2.rpy:1025
translate Spanish dinner_day2_6f8fe218:

    # "Someone with dark maroon, wavy hair, neatly tied back."
    "Alguien con el cabello ondulado de un granate oscuro, pulcramente recogido."

# game/script day2.rpy:1026
translate Spanish dinner_day2_cbbdc264:

    # "His clothes were immaculate and elegant, complemented by a deep red robe."
    "Su ropa era impecable y elegante, complementada con una túnica roja intensa."

# game/script day2.rpy:1027
translate Spanish dinner_day2_42e5b2c2:

    # "At first glance... he almost looked like a king."
    "A primera vista... casi parecía un rey."

# game/script day2.rpy:1028
translate Spanish dinner_day2_fe12e0e2:

    # "But the moment I saw his face, I finally realized."
    "Pero en cuanto vi su rostro, por fin me di cuenta."

# game/script day2.rpy:1030
translate Spanish dinner_day2_ab54c249:

    # mc "......Jestyn...?"
    mc "......¿Jestyn...?"

# game/script day2.rpy:1032
translate Spanish dinner_day2_bb374c6b:

    # "Jestyn's smile widened even further at the sound of his name."
    "La sonrisa de Jestyn se ensanchó aún más al oír su nombre."

# game/script day2.rpy:1034
translate Spanish dinner_day2_a9925365:

    # voice "JESTYN02_DAY2.ogg"
    # jes "I want to asking whether Your Majesty likes the atmosphere of our little dinner. Though... I suppose you're rather enjoying the view in front of you as well, hm~?"
    voice "JESTYN02_DAY2.ogg"
    jes "Quería preguntarle si a Su Majestad le agrada el ambiente de nuestra pequeña cena. Aunque... supongo que también está disfrutando bastante de la vista que tiene enfrente, ¿hm~?"

# game/script day2.rpy:1037
translate Spanish dinner_day2_7cbd6804:

    # "I snapped out of my daze."
    "Salí de mi aturdimiento."

# game/script day2.rpy:1040
translate Spanish dinner_day2_c742bbaa:

    # mc "Why are you dressed like that?"
    mc "¿Por qué estás vestido así?"

# game/script day2.rpy:1043
translate Spanish dinner_day2_9ec591f0:

    # jes "Why, because I simply had to make an impression on Your Majesty!"
    jes "¡Pues porque tenía que causarle una buena impresión a Su Majestad!"

# game/script day2.rpy:1044
translate Spanish dinner_day2_b6c7b15c:

    # jes "To be honest... I've never actually been on something called a date. I've only ever read about them in books."
    jes "Para ser sincero... en realidad nunca he tenido una cita. Solo he leído sobre ellas en libros."

# game/script day2.rpy:1045
translate Spanish dinner_day2_88fa8c81:

    # jes "So... this is my first one."
    jes "Así que... esta es mi primera."

# game/script day2.rpy:1046
translate Spanish dinner_day2_31b11213:

    # jes "I spent quite a while deciding what to wear..."
    jes "Pasé bastante tiempo decidiendo qué ponerme..."

# game/script day2.rpy:1047
translate Spanish dinner_day2_63e6306c:

    # jes "I suppose I do look a little different... but tell me, Your Majesty..."
    jes "Supongo que me veo un poco diferente... pero dígame, Su Majestad..."

# game/script day2.rpy:1049
translate Spanish dinner_day2_f6089175:

    # jes "Do you like it~?"
    jes "¿Le gusta~?"

# game/script day2.rpy:1053
translate Spanish dinner_day2_b3eaaf81:

    # mc "Yeah. You look different and handsome."
    mc "Sí. Te ves diferente y apuesto."

# game/script day2.rpy:1055
translate Spanish dinner_day2_4b892859:

    # "Jestyn giggled like a lovestruck high school girl."
    "Jestyn soltó una risita como una colegiala enamorada."

# game/script day2.rpy:1056
translate Spanish dinner_day2_483309d1:

    # jes "Mnhh~ I'm so glad Your Majesty likes it~"
    jes "Mnhh~ Me alegra tanto que a Su Majestad le guste~"

# game/script day2.rpy:1059
translate Spanish dinner_day2_7f08e5f1:

    # mc "Not really."
    mc "En realidad no."

# game/script day2.rpy:1062
translate Spanish dinner_day2_7d3e3dc6:

    # "His smile instantly melted into a pout."
    "Su sonrisa se derritió al instante en un puchero."

# game/script day2.rpy:1064
translate Spanish dinner_day2_2d480f1e:

    # jes "Hmph. How cruel. I went through all the trouble of dressing up just for you, Your Majesty."
    jes "Hmph. Qué cruel. Me tomé la molestia de arreglarme solo para usted, Su Majestad."

# game/script day2.rpy:1067
translate Spanish dinner_day2_4bcc3c36:

    # jes ".....Mmmnnn... but then again... I suppose I can't exactly refuse it either..."
    jes ".....Mmmnnn... pero pensándolo bien... supongo que tampoco puedo rechazarlo del todo..."

# game/script day2.rpy:1068
translate Spanish dinner_day2_fb246c29:

    # jes "If Your Majesty wishes to keep insulting me... please, be my guest~"
    jes "Si Su Majestad desea seguir insultándome... adelante, no se prive~"

# game/script day2.rpy:1070
translate Spanish dinner_day2_54174af0:

    # "What a freak."
    "Qué bicho raro."

# game/script day2.rpy:1073
translate Spanish dinner_day2_16e0f6a2:

    # jes "Now then~ How about we continue the dinner that was so rudely interrupted?"
    jes "Y ahora~ ¿Qué le parece si continuamos la cena que tan groseramente fue interrumpida?"

# game/script day2.rpy:1075
translate Spanish dinner_day2_16aa6f6f:

    # "Jestyn snapped his fingers, and in an instant, the bread and cream soup we'd been eating earlier reappeared on the table."
    "Jestyn chasqueó los dedos y, en un instante, el pan y la sopa cremosa que estábamos comiendo antes reaparecieron sobre la mesa."

# game/script day2.rpy:1078
translate Spanish dinner_day2_d5022380:

    # jes "Please, enjoy your food, Your Majesty~"
    jes "Por favor, disfrute su comida, Su Majestad~"

# game/script day2.rpy:1081
translate Spanish dinner_day2_89b5c6b9:

    # "I was already hungry, so I wasted no time digging into the bread and cream soup."
    "Ya tenía hambre, así que no perdí tiempo en lanzarme sobre el pan y la sopa cremosa."

# game/script day2.rpy:1082
translate Spanish dinner_day2_80873371:

    # "But Jestyn didn't touch his own food. Instead, he simply watched me with his usual smile."
    "Pero Jestyn no tocó su propia comida. En cambio, simplemente me observó con su sonrisa de siempre."

# game/script day2.rpy:1084
translate Spanish dinner_day2_3162f6e6:

    # mc "Jestyn, you should eat too."
    mc "Jestyn, tú también deberías comer."

# game/script day2.rpy:1087
translate Spanish dinner_day2_c1811f98:

    # jes "Hehe... Of course... of course, Your Majesty... I am enjoying my food..."
    jes "Jeje... Por supuesto... por supuesto, Su Majestad... Estoy disfrutando de mi comida..."

# game/script day2.rpy:1088
translate Spanish dinner_day2_bb50df9c:

    # mc "Your food isn't me."
    mc "Tu comida no soy yo."

# game/script day2.rpy:1090
translate Spanish dinner_day2_41db0433:

    # "Jestyn let out a quiet chuckle before finally taking a bite of his bread and dipping it into the cream soup."
    "Jestyn soltó una risita suave antes de por fin darle un mordisco a su pan y mojarlo en la sopa cremosa."

# game/script day2.rpy:1093
translate Spanish dinner_day2_808d1201:

    # jes "Your Majesty... may I ask you something?"
    jes "Su Majestad... ¿puedo preguntarle algo?"

# game/script day2.rpy:1094
translate Spanish dinner_day2_582359ea:

    # mc "Hm?"
    mc "¿Hm?"

# game/script day2.rpy:1095
translate Spanish dinner_day2_f5c7db15:

    # jes "Earlier, when Your Majesty was spending time with Knighter and Wizzy..."
    jes "Hace un rato, cuando Su Majestad pasaba tiempo con Knighter y Wizzy..."

# game/script day2.rpy:1096
translate Spanish dinner_day2_eb84a1a1:

    # mc "...Yes?"
    mc "...¿Sí?"

# game/script day2.rpy:1098
translate Spanish dinner_day2_3bca6fbc:

    # jes "...It felt... strange."
    jes "...Se sintió... extraño."

# game/script day2.rpy:1099
translate Spanish dinner_day2_b2b9e19d:

    # mc "What do you mean?"
    mc "¿A qué te refieres?"

# game/script day2.rpy:1101
translate Spanish dinner_day2_390907bf:

    # "He fell silent for a moment, taking another bite of his bread."
    "Guardó silencio un momento mientras daba otro mordisco a su pan."

# game/script day2.rpy:1103
translate Spanish dinner_day2_78d69ba7:

    # jes "...Your Majesty seemed... close to them."
    jes "...Su Majestad parecía... estar cerca de ellos."

# game/script day2.rpy:1104
translate Spanish dinner_day2_63859231:

    # jes "And it made me feel... I don't quite know how to put it."
    jes "Y eso me hizo sentir... no sé muy bien cómo decirlo."

# game/script day2.rpy:1106
translate Spanish dinner_day2_a20cefa7:

    # "..."
    "..."

# game/script day2.rpy:1107
translate Spanish dinner_day2_22f83f99:

    # "...Oh? Don't tell me he's..."
    "...¿Oh? No me digas que está..."

# game/script day2.rpy:1108
translate Spanish dinner_day2_c20c569c:

    # "I had a feeling I already knew what he was trying to say. Still, I wanted to hear him say it himself."
    "Tenía la sensación de que ya sabía lo que intentaba decir. Aun así, quería oírselo decir a él mismo."

# game/script day2.rpy:1110
translate Spanish dinner_day2_bfe27581:

    # mc "Just tell me what's on your mind."
    mc "Solo dime qué tienes en mente."

# game/script day2.rpy:1111
translate Spanish dinner_day2_86d92e86:

    # jes "... I'm so confused with myself, Your Majesty."
    jes "... Estoy tan confundido conmigo mismo, Su Majestad."

# game/script day2.rpy:1112
translate Spanish dinner_day2_8a3e15f3:

    # jes "I want Your Majesty to get to know them..."
    jes "Quiero que Su Majestad los conozca..."

# game/script day2.rpy:1113
translate Spanish dinner_day2_599771c1:

    # jes "...But I don't want Your Majesty to become that close to them."
    jes "...Pero no quiero que Su Majestad se encariñe tanto con ellos."

# game/script day2.rpy:1116
translate Spanish dinner_day2_7d9c9bce:

    # jes "Especially... if it means Your Majesty might forget about me..."
    jes "Sobre todo... si eso significa que Su Majestad podría olvidarse de mí..."

# game/script day2.rpy:1117
translate Spanish dinner_day2_5adf15ad:

    # jes "Ever since I met Your Majesty... I've been feeling so many things I can't even begin to explain."
    jes "Desde que conocí a Su Majestad... he estado sintiendo tantas cosas que ni siquiera sé cómo empezar a explicarlas."

# game/script day2.rpy:1118
translate Spanish dinner_day2_8fb52037:

    # jes "They're all so... unfamiliar. I've never experienced anything like them before."
    jes "Son todas tan... desconocidas. Nunca había experimentado nada parecido."

# game/script day2.rpy:1119
translate Spanish dinner_day2_052da218:

    # jes "I feel like a little bird that's finally escaped its nest... spreading its wings and soaring into the great, wide world for the very first time..."
    jes "Me siento como un pajarito que por fin ha escapado de su nido... extendiendo las alas y surcando por primera vez el vasto y ancho mundo..."

# game/script day2.rpy:1120
translate Spanish dinner_day2_2b2475eb:

    # mc "........"
    mc "........"

# game/script day2.rpy:1121
translate Spanish dinner_day2_b737776e:

    # mc "Jestyn... that's called jealousy."
    mc "Jestyn... eso se llama celos."

# game/script day2.rpy:1124
translate Spanish dinner_day2_41909de9:

    # jes "...Jealousy..."
    jes "...Celos..."

# game/script day2.rpy:1126
translate Spanish dinner_day2_818e64af:

    # "Jestyn slowly lifted his gaze to meet mine."
    "Jestyn alzó lentamente la mirada para encontrarse con la mía."

# game/script day2.rpy:1129
translate Spanish dinner_day2_ebb457b9:

    # jes "...Then yes."
    jes "...Entonces sí."

# game/script day2.rpy:1130
translate Spanish dinner_day2_f4147b20:

    # jes "This humble jester is terribly jealous."
    jes "Este humilde bufón está terriblemente celoso."

# game/script day2.rpy:1131
translate Spanish dinner_day2_519893dd:

    # jes "Painfully... shamelessly... hopelessly jealous."
    jes "Dolorosamente... descaradamente... irremediablemente celoso."

# game/script day2.rpy:1134
translate Spanish dinner_day2_e277a06e:

    # jes "...And yet, what right does a mere court jester have? I'm nothing more than Your Majesty's faithful toy... a fool meant to amuse the Crown. I have no place demanding Your Majesty's attention."
    jes "...Y aun así, ¿qué derecho tiene un simple bufón de la corte? No soy más que el fiel juguete de Su Majestad... un necio destinado a divertir a la Corona. No tengo lugar para exigir la atención de Su Majestad."

# game/script day2.rpy:1135
translate Spanish dinner_day2_26a7a74b:

    # jes "...But..."
    jes "...Pero..."

# game/script day2.rpy:1137
translate Spanish dinner_day2_f43bb810:

    # jes "...Would it truly be so selfish... if this poor jester wished to be the only toy Your Majesty ever reached for?"
    jes "...¿Sería realmente tan egoísta... que este pobre bufón deseara ser el único juguete que Su Majestad alguna vez tome?"

# game/script day2.rpy:1139
translate Spanish dinner_day2_be8f653f:

    # "He looked at me with an intensity I'd never seen before. His voice grew heavier."
    "Me miró con una intensidad que nunca le había visto. Su voz se volvió más grave."

# game/script day2.rpy:1140
translate Spanish dinner_day2_0434c7f5:

    # "...Did that mean... he had fallen in love with me?"
    "...¿Eso significaba... que se había enamorado de mí?"

# game/script day2.rpy:1141
translate Spanish dinner_day2_2eef42df:

    # "That quickly...?"
    "¿Tan rápido...?"

# game/script day2.rpy:1143
translate Spanish dinner_day2_2ffda830:

    # mc "Jestyn... does that mean you're in love with me?"
    mc "Jestyn... ¿eso significa que estás enamorado de mí?"

# game/script day2.rpy:1146
translate Spanish dinner_day2_864edbe4:

    # jes "...Love...?"
    jes "...¿Amor...?"

# game/script day2.rpy:1148
translate Spanish dinner_day2_fd6d13bf:

    # "Jestyn fell silent, turning my words over in his mind."
    "Jestyn guardó silencio, dándole vueltas a mis palabras."

# game/script day2.rpy:1150
translate Spanish dinner_day2_6b2b4f2e:

    # jes "...Love... love... love..."
    jes "...Amor... amor... amor..."

# game/script day2.rpy:1151
translate Spanish dinner_day2_e4ff4886:

    # jes "A feeling that stirs whenever your eyes fall upon someone... someone truly special..."
    jes "Un sentimiento que se agita cada vez que tus ojos se posan en alguien... alguien verdaderamente especial..."

# game/script day2.rpy:1152
translate Spanish dinner_day2_e139ebe9:

    # jes "A longing to stay by their side... a longing to have them all to yourself..."
    jes "Un anhelo de quedarte a su lado... un anhelo de tenerle solo para ti..."

# game/script day2.rpy:1154
translate Spanish dinner_day2_7c17a134:

    # "He murmured the words to himself. Then, little by little, a smile returned to his face. Wider than before."
    "Murmuró las palabras para sí mismo. Luego, poco a poco, una sonrisa volvió a su rostro. Más amplia que antes."

# game/script day2.rpy:1157
translate Spanish dinner_day2_d714ee98:

    # jes "...Yes... Yes!"
    jes "...Sí... ¡Sí!"

# game/script day2.rpy:1158
translate Spanish dinner_day2_aa65c28f:

    # jes "I... I love you... Your Majesty!"
    jes "Yo... ¡Estoy enamorado de usted... Su Majestad!"

# game/script day2.rpy:1159
translate Spanish dinner_day2_9d52a09e:

    # jes "I've always known what love was... at least, I knew its definition. But I'd never truly felt it myself."
    jes "Siempre supe lo que era el amor... al menos, conocía su definición. Pero nunca lo había sentido de verdad."

# game/script day2.rpy:1161
translate Spanish dinner_day2_40a11268:

    # jes "So this is what love feels like... Haha..."
    jes "Así que esto es lo que se siente el amor... Jaja..."

# game/script day2.rpy:1163
translate Spanish dinner_day2_510a1e83:

    # "He paused."
    "Hizo una pausa."

# game/script day2.rpy:1165
translate Spanish dinner_day2_573f5b00:

    # jes "...Then..."
    jes "...Entonces..."

# game/script day2.rpy:1166
translate Spanish dinner_day2_fb8ce0ed:

    # jes "...How does Your Majesty feel about me?"
    jes "...¿Qué siente Su Majestad por mí?"

# game/script day2.rpy:1167
translate Spanish dinner_day2_f38cc58d:

    # jes "Now that you've learned how this humble jester feels... what place does this foolish heart hold in Yours?"
    jes "Ahora que sabe lo que siente este humilde bufón... ¿qué lugar ocupa este necio corazón en el Suyo?"

# game/script day2.rpy:1169
translate Spanish dinner_day2_8ec7d7ee:

    # "...How did I feel about Jestyn?"
    "...¿Qué sentía yo por Jestyn?"

# game/script day2.rpy:1173
translate Spanish dinner_day2_ef98b420:

    # "He could be unbearably cheeky with all his teasing... but he was also thoughtful, caring, and surprisingly funny."
    "Podía ser insoportablemente descarado con todas sus burlas... pero también era atento, cariñoso y sorprendentemente gracioso."

# game/script day2.rpy:1174
translate Spanish dinner_day2_8a38e616:

    # "I liked him... but everything was happening so fast."
    "Me gustaba... pero todo estaba pasando muy rápido."

# game/script day2.rpy:1177
translate Spanish dinner_day2_5f9b772e:

    # "...."
    "...."

# game/script day2.rpy:1178
translate Spanish dinner_day2_adf9dec9:

    # "I'm not sure if I like Jestyn that way."
    "No estoy segur[letra] de que me guste Jestyn de esa manera."

# game/script day2.rpy:1179
translate Spanish dinner_day2_9b965857:

    # "Sure, he's a fun puppet... but it's all happening way too fast for me."
    "Claro, es un títere divertido... pero todo está pasando demasiado rápido para mí."

# game/script day2.rpy:1181
translate Spanish dinner_day2_07d42f15:

    # mc "...The truth is, Jestyn... we only met yesterday."
    mc "...La verdad, Jestyn... apenas nos conocimos ayer."

# game/script day2.rpy:1182
translate Spanish dinner_day2_7dabce44:

    # mc "I do like you... but I need time."
    mc "Me gustas... pero necesito tiempo."

# game/script day2.rpy:1185
translate Spanish dinner_day2_95a7e98e:

    # "A flicker of disappointment crossed Jestyn's face, though he nodded in understanding."
    "Un destello de decepción cruzó el rostro de Jestyn, aunque asintió comprendiendo."

# game/script day2.rpy:1187
translate Spanish dinner_day2_1af77692:

    # jes "I understand, Your Majesty... Human hearts need time. This impatient jester can wait."
    jes "Lo entiendo, Su Majestad... Los corazones humanos necesitan tiempo. Este impaciente bufón puede esperar."

# game/script day2.rpy:1190
translate Spanish dinner_day2_b08313b6:

    # "Silence settled between us once more as we returned to our bread."
    "El silencio se asentó otra vez entre nosotros mientras volvíamos a nuestro pan."

# game/script day2.rpy:1193
translate Spanish dinner_day2_6e7c3c45:

    # mc "Well, Jestyn... if you're really in love with me... then why were you hugging Maidy like that?"
    mc "Bueno, Jestyn... si de verdad estás enamorado de mí... entonces ¿por qué abrazabas así a Maidy?"

# game/script day2.rpy:1196
translate Spanish dinner_day2_ec68662a:

    # jes "Maidy?... Ah!"
    jes "¿Maidy?... ¡Ah!"

# game/script day2.rpy:1198
translate Spanish dinner_day2_5a517499:

    # "That mischievous grin of his returned at once."
    "Su sonrisa traviesa regresó de inmediato."

# game/script day2.rpy:1201
translate Spanish dinner_day2_37f8dc29:

    # jes "I merely gave Maidy a warm little hug. Surely there's no crime in that~?"
    jes "Solo le di a Maidy un cálido abracito. Seguramente no hay delito en eso, ¿verdad~?"

# game/script day2.rpy:1203
translate Spanish dinner_day2_be294f2f:

    # "He said it with that same teasing, playful tone."
    "Lo dijo con ese mismo tono burlón y juguetón."

# game/script day2.rpy:1207
translate Spanish dinner_day2_33c9d5d1:

    # jes "...To be honest, Your Majesty... I was hoping you'd get at least a little jealous."
    jes "...Para ser sincero, Su Majestad... esperaba que al menos sintiera un poquito de celos."

# game/script day2.rpy:1208
translate Spanish dinner_day2_f1368de7:

    # mc "Jealous...?"
    mc "¿Celos...?"

# game/script day2.rpy:1210
translate Spanish dinner_day2_bce1639d:

    # jes "When I hugged Maidy... you didn't react at all. Not even the slightest change in your expression."
    jes "Cuando abracé a Maidy... usted no reaccionó en absoluto. Ni siquiera el más mínimo cambio en su expresión."

# game/script day2.rpy:1212
translate Spanish dinner_day2_fc74024a:

    # jes "........"
    jes "........"

# game/script day2.rpy:1214
translate Spanish dinner_day2_5ee380e4:

    # jes "...It made me a little sad."
    jes "...Me puso un poquito triste."

# game/script day2.rpy:1216
translate Spanish dinner_day2_2c67aa8b:

    # "Oh... so that hug really was intentional?"
    "Oh... ¿entonces ese abrazo fue a propósito?"

# game/script day2.rpy:1218
translate Spanish dinner_day2_2f1bc7ba:

    # "...I see. So that's the game he wanted to play."
    "...Ya veo. Así que ese era el juego que quería jugar."

# game/script day2.rpy:1220
translate Spanish dinner_day2_054c5ee0:

    # mc "I see."
    mc "Ya veo."

# game/script day2.rpy:1221
translate Spanish dinner_day2_32df1e7c:

    # mc "Was that your way of getting my attention?"
    mc "¿Esa era tu manera de llamar mi atención?"

# game/script day2.rpy:1224
translate Spanish dinner_day2_e69aba46:

    # "Jestyn let out a soft giggle as the blush on his cheeks deepened."
    "Jestyn soltó una suave risita mientras el rubor de sus mejillas se intensificaba."

# game/script day2.rpy:1226
translate Spanish dinner_day2_60d8946c:

    # jes "I haven't the faintest idea what Your Majesty is talking about~"
    jes "No tengo la menor idea de a qué se refiere Su Majestad~"

# game/script day2.rpy:1237
translate Spanish punishment_day2_6651ab87:

    # mc "Alright."
    mc "Bien."

# game/script day2.rpy:1241
translate Spanish punishment_day2_7656e28e:

    # "I stood up from my chair and walked over to Jestyn."
    "Me levanté de mi silla y caminé hacia Jestyn."

# game/script day2.rpy:1243
translate Spanish punishment_day2_4cd5b26b:

    # "I took the piece of bread from his hand."
    "Le quité el trozo de pan de la mano."

# game/script day2.rpy:1244
translate Spanish punishment_day2_86164482:

    # "He looked at me in confusion for a moment before I gently stuffed the bread into his mouth."
    "Me miró confundido un momento antes de que le metiera el pan en la boca con suavidad."

# game/script day2.rpy:1247
translate Spanish punishment_day2_b9bf963b:

    # "His eyes widened in surprise."
    "Sus ojos se abrieron de sorpresa."

# game/script day2.rpy:1249
translate Spanish punishment_day2_43ac09ae:

    # "...Maybe, I was starting to figure out how to keep this troublesome jester in line."
    "...Quizás estaba empezando a descubrir cómo mantener a raya a este problemático bufón."

# game/script day2.rpy:1251
translate Spanish punishment_day2_10a78d00:

    # mc "Are you really that desperate to be punished?"
    mc "¿De verdad estás tan desesperado por que te castiguen?"

# game/script day2.rpy:1254
translate Spanish punishment_day2_d9e824c3:

    # "His body began to tremble, and his breathing grew uneven."
    "Su cuerpo empezó a temblar y su respiración se volvió irregular."

# game/script day2.rpy:1255
translate Spanish punishment_day2_bd5f13c7:

    # "...It seemed he was enjoying this far more than he should."
    "...Parecía que lo estaba disfrutando mucho más de lo debido."

# game/script day2.rpy:1257
translate Spanish punishment_day2_5a828644:

    # jes "Mmph..."
    jes "Mmph..."

# game/script day2.rpy:1258
translate Spanish punishment_day2_a83da2db:

    # mc "You want to say something?"
    mc "¿Quieres decir algo?"

# game/script day2.rpy:1260
translate Spanish punishment_day2_e8927d32:

    # "He nodded. I pulled the piece of bread out of his mouth."
    "Asintió. Saqué el trozo de pan de su boca."

# game/script day2.rpy:1264
translate Spanish punishment_day2_7f2cb965:

    # jes "Ehe... Is Your Majesty... jealous~?"
    jes "Ehe... ¿Su Majestad... siente celos~?"

# game/script day2.rpy:1265
translate Spanish punishment_day2_d1ddaffa:

    # "........"
    "........"

# game/script day2.rpy:1266
translate Spanish punishment_day2_4d5bdd14:

    # "The way he said those words stirred something inside me."
    "La forma en que dijo esas palabras despertó algo dentro de mí."

# game/script day2.rpy:1267
translate Spanish punishment_day2_3e98b170:

    # "It made me want to put him in his place... to make him behave."
    "Me dieron ganas de ponerlo en su lugar... de hacer que se portara bien."

# game/script day2.rpy:1271
translate Spanish punishment_day2_430018e4:

    # jes "Y-Yes... p-please..."
    jes "S-Sí... p-por favor..."

# game/script day2.rpy:1272
translate Spanish punishment_day2_46d024ef:

    # mc "Please what?"
    mc "¿Por favor qué?"

# game/script day2.rpy:1273
translate Spanish punishment_day2_70d9a902:

    # jes "Please... punish me.... pay attention to me..."
    jes "Por favor... castígueme.... présteme atención..."

# game/script day2.rpy:1274
translate Spanish punishment_day2_a7a66213:

    # jes "I need it... I need it... I need it... I need it..."
    jes "Lo necesito... lo necesito... lo necesito... lo necesito..."

# game/script day2.rpy:1276
translate Spanish punishment_day2_b94cdc89:

    # jes "LOOK AT ME. ONLY ME."
    jes "MÍREME. SOLO A MÍ."

# game/script day2.rpy:1278
translate Spanish punishment_day2_098246d7:

    # "...So this was what it felt like to truly have the upper hand over someone...?"
    "...¿Así que esto era lo que se sentía tener realmente la ventaja sobre alguien...?"

# game/script day2.rpy:1280
translate Spanish punishment_day2_bab174bb:

    # "Before I knew it, a smile spread across my face as I pushed the bread back into his mouth."
    "Antes de darme cuenta, una sonrisa se extendió por mi rostro mientras volvía a empujar el pan dentro de su boca."

# game/script day2.rpy:1281
translate Spanish punishment_day2_bf0d30af:

    # "Then I took a bite from the other end of the same piece of bread."
    "Luego le di un mordisco al otro extremo del mismo trozo de pan."

# game/script day2.rpy:1282
translate Spanish punishment_day2_69baafa8:

    # "My eyes never left his."
    "Mis ojos nunca se apartaron de los suyos."

# game/script day2.rpy:1283
translate Spanish punishment_day2_51f7cb3b:

    # "His gaze remained fixed on mine, unwavering, while his breathing grew increasingly uneven."
    "Su mirada permaneció fija en la mía, inquebrantable, mientras su respiración se volvía cada vez más irregular."

# game/script day2.rpy:1285
translate Spanish punishment_day2_5533ca8f:

    # mc "You know, Jestyn... I don't have any experience being the dominant one."
    mc "Sabes, Jestyn... no tengo experiencia siendo el dominante."

# game/script day2.rpy:1286
translate Spanish punishment_day2_e770f738:

    # mc "But... after everything you've taught me since yesterday... I think I'm starting to like it."
    mc "Pero... después de todo lo que me has enseñado desde ayer... creo que me está empezando a gustar."

# game/script day2.rpy:1287
translate Spanish punishment_day2_9795cac3:

    # mc "And I think... this is the perfect chance to learn."
    mc "Y creo... que esta es la oportunidad perfecta para aprender."

# game/script day2.rpy:1288
translate Spanish punishment_day2_51e45bd8:

    # jes "Nngh... Mmh..."
    jes "Nngh... Mmh..."

# game/script day2.rpy:1290
translate Spanish punishment_day2_afbd6add:

    # "I tried to remember what I'd read about this kind of dynamic before."
    "Intenté recordar lo que había leído antes sobre este tipo de dinámica."

# game/script day2.rpy:1291
translate Spanish punishment_day2_848d0852:

    # "If I remembered correctly... there was something called 'brat taming,' where the more dominant partner disciplines a mischievous submissive until they behave."
    "Si mal no recordaba... había algo llamado 'brat taming', donde la pareja más dominante disciplina a un sumiso travieso hasta que se porta bien."

# game/script day2.rpy:1292
translate Spanish punishment_day2_85a02d16:

    # "...Or at least, that's what I remembered reading online."
    "...O al menos, eso era lo que recordaba haber leído en internet."

# game/script day2.rpy:1293
translate Spanish punishment_day2_7251c00f:

    # "But... what should I do from here?"
    "Pero... ¿qué debía hacer a partir de aquí?"

# game/script day2.rpy:1294
translate Spanish punishment_day2_94f4cdd4:

    # "Seeing the confused look on my face, Jestyn began gesturing instead."
    "Al ver la expresión confundida en mi rostro, Jestyn empezó a hacer gestos en su lugar."

# game/script day2.rpy:1295
translate Spanish punishment_day2_73144484:

    # "He patted his own cheek... then gave his backside a few pats before making a swatting motion with his hand."
    "Se dio unas palmadas en la mejilla... luego unas palmaditas en el trasero antes de hacer un gesto de azotar con la mano."

# game/script day2.rpy:1297
translate Spanish punishment_day2_66d2f697:

    # mc "... Slap you... or spank you...?"
    mc "... ¿Abofetearte... o darte una nalgada...?"

# game/script day2.rpy:1299
translate Spanish punishment_day2_9b7a8e6e:

    # "He nodded."
    "Asintió."

# game/script day2.rpy:1300
translate Spanish punishment_day2_07bdde05:

    # "....."
    "....."

# game/script day2.rpy:1301
translate Spanish punishment_day2_f9964084:

    # "I have 2 options. What am I supposed to do?"
    "Tengo 2 opciones. ¿Qué se supone que haga?"

# game/script day2.rpy:1307
translate Spanish punishment_day2_09c90f01:

    # "I decided to slap his cheek."
    "Decidí abofetearle la mejilla."

# game/script day2.rpy:1308
translate Spanish punishment_day2_887ab5ec:

    # "I slowly raised my hand."
    "Levanté la mano lentamente."

# game/script day2.rpy:1309
translate Spanish punishment_day2_48206dc7:

    # "But... did I really have the nerve to hit him that hard...?"
    "Pero... ¿de verdad tenía las agallas para golpearlo tan fuerte...?"

# game/script day2.rpy:1310
translate Spanish punishment_day2_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:1311
translate Spanish punishment_day2_8ab85f93:

    # "No... No matter what, I didn't want to hurt Jestyn."
    "No... Pasara lo que pasara, no quería lastimar a Jestyn."

# game/script day2.rpy:1312
translate Spanish punishment_day2_43ee35ae:

    # "My hand landed gently against his cheek."
    "Mi mano aterrizó suavemente sobre su mejilla."

# game/script day2.rpy:1317
translate Spanish punishment_day2_b898fbd4:

    # jes "Mnh!"
    jes "Mnh!"

# game/script day2.rpy:1319
translate Spanish punishment_day2_92dcf817:

    # "The slap was light, leaving only the faintest blush on his cheek."
    "La bofetada fue ligera, dejando apenas un leve rubor en su mejilla."

# game/script day2.rpy:1321
translate Spanish punishment_day2_855a307c:

    # "Jestyn looked at me in confusion, as if checking whether something had gone wrong, before realizing I simply couldn't bring myself to hurt him."
    "Jestyn me miró confundido, como comprobando si algo había salido mal, antes de darse cuenta de que simplemente no podía hacerle daño."

# game/script day2.rpy:1322
translate Spanish punishment_day2_58b15bd3:

    # "His expression gradually softened."
    "Su expresión se fue suavizando poco a poco."

# game/script day2.rpy:1323
translate Spanish punishment_day2_785ffbc6:

    # "Without saying a word, his eyes seemed to tell me... that it was alright if I hit him harder."
    "Sin decir palabra, sus ojos parecieron decirme... que estaba bien si le pegaba más fuerte."

# game/script day2.rpy:1324
translate Spanish punishment_day2_ee69e427:

    # "I slapped him harder this time."
    "Esta vez lo abofeteé más fuerte."

# game/script day2.rpy:1328
translate Spanish punishment_day2_3289b8ed:

    # "SLAP!!!"
    "¡¡¡PLAS!!!"

# game/script day2.rpy:1330
translate Spanish punishment_day2_ee33d96f:

    # jes "MNNHHH-!!"
    jes "MNNHHH-!!"

# game/script day2.rpy:1332
translate Spanish punishment_day2_234a7d28:

    # "Jestyn's breathing grew heavier. He seemed to be enjoying it."
    "La respiración de Jestyn se volvió más pesada. Parecía estar disfrutándolo."

# game/script day2.rpy:1333
translate Spanish punishment_day2_b54aad57:

    # "I finally decided to say something."
    "Por fin decidí decir algo."

# game/script day2.rpy:1335
translate Spanish punishment_day2_8ff4a86c:

    # mc "You're such a brat, you know that, Jestyn?"
    mc "Eres un malcriado, ¿lo sabías, Jestyn?"

# game/script day2.rpy:1338
translate Spanish punishment_day2_ab4b6785:

    # "The moment the words left my mouth, his entire body trembled."
    "En cuanto las palabras salieron de mi boca, todo su cuerpo tembló."

# game/script day2.rpy:1340
translate Spanish punishment_day2_9385f10b:

    # jes "Nghhhh~..."
    jes "Nghhhh~..."

# game/script day2.rpy:1342
translate Spanish punishment_day2_409406be:

    # "I gently caressed Jestyn's cheek... before giving him another slap."
    "Acaricié suavemente la mejilla de Jestyn... antes de darle otra bofetada."

# game/script day2.rpy:1349
translate Spanish punishment_day2_f1c574e4:

    # "I slapped Jestyn again."
    "Volví a abofetear a Jestyn."

# game/script day2.rpy:1351
translate Spanish punishment_day2_6778a0fc:

    # "SLAP!"
    "¡PLAS!"

# game/script day2.rpy:1353
translate Spanish punishment_day2_200ee120:

    # jes "Mnhhhhhh!!"
    jes "Mnhhhhhh!!"

# game/script day2.rpy:1355
translate Spanish punishment_day2_b0d3b6c5:

    # mc "You want my attention that badly, yes? So here. Take it."
    mc "Quieres mi atención con tantas ganas, ¿verdad? Pues toma. Tómala."

# game/script day2.rpy:1356
translate Spanish punishment_day2_5b969459:

    # mc "I'll give you. A lot of my attention."
    mc "Te daré. Mucha de mi atención."

# game/script day2.rpy:1358
translate Spanish punishment_day2_2e314a6f:

    # "Jestyn nodded eagerly."
    "Jestyn asintió con entusiasmo."

# game/script day2.rpy:1360
translate Spanish punishment_day2_b484538b:

    # jes "Nhhh... hhhh...."
    jes "Nhhh... hhhh...."

# game/script day2.rpy:1366
translate Spanish punishment_day2_24d8ad06:

    # "I slapped him once more... this time even harder than before."
    "Lo abofeteé una vez más... esta vez aún más fuerte que antes."

# game/script day2.rpy:1368
translate Spanish punishment_day2_83199f30:

    # jes "NGHHHH!!! MNHHHH!!"
    jes "NGHHHH!!! MNHHHH!!"

# game/script day2.rpy:1370
translate Spanish punishment_day2_b0d3b6c5_1:

    # mc "You want my attention that badly, yes? So here. Take it."
    mc "Quieres mi atención con tantas ganas, ¿verdad? Pues toma. Tómala."

# game/script day2.rpy:1371
translate Spanish punishment_day2_fcbdce4a:

    # mc "I'll give you. A LOT of my attention."
    mc "Te daré. MUCHA de mi atención."

# game/script day2.rpy:1373
translate Spanish punishment_day2_2e314a6f_1:

    # "Jestyn nodded eagerly."
    "Jestyn asintió con entusiasmo."

# game/script day2.rpy:1375
translate Spanish punishment_day2_b484538b_1:

    # jes "Nhhh... hhhh...."
    jes "Nhhh... hhhh...."

# game/script day2.rpy:1382
translate Spanish punishment_day2_3289b8ed_1:

    # "SLAP!!!"
    "¡¡¡PLAS!!!"

# game/script day2.rpy:1384
translate Spanish punishment_day2_7a7e81dd:

    # jes "NGHHH!!!"
    jes "NGHHH!!!"

# game/script day2.rpy:1391
translate Spanish punishment_day2_ddcd1781:

    # "SLAP!!!!"
    "¡¡¡¡PLAS!!!!"

# game/script day2.rpy:1393
translate Spanish punishment_day2_5662b9b8:

    # jes "MNHHHNNN!!! NHH!!"
    jes "MNHHHNNN!!! NHH!!"

# game/script day2.rpy:1400
translate Spanish punishment_day2_673afd65:

    # "SLAP!!"
    "¡¡PLAS!!"

# game/script day2.rpy:1405
translate Spanish punishment_day2_3289b8ed_2:

    # "SLAP!!!"
    "¡¡¡PLAS!!!"

# game/script day2.rpy:1410
translate Spanish punishment_day2_ddcd1781_1:

    # "SLAP!!!!"
    "¡¡¡¡PLAS!!!!"

# game/script day2.rpy:1416
translate Spanish punishment_day2_2c118555:

    # jes "NGH! GHH!! NHHHHHH!!!"
    jes "NGH! GHH!! NHHHHHH!!!"

# game/script day2.rpy:1426
translate Spanish punishment_day2_83a8174f:

    # "!!!!!"
    "!!!!!"

# game/script day2.rpy:1429
translate Spanish punishment_day2_94250a6c:

    # "What... what just happened?"
    "¿Qué... qué acaba de pasar?"

# game/script day2.rpy:1430
translate Spanish punishment_day2_5ceacc20:

    # "For a brief moment... I felt strangely light."
    "Por un breve instante... me sentí extrañamente liger[letra]."

# game/script day2.rpy:1431
translate Spanish punishment_day2_fdb9c0b9:

    # "When I heard someone crying, I realized it was Jestyn."
    "Cuando oí que alguien lloraba, me di cuenta de que era Jestyn."

# game/script day2.rpy:1433
translate Spanish punishment_day2_ff1dd228:

    # jes ".... sob.... sob...."
    jes ".... snif.... snif...."

# game/script day2.rpy:1435
translate Spanish punishment_day2_f8f5f642:

    # "Oh no... What have I done?!"
    "Oh no... ¡¿Qué he hecho?!"

# game/script day2.rpy:1437
translate Spanish punishment_day2_c4b00689:

    # "I quickly pulled the piece of bread out of Jestyn's mouth."
    "Rápidamente saqué el trozo de pan de la boca de Jestyn."

# game/script day2.rpy:1439
translate Spanish punishment_day2_2e0989f8:

    # mc "JESTYN! I'm so sorry! I really am! Are you okay?!"
    mc "¡JESTYN! ¡Lo siento mucho! ¡De verdad! ¡¿Estás bien?!"

# game/script day2.rpy:1441
translate Spanish punishment_day2_d213fafa:

    # "But Jestyn didn't seem to hear me."
    "Pero Jestyn no parecía oírme."

# game/script day2.rpy:1443
translate Spanish punishment_day2_72c5f294:

    # mc "Jestyn... hey... I'm sorry... I went too far..."
    mc "Jestyn... oye... lo siento... me pasé..."

# game/script day2.rpy:1445
translate Spanish punishment_day2_95f8fb5e:

    # "I gently cupped his cheek, hoping it would comfort him, even just a little."
    "Le acuné suavemente la mejilla, esperando consolarlo aunque fuera un poco."

# game/script day2.rpy:1446
translate Spanish punishment_day2_c19627de:

    # "At last, Jestyn looked up at me."
    "Por fin, Jestyn alzó la vista hacia mí."

# game/script day2.rpy:1448
translate Spanish punishment_day2_26f7fd0a:

    # jes "...sob... Your Majesty... I'm sorry..."
    jes "...snif... Su Majestad... lo siento..."

# game/script day2.rpy:1449
translate Spanish punishment_day2_973df8f8:

    # mc "No, no, no. I'm the one who should be apologizing. I took it too far, okay?"
    mc "No, no, no. Soy yo quien debería disculparse. Me pasé de la raya, ¿de acuerdo?"

# game/script day2.rpy:1451
translate Spanish punishment_day2_8101c1b4:

    # jes "...Ehe... It's okay..."
    jes "...Ehe... Está bien..."

# game/script day2.rpy:1452
translate Spanish punishment_day2_a73ce39e:

    # jes "...I liked it..."
    jes "...Me gustó..."

# game/script day2.rpy:1454
translate Spanish punishment_day2_0e8cd77a:

    # jes "...Though, for a moment... I thought Your Majesty..."
    jes "...Aunque, por un momento... pensé que Su Majestad..."

# game/script day2.rpy:1456
translate Spanish punishment_day2_cdc741e0:

    # "Jestyn trailed off before he could finish."
    "Jestyn se quedó callado sin terminar la frase."

# game/script day2.rpy:1459
translate Spanish punishment_day2_926f99d2:

    # jes "...It's nothing, hehe... Don't worry about it, Your Majesty..."
    jes "...No es nada, jeje... No se preocupe por eso, Su Majestad..."

# game/script day2.rpy:1464
translate Spanish punishment_day2_5719b771:

    # "I think that's enough."
    "Creo que ya es suficiente."

# game/script day2.rpy:1466
translate Spanish punishment_day2_370bb416:

    # "I gently caressed Jestyn's cheek again, brushing my fingers over the flushed skin."
    "Volví a acariciar suavemente la mejilla de Jestyn, rozando con los dedos la piel sonrojada."

# game/script day2.rpy:1468
translate Spanish punishment_day2_efece155:

    # jes "Mnh... nh..."
    jes "Mnh... nh..."

# game/script day2.rpy:1470
translate Spanish punishment_day2_052b04bf:

    # "I finally took the piece of bread out of his mouth, allowing him to speak."
    "Por fin saqué el trozo de pan de su boca, permitiéndole hablar."

# game/script day2.rpy:1473
translate Spanish punishment_day2_0bbb3a84:

    # jes "Hahh... hahh... Y-Your Majesty..."
    jes "Hahh... hahh... S-Su Majestad..."

# game/script day2.rpy:1474
translate Spanish punishment_day2_a5ffb19f:

    # mc "Have you learned your lesson?"
    mc "¿Has aprendido la lección?"

# game/script day2.rpy:1476
translate Spanish punishment_day2_a9630362:

    # "Jestyn nodded."
    "Jestyn asintió."

# game/script day2.rpy:1478
translate Spanish punishment_day2_51f4b613:

    # mc "Then what do you say?"
    mc "Entonces, ¿qué se dice?"

# game/script day2.rpy:1479
translate Spanish punishment_day2_c260d9ac:

    # jes "I-I'm sorry, Your Majesty... I was wrong..."
    jes "L-Lo siento, Su Majestad... Me equivoqué..."

# game/script day2.rpy:1480
translate Spanish punishment_day2_37fa6578:

    # mc "Good boy."
    mc "Buen chico."

# game/script day2.rpy:1482
translate Spanish punishment_day2_54eb179b:

    # "I gently stroked his head, and Jestyn practically melted beneath the praise, looking genuinely happy with the affection I gave him."
    "Le acaricié suavemente la cabeza, y Jestyn prácticamente se derritió ante el elogio, luciendo genuinamente feliz con el cariño que le di."

# game/script day2.rpy:1486
translate Spanish punishment_day2_5719b771_1:

    # "I think that's enough."
    "Creo que ya es suficiente."

# game/script day2.rpy:1488
translate Spanish punishment_day2_370bb416_1:

    # "I gently caressed Jestyn's cheek again, brushing my fingers over the flushed skin."
    "Volví a acariciar suavemente la mejilla de Jestyn, rozando con los dedos la piel sonrojada."

# game/script day2.rpy:1489
translate Spanish punishment_day2_efece155_1:

    # jes "Mnh... nh..."
    jes "Mnh... nh..."

# game/script day2.rpy:1491
translate Spanish punishment_day2_052b04bf_1:

    # "I finally took the piece of bread out of his mouth, allowing him to speak."
    "Por fin saqué el trozo de pan de su boca, permitiéndole hablar."

# game/script day2.rpy:1494
translate Spanish punishment_day2_0bbb3a84_1:

    # jes "Hahh... hahh... Y-Your Majesty..."
    jes "Hahh... hahh... S-Su Majestad..."

# game/script day2.rpy:1495
translate Spanish punishment_day2_a5ffb19f_1:

    # mc "Have you learned your lesson?"
    mc "¿Has aprendido la lección?"

# game/script day2.rpy:1497
translate Spanish punishment_day2_a9630362_1:

    # "Jestyn nodded."
    "Jestyn asintió."

# game/script day2.rpy:1499
translate Spanish punishment_day2_51f4b613_1:

    # mc "Then what do you say?"
    mc "Entonces, ¿qué se dice?"

# game/script day2.rpy:1500
translate Spanish punishment_day2_c260d9ac_1:

    # jes "I-I'm sorry, Your Majesty... I was wrong..."
    jes "L-Lo siento, Su Majestad... Me equivoqué..."

# game/script day2.rpy:1501
translate Spanish punishment_day2_37fa6578_1:

    # mc "Good boy."
    mc "Buen chico."

# game/script day2.rpy:1503
translate Spanish punishment_day2_54eb179b_1:

    # "I gently stroked his head, and Jestyn practically melted beneath the praise, looking genuinely happy with the affection I gave him."
    "Le acaricié suavemente la cabeza, y Jestyn prácticamente se derritió ante el elogio, luciendo genuinamente feliz con el cariño que le di."

# game/script day2.rpy:1507
translate Spanish punishment_day2_cf66ecf1:

    # "I instructed Jestyn to bend over the table."
    "Le ordené a Jestyn que se inclinara sobre la mesa."

# game/script day2.rpy:1510
translate Spanish punishment_day2_6e5ba04b:

    # "Jestyn's face flushed with eager anticipation at the thought of what might happen next."
    "El rostro de Jestyn se sonrojó con ansiosa expectación ante lo que podría pasar a continuación."

# game/script day2.rpy:1511
translate Spanish punishment_day2_869943a0:

    # "He bent over the table just as I had ordered."
    "Se inclinó sobre la mesa tal como yo había ordenado."

# game/script day2.rpy:1513
translate Spanish punishment_day2_37ec86f6:

    # "I slowly ran my hand down his back, from his shoulders to his lower back, making him shiver at the gentle touch."
    "Deslicé lentamente la mano por su espalda, desde los hombros hasta la parte baja, haciéndolo estremecer con el suave toque."

# game/script day2.rpy:1515
translate Spanish punishment_day2_7e5e6070:

    # jes "Ngh......"
    jes "Ngh......"

# game/script day2.rpy:1517
translate Spanish punishment_day2_7c74cfc6:

    # "When my hand reached the small of his back, I gave his backside a light pat."
    "Cuando mi mano llegó a la base de su espalda, le di una ligera palmada en el trasero."

# game/script day2.rpy:1519
translate Spanish punishment_day2_20d09778:

    # jes "Mnh-"
    jes "Mnh-"

# game/script day2.rpy:1522
translate Spanish punishment_day2_ca9112f4:

    # "Then I drew my arm back, preparing to spank him"
    "Luego eché el brazo hacia atrás, preparándome para darle una nalgada"

# game/script day2.rpy:1523
translate Spanish punishment_day2_48206dc7_1:

    # "But... did I really have the nerve to hit him that hard...?"
    "Pero... ¿de verdad tenía las agallas para golpearlo tan fuerte...?"

# game/script day2.rpy:1524
translate Spanish punishment_day2_0fd4d656_1:

    # "......"
    "......"

# game/script day2.rpy:1525
translate Spanish punishment_day2_8ab85f93_1:

    # "No... No matter what, I didn't want to hurt Jestyn."
    "No... Pasara lo que pasara, no quería lastimar a Jestyn."

# game/script day2.rpy:1526
translate Spanish punishment_day2_04308bbd:

    # "My hand landed gently against his backside."
    "Mi mano aterrizó suavemente sobre su trasero."

# game/script day2.rpy:1531
translate Spanish punishment_day2_b898fbd4_1:

    # jes "Mnh!"
    jes "Mnh!"

# game/script day2.rpy:1533
translate Spanish punishment_day2_2bf260ec:

    # "The slap was light, just a normal slap"
    "La palmada fue ligera, una simple palmada normal"

# game/script day2.rpy:1534
translate Spanish punishment_day2_855a307c_1:

    # "Jestyn looked at me in confusion, as if checking whether something had gone wrong, before realizing I simply couldn't bring myself to hurt him."
    "Jestyn me miró confundido, como comprobando si algo había salido mal, antes de darse cuenta de que simplemente no podía hacerle daño."

# game/script day2.rpy:1536
translate Spanish punishment_day2_58b15bd3_1:

    # "His expression gradually softened."
    "Su expresión se fue suavizando poco a poco."

# game/script day2.rpy:1537
translate Spanish punishment_day2_785ffbc6_1:

    # "Without saying a word, his eyes seemed to tell me... that it was alright if I hit him harder."
    "Sin decir palabra, sus ojos parecieron decirme... que estaba bien si le pegaba más fuerte."

# game/script day2.rpy:1538
translate Spanish punishment_day2_35e70286:

    # "I spanked him harder this time."
    "Esta vez le di una nalgada más fuerte."

# game/script day2.rpy:1542
translate Spanish punishment_day2_3289b8ed_3:

    # "SLAP!!!"
    "¡¡¡PLAS!!!"

# game/script day2.rpy:1544
translate Spanish punishment_day2_ee33d96f_1:

    # jes "MNNHHH-!!"
    jes "MNNHHH-!!"

# game/script day2.rpy:1546
translate Spanish punishment_day2_234a7d28_1:

    # "Jestyn's breathing grew heavier. He seemed to be enjoying it."
    "La respiración de Jestyn se volvió más pesada. Parecía estar disfrutándolo."

# game/script day2.rpy:1547
translate Spanish punishment_day2_b54aad57_1:

    # "I finally decided to say something."
    "Por fin decidí decir algo."

# game/script day2.rpy:1549
translate Spanish punishment_day2_8ff4a86c_1:

    # mc "You're such a brat, you know that, Jestyn?"
    mc "Eres un malcriado, ¿lo sabías, Jestyn?"

# game/script day2.rpy:1551
translate Spanish punishment_day2_ab4b6785_1:

    # "The moment the words left my mouth, his entire body trembled."
    "En cuanto las palabras salieron de mi boca, todo su cuerpo tembló."

# game/script day2.rpy:1553
translate Spanish punishment_day2_9385f10b_1:

    # jes "Nghhhh~..."
    jes "Nghhhh~..."

# game/script day2.rpy:1555
translate Spanish punishment_day2_3ebde4e2:

    # "I gently caressed Jestyn's backside... before giving him another spank."
    "Acaricié suavemente el trasero de Jestyn... antes de darle otra nalgada."

# game/script day2.rpy:1559
translate Spanish punishment_day2_da1e6529:

    # "I spanked Jestyn again."
    "Volví a darle una nalgada a Jestyn."

# game/script day2.rpy:1563
translate Spanish punishment_day2_6778a0fc_1:

    # "SLAP!"
    "¡PLAS!"

# game/script day2.rpy:1565
translate Spanish punishment_day2_200ee120_1:

    # jes "Mnhhhhhh!!"
    jes "Mnhhhhhh!!"

# game/script day2.rpy:1567
translate Spanish punishment_day2_b0d3b6c5_2:

    # mc "You want my attention that badly, yes? So here. Take it."
    mc "Quieres mi atención con tantas ganas, ¿verdad? Pues toma. Tómala."

# game/script day2.rpy:1568
translate Spanish punishment_day2_5b969459_1:

    # mc "I'll give you. A lot of my attention."
    mc "Te daré. Mucha de mi atención."

# game/script day2.rpy:1570
translate Spanish punishment_day2_244c1829:

    # "Jestyn nod eagerly"
    "Jestyn asintió con entusiasmo"

# game/script day2.rpy:1572
translate Spanish punishment_day2_faa6068b:

    # jes "nhhh... hhhh...."
    jes "nhhh... hhhh...."

# game/script day2.rpy:1575
translate Spanish punishment_day2_cc71d320:

    # "I spanked him once more... this time even harder than before."
    "Le di una nalgada una vez más... esta vez aún más fuerte que antes."

# game/script day2.rpy:1579
translate Spanish punishment_day2_83199f30_1:

    # jes "NGHHHH!!! MNHHHH!!"
    jes "NGHHHH!!! MNHHHH!!"

# game/script day2.rpy:1581
translate Spanish punishment_day2_b0d3b6c5_3:

    # mc "You want my attention that badly, yes? So here. Take it."
    mc "Quieres mi atención con tantas ganas, ¿verdad? Pues toma. Tómala."

# game/script day2.rpy:1582
translate Spanish punishment_day2_fcbdce4a_1:

    # mc "I'll give you. A LOT of my attention."
    mc "Te daré. MUCHA de mi atención."

# game/script day2.rpy:1584
translate Spanish punishment_day2_2e314a6f_2:

    # "Jestyn nodded eagerly."
    "Jestyn asintió con entusiasmo."

# game/script day2.rpy:1586
translate Spanish punishment_day2_b484538b_2:

    # jes "Nhhh... hhhh...."
    jes "Nhhh... hhhh...."

# game/script day2.rpy:1594
translate Spanish punishment_day2_3289b8ed_4:

    # "SLAP!!!"
    "¡¡¡PLAS!!!"

# game/script day2.rpy:1596
translate Spanish punishment_day2_7a7e81dd_1:

    # jes "NGHHH!!!"
    jes "NGHHH!!!"

# game/script day2.rpy:1604
translate Spanish punishment_day2_ddcd1781_2:

    # "SLAP!!!!"
    "¡¡¡¡PLAS!!!!"

# game/script day2.rpy:1606
translate Spanish punishment_day2_5662b9b8_1:

    # jes "MNHHHNNN!!! NHH!!"
    jes "MNHHHNNN!!! NHH!!"

# game/script day2.rpy:1614
translate Spanish punishment_day2_673afd65_1:

    # "SLAP!!"
    "¡¡PLAS!!"

# game/script day2.rpy:1620
translate Spanish punishment_day2_3289b8ed_5:

    # "SLAP!!!"
    "¡¡¡PLAS!!!"

# game/script day2.rpy:1626
translate Spanish punishment_day2_ddcd1781_3:

    # "SLAP!!!!"
    "¡¡¡¡PLAS!!!!"

# game/script day2.rpy:1629
translate Spanish punishment_day2_2c118555_1:

    # jes "NGH! GHH!! NHHHHHH!!!"
    jes "NGH! GHH!! NHHHHHH!!!"

# game/script day2.rpy:1637
translate Spanish punishment_day2_83a8174f_1:

    # "!!!!!"
    "!!!!!"

# game/script day2.rpy:1640
translate Spanish punishment_day2_94250a6c_1:

    # "What... what just happened?"
    "¿Qué... qué acaba de pasar?"

# game/script day2.rpy:1641
translate Spanish punishment_day2_5ceacc20_1:

    # "For a brief moment... I felt strangely light."
    "Por un breve instante... me sentí extrañamente liger[letra]."

# game/script day2.rpy:1642
translate Spanish punishment_day2_fdb9c0b9_1:

    # "When I heard someone crying, I realized it was Jestyn."
    "Cuando oí que alguien lloraba, me di cuenta de que era Jestyn."

# game/script day2.rpy:1644
translate Spanish punishment_day2_ff1dd228_1:

    # jes ".... sob.... sob...."
    jes ".... snif.... snif...."

# game/script day2.rpy:1646
translate Spanish punishment_day2_f8f5f642_1:

    # "Oh no... What have I done?!"
    "Oh no... ¡¿Qué he hecho?!"

# game/script day2.rpy:1648
translate Spanish punishment_day2_c4b00689_1:

    # "I quickly pulled the piece of bread out of Jestyn's mouth."
    "Rápidamente saqué el trozo de pan de la boca de Jestyn."

# game/script day2.rpy:1650
translate Spanish punishment_day2_2e0989f8_1:

    # mc "JESTYN! I'm so sorry! I really am! Are you okay?!"
    mc "¡JESTYN! ¡Lo siento mucho! ¡De verdad! ¡¿Estás bien?!"

# game/script day2.rpy:1652
translate Spanish punishment_day2_d213fafa_1:

    # "But Jestyn didn't seem to hear me."
    "Pero Jestyn no parecía oírme."

# game/script day2.rpy:1654
translate Spanish punishment_day2_72c5f294_1:

    # mc "Jestyn... hey... I'm sorry... I went too far..."
    mc "Jestyn... oye... lo siento... me pasé..."

# game/script day2.rpy:1656
translate Spanish punishment_day2_95f8fb5e_1:

    # "I gently cupped his cheek, hoping it would comfort him, even just a little."
    "Le acuné suavemente la mejilla, esperando consolarlo aunque fuera un poco."

# game/script day2.rpy:1657
translate Spanish punishment_day2_c19627de_1:

    # "At last, Jestyn looked up at me."
    "Por fin, Jestyn alzó la vista hacia mí."

# game/script day2.rpy:1659
translate Spanish punishment_day2_26f7fd0a_1:

    # jes "...sob... Your Majesty... I'm sorry..."
    jes "...snif... Su Majestad... lo siento..."

# game/script day2.rpy:1660
translate Spanish punishment_day2_973df8f8_1:

    # mc "No, no, no. I'm the one who should be apologizing. I took it too far, okay?"
    mc "No, no, no. Soy yo quien debería disculparse. Me pasé de la raya, ¿de acuerdo?"

# game/script day2.rpy:1662
translate Spanish punishment_day2_8101c1b4_1:

    # jes "...Ehe... It's okay..."
    jes "...Ehe... Está bien..."

# game/script day2.rpy:1663
translate Spanish punishment_day2_a73ce39e_1:

    # jes "...I liked it..."
    jes "...Me gustó..."

# game/script day2.rpy:1665
translate Spanish punishment_day2_0e8cd77a_1:

    # jes "...Though, for a moment... I thought Your Majesty..."
    jes "...Aunque, por un momento... pensé que Su Majestad..."

# game/script day2.rpy:1667
translate Spanish punishment_day2_cdc741e0_1:

    # "Jestyn trailed off before he could finish."
    "Jestyn se quedó callado sin terminar la frase."

# game/script day2.rpy:1669
translate Spanish punishment_day2_926f99d2_1:

    # jes "...It's nothing, hehe... Don't worry about it, Your Majesty..."
    jes "...No es nada, jeje... No se preocupe por eso, Su Majestad..."

# game/script day2.rpy:1673
translate Spanish punishment_day2_5719b771_2:

    # "I think that's enough."
    "Creo que ya es suficiente."

# game/script day2.rpy:1674
translate Spanish punishment_day2_cc0ee10d:

    # "I gently caressed Jestyn's backside again."
    "Acaricié suavemente el trasero de Jestyn otra vez."

# game/script day2.rpy:1676
translate Spanish punishment_day2_efece155_2:

    # jes "Mnh... nh..."
    jes "Mnh... nh..."

# game/script day2.rpy:1678
translate Spanish punishment_day2_052b04bf_2:

    # "I finally took the piece of bread out of his mouth, allowing him to speak."
    "Por fin saqué el trozo de pan de su boca, permitiéndole hablar."

# game/script day2.rpy:1680
translate Spanish punishment_day2_0bbb3a84_2:

    # jes "Hahh... hahh... Y-Your Majesty..."
    jes "Hahh... hahh... S-Su Majestad..."

# game/script day2.rpy:1681
translate Spanish punishment_day2_a5ffb19f_2:

    # mc "Have you learned your lesson?"
    mc "¿Has aprendido la lección?"

# game/script day2.rpy:1683
translate Spanish punishment_day2_a9630362_2:

    # "Jestyn nodded."
    "Jestyn asintió."

# game/script day2.rpy:1685
translate Spanish punishment_day2_51f4b613_2:

    # mc "Then what do you say?"
    mc "Entonces, ¿qué se dice?"

# game/script day2.rpy:1686
translate Spanish punishment_day2_c260d9ac_2:

    # jes "I-I'm sorry, Your Majesty... I was wrong..."
    jes "L-Lo siento, Su Majestad... Me equivoqué..."

# game/script day2.rpy:1687
translate Spanish punishment_day2_37fa6578_2:

    # mc "Good boy."
    mc "Buen chico."

# game/script day2.rpy:1689
translate Spanish punishment_day2_54eb179b_2:

    # "I gently stroked his head, and Jestyn practically melted beneath the praise, looking genuinely happy with the affection I gave him."
    "Le acaricié suavemente la cabeza, y Jestyn prácticamente se derritió ante el elogio, luciendo genuinamente feliz con el cariño que le di."

# game/script day2.rpy:1692
translate Spanish punishment_day2_5719b771_3:

    # "I think that's enough."
    "Creo que ya es suficiente."

# game/script day2.rpy:1693
translate Spanish punishment_day2_cc0ee10d_1:

    # "I gently caressed Jestyn's backside again."
    "Acaricié suavemente el trasero de Jestyn otra vez."

# game/script day2.rpy:1695
translate Spanish punishment_day2_efece155_3:

    # jes "Mnh... nh..."
    jes "Mnh... nh..."

# game/script day2.rpy:1697
translate Spanish punishment_day2_052b04bf_3:

    # "I finally took the piece of bread out of his mouth, allowing him to speak."
    "Por fin saqué el trozo de pan de su boca, permitiéndole hablar."

# game/script day2.rpy:1699
translate Spanish punishment_day2_0bbb3a84_3:

    # jes "Hahh... hahh... Y-Your Majesty..."
    jes "Hahh... hahh... S-Su Majestad..."

# game/script day2.rpy:1700
translate Spanish punishment_day2_a5ffb19f_3:

    # mc "Have you learned your lesson?"
    mc "¿Has aprendido la lección?"

# game/script day2.rpy:1702
translate Spanish punishment_day2_a9630362_3:

    # "Jestyn nodded."
    "Jestyn asintió."

# game/script day2.rpy:1704
translate Spanish punishment_day2_51f4b613_3:

    # mc "Then what do you say?"
    mc "Entonces, ¿qué se dice?"

# game/script day2.rpy:1705
translate Spanish punishment_day2_c260d9ac_3:

    # jes "I-I'm sorry, Your Majesty... I was wrong..."
    jes "L-Lo siento, Su Majestad... Me equivoqué..."

# game/script day2.rpy:1706
translate Spanish punishment_day2_37fa6578_3:

    # mc "Good boy."
    mc "Buen chico."

# game/script day2.rpy:1708
translate Spanish punishment_day2_54eb179b_3:

    # "I gently stroked his head, and Jestyn practically melted beneath the praise, looking genuinely happy with the affection I gave him."
    "Le acaricié suavemente la cabeza, y Jestyn prácticamente se derritió ante el elogio, luciendo genuinamente feliz con el cariño que le di."

# game/script day2.rpy:1712
translate Spanish punishment_day2_bfbd85df:

    # jes "...Hehe... Time for the main course, Your Majesty."
    jes "...Jeje... Es hora del plato principal, Su Majestad."

# game/script day2.rpy:1715
translate Spanish punishment_day2_a0f212c3:

    # "Jestyn picked up the main dish. A steak served with mashed potatoes."
    "Jestyn tomó el plato principal. Un filete acompañado de puré de papas."

# game/script day2.rpy:1716
translate Spanish punishment_day2_1cc8ce09:

    # "I could see his hands trembling with anticipation."
    "Podía ver sus manos temblar de anticipación."

# game/script day2.rpy:1719
translate Spanish punishment_day2_1bb175bc:

    # jes "The main course was a steak with BBQ sauce, served alongside a generous helping of mashed potatoes."
    jes "El plato principal era un filete con salsa BBQ, servido junto a una generosa porción de puré de papas."

# game/script day2.rpy:1721
translate Spanish punishment_day2_0ace39cc:

    # jes "Please, enjoy your meal, Your Majesty... Or perhaps... would Your Majesty like me to feed you instead~?"
    jes "Por favor, disfrute su comida, Su Majestad... O quizás... ¿preferiría Su Majestad que yo le diera de comer~?"

# game/script day2.rpy:1723
translate Spanish punishment_day2_bbe123dc:

    # "I thought about it for a moment. That... wasn't such a bad idea."
    "Lo pensé un momento. Eso... no era tan mala idea."

# game/script day2.rpy:1726
translate Spanish punishment_day2_80da971c:

    # jes "...With my mouth."
    jes "...Con mi boca."

# game/script day2.rpy:1727
translate Spanish punishment_day2_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:1729
translate Spanish punishment_day2_94893f11:

    # "I can feel my cheeks heat up. Damn it. It's so hot."
    "Siento cómo me sube el calor a las mejillas. Maldita sea. Qué calor hace."

# game/script day2.rpy:1730
translate Spanish punishment_day2_f7952998:

    # "I hate it the fact that I'm not against that idea."
    "Odio que no me oponga a esa idea."

# game/script day2.rpy:1731
translate Spanish punishment_day2_bf7007be:

    # mc "Then, go on... Feed me, my jester."
    mc "Entonces, adelante... Aliméntame, mi bufón."

# game/script day2.rpy:1732
translate Spanish punishment_day2_ed286f09:

    # jes "...As You command, Your Majesty."
    jes "...Como ordene, Su Majestad."

# game/script day2.rpy:1735
translate Spanish punishment_day2_4391c37c:

    # "Jestyn picked up a piece of steak with his mouth and leaned toward me."
    "Jestyn tomó un trozo de filete con la boca y se inclinó hacia mí."

# game/script day2.rpy:1736
translate Spanish punishment_day2_6ca679bc:

    # "I bit into the other end."
    "Mordí el otro extremo."

# game/script day2.rpy:1737
translate Spanish punishment_day2_5b902068:

    # "It tasted like grilled beef with a rich barbecue sauce, though the flavors were far deeper, layered with fragrant herbs and spices. It was delicious."
    "Sabía a carne asada con una rica salsa barbacoa, aunque los sabores eran mucho más profundos, con capas de hierbas y especias aromáticas. Estaba delicioso."

# game/script day2.rpy:1738
translate Spanish punishment_day2_475b6333:

    # "But more than the food itself... what captivated me was seeing Jestyn submit so obediently."
    "Pero más que la comida en sí... lo que me cautivaba era ver a Jestyn someterse con tanta obediencia."

# game/script day2.rpy:1741
translate Spanish punishment_day2_736421e8:

    # "I took another bite."
    "Di otro mordisco."

# game/script day2.rpy:1742
translate Spanish punishment_day2_f9906a1f:

    # "Our lips nearly brushed against each other, making Jestyn let out a shaky breath."
    "Nuestros labios casi se rozaron, haciendo que Jestyn soltara un aliento tembloroso."

# game/script day2.rpy:1743
translate Spanish punishment_day2_25e8408d:

    # "With a soft, desperate whine, he nudged the remaining piece of steak toward me, silently asking me to finish it."
    "Con un quejido suave y desesperado, empujó el trozo de filete restante hacia mí, pidiéndome en silencio que lo terminara."

# game/script day2.rpy:1744
translate Spanish punishment_day2_9018b8bc:

    # "He is getting needy, isn't he?"
    "Se está volviendo necesitado, ¿no es cierto?"

# game/script day2.rpy:1746
translate Spanish punishment_day2_75e93509:

    # mc "No, Jestyn. Good boys know how to behave, don't they?"
    mc "No, Jestyn. Los buenos chicos saben comportarse, ¿no es así?"

# game/script day2.rpy:1748
translate Spanish punishment_day2_1014a52c:

    # "He froze for a sec, before then he gave a small nod of understanding."
    "Se quedó helado un segundo, y luego hizo un pequeño gesto de asentimiento en señal de comprensión."

# game/script day2.rpy:1752
translate Spanish punishment_day2_3fc58521:

    # "I gently stroked his cheek. Jestyn closed his eyes and leaned into my touch."
    "Le acaricié suavemente la mejilla. Jestyn cerró los ojos y se apoyó en mi toque."

# game/script day2.rpy:1753
translate Spanish punishment_day2_a7e6cf61:

    # "He loved every second of it."
    "Disfrutó cada segundo."

# game/script day2.rpy:1754
translate Spanish punishment_day2_5776a57f:

    # "Watching him become so obedient, almost like a loyal little puppy, was unexpectedly adorable. I couldn't help but feel a gentle warmth bloom inside my chest."
    "Verlo volverse tan obediente, casi como un leal cachorrito, era inesperadamente adorable. No pude evitar sentir cómo florecía una cálida ternura en mi pecho."

# game/script day2.rpy:1758
translate Spanish punishment_day2_d2290fa3:

    # voice "JESTYN03_DAY2.ogg"
    # jes ".... Am I a good boy, Your Majesty..?"
    voice "JESTYN03_DAY2.ogg"
    jes ".... ¿Soy un buen chico, Su Majestad..?"

# game/script day2.rpy:1761
translate Spanish punishment_day2_51b6be65:

    # mc "Yes. You've been such a good boy, Jestyn."
    mc "Sí. Has sido un muy buen chico, Jestyn."

# game/script day2.rpy:1763
translate Spanish punishment_day2_323089b6:

    # jes "Now then~ this jester's been such a good little fool for Your Majesty. Surely that earns me a reward, doesn't it?"
    jes "Ahora bien~ este bufón ha sido un buen y pequeño necio para Su Majestad. Seguro que eso merece una recompensa, ¿no es así?"

# game/script day2.rpy:1764
translate Spanish punishment_day2_95514956:

    # mc ".... A reward?"
    mc ".... ¿Una recompensa?"

# game/script day2.rpy:1765
translate Spanish punishment_day2_435608b7:

    # jes "Mmh..."
    jes "Mmh..."

# game/script day2.rpy:1767
translate Spanish punishment_day2_2e314a6f_3:

    # "Jestyn nodded eagerly."
    "Jestyn asintió con entusiasmo."

# game/script day2.rpy:1768
translate Spanish punishment_day2_a51a067f:

    # "Ah yes... a reward that's right..."
    "Ah, sí... una recompensa, eso es..."

# game/script day2.rpy:1769
translate Spanish punishment_day2_f4ae934b:

    # "I leaned in and took the last piece of steak from between his lips."
    "Me incliné y tomé el último trozo de filete de entre sus labios."

# game/script day2.rpy:1771
translate Spanish punishment_day2_9fa1a25b:

    # "For the briefest moment, my tongue brushed against his as I took it."
    "Por un instante brevísimo, mi lengua rozó la suya al tomarlo."

# game/script day2.rpy:1772
translate Spanish punishment_day2_99b6d26e:

    # "It was soft... smooth... unmistakably warm."
    "Era suave... lisa... inconfundiblemente cálida."

# game/script day2.rpy:1773
translate Spanish punishment_day2_94930984:

    # "He let out another needy whine."
    "Soltó otro quejido necesitado."

# game/script day2.rpy:1776
translate Spanish punishment_day2_08a328b7:

    # jes "Your Majesty... why... why was it only for a moment...?"
    jes "Su Majestad... por qué... ¿por qué fue solo un instante...?"

# game/script day2.rpy:1777
translate Spanish punishment_day2_07a338c7:

    # mc "What's wrong? Wasn't that reward enough?"
    mc "¿Qué pasa? ¿No fue suficiente recompensa?"

# game/script day2.rpy:1779
translate Spanish punishment_day2_a17e9e79:

    # "He fidgeted for a moment before giving a timid nod."
    "Se removió un momento antes de asentir tímidamente."

# game/script day2.rpy:1781
translate Spanish punishment_day2_6d369b96:

    # jes "Mmmnh... this jester is terribly greedy, isn't he, Your Majesty? A single drop of sweet honey could never satisfy me..."
    jes "Mmmnh... este bufón es terriblemente codicioso, ¿no es cierto, Su Majestad? Una sola gota de dulce miel jamás podría saciarme..."

# game/script day2.rpy:1783
translate Spanish punishment_day2_8712f16e:

    # "Jestyn pauses for a moment."
    "Jestyn hace una pausa."

# game/script day2.rpy:1786
translate Spanish punishment_day2_6afb25cb:

    # jes "Does that mean... this jester must offer a piece of gold... something far more precious... if he wishes to earn more than just a single drop of honey from Your Majesty?"
    jes "¿Significa eso... que este bufón debe ofrecer una pieza de oro... algo mucho más preciado... si desea ganar de Su Majestad algo más que una sola gota de miel?"

# game/script day2.rpy:1788
translate Spanish punishment_day2_13c98b39:

    # "Though he never says it outright, Jestyn is clearly hinting that I could ask him to give me something more..."
    "Aunque nunca lo dice abiertamente, Jestyn está insinuando claramente que podría pedirle algo más..."

# game/script day2.rpy:1789
translate Spanish punishment_day2_f8080dc6:

    # "Something worthy of a greater reward."
    "Algo digno de una mayor recompensa."

# game/script day2.rpy:1790
translate Spanish punishment_day2_89fae4f2:

    # "I see now."
    "Ya veo."

# game/script day2.rpy:1792
translate Spanish punishment_day2_fc64050b:

    # mc "And what exactly have you done to deserve something more?"
    mc "¿Y qué has hecho exactamente para merecer algo más?"

# game/script day2.rpy:1794
translate Spanish punishment_day2_7000c4e2:

    # jes "I-I...!"
    jes "Y-Yo...!"

# game/script day2.rpy:1796
translate Spanish punishment_day2_26565bd8:

    # jes "Your humble jester would do anything Your Majesty asks of me."
    jes "Este humilde bufón haría cualquier cosa que Su Majestad le pida."

# game/script day2.rpy:1798
translate Spanish punishment_day2_6e4a9d47:

    # jes "Just... give me Your Majesty's attention... I promise I'll behave..."
    jes "Solo... présteme la atención de Su Majestad... prometo que me portaré bien..."

# game/script day2.rpy:1799
translate Spanish punishment_day2_8fea2db2:

    # mc "Hmm..."
    mc "Mmm..."

# game/script day2.rpy:1801
translate Spanish punishment_day2_a818f3a6:

    # "I picked up a piece of steak and held it between my lips."
    "Tomé un trozo de filete y lo sostuve entre mis labios."

# game/script day2.rpy:1802
translate Spanish punishment_day2_c1e77cb6:

    # "Then, I offered it to Jestyn."
    "Luego se lo ofrecí a Jestyn."

# game/script day2.rpy:1805
translate Spanish punishment_day2_957f02c3:

    # jes "Your... Your Majesty... that's..."
    jes "Su... Su Majestad... eso es..."

# game/script day2.rpy:1807
translate Spanish punishment_day2_148115d7:

    # "Jestyn's eyes widened, and he couldn't suppress the grin spreading across his face, brimming with anticipation."
    "Los ojos de Jestyn se abrieron de par en par, y no pudo reprimir la sonrisa que se extendía por su rostro, rebosante de anticipación."

# game/script day2.rpy:1808
translate Spanish punishment_day2_ebc74456:

    # "But seeing my impatience, Jestyn slowly leaned in."
    "Pero al ver mi impaciencia, Jestyn se inclinó lentamente."

# game/script day2.rpy:1811
translate Spanish punishment_day2_2a46d638:

    # jes "Then... if you'll excuse me..."
    jes "Entonces... con su permiso..."

# game/script day2.rpy:1814
translate Spanish punishment_day2_bd2bc290:

    # "Jestyn gently bit down on the opposite end of the piece of meat I was holding between my lips."
    "Jestyn mordió con suavidad el extremo opuesto del trozo de carne que yo sostenía entre los labios."

# game/script day2.rpy:1815
translate Spanish punishment_day2_7cc32a4b:

    # "I could tell he wasn't paying any attention to the meat itself, nor its taste."
    "Pude notar que no le prestaba atención alguna a la carne en sí, ni a su sabor."

# game/script day2.rpy:1816
translate Spanish punishment_day2_a8e2f5d2:

    # "His eyes never left mine as he took slow, deliberate bites, as though savoring the moment far more than the meal."
    "Sus ojos nunca se apartaron de los míos mientras daba bocados lentos y deliberados, como si saboreara el momento mucho más que la comida."

# game/script day2.rpy:1817
translate Spanish punishment_day2_95c92a50:

    # "Our eyes remained locked on each other."
    "Nuestras miradas permanecieron fijas la una en la otra."

# game/script day2.rpy:1818
translate Spanish punishment_day2_a629b6e7:

    # "As much as I tried to act like a seasoned dom, I couldn't stop the heat creeping into my cheeks or the frantic pounding of my heart."
    "Por más que intentaba actuar como un dom experimentado, no podía evitar que el calor me subiera a las mejillas ni que mi corazón latiera frenéticamente."

# game/script day2.rpy:1819
translate Spanish punishment_day2_29df5578:

    # "His gaze was making me blush. Even so, I did everything I could to keep from faltering."
    "Su mirada me hacía sonrojar. Aun así, hice todo lo posible por no flaquear."

# game/script day2.rpy:1820
translate Spanish punishment_day2_9ba78eb9:

    # "After swallowing, Jestyn took another bite, never once breaking eye contact."
    "Tras tragar, Jestyn dio otro mordisco, sin romper el contacto visual ni una sola vez."

# game/script day2.rpy:1821
translate Spanish punishment_day2_7f85922c:

    # "At this point, I thought I was going to lose my mind."
    "A estas alturas, creía que iba a perder la cabeza."

# game/script day2.rpy:1822
translate Spanish punishment_day2_b71899fb:

    # "What caught me completely off guard was when he stopped trying to bite the remaining piece of meat."
    "Lo que me tomó completamente por sorpresa fue que dejó de intentar morder el trozo de carne que quedaba."

# game/script day2.rpy:1823
translate Spanish punishment_day2_e4b70b10:

    # "Instead, he slowly ran his tongue along its tip... slowly... deliberately... inch by inch, his tongue traced its way higher."
    "En cambio, deslizó lentamente la lengua por su punta... despacio... deliberadamente... centímetro a centímetro, su lengua fue trazando un camino cada vez más arriba."

# game/script day2.rpy:1824
translate Spanish punishment_day2_9ac2c835:

    # "My mind struggled to process what he was doing until a soft sensation brushed against my lower lip."
    "Mi mente se esforzaba por procesar lo que hacía hasta que una sensación suave me rozó el labio inferior."

# game/script day2.rpy:1825
translate Spanish punishment_day2_46913501:

    # "Jestyn's tongue had reached my lips, gently grazing my lower lip with slow, deliberate strokes."
    "La lengua de Jestyn había llegado a mis labios, rozando suavemente mi labio inferior con caricias lentas y deliberadas."

# game/script day2.rpy:1826
translate Spanish punishment_day2_d73c3764:

    # "Startled, I quickly pulled myself back from Jestyn."
    "Sobresaltad[letra], me eché hacia atrás de golpe, apartándome de Jestyn."

# game/script day2.rpy:1827
translate Spanish punishment_day2_8fd4410c:

    # "And my face flushed uncontrollably."
    "Y mi rostro se sonrojó sin control."

# game/script day2.rpy:1829
translate Spanish punishment_day2_e49114ed:

    # mc "Jestyn, what are you-"
    mc "Jestyn, ¿qué estás-"

# game/script day2.rpy:1831
translate Spanish punishment_day2_9f1688c1:

    # "Jestyn simply laughed at my reaction."
    "Jestyn simplemente rio ante mi reacción."

# game/script day2.rpy:1834
translate Spanish punishment_day2_5f97f541:

    # jes "Mmmh~ You look so very sexy when you're trying to dominate me, Your Majesty..."
    jes "Mmmh~ Se ve tan sumamente sexy cuando intenta dominarme, Su Majestad..."

# game/script day2.rpy:1836
translate Spanish punishment_day2_cd5563b9:

    # jes "But this wild, mischievous little soul of mine... it's like trying to keep a monkey on a leash. I simply can't help myself."
    jes "Pero esta alma mía, salvaje y traviesa... es como intentar mantener a un mono con correa. Simplemente no puedo evitarlo."

# game/script day2.rpy:1837
translate Spanish punishment_day2_e085ce04:

    # jes "And it seems Your Majesty is nothing more than a sheep wearing a wolf's clothing after all. Haha~"
    jes "Y parece que Su Majestad no es más que una oveja con piel de lobo, después de todo. Jaja~"

# game/script day2.rpy:1839
translate Spanish punishment_day2_d7c6cb1c:

    # "He said it with an unmistakably mocking grin."
    "Lo dijo con una sonrisa burlona inconfundible."

# game/script day2.rpy:1840
translate Spanish punishment_day2_36f0fb4e:

    # "If I didn't know Jestyn as well as I did, I might've taken those words at face value."
    "Si no conociera a Jestyn tan bien como lo conocía, quizás habría tomado esas palabras al pie de la letra."

# game/script day2.rpy:1841
translate Spanish punishment_day2_c0af7d84:

    # "But I knew better. Even now, he was just trying to provoke me. Honestly... it was almost impressive."
    "Pero yo lo conocía mejor. Incluso ahora, solo intentaba provocarme. Sinceramente... era casi impresionante."

# game/script day2.rpy:1843
translate Spanish punishment_day2_d9a305cc:

    # mc "Jestyn, I thought you wanted a reward?"
    mc "Jestyn, ¿no que querías una recompensa?"

# game/script day2.rpy:1845
translate Spanish punishment_day2_5ee53402:

    # jes "Oh, I certainly do~ But like I said... I simply can't stop myself from being... naughty."
    jes "Oh, claro que sí~ Pero como dije... simplemente no puedo evitar ser... travieso."

# game/script day2.rpy:1846
translate Spanish punishment_day2_fef3593a:

    # jes "Especially... when it comes to Your Majesty. Ehehe~"
    jes "Sobre todo... cuando se trata de Su Majestad. Ehehe~"

# game/script day2.rpy:1848
translate Spanish punishment_day2_ae12902f:

    # "So... he still wanted to act like a brat."
    "Así que... todavía quería seguir portándose como un malcriado."

# game/script day2.rpy:1849
translate Spanish punishment_day2_47db4924:

    # "Something told me I needed to make him a little more obedient."
    "Algo me dijo que necesitaba hacerlo un poco más obediente."

# game/script day2.rpy:1850
translate Spanish punishment_day2_dba47c01:

    # "And I think, creativity hit my head."
    "Y creo que me vino una idea creativa a la cabeza."

# game/script day2.rpy:1852
translate Spanish punishment_day2_9c803a24:

    # mc "I think it's time for dessert, right?"
    mc "Creo que es hora del postre, ¿no?"

# game/script day2.rpy:1854
translate Spanish punishment_day2_06a6741c:

    # jes "Yes it is... time for dessert, Your Majesty."
    jes "Así es... hora del postre, Su Majestad."

# game/script day2.rpy:1856
translate Spanish punishment_day2_11732597:

    # "He picked up a slice of chocolate cake topped with strawberry jam. And he offered the cake to me."
    "Tomó una rebanada de pastel de chocolate con mermelada de fresa encima. Y me ofreció el pastel."

# game/script day2.rpy:1858
translate Spanish punishment_day2_a3236c1b:

    # mc "Jestyn... I think you should have the first taste."
    mc "Jestyn... creo que deberías probarlo tú primero."

# game/script day2.rpy:1860
translate Spanish punishment_day2_806047a0:

    # jes "Hm? And why might that be, Your Majesty?"
    jes "¿Hm? ¿Y por qué sería eso, Su Majestad?"

# game/script day2.rpy:1862
translate Spanish punishment_day2_48a56601:

    # "I gently lifted his chin before softly caressing it."
    "Le levanté suavemente la barbilla antes de acariciarla con ternura."

# game/script day2.rpy:1865
translate Spanish punishment_day2_663f5536:

    # "He jolted from my sudden movement."
    "Se sobresaltó por mi movimiento repentino."

# game/script day2.rpy:1867
translate Spanish punishment_day2_fe4aa652:

    # "I dabbed a bit of the strawberry jam from the top of the cake onto my fingertip, then held it out toward him."
    "Tomé un poco de mermelada de fresa de la parte superior del pastel con la punta del dedo y se la acerqué."

# game/script day2.rpy:1868
translate Spanish punishment_day2_d1c24535:

    # "Jestyn blinked, taking a moment to process what I was doing. Then a knowing laugh escaped him."
    "Jestyn parpadeó, tardando un momento en procesar lo que hacía. Luego se le escapó una risa cómplice."

# game/script day2.rpy:1871
translate Spanish punishment_day2_0c881347:

    # jes "My, my... It seems Your Majesty has begun to understand this humble jester rather well."
    jes "Vaya, vaya... Parece que Su Majestad ha comenzado a comprender bastante bien a este humilde bufón."

# game/script day2.rpy:1872
translate Spanish punishment_day2_41b8cef6:

    # jes "Now, how could I possibly refuse such a gracious offering from the Crown?"
    jes "Ahora bien, ¿cómo podría rechazar una oferta tan generosa de la Corona?"

# game/script day2.rpy:1873
translate Spanish punishment_day2_e9e16a29:

    # mc "Then, open your mouth..."
    mc "Entonces, abre la boca..."

# game/script day2.rpy:1875
translate Spanish punishment_day2_3fd32211:

    # "My fingers traveled higher. Slowly traced up to his lips until I slowly slipped one into his mouth."
    "Mis dedos subieron. Trazaron lentamente el camino hasta sus labios y, poco a poco, deslicé uno dentro de su boca."

# game/script day2.rpy:1877
translate Spanish punishment_day2_9fa74339:

    # "Jestyn gently took hold of my wrist and tasted the strawberry jam from my fingertip."
    "Jestyn tomó con delicadeza mi muñeca y probó la mermelada de fresa de la punta de mi dedo."

# game/script day2.rpy:1878
translate Spanish punishment_day2_18566c85:

    # "The strawberry jam on my index finger was slowly licked away by Jestyn's tongue. His movements were slow and careful."
    "La mermelada de fresa de mi dedo índice fue lamida lentamente por la lengua de Jestyn. Sus movimientos eran lentos y cuidadosos."

# game/script day2.rpy:1879
translate Spanish punishment_day2_1c991bb7:

    # "Throughout it all, his glowing red eyes never left mine."
    "Durante todo el rato, sus ojos rojos y brillantes nunca se apartaron de los míos."

# game/script day2.rpy:1881
translate Spanish punishment_day2_b206cba5:

    # "He noticed my flushed expression, and his smile widened with satisfaction."
    "Notó mi expresión sonrojada, y su sonrisa se ensanchó con satisfacción."

# game/script day2.rpy:1882
translate Spanish punishment_day2_2ae54518:

    # "As if he wanted to see more of my reaction, Jestyn slowed his movements even further, making each motion more deliberate and teasing."
    "Como si quisiera ver más de mi reacción, Jestyn ralentizó aún más sus movimientos, haciendo cada gesto más deliberado y provocador."

# game/script day2.rpy:1883
translate Spanish punishment_day2_3e1ac522:

    # "Damn it... somehow, he only managed to make my cheeks burn even hotter and leave me even more flustered."
    "Maldita sea... de algún modo, solo logró que mis mejillas ardieran aún más y que me sintiera todavía más alterad[letra]."

# game/script day2.rpy:1884
translate Spanish punishment_day2_dc4fd5c6:

    # "My reaction only seemed to feed his ego."
    "Mi reacción pareció alimentar su ego."

# game/script day2.rpy:1885
translate Spanish punishment_day2_0187ba54:

    # "Ugh... I had to remember that I was the one in charge here. I wasn't going to let him take control whenever he pleased."
    "Ugh... tenía que recordar que yo era quien mandaba aquí. No iba a dejar que tomara el control cada vez que se le antojara."

# game/script day2.rpy:1886
translate Spanish punishment_day2_42ba1aeb:

    # "But what was I supposed to do...?"
    "Pero ¿qué se suponía que debía hacer...?"

# game/script day2.rpy:1887
translate Spanish punishment_day2_5f9b772e:

    # "...."
    "...."

# game/script day2.rpy:1890
translate Spanish punishment_day2_5f3e16dc:

    # "I don't even know what came over me. On impulse, I grabbed his tongue."
    "Ni siquiera sé qué se apoderó de mí. Por impulso, le agarré la lengua."

# game/script day2.rpy:1892
translate Spanish punishment_day2_e0ac5919:

    # "And Jestyn immediately let out a startled yelp."
    "Y Jestyn soltó de inmediato un chillido de sorpresa."

# game/script day2.rpy:1893
translate Spanish punishment_day2_615e55a0:

    # "It felt smooth and velvety beneath my fingertips."
    "Se sentía suave y aterciopelada bajo las yemas de mis dedos."

# game/script day2.rpy:1894
translate Spanish punishment_day2_28950e31:

    # "His tongue was black, yet it felt no different from a human's... aside from its unusual color."
    "Su lengua era negra, pero se sentía igual que la de un humano... aparte de su inusual color."

# game/script day2.rpy:1896
translate Spanish punishment_day2_042a5a2a:

    # "He start to moan from the sensation."
    "Empezó a gemir por la sensación."

# game/script day2.rpy:1898
translate Spanish punishment_day2_899764e9:

    # jes "A-Ah... hnn... hah... Y-Your... Majesty..."
    jes "A-Ah... hnn... hah... S-Su... Majestad..."

# game/script day2.rpy:1899
translate Spanish punishment_day2_253be8db:

    # jes "C-Could I... may I... nnh..."
    jes "¿P-Podría... puedo... nnh..."

# game/script day2.rpy:1900
translate Spanish punishment_day2_fef43c01:

    # mc "May you what?"
    mc "¿Puedes qué?"

# game/script day2.rpy:1901
translate Spanish punishment_day2_d4c98f9e:

    # jes "...I want..."
    jes "...Quiero..."

# game/script day2.rpy:1902
translate Spanish punishment_day2_707bbf3a:

    # jes "...to lick Your Majesty's arm."
    jes "...lamer el brazo de Su Majestad."

# game/script day2.rpy:1904
translate Spanish punishment_day2_0e37b70d:

    # "I froze at Jestyn's request. It was the last thing I had expected to hear."
    "Me quedé helad[letra] ante la petición de Jestyn. Era lo último que esperaba oír."

# game/script day2.rpy:1905
translate Spanish punishment_day2_4f619980:

    # "I could feel my cheeks growing warm, but..."
    "Podía sentir cómo mis mejillas se calentaban, pero..."

# game/script day2.rpy:1909
translate Spanish punishment_day2_514c4ce3:

    # mc "Mmm... I think you deserve it, Jestyn. Go on."
    mc "Mmm... creo que te lo mereces, Jestyn. Adelante."

# game/script day2.rpy:1911
translate Spanish punishment_day2_0f8b1f98:

    # "I gave him permission."
    "Le di permiso."

# game/script day2.rpy:1913
translate Spanish punishment_day2_df7e92b3:

    # "Jestyn's tongue slowly extended, curling gently around my arm."
    "La lengua de Jestyn se extendió lentamente, enroscándose con suavidad alrededor de mi brazo."

# game/script day2.rpy:1914
translate Spanish punishment_day2_30fa004b:

    # "I flinched in surprise. I hadn't expected his tongue to stretch that far."
    "Me estremecí de sorpresa. No esperaba que su lengua se estirara tanto."

# game/script day2.rpy:1915
translate Spanish punishment_day2_2156107b:

    # "It glided slowly and sensually along my skin, the sensation strangely ticklish, almost like the touch of a tentacle."
    "Se deslizó despacio y sensualmente por mi piel, la sensación extrañamente cosquilleante, casi como el roce de un tentáculo."

# game/script day2.rpy:1916
translate Spanish punishment_day2_ebf2d682:

    # "My free hand found his cheek, gently caressing it as he instinctively leaned into my palm once again while I continued stroking his tongue."
    "Mi mano libre encontró su mejilla, acariciándola con suavidad mientras él se inclinaba instintivamente contra mi palma una vez más y yo seguía acariciándole la lengua."

# game/script day2.rpy:1917
translate Spanish punishment_day2_42ae7cd0:

    # "Just looking at him, it was obvious how overwhelmed he was. His body trembled, his face was flushed and damp with sweat, and his breathing came in shaky, uneven breaths."
    "Con solo mirarlo, era obvio lo abrumado que estaba. Su cuerpo temblaba, su rostro estaba sonrojado y húmedo de sudor, y su respiración salía en bocanadas temblorosas e irregulares."

# game/script day2.rpy:1920
translate Spanish punishment_day2_76a23e70:

    # mc "No, Jestyn. I need to dicipline you. Have a little more patience and I will reward you with something more."
    mc "No, Jestyn. Necesito disciplinarte. Ten un poco más de paciencia y te recompensaré con algo más."

# game/script day2.rpy:1921
translate Spanish punishment_day2_087e34a2:

    # jes "Hnnnhhh~...."
    jes "Hnnnhhh~...."

# game/script day2.rpy:1923
translate Spanish punishment_day2_296ac6e2:

    # "What would happen if I pressed down on his tongue?"
    "¿Qué pasaría si presionara su lengua?"

# game/script day2.rpy:1924
translate Spanish punishment_day2_e1fb655c:

    # "Curiosity got the better of me, and I gently pressed down on Jestyn's tongue."
    "La curiosidad pudo conmigo, y presioné suavemente la lengua de Jestyn."

# game/script day2.rpy:1926
translate Spanish punishment_day2_aa315218:

    # jes "Hnngghh- h-ahh..."
    jes "Hnngghh- h-ahh..."

# game/script day2.rpy:1928
translate Spanish punishment_day2_c044bd0c:

    # "Jestyn's reaction felt like a green light, so I continued, rubbing his tongue a little more firmly."
    "La reacción de Jestyn se sintió como luz verde, así que continué, frotando su lengua con un poco más de firmeza."

# game/script day2.rpy:1930
translate Spanish punishment_day2_0562e4c8:

    # jes "Ahh- y-your-... ah-"
    jes "Ahh- s-su-... ah-"

# game/script day2.rpy:1932
translate Spanish punishment_day2_ebf2d682_1:

    # "My free hand found his cheek, gently caressing it as he instinctively leaned into my palm once again while I continued stroking his tongue."
    "Mi mano libre encontró su mejilla, acariciándola con suavidad mientras él se inclinaba instintivamente contra mi palma una vez más y yo seguía acariciándole la lengua."

# game/script day2.rpy:1933
translate Spanish punishment_day2_42ae7cd0_1:

    # "Just looking at him, it was obvious how overwhelmed he was. His body trembled, his face was flushed and damp with sweat, and his breathing came in shaky, uneven breaths."
    "Con solo mirarlo, era obvio lo abrumado que estaba. Su cuerpo temblaba, su rostro estaba sonrojado y húmedo de sudor, y su respiración salía en bocanadas temblorosas e irregulares."

# game/script day2.rpy:1935
translate Spanish punishment_day2_f34a97c8:

    # "After a while, I finally withdrew my finger from his mouth, allowing Jestyn to catch his breath."
    "Después de un rato, por fin retiré el dedo de su boca, permitiendo que Jestyn recuperara el aliento."

# game/script day2.rpy:1938
translate Spanish punishment_day2_50e0522a:

    # jes "Hah... hah..."
    jes "Hah... hah..."

# game/script day2.rpy:1940
translate Spanish punishment_day2_6602c44b:

    # "He steadied his breathing, taking a few moments to compose himself before looking back at me with a cheeky smile."
    "Estabilizó su respiración, tomándose unos instantes para recomponerse antes de volver a mirarme con una sonrisa descarada."

# game/script day2.rpy:1942
translate Spanish punishment_day2_aa0d73cc:

    # jes "...He... hehe... Your Majesty is becoming remarkably skilled at this..."
    jes "...Je... jeje... Su Majestad se está volviendo notablemente hábil en esto..."

# game/script day2.rpy:1944
translate Spanish punishment_day2_5be9dee1:

    # mc "Good?"
    mc "¿Te gustó?"

# game/script day2.rpy:1946
translate Spanish punishment_day2_4a46479f:

    # "Jestyn nodded, still looking slightly dazed from the moment we'd just shared."
    "Jestyn asintió, todavía algo aturdido por el momento que acabábamos de compartir."

# game/script day2.rpy:1947
translate Spanish punishment_day2_9ae2fef2:

    # "I reached over and gently ruffled his hair."
    "Me acerqué y le alboroté el cabello con suavidad."

# game/script day2.rpy:1949
translate Spanish punishment_day2_eb734514:

    # mc "You've been such a good boy, Jestyn."
    mc "Has sido un muy buen chico, Jestyn."

# game/script day2.rpy:1950
translate Spanish punishment_day2_890ae4b5:

    # jes "Mmh... Thank you, Your Majesty..."
    jes "Mmh... Gracias, Su Majestad..."

# game/script day2.rpy:1951
translate Spanish punishment_day2_50b67dbd:

    # mc "Drink something."
    mc "Bebe algo."

# game/script day2.rpy:1952
translate Spanish punishment_day2_d65273a5:

    # jes "...I don't need to drink, Your Majesty..."
    jes "...No necesito beber, Su Majestad..."

# game/script day2.rpy:1954
translate Spanish punishment_day2_b56966a7:

    # mc "That's an order, Jestyn. I know you don't need it, but maybe it'll help clear your head."
    mc "Es una orden, Jestyn. Sé que no lo necesitas, pero quizás te ayude a despejar la cabeza."

# game/script day2.rpy:1956
translate Spanish punishment_day2_baf9ad5c:

    # "Even though I knew he'd said it had no real effect on their kind."
    "Aunque sabía que él había dicho que no tenía ningún efecto real en los de su especie."

# game/script day2.rpy:1958
translate Spanish punishment_day2_94fb1996:

    # mc "...Or are you planning to disobey me again?"
    mc "...¿O planeas desobedecerme otra vez?"

# game/script day2.rpy:1960
translate Spanish punishment_day2_d0ca9c95:

    # jes "Mmmhhh..."
    jes "Mmmhhh..."

# game/script day2.rpy:1962
translate Spanish punishment_day2_d50068cf:

    # "At my command, Jestyn picked up the glass of water and drank it."
    "Por mi orden, Jestyn tomó el vaso de agua y se lo bebió."

# game/script day2.rpy:1964
translate Spanish punishment_day2_bbea7d17:

    # mc "Feeling better?"
    mc "¿Te sientes mejor?"

# game/script day2.rpy:1966
translate Spanish punishment_day2_4e459a49:

    # jes "...Yes..."
    jes "...Sí..."

# game/script day2.rpy:1967
translate Spanish punishment_day2_3b21f354_1:

    # mc "......"
    mc "......"

# game/script day2.rpy:1968
translate Spanish punishment_day2_35d1c0ed:

    # mc "Sorry, Jestyn... I think I was a little too rough earlier. I wasn't really thinking."
    mc "Perdona, Jestyn... creo que fui un poco brusc[letra] hace rato. No estaba pensando realmente."

# game/script day2.rpy:1970
translate Spanish punishment_day2_bc5bbcea:

    # "Jestyn simply laughed."
    "Jestyn simplemente rio."

# game/script day2.rpy:1973
translate Spanish punishment_day2_aea8303b:

    # jes "Whatever are You apologizing for, Your Majesty? What you did was hardly anything compared to what this poor jester has endured."
    jes "¿De qué se disculpa, Su Majestad? Lo que hizo apenas fue nada comparado con lo que este pobre bufón ha soportado."

# game/script day2.rpy:1974
translate Spanish punishment_day2_dd9fd80d:

    # jes "You're still like a little fledgling taking its very first steps, Your Majesty. Hehe... Surely you didn't think you'd become that skilled overnight~?"
    jes "Todavía es como un polluelo dando sus primeros pasos, Su Majestad. Jeje... ¿Seguro que no pensó que se volvería tan hábil de la noche a la mañana~?"

# game/script day2.rpy:1975
translate Spanish punishment_day2_39369a89:

    # mc "...I'm trying to be nice here, and you repay me with insults. Impressive."
    mc "...Estoy intentando ser amable y me pagas con insultos. Impresionante."

# game/script day2.rpy:1978
translate Spanish punishment_day2_d38deca2:

    # jes "Hahaha! Your Majesty will simply have to grow accustomed to this jester's mockery~"
    jes "¡Jajaja! Su Majestad simplemente tendrá que acostumbrarse a las burlas de este bufón~"

# game/script day2.rpy:1984
translate Spanish let_it_slide_a99b892e:

    # "...He really is annoying, and I really want to punish Jestyn."
    "...De verdad es molesto, y de verdad quiero castigar a Jestyn."

# game/script day2.rpy:1985
translate Spanish let_it_slide_03f33fcd:

    # "But on the other hand, I'm not really in the mood to play."
    "Pero, por otro lado, no tengo ganas de jugar."

# game/script day2.rpy:1987
translate Spanish let_it_slide_cb904ddb:

    # mc "You're lucky, Jestyn. I'm not in the mood to punish you."
    mc "Tienes suerte, Jestyn. No tengo ganas de castigarte."

# game/script day2.rpy:1990
translate Spanish let_it_slide_ecccf6d0:

    # "Jestyn's grin slowly turned into a pout."
    "El gesto sonriente de Jestyn se fue transformando poco a poco en un puchero."

# game/script day2.rpy:1992
translate Spanish let_it_slide_56d40f12:

    # jes "....Lucky? Oh, Your Majesty... I fear we have very different definitions of that word."
    jes "....¿Suerte? Oh, Su Majestad... me temo que tenemos definiciones muy distintas de esa palabra."

# game/script day2.rpy:1993
translate Spanish let_it_slide_5089eb12:

    # mc "Yeah, I know. But still."
    mc "Sí, lo sé. Pero aun así."

# game/script day2.rpy:1995
translate Spanish let_it_slide_f4c247bb:

    # jes "Hehe, of course, Your Majesty. I would never dream of forcing you to punish me."
    jes "Jeje, por supuesto, Su Majestad. Jamás soñaría con obligarle a castigarme."

# game/script day2.rpy:1996
translate Spanish let_it_slide_8ed151b5:

    # jes "But if that's the case... then I suppose I'll simply have to put on an even better performance and work a little harder to get what I want."
    jes "Pero si ese es el caso... entonces supongo que simplemente tendré que dar una actuación aún mejor y esforzarme un poco más para conseguir lo que quiero."

# game/script day2.rpy:1998
translate Spanish let_it_slide_6f09f68d:

    # "So I should prepare myself for whatever comes next, huh...? Wonderful."
    "Así que debería prepararme para lo que venga, ¿eh...? Maravilloso."

# game/script day2.rpy:1999
translate Spanish let_it_slide_3b472005:

    # "I continued eating my bread."
    "Seguí comiendo mi pan."

# game/script day2.rpy:2001
translate Spanish let_it_slide_9e5f9196:

    # "Jestyn doesn't take his eyes off me even once. He doesn't say a word, either."
    "Jestyn no me quita los ojos de encima ni una sola vez. Tampoco dice una palabra."

# game/script day2.rpy:2002
translate Spanish let_it_slide_62ab1eed:

    # "What could I possibly talk about...?"
    "¿De qué podría hablar...?"

# game/script day2.rpy:2003
translate Spanish let_it_slide_3ac3370c:

    # "My eyes wander around the room, searching for something I could bring up with him, until they eventually land on his clothes."
    "Mis ojos vagan por la habitación, buscando algo que pudiera mencionarle, hasta que terminan posándose en su ropa."

# game/script day2.rpy:2004
translate Spanish let_it_slide_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:2005
translate Spanish let_it_slide_77c60f0a:

    # "Come to think of it, I could probably ask him about his clothes."
    "Ahora que lo pienso, probablemente podría preguntarle por su ropa."

# game/script day2.rpy:2007
translate Spanish let_it_slide_355aabc3:

    # mc "Your clothes look cool. You look like a king."
    mc "Tu ropa se ve genial. Pareces un rey."

# game/script day2.rpy:2010
translate Spanish let_it_slide_d72f23d7:

    # "I noticed Jestyn suddenly froze for a moment."
    "Noté que Jestyn se quedó paralizado de repente por un momento."

# game/script day2.rpy:2012
translate Spanish let_it_slide_50611cc0:

    # jes "......."
    jes "......."

# game/script day2.rpy:2013
translate Spanish let_it_slide_43b7c3d9:

    # jes "Really?"
    jes "¿De verdad?"

# game/script day2.rpy:2014
translate Spanish let_it_slide_43b14ef3:

    # mc "Yeah. It suits you. You look dashing."
    mc "Sí. Te queda bien. Te ves apuesto."

# game/script day2.rpy:2016
translate Spanish let_it_slide_e06f45ab:

    # "I know complimenting him like this will probably only make him even more full of himself, but right now, I just want to say what's on my mind."
    "Sé que halagarlo así probablemente solo lo hará aún más engreído, pero ahora mismo solo quiero decir lo que pienso."

# game/script day2.rpy:2018
translate Spanish let_it_slide_0f786dc6:

    # "But surprisingly, instead of boasting like I expected him to, he averted his gaze slightly."
    "Pero, sorprendentemente, en lugar de presumir como esperaba, desvió un poco la mirada."

# game/script day2.rpy:2019
translate Spanish let_it_slide_4658c671:

    # "And I could see his cheeks turning red."
    "Y pude ver cómo sus mejillas se ponían rojas."

# game/script day2.rpy:2020
translate Spanish let_it_slide_ca903d4e:

    # "...Is he embarrassed?"
    "...¿Se avergüenza?"

# game/script day2.rpy:2022
translate Spanish let_it_slide_44ba9ca9:

    # jes "...Such sweet words, Your Majesty... Even this jester's heart melts at the sound of them."
    jes "...Qué dulces palabras, Su Majestad... Hasta el corazón de este bufón se derrite al oírlas."

# game/script day2.rpy:2024
translate Spanish let_it_slide_7cda1da1:

    # "Huh... So he can get embarrassed after all. That's unexpected."
    "Vaya... Así que sí puede avergonzarse. Qué inesperado."

# game/script day2.rpy:2026
translate Spanish let_it_slide_220e3b02:

    # mc "I'm curious. What do you usually wear with that outfit?"
    mc "Tengo curiosidad. ¿Qué sueles usar con ese atuendo?"

# game/script day2.rpy:2028
translate Spanish let_it_slide_167a49da:

    # jes "Hm? What does Your Majesty mean?"
    jes "¿Hm? ¿A qué se refiere Su Majestad?"

# game/script day2.rpy:2029
translate Spanish let_it_slide_52bb4148:

    # mc "I mean, you're a puppet jester. So I would expect you to only have jester outfits."
    mc "Me refiero a que eres un títere bufón. Así que esperaría que solo tuvieras atuendos de bufón."

# game/script day2.rpy:2030
translate Spanish let_it_slide_84cc4ad1:

    # mc "But what you're wearing doesn't look like a jester's outfit at all. You look more like a nobleman."
    mc "Pero lo que llevas puesto no parece un atuendo de bufón en absoluto. Pareces más bien un noble."

# game/script day2.rpy:2032
translate Spanish let_it_slide_9113d194:

    # jes ".........."
    jes ".........."

# game/script day2.rpy:2034
translate Spanish let_it_slide_f860460f:

    # "Jestyn falls silent for a moment. He seems lost in thought."
    "Jestyn guarda silencio un momento. Parece perdido en sus pensamientos."

# game/script day2.rpy:2035
translate Spanish let_it_slide_17269a94:

    # "Did I say something wrong?"
    "¿Dije algo malo?"

# game/script day2.rpy:2036
translate Spanish let_it_slide_a78b1d45:

    # "Before I can ask, Jestyn snaps out of his thoughts and gives me his usual smile."
    "Antes de que pueda preguntar, Jestyn sale de sus pensamientos y me regala su sonrisa de siempre."

# game/script day2.rpy:2038
translate Spanish let_it_slide_91b6a170:

    # jes "Mmm... actually, it's not really an outfit for anything. It's just an old set of clothes I haven't worn in a very long time."
    jes "Mmm... en realidad, no es un atuendo para nada en particular. Es solo un viejo conjunto de ropa que hace muchísimo tiempo que no uso."

# game/script day2.rpy:2040
translate Spanish let_it_slide_a2d9a178:

    # jes "I used to wear it back when the theater was still operating. There was a time when I would wear these clothes quite often. So... you can imagine just how old they are."
    jes "Solía usarla cuando el teatro todavía funcionaba. Hubo una época en que usaba esta ropa con bastante frecuencia. Así que... puede imaginar cuán antigua es."

# game/script day2.rpy:2041
translate Spanish let_it_slide_09f55f95:

    # jes "And... well, I kept them because I suppose I thought they wouldn't be needed anymore....."
    jes "Y... bueno, la conservé porque supongo que pensé que ya no se necesitaría....."

# game/script day2.rpy:2043
translate Spanish let_it_slide_07f4dfb9:

    # "Jestyn's voice grows heavier with every word."
    "La voz de Jestyn se vuelve más grave con cada palabra."

# game/script day2.rpy:2045
translate Spanish let_it_slide_1720d41c:

    # mc "...I see."
    mc "...Ya veo."

# game/script day2.rpy:2046
translate Spanish let_it_slide_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:2047
translate Spanish let_it_slide_5857cbbf:

    # mc "But did you like wearing them?"
    mc "¿Pero te gustaba usarla?"

# game/script day2.rpy:2050
translate Spanish let_it_slide_e51c08a0:

    # "Jestyn's eyes widen as he looks at me, slightly surprised by my question."
    "Los ojos de Jestyn se abren al mirarme, algo sorprendido por mi pregunta."

# game/script day2.rpy:2052
translate Spanish let_it_slide_ddfd007e:

    # jes "....Did I like them...?"
    jes "....¿Si me gustaba...?"

# game/script day2.rpy:2053
translate Spanish let_it_slide_9d096535:

    # mc "Yeah. I don't know why you stopped wearing them. But did you enjoy wearing them?"
    mc "Sí. No sé por qué dejaste de usarla. Pero ¿lo disfrutabas?"

# game/script day2.rpy:2055
translate Spanish let_it_slide_cb984a7a:

    # jes "Mmm....."
    jes "Mmm....."

# game/script day2.rpy:2057
translate Spanish let_it_slide_360089ba:

    # "Jestyn's eyes slowly drift down toward the table."
    "Los ojos de Jestyn descienden lentamente hacia la mesa."

# game/script day2.rpy:2059
translate Spanish let_it_slide_6bcd8efb:

    # jes ".......Yes. I did."
    jes ".......Sí. Me gustaba."

# game/script day2.rpy:2060
translate Spanish let_it_slide_4aefec05:

    # jes "But I suppose that's a feeling from long ago. I don't feel the same way about them anymore."
    jes "Pero supongo que ese es un sentimiento de hace mucho tiempo. Ya no siento lo mismo por ella."

# game/script day2.rpy:2062
translate Spanish let_it_slide_4929852f:

    # jes "It feels... uncomfortable."
    jes "Se siente... incómoda."

# game/script day2.rpy:2064
translate Spanish let_it_slide_fd44b1bb:

    # "Jestyn's brow furrows, discomfort evident on his face as he talks about his clothes."
    "El ceño de Jestyn se frunce, con la incomodidad evidente en su rostro mientras habla de su ropa."

# game/script day2.rpy:2065
translate Spanish let_it_slide_ce713e55:

    # "I want to ask what exactly makes him so uncomfortable. But I hesitate. I don't want to make him feel even worse."
    "Quiero preguntarle qué es exactamente lo que lo incomoda tanto. Pero dudo. No quiero hacerlo sentir aún peor."

# game/script day2.rpy:2067
translate Spanish let_it_slide_a462625c:

    # "Jestyn's eyes then move away from the table and return to me. The moment our eyes meet, the furrow in his brow disappears."
    "Los ojos de Jestyn se apartan entonces de la mesa y regresan a mí. En cuanto nuestras miradas se encuentran, el ceño se le relaja."

# game/script day2.rpy:2069
translate Spanish let_it_slide_92871432:

    # jes ".......And yet, Your Majesty makes me want to wear them again."
    jes ".......Y sin embargo, Su Majestad me hace querer usarla de nuevo."

# game/script day2.rpy:2071
translate Spanish let_it_slide_f4d64717:

    # jes "I... wanted to impress you. So I decided to put these clothes on again."
    jes "Yo... quería impresionarle. Así que decidí ponerme esta ropa otra vez."

# game/script day2.rpy:2072
translate Spanish let_it_slide_7bd3888f:

    # jes "The discomfort is still there, lingering in my heart... but somehow, it all seems to fade away when I get to see your reaction."
    jes "La incomodidad sigue ahí, aferrada a mi corazón... pero de algún modo todo parece desvanecerse cuando puedo ver su reacción."

# game/script day2.rpy:2073
translate Spanish let_it_slide_2fddff31:

    # jes "And yes... I suppose it was all worth it."
    jes "Y sí... supongo que valió la pena."

# game/script day2.rpy:2075
translate Spanish let_it_slide_f614ac6c:

    # "Jestyn's smile returns, growing wider."
    "La sonrisa de Jestyn regresa, ensanchándose."

# game/script day2.rpy:2076
translate Spanish let_it_slide_79a04515:

    # "Seeing Jestyn willingly endure that discomfort just for me makes my heart race."
    "Ver a Jestyn soportar voluntariamente esa incomodidad solo por mí hace que el corazón se me acelere."

# game/script day2.rpy:2077
translate Spanish let_it_slide_3ac22eed:

    # "Ugh, seriously... this puppet..."
    "Ugh, en serio... este títere..."

# game/script day2.rpy:2079
translate Spanish let_it_slide_21709f3c:

    # mc "Mhh... yeah... You really do look cool. Just like I said."
    mc "Mhh... sí... De verdad te ves genial. Tal como dije."

# game/script day2.rpy:2082
translate Spanish let_it_slide_380c2a10:

    # "He nods, looking satisfied."
    "Asiente, luciendo satisfecho."

# game/script day2.rpy:2085
translate Spanish let_it_slide_63df2f71:

    # jes "That makes me very happy, Your Majesty..."
    jes "Eso me hace muy feliz, Su Majestad..."

# game/script day2.rpy:2087
translate Spanish let_it_slide_72fa33be:

    # "Before I realize it, I've already eaten all the bread on my plate."
    "Antes de darme cuenta, ya me he comido todo el pan de mi plato."

# game/script day2.rpy:2089
translate Spanish let_it_slide_2f151694:

    # jes "Mmm... I believe it's time we move on to the main course, Your Majesty."
    jes "Mmm... creo que es hora de pasar al plato principal, Su Majestad."

# game/script day2.rpy:2092
translate Spanish let_it_slide_ce1cf992:

    # "Jestyn then snaps his fingers. In an instant, my empty plate is replaced with one filled with slices of roasted meat, generously coated in BBQ sauce."
    "Entonces Jestyn chasquea los dedos. En un instante, mi plato vacío es reemplazado por uno lleno de rebanadas de carne asada, generosamente cubiertas de salsa BBQ."

# game/script day2.rpy:2094
translate Spanish let_it_slide_6cbd7266:

    # jes "Please, enjoy yourself, Your Majesty. Don't mind me."
    jes "Por favor, disfrute, Su Majestad. No se preocupe por mí."

# game/script day2.rpy:2096
translate Spanish let_it_slide_d7e0faaf:

    # jes "That poor little stomach of yours deserves to taste some delicious roasted meat every once in a while."
    jes "Ese pobre estómago suyo merece probar un delicioso asado de vez en cuando."

# game/script day2.rpy:2098
translate Spanish let_it_slide_e5c74ffd:

    # "What a cheeky bastard."
    "Qué bastardo descarado."

# game/script day2.rpy:2099
translate Spanish let_it_slide_2f117457:

    # "But he's not wrong. Just looking at it is enough to make my stomach rumble. I can't wait to try it."
    "Pero no se equivoca. Con solo mirarla, ya me ruge el estómago. No veo la hora de probarla."

# game/script day2.rpy:2101
translate Spanish let_it_slide_d8e64b17:

    # "Without giving it another thought, I pick up a piece of meat with my fork and pop it into my mouth."
    "Sin pensarlo dos veces, tomo un trozo de carne con el tenedor y me lo llevo a la boca."

# game/script day2.rpy:2102
translate Spanish let_it_slide_070a1dc1:

    # "The flavor is so rich with spices. The BBQ sauce bursts across my palate, coating my tongue with its smoky, savory sweetness."
    "El sabor es tan rico en especias. La salsa BBQ estalla en mi paladar, cubriéndome la lengua con su dulzura ahumada y sabrosa."

# game/script day2.rpy:2103
translate Spanish let_it_slide_b84f3aa9:

    # "The meat itself is thick, yet wonderfully tender."
    "La carne en sí es gruesa, pero maravillosamente tierna."

# game/script day2.rpy:2104
translate Spanish let_it_slide_2634ae61:

    # "Whoever cooked this really knew what they're doing."
    "Quienquiera que haya cocinado esto de verdad sabía lo que hacía."

# game/script day2.rpy:2105
translate Spanish let_it_slide_6aa0e568:

    # "Seeing me devour the meat, Jestyn could only smile broadly, looking quite pleased with himself."
    "Al verme devorar la carne, Jestyn solo pudo sonreír ampliamente, luciendo bastante complacido consigo mismo."

# game/script day2.rpy:2107
translate Spanish let_it_slide_007e5415:

    # jes "Good?"
    jes "¿Le gustó?"

# game/script day2.rpy:2109
translate Spanish let_it_slide_f50302ba:

    # "I nod without a second thought."
    "Asiento sin pensarlo dos veces."

# game/script day2.rpy:2111
translate Spanish let_it_slide_e9a28e46:

    # mc "Yeah!"
    mc "¡Sí!"

# game/script day2.rpy:2114
translate Spanish let_it_slide_9ff20567:

    # "Jestyn lets out a quiet laugh at my enthusiastic response."
    "Jestyn suelta una risa tranquila ante mi entusiasta respuesta."

# game/script day2.rpy:2116
translate Spanish let_it_slide_81f9700c:

    # jes "If you'd like some more, just say the word."
    jes "Si desea más, solo dígalo."

# game/script day2.rpy:2117
translate Spanish let_it_slide_61bed4da:

    # mc "Wait, you can make more?"
    mc "Espera, ¿puedes hacer más?"

# game/script day2.rpy:2121
translate Spanish let_it_slide_175dae8a:

    # "Jestyn doesn't bother answering. He simply snaps his fingers."
    "Jestyn no se molesta en responder. Simplemente chasquea los dedos."

# game/script day2.rpy:2122
translate Spanish let_it_slide_3124f775:

    # "The meat that was nearly gone, most of it already eaten by me, is suddenly replenished."
    "La carne que casi se había acabado, la mayoría ya comida por mí, se repone de repente."

# game/script day2.rpy:2124
translate Spanish let_it_slide_37f5c6ac:

    # mc "You still had more??? Where did you even get it?"
    mc "¿¡Todavía tenías más??? ¿De dónde la sacaste?"

# game/script day2.rpy:2126
translate Spanish let_it_slide_ca41612e:

    # jes "I bought twice as much, just in case Your Majesty wanted seconds. And it seems my instincts were right, hm?"
    jes "Compré el doble, por si Su Majestad quería repetir. Y parece que mi instinto tenía razón, ¿hm?"

# game/script day2.rpy:2127
translate Spanish let_it_slide_7c7e8707:

    # jes "Besides, you looked hungry."
    jes "Además, parecía tener hambre."

# game/script day2.rpy:2129
translate Spanish let_it_slide_1a547226:

    # "I immediately feel embarrassed."
    "De inmediato me da vergüenza."

# game/script day2.rpy:2130
translate Spanish let_it_slide_c9994f1c:

    # "Was it really that obvious?"
    "¿Fue tan obvio?"

# game/script day2.rpy:2131
translate Spanish let_it_slide_4819a1d7:

    # "Well... I do eat instant noodles pretty often..."
    "Bueno... sí como fideos instantáneos bastante seguido..."

# game/script day2.rpy:2134
translate Spanish let_it_slide_5c9e5ea0:

    # jes "No, no. You don't look like someone who's starving. More like someone who hasn't been getting enough sleep."
    jes "No, no. No parece alguien que se muere de hambre. Más bien alguien que no ha dormido lo suficiente."

# game/script day2.rpy:2135
translate Spanish let_it_slide_1e26265d:

    # jes "But eating instant noodles every day isn't healthy, Your Majesty."
    jes "Pero comer fideos instantáneos todos los días no es saludable, Su Majestad."

# game/script day2.rpy:2136
translate Spanish let_it_slide_a5c8425f:

    # jes "Still, I can't exactly blame you for it. Sometimes, circumstances leave us with little choice but to do things we don't truly wish to do."
    jes "Aun así, no puedo culparle del todo. A veces las circunstancias no nos dejan más opción que hacer cosas que en realidad no deseamos hacer."

# game/script day2.rpy:2137
translate Spanish let_it_slide_a167c9e3:

    # jes "It's an unpleasant feeling, isn't it? When circumstances force you into doing something you never wanted to do in the first place."
    jes "Es una sensación desagradable, ¿no es así? Cuando las circunstancias te obligan a hacer algo que nunca quisiste hacer en primer lugar."

# game/script day2.rpy:2138
translate Spanish let_it_slide_aa29e72f:

    # mc "...Yeah...."
    mc "...Sí...."

# game/script day2.rpy:2140
translate Spanish let_it_slide_07bdde05:

    # "....."
    "....."

# game/script day2.rpy:2141
translate Spanish let_it_slide_fe2861f4:

    # "Wait, how did he know that I eat noodles often? I never told him, did I?"
    "Espera, ¿cómo supo que como fideos seguido? Nunca se lo dije, ¿o sí?"

# game/script day2.rpy:2142
translate Spanish let_it_slide_0f91fb24:

    # "Or maybe I just forgot..."
    "O quizás simplemente se me olvidó..."

# game/script day2.rpy:2144
translate Spanish let_it_slide_c672b15f:

    # "Jestyn sighed softly at my answer."
    "Jestyn suspiró suavemente ante mi respuesta."

# game/script day2.rpy:2146
translate Spanish let_it_slide_0ff8f9d4:

    # jes "But that's alright, Your Majesty. I'm here now, aren't I?"
    jes "Pero no importa, Su Majestad. Ahora estoy aquí, ¿no es así?"

# game/script day2.rpy:2147
translate Spanish let_it_slide_70bd5036:

    # jes "Which means you're not alone anymore."
    jes "Lo cual significa que ya no está sol[letra]."

# game/script day2.rpy:2148
translate Spanish let_it_slide_1f3483e6:

    # jes "And it also means there's someone here who will sincerely care for you... and keep you safe."
    jes "Y también significa que hay alguien aquí que se preocupará sinceramente por usted... y le mantendrá a salvo."

# game/script day2.rpy:2150
translate Spanish let_it_slide_e785277b:

    # "Jestyn's voice wasn't like it usually was. It sounds deeper, softer."
    "La voz de Jestyn no era como solía ser. Suena más grave, más suave."

# game/script day2.rpy:2151
translate Spanish let_it_slide_c233861a:

    # "It feels... comforting."
    "Se siente... reconfortante."

# game/script day2.rpy:2152
translate Spanish let_it_slide_4b2d215d:

    # "The thought of having someone who could protect you from the cruelty of the world feels like being wrapped in something warm in the middle of a cold wind."
    "La idea de tener a alguien que pueda protegerte de la crueldad del mundo se siente como si te envolvieran en algo cálido en medio de un viento frío."

# game/script day2.rpy:2154
translate Spanish let_it_slide_3d92d6a7:

    # mc "But you're only a puppet... I mean, we're different."
    mc "Pero solo eres un títere... quiero decir, somos diferentes."

# game/script day2.rpy:2155
translate Spanish let_it_slide_219a6f9e:

    # jes "It is only your own mind that limits the possibilities, Your Majesty."
    jes "Solo su propia mente limita las posibilidades, Su Majestad."

# game/script day2.rpy:2157
translate Spanish let_it_slide_ed52aca0:

    # jes "Perhaps I may look like nothing more than an ordinary puppet, albeit a rather tall one. But trust me... I can do far more than that."
    jes "Quizás parezca nada más que un títere corriente, aunque bastante alto. Pero créame... puedo hacer mucho más que eso."

# game/script day2.rpy:2158
translate Spanish let_it_slide_f25e3591:

    # jes "Far more than human reason could ever comprehend."
    jes "Mucho más de lo que la razón humana podría llegar a comprender."

# game/script day2.rpy:2160
translate Spanish let_it_slide_720e6b01:

    # "Jestyn's eyes settled on the meat I hadn't finished yet."
    "Los ojos de Jestyn se posaron en la carne que aún no había terminado."

# game/script day2.rpy:2163
translate Spanish let_it_slide_7a52c780:

    # jes "Go on, Your Majesty. Keep eating."
    jes "Adelante, Su Majestad. Siga comiendo."

# game/script day2.rpy:2164
translate Spanish let_it_slide_6a9a11b1:

    # jes "Finish it."
    jes "Termínela."

# game/script day2.rpy:2166
translate Spanish let_it_slide_3e039dc3:

    # "I wanted to continue eating."
    "Quería seguir comiendo."

# game/script day2.rpy:2167
translate Spanish let_it_slide_0ea63ffb:

    # "But for some reason, my hand felt strangely heavy when I tried to lift it, even though I knew I could."
    "Pero por alguna razón, mi mano se sentía extrañamente pesada al intentar levantarla, aunque sabía que podía."

# game/script day2.rpy:2169
translate Spanish let_it_slide_510b4cd3:

    # jes "Or... would Your Majesty prefer that I feed you?"
    jes "¿O... preferiría Su Majestad que le diera de comer yo?"

# game/script day2.rpy:2170
translate Spanish let_it_slide_06923edf:

    # mc "I....."
    mc "Yo....."

# game/script day2.rpy:2172
translate Spanish let_it_slide_77e71ca9:

    # "My heart pounds against my chest. Hard. Far too hard."
    "El corazón me golpea contra el pecho. Fuerte. Demasiado fuerte."

# game/script day2.rpy:2174
translate Spanish let_it_slide_6a3c9469:

    # mc "...I... would..."
    mc "...Yo... querría..."

# game/script day2.rpy:2177
translate Spanish let_it_slide_c4e03bd8:

    # "Jestyn let out a quiet, knowing laugh at my hesitation. Without another word, he gently took the fork from my hand."
    "Jestyn soltó una risita cómplice y tranquila ante mi vacilación. Sin decir una palabra más, me quitó el tenedor de la mano con suavidad."

# game/script day2.rpy:2179
translate Spanish let_it_slide_8df37bb5:

    # jes "There we are. You could have simply told me."
    jes "Ahí lo tiene. Podría haberlo dicho simplemente."

# game/script day2.rpy:2180
translate Spanish let_it_slide_62401f44:

    # jes "No need to make things difficult for yourself."
    jes "No hace falta complicarse las cosas."

# game/script day2.rpy:2182
translate Spanish let_it_slide_7ff52725:

    # "Jestyn speared a piece of meat with the fork and slowly brought it toward my mouth."
    "Jestyn pinchó un trozo de carne con el tenedor y lo acercó lentamente a mi boca."

# game/script day2.rpy:2185
translate Spanish let_it_slide_addb40b7:

    # jes "Now... open."
    jes "Ahora... abra."

# game/script day2.rpy:2187
translate Spanish let_it_slide_c0379b8d:

    # "My lips parted before I even realized what I was doing."
    "Mis labios se entreabrieron antes de que me diera cuenta de lo que hacía."

# game/script day2.rpy:2188
translate Spanish let_it_slide_1641c713:

    # "I hadn't meant to obey him."
    "No había querido obedecerle."

# game/script day2.rpy:2189
translate Spanish let_it_slide_3f2fc06a:

    # "I simply... did."
    "Simplemente... lo hice."

# game/script day2.rpy:2191
translate Spanish let_it_slide_b4f7e55e:

    # jes "Good."
    jes "Bien."

# game/script day2.rpy:2193
translate Spanish let_it_slide_5d77d191:

    # "His smile widens ever so slightly."
    "Su sonrisa se ensancha apenas un poco."

# game/script day2.rpy:2195
translate Spanish let_it_slide_70339713:

    # jes "See? That wasn't so difficult, was it?"
    jes "¿Ve? No fue tan difícil, ¿verdad?"

# game/script day2.rpy:2196
translate Spanish let_it_slide_9fee9fe3:

    # jes "Now, would you like another?"
    jes "Ahora, ¿desea otro?"

# game/script day2.rpy:2198
translate Spanish let_it_slide_8ce61eb8:

    # "I nod."
    "Asiento."

# game/script day2.rpy:2199
translate Spanish let_it_slide_0f7bd799:

    # "Jestyn took another piece of meat."
    "Jestyn tomó otro trozo de carne."

# game/script day2.rpy:2200
translate Spanish let_it_slide_e742dd77:

    # "And placed it into my mouth."
    "Y lo colocó en mi boca."

# game/script day2.rpy:2201
translate Spanish let_it_slide_84f2cd0f:

    # "Again and again..."
    "Una y otra vez..."

# game/script day2.rpy:2202
translate Spanish let_it_slide_912730c8:

    # "Until there wasn't a single piece of meat left on the plate."
    "Hasta que no quedó ni un solo trozo de carne en el plato."

# game/script day2.rpy:2204
translate Spanish let_it_slide_1777ec68:

    # jes "Would you like some more?"
    jes "¿Desea un poco más?"

# game/script day2.rpy:2206
translate Spanish let_it_slide_57d3d2fe:

    # "I shook my head, feeling completely full."
    "Negué con la cabeza, sintiéndome completamente llen[letra]."

# game/script day2.rpy:2209
translate Spanish let_it_slide_2f224365:

    # jes "You finished the whole thing. I'm proud of you."
    jes "Se lo terminó todo. Estoy orgulloso de usted."

# game/script day2.rpy:2211
translate Spanish let_it_slide_1d9890ea:

    # "Jestyn then picked up a napkin from beside me and gently wiped my mouth with it."
    "Jestyn tomó entonces una servilleta de junto a mí y me limpió suavemente la boca."

# game/script day2.rpy:2214
translate Spanish let_it_slide_ba1d954e:

    # jes "Do you still have room for dessert?"
    jes "¿Todavía tiene espacio para el postre?"

# game/script day2.rpy:2215
translate Spanish let_it_slide_e86e19bf:

    # mc "Mhh... I don't think so... I ate quite a lot of meat."
    mc "Mhh... no creo... Comí bastante carne."

# game/script day2.rpy:2216
translate Spanish let_it_slide_59000a07:

    # jes "Then you can take the dessert back to your apartment and enjoy it later."
    jes "Entonces puede llevarse el postre a su apartamento y disfrutarlo más tarde."

# game/script day2.rpy:2217
translate Spanish let_it_slide_dd0624e2:

    # jes "How does that sound?"
    jes "¿Qué le parece?"

# game/script day2.rpy:2218
translate Spanish let_it_slide_08d60d58:

    # mc "Sounds like a good idea...."
    mc "Me parece buena idea...."

# game/script day2.rpy:2220
translate Spanish let_it_slide_db18b29f:

    # "Eating such a luxurious meal in my shabby little apartment... I suppose that would be quite the experience."
    "Comer una comida tan lujosa en mi destartalado apartamentito... supongo que sería toda una experiencia."

# game/script day2.rpy:2236
translate Spanish end_repeat_route_4c0cd545:

    # "Jestyn snapped his fingers. In an instant, the two of us were back in my office bedroom."
    "Jestyn chasqueó los dedos. En un instante, los dos estábamos de vuelta en mi oficina-dormitorio."

# game/script day2.rpy:2238
translate Spanish end_repeat_route_8fad57e2:

    # "He sat down on my bed, taking off his robe and let his hair fall loose. Soft, wavy strands framed his face beautifully."
    "Se sentó en mi cama, se quitó la túnica y dejó caer su cabello suelto. Las suaves hebras onduladas le enmarcaban el rostro de forma hermosa."

# game/script day2.rpy:2240
translate Spanish end_repeat_route_88056451:

    # jes "......"
    jes "......"

# game/script day2.rpy:2241
translate Spanish end_repeat_route_a8846724:

    # jes "...Your Majesty..."
    jes "...Su Majestad..."

# game/script day2.rpy:2242
translate Spanish end_repeat_route_c374ebd8:

    # mc "Hm? What is it?"
    mc "¿Hm? ¿Qué pasa?"

# game/script day2.rpy:2244
translate Spanish end_repeat_route_806d245d:

    # "Jestyn slowly held his arms open."
    "Jestyn abrió lentamente los brazos."

# game/script day2.rpy:2246
translate Spanish end_repeat_route_44ede720:

    # jes "...... Hug...?"
    jes "...... ¿Abrazo...?"

# game/script day2.rpy:2248
translate Spanish end_repeat_route_a20cefa7:

    # "..."
    "..."

# game/script day2.rpy:2249
translate Spanish end_repeat_route_64695f2b:

    # "How was I supposed to say no to that face? Besides, Jestyn looked exhausted."
    "¿Cómo iba a decirle que no a esa cara? Además, Jestyn se veía agotado."

# game/script day2.rpy:2251
translate Spanish end_repeat_route_36d918d5:

    # "So I stepped closer. The moment I was within reach, he wrapped his arms around my waist and gently pulled me into his embrace."
    "Así que me acerqué. En cuanto estuve a su alcance, rodeó mi cintura con los brazos y me atrajo con delicadeza a su abrazo."

# game/script day2.rpy:2253
translate Spanish end_repeat_route_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:2254
translate Spanish end_repeat_route_d4e6b0f8:

    # mc "Are you tired, Jestyn?"
    mc "¿Estás cansado, Jestyn?"

# game/script day2.rpy:2255
translate Spanish end_repeat_route_7b47dbd2:

    # jes "...Mmmnn..."
    jes "...Mmmnn..."

# game/script day2.rpy:2256
translate Spanish end_repeat_route_a94f0023:

    # jes "A little..."
    jes "Un poco..."

# game/script day2.rpy:2257
translate Spanish end_repeat_route_88056451_1:

    # jes "......"
    jes "......"

# game/script day2.rpy:2259
translate Spanish end_repeat_route_715f9be8:

    # jes "...May this humble jester rest in Your Majesty's lap?"
    jes "...¿Puede este humilde bufón descansar en el regazo de Su Majestad?"

# game/script day2.rpy:2260
translate Spanish end_repeat_route_1bf60051:

    # mc "Of course."
    mc "Por supuesto."

# game/script day2.rpy:2262
translate Spanish end_repeat_route_a702f6cb:

    # "Jestyn carefully lay down, resting his head on my lap."
    "Jestyn se recostó con cuidado, apoyando la cabeza en mi regazo."

# game/script day2.rpy:2264
translate Spanish end_repeat_route_30d95d2d:

    # jes "...Though I must confess..."
    jes "...Aunque debo confesar..."

# game/script day2.rpy:2267
translate Spanish end_repeat_route_12d670dc:

    # jes "...I liked the way Your Majesty played with me even more."
    jes "...Me gustó aún más la manera en que Su Majestad jugó conmigo."

# game/script day2.rpy:2268
translate Spanish end_repeat_route_68a92828:

    # jes "The way You treated me... as though I were Your most treasured toy..."
    jes "La manera en que Usted me trató... como si fuera Su juguete más preciado..."

# game/script day2.rpy:2269
translate Spanish end_repeat_route_1a94fda0:

    # jes "...It made this foolish jester feel truly precious."
    jes "...Eso hizo que este necio bufón se sintiera verdaderamente valioso."

# game/script day2.rpy:2271
translate Spanish end_repeat_route_c3f0f525:

    # jes "...I'm happier when I'm with You."
    jes "...Soy más feliz cuando estoy con Usted."

# game/script day2.rpy:2274
translate Spanish end_repeat_route_9593dfd0:

    # jes "You're so obedient, Your Majesty. So innocent, so pure, so gentle."
    jes "Es tan obediente, Su Majestad. Tan inocente, tan pur[letra], tan gentil."

# game/script day2.rpy:2275
translate Spanish end_repeat_route_65c1f3a2:

    # jes "Like a little lost rabbit, simply following wherever I lead you."
    jes "Como un pequeño conejito perdido, siguiendo sencillamente adondequiera que yo le guíe."

# game/script day2.rpy:2276
translate Spanish end_repeat_route_4884f037:

    # jes "It makes me feel even more protective of you than before."
    jes "Eso me hace sentir aún más protector con usted que antes."

# game/script day2.rpy:2277
translate Spanish end_repeat_route_95b47a59:

    # jes "And I suppose that's exactly how it should be. After all... it's for Your Majesty's safety."
    jes "Y supongo que así debe ser. Después de todo... es por la seguridad de Su Majestad."

# game/script day2.rpy:2279
translate Spanish end_repeat_route_36d79df1:

    # "My heart pounded so loudly it felt like a drum. Jestyn had suddenly become so... shamelessly sweet."
    "Mi corazón latía tan fuerte que parecía un tambor. Jestyn se había vuelto de pronto tan... descaradamente dulce."

# game/script day2.rpy:2280
translate Spanish end_repeat_route_e140ea29:

    # "Then again... why was I so surprised? This was Jestyn. The most unpredictable puppet in the theater."
    "Aunque... ¿por qué me sorprendía tanto? Este era Jestyn. El títere más impredecible del teatro."

# game/script day2.rpy:2281
translate Spanish end_repeat_route_dabda7d0:

    # "...Even so, I couldn't help being caught off guard."
    "...Aun así, no pude evitar quedar desprevenid[letra]."

# game/script day2.rpy:2282
translate Spanish end_repeat_route_71be648f:

    # "As I watched him, his eyelids gradually grew heavier. His gaze softened with sleepiness."
    "Mientras lo observaba, sus párpados se fueron haciendo más pesados. Su mirada se suavizó con el sueño."

# game/script day2.rpy:2284
translate Spanish end_repeat_route_6b7fe13b:

    # mc "You're getting sleepy, aren't you, Jestyn?"
    mc "Tienes sueño, ¿verdad, Jestyn?"

# game/script day2.rpy:2286
translate Spanish end_repeat_route_6c5918df:

    # "He gave a slow, sleepy nod."
    "Asintió con un cabeceo lento y somnoliento."

# game/script day2.rpy:2287
translate Spanish end_repeat_route_627d9971:

    # "His arms lazily slipped around my waist, gently holding me in place."
    "Sus brazos se deslizaron perezosamente alrededor de mi cintura, sujetándome con suavidad."

# game/script day2.rpy:2288
translate Spanish end_repeat_route_7f0fe509:

    # "He was probably exhausted after everything that had happened earlier. Understandably so."
    "Probablemente estaba agotado después de todo lo que había pasado antes. Comprensiblemente."

# game/script day2.rpy:2289
translate Spanish end_repeat_route_edffed98:

    # "I gently stroked Jestyn's hair. He seemed to enjoy every second of it."
    "Acaricié suavemente el cabello de Jestyn. Parecía disfrutar cada segundo."

# game/script day2.rpy:2291
translate Spanish end_repeat_route_d9703b99:

    # jes "...Your Majesty will still be here when I wake up... won't You?"
    jes "...Su Majestad seguirá aquí cuando despierte... ¿verdad?"

# game/script day2.rpy:2292
translate Spanish end_repeat_route_13c42261:

    # mc "How am I supposed to leave when you're lying on top of me like this?"
    mc "¿Cómo se supone que me vaya si estás acostado encima de mí así?"

# game/script day2.rpy:2293
translate Spanish end_repeat_route_d7d1df57:

    # jes "Hehe... true enough..."
    jes "Jeje... cierto..."

# game/script day2.rpy:2294
translate Spanish end_repeat_route_91a41cf0:

    # jes "...Then... good night, Your Majesty..."
    jes "...Entonces... buenas noches, Su Majestad..."

# game/script day2.rpy:2295
translate Spanish end_repeat_route_8dc0db56:

    # mc "...Good night, Jestyn."
    mc "...Buenas noches, Jestyn."

# game/script day2.rpy:2297
translate Spanish end_repeat_route_a4f7af66:

    # "Jestyn slowly closed his eyes."
    "Jestyn cerró lentamente los ojos."

# game/script day2.rpy:2300
translate Spanish end_repeat_route_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:2301
translate Spanish end_repeat_route_57368e71:

    # "I still couldn't believe I'd done all of that willingly. At first, I'd been completely out of my element... but little by little, this puppet had somehow made it feel almost natural."
    "Aún no podía creer que hubiera hecho todo eso por voluntad propia. Al principio me había sentido completamente fuera de lugar... pero poco a poco, este títere había logrado hacerlo parecer casi natural."

# game/script day2.rpy:2302
translate Spanish end_repeat_route_a760b33d:

    # "I absentmindedly continued stroking Jestyn's hair when my phone suddenly buzzed with a notification."
    "Seguía acariciando distraídamente el cabello de Jestyn cuando mi teléfono vibró de pronto con una notificación."

# game/script day2.rpy:2303
translate Spanish end_repeat_route_b88d51d2:

    # "...Oh. Boss."
    "...Oh. El jefe."

# game/script day2.rpy:2304
translate Spanish end_repeat_route_91c4162f:

    # "I hadn't expected to hear from them today. The message said my first paycheck had already been transferred."
    "No esperaba tener noticias suyas hoy. El mensaje decía que mi primer sueldo ya había sido transferido."

# game/script day2.rpy:2306
translate Spanish end_repeat_route_a05511c4:

    # mc "Huh... I wasn't expecting to get paid this soon. I've only been working here for two days."
    mc "Vaya... No esperaba que me pagaran tan pronto. Solo llevo trabajando aquí dos días."

# game/script day2.rpy:2308
translate Spanish end_repeat_route_0be62a99:

    # "I guess you could call it a bonus."
    "Supongo que podría decirse que es un bono."

# game/script day2.rpy:2310
translate Spanish end_repeat_route_6b69450d:

    # mc "...My boss is surprisingly generous... At this rate, I might actually enjoy working here."
    mc "...Mi jefe es sorprendentemente generoso... A este paso, quizás hasta disfrute trabajar aquí."

# game/script day2.rpy:2312
translate Spanish end_repeat_route_f7be8c1a:

    # "The paycheck was enough to cover my debts and my living expenses for a while. Not bad at all."
    "El sueldo era suficiente para cubrir mis deudas y mis gastos de vida por un tiempo. Nada mal."

# game/script day2.rpy:2313
translate Spanish end_repeat_route_526a5b64:

    # "I glanced at the clock. It was only midnight."
    "Eché un vistazo al reloj. Era apenas medianoche."

# game/script day2.rpy:2314
translate Spanish end_repeat_route_bd5fbc1d:

    # "There were still about six hours left before my shift ended...I've already finished all of my work... so what am I supposed to do now?"
    "Aún faltaban unas seis horas para que terminara mi turno... Ya he terminado todo mi trabajo... así que ¿qué se supone que haga ahora?"

# game/script day2.rpy:2315
translate Spanish end_repeat_route_19c0fe46:

    # "Let's see..."
    "A ver..."

# game/script day2.rpy:2316
translate Spanish end_repeat_route_6ec1b285:

    # "Today, I learned that every puppet in this theater is alive. I also met several new puppets. I swear I'm not losing my mind and keep denial that these puppets are not alive."
    "Hoy descubrí que todos los títeres de este teatro están vivos. También conocí a varios títeres nuevos. Juro que no estoy perdiendo la cabeza ni sigo negando que estos títeres estén vivos."

# game/script day2.rpy:2319
translate Spanish end_repeat_route_e403c666:

    # "And... I learned a little about the King Puppet."
    "Y... aprendí un poco sobre el Rey Títere."

# game/script day2.rpy:2320
translate Spanish end_repeat_route_1cdc2a46:

    # "Judging from what Wizzy said earlier... the King Puppet didn't seem like a good person."
    "A juzgar por lo que dijo Wizzy antes... el Rey Títere no parecía una buena persona."

# game/script day2.rpy:2321
translate Spanish end_repeat_route_4761aedc:

    # "If that's true... then maybe his death really was for the best."
    "Si eso es cierto... entonces quizás su muerte realmente fue lo mejor."

# game/script day2.rpy:2322
translate Spanish end_repeat_route_6642f09f:

    # "After all... cruel people don't deserve to live."
    "Después de todo... las personas crueles no merecen vivir."

# game/script day2.rpy:2323
translate Spanish end_repeat_route_1550e6ab:

    # "...My life would probably be better without people like that, too."
    "...Mi vida probablemente también sería mejor sin gente así."

# game/script day2.rpy:2325
translate Spanish end_repeat_route_07f454f9:

    # mc "Forget it. Rather than overthinking all this... I should just play a game to pass the time."
    mc "Olvídalo. En vez de darle tantas vueltas a todo esto... debería simplemente jugar algo para pasar el rato."

# game/script day2.rpy:2327
translate Spanish end_repeat_route_8b4d35fb:

    # "I picked up my phone and started playing."
    "Tomé mi teléfono y empecé a jugar."

# game/script day2.rpy:2328
translate Spanish end_repeat_route_5e3a71cd:

    # "Nothing today had truly frightened me. Maybe I was finally getting used to this place."
    "Nada hoy me había asustado de verdad. Quizás por fin me estaba acostumbrando a este lugar."

# game/script day2.rpy:2329
translate Spanish end_repeat_route_8194eeb2:

    # "Tomorrow... I'd probably be even more used to it."
    "Mañana... probablemente estaría aún más acostumbrad[letra]."

# game/script day2.rpy:2342
translate Spanish end_repeat_route_d41d8cd9:

    # voice "CROWNUS06_DAY2.ogg"
    voice "CROWNUS06_DAY2.ogg"

# game/script day2.rpy:2349
translate Spanish end_repeat_route_d41d8cd9_1:

    # voice "CROWNUS07_DAY2.ogg"
    voice "CROWNUS07_DAY2.ogg"

# game/script day2.rpy:2356
translate Spanish end_repeat_route_d41d8cd9_2:

    # voice "CROWNUS08_DAY2.ogg"
    voice "CROWNUS08_DAY2.ogg"

# game/script day2.rpy:2361
translate Spanish end_repeat_route_d41d8cd9_3:

    # voice "CROWNUS09_DAY2.ogg"
    voice "CROWNUS09_DAY2.ogg"

# game/script day2.rpy:2366
translate Spanish end_repeat_route_d41d8cd9_4:

    # voice "CROWNUS10_DAY2.ogg"
    voice "CROWNUS10_DAY2.ogg"

# game/script day2.rpy:2371
translate Spanish end_repeat_route_d41d8cd9_5:

    # voice "CROWNUS11_DAY2.ogg"
    voice "CROWNUS11_DAY2.ogg"

# game/script day2.rpy:2376
translate Spanish end_repeat_route_d41d8cd9_6:

    # voice "CROWNUS12_DAY2.ogg"
    voice "CROWNUS12_DAY2.ogg"

# game/script day2.rpy:2423
translate Spanish end_repeat_route_d41d8cd9_7:

    # voice "CROWNUS13_DAY2.ogg"
    voice "CROWNUS13_DAY2.ogg"

# game/script day2.rpy:2430
translate Spanish end_repeat_route_d41d8cd9_8:

    # voice "CROWNUS14_DAY2.ogg"
    voice "CROWNUS14_DAY2.ogg"

# game/script day2.rpy:2435
translate Spanish end_repeat_route_d41d8cd9_9:

    # voice "CROWNUS15_DAY2.ogg"
    voice "CROWNUS15_DAY2.ogg"

# game/script day2.rpy:2440
translate Spanish end_repeat_route_d41d8cd9_10:

    # voice "CROWNUS16_DAY2.ogg"
    voice "CROWNUS16_DAY2.ogg"

# game/script day2.rpy:2514
translate Spanish the_truth_route_60c5069e:

    # jes "Now then, I believe this is a good place to stop for today, Your Majesty."
    jes "Ahora bien, creo que este es un buen lugar para detenernos por hoy, Su Majestad."

# game/script day2.rpy:2515
translate Spanish the_truth_route_a725d425:

    # jes "You must be tired."
    jes "Debe de estar cansad[letra]."

# game/script day2.rpy:2517
translate Spanish the_truth_route_66ed93b1:

    # jes "Allow me to escort you back to your room."
    jes "Permítame acompañarle de vuelta a su cuarto."

# game/script day2.rpy:2520
translate Spanish the_truth_route_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:2521
translate Spanish the_truth_route_7450c5b0:

    # "Part of me wanted to rest."
    "Una parte de mí quería descansar."

# game/script day2.rpy:2522
translate Spanish the_truth_route_f8c175ea:

    # "But another part of me insisted that now wasn't the time."
    "Pero otra parte insistía en que este no era el momento."

# game/script day2.rpy:2523
translate Spanish the_truth_route_8b3171a0:

    # "There was an uneasy feeling lingering in the back of my mind."
    "Había una sensación de inquietud rondando en el fondo de mi mente."

# game/script day2.rpy:2524
translate Spanish the_truth_route_71b56e02:

    # "Something about all of this refused to sit right with me."
    "Algo en todo esto se negaba a cuadrarme."

# game/script day2.rpy:2525
translate Spanish the_truth_route_9643356d:

    # "Why did I have the feeling that Jestyn was hiding something?"
    "¿Por qué tenía la sensación de que Jestyn me ocultaba algo?"

# game/script day2.rpy:2526
translate Spanish the_truth_route_b2581ffc:

    # "That strange feeling had started the moment he refused to let me enter the King Puppet's room."
    "Esa extraña sensación había comenzado en el momento en que se negó a dejarme entrar al cuarto del Rey Títere."

# game/script day2.rpy:2538
translate Spanish jestynotfollow_day2_3928a113:

    # "......."
    "......."

# game/script day2.rpy:2539
translate Spanish jestynotfollow_day2_192d58e2:

    # "I have to find out what's really going on."
    "Tengo que averiguar qué está pasando realmente."

# game/script day2.rpy:2540
translate Spanish jestynotfollow_day2_438f1991:

    # "I snapped out of my thoughts and looked over at Jestyn, who was patiently waiting for me."
    "Salí de mis pensamientos y miré a Jestyn, que esperaba pacientemente por mí."

# game/script day2.rpy:2541
translate Spanish jestynotfollow_day2_8bcd9c2b:

    # "He seemed to notice that something was on my mind."
    "Parecía haber notado que algo me rondaba la cabeza."

# game/script day2.rpy:2544
translate Spanish jestynotfollow_day2_11497d57:

    # jes "Is something troubling You, Your Majesty?"
    jes "¿Le inquieta algo, Su Majestad?"

# game/script day2.rpy:2545
translate Spanish jestynotfollow_day2_7f225f53:

    # mc "...Actually, I'm tired of sitting around in my room."
    mc "...En realidad, estoy cansad[letra] de estar sentad[letra] en mi cuarto."

# game/script day2.rpy:2546
translate Spanish jestynotfollow_day2_bb05efeb:

    # mc "I think I need some fresh air to clear my head."
    mc "Creo que necesito algo de aire fresco para despejar la cabeza."

# game/script day2.rpy:2547
translate Spanish jestynotfollow_day2_a84dd677:

    # mc "So I'm going to take a walk for a while."
    mc "Así que voy a salir a caminar un rato."

# game/script day2.rpy:2548
translate Spanish jestynotfollow_day2_e40334dc:

    # jes "In that case, allow me to-"
    jes "En ese caso, permítame-"

# game/script day2.rpy:2549
translate Spanish jestynotfollow_day2_bc664957:

    # mc "Alone."
    mc "Sol[letra]."

# game/script day2.rpy:2553
translate Spanish jestynotfollow_day2_c304aca1:

    # "Jestyn fell silent."
    "Jestyn guardó silencio."

# game/script day2.rpy:2554
translate Spanish jestynotfollow_day2_11d99cf8:

    # "His brow furrowed, making it obvious that he wasn't fond of the idea."
    "Frunció el ceño, dejando claro que la idea no le agradaba."

# game/script day2.rpy:2556
translate Spanish jestynotfollow_day2_248ab29e:

    # jes "Your Majesty, I respect your wishes..."
    jes "Su Majestad, respeto sus deseos..."

# game/script day2.rpy:2558
translate Spanish jestynotfollow_day2_818549ff:

    # jes "But wandering the kingdom alone isn't exactly..."
    jes "Pero vagar por el reino a solas no es exactamente..."

# game/script day2.rpy:2560
translate Spanish jestynotfollow_day2_b88a04c3:

    # "He paused, choosing his words carefully."
    "Hizo una pausa, escogiendo cuidadosamente sus palabras."

# game/script day2.rpy:2562
translate Spanish jestynotfollow_day2_2f9f9ec4:

    # jes "As your jester and your right hand, it's my duty to accompany you wherever you go."
    jes "Como su bufón y su mano derecha, es mi deber acompañarle adondequiera que vaya."

# game/script day2.rpy:2564
translate Spanish jestynotfollow_day2_70d42747:

    # jes "Surely you're not naive enough to think I'd let you wander off by yourself? Haha..."
    jes "Seguramente no es tan ingenu[letra] como para pensar que le dejaría vagar por ahí sol[letra], ¿verdad? Jaja..."

# game/script day2.rpy:2566
translate Spanish jestynotfollow_day2_2654d459:

    # "He tried to mask his unease behind a joke and a teasing remark."
    "Intentó disimular su inquietud tras una broma y un comentario burlón."

# game/script day2.rpy:2568
translate Spanish jestynotfollow_day2_5db6cd35:

    # mc "And as your ruler, I'm ordering you to take a break...and leave me alone."
    mc "Y como tu gobernante, te ordeno que te tomes un descanso... y me dejes en paz."

# game/script day2.rpy:2571
translate Spanish jestynotfollow_day2_eb0ba432:

    # "The smile on Jestyn's face grew noticeably more strained."
    "La sonrisa en el rostro de Jestyn se volvió notablemente más forzada."

# game/script day2.rpy:2572
translate Spanish jestynotfollow_day2_8f4d155e:

    # "His expression darkened, making it obvious he was becoming increasingly displeased."
    "Su expresión se ensombreció, dejando claro que se estaba molestando cada vez más."

# game/script day2.rpy:2573
translate Spanish jestynotfollow_day2_226140e5:

    # "For the first time, I could see genuine irritation creeping onto his face."
    "Por primera vez, pude ver una irritación genuina asomándose en su rostro."

# game/script day2.rpy:2575
translate Spanish jestynotfollow_day2_b0109e13:

    # jes "Hmph.. What an ungrateful little monarch I've been blessed with."
    jes "Hmph.. Qué monarca más desagradecid[letra] me ha tocado en suerte."

# game/script day2.rpy:2576
translate Spanish jestynotfollow_day2_afaa2f6d:

    # jes "To cast aside one's most loyal fool...How tragic."
    jes "Desechar al bufón más leal de uno...Qué trágico."

# game/script day2.rpy:2578
translate Spanish jestynotfollow_day2_9b383c78:

    # "His words caught me completely off guard."
    "Sus palabras me tomaron completamente por sorpresa."

# game/script day2.rpy:2579
translate Spanish jestynotfollow_day2_dad43082:

    # "I hadn't expected something so sharp... so venomous... to come out of his mouth."
    "No esperaba que algo tan afilado... tan venenoso... saliera de su boca."

# game/script day2.rpy:2580
translate Spanish jestynotfollow_day2_868817e4:

    # "Why was he so determined not to leave me alone?"
    "¿Por qué estaba tan empeñado en no dejarme en paz?"

# game/script day2.rpy:2581
translate Spanish jestynotfollow_day2_d4eecbc0:

    # "Something wasn't right."
    "Algo no estaba bien."

# game/script day2.rpy:2582
translate Spanish jestynotfollow_day2_caae8b13:

    # "He clearly had no intention of leaving."
    "Claramente no tenía intención de irse."

# game/script day2.rpy:2583
translate Spanish jestynotfollow_day2_da047c5c:

    # "What am I supposed to do?"
    "¿Qué se supone que haga?"

# game/script day2.rpy:2584
translate Spanish jestynotfollow_day2_6d6a145e:

    # "I had a feeling that if I kept pushing him or raised my voice again, things would only get worse."
    "Tenía la sensación de que si seguía presionándolo o volvía a alzar la voz, las cosas solo empeorarían."

# game/script day2.rpy:2585
translate Spanish jestynotfollow_day2_939252a7:

    # "If force wasn't going to work, then I'd have to try a gentler approach."
    "Si la fuerza no iba a funcionar, tendría que probar un enfoque más suave."

# game/script day2.rpy:2586
translate Spanish jestynotfollow_day2_4136c97d:

    # "I looked back at his frustrated expression."
    "Volví a mirar su expresión frustrada."

# game/script day2.rpy:2588
translate Spanish jestynotfollow_day2_ccd5ba6f:

    # mc "Jestyn..."
    mc "Jestyn..."

# game/script day2.rpy:2589
translate Spanish jestynotfollow_day2_5e59c15e:

    # mc "You're a good, loyal jester... aren't you?"
    mc "Eres un bufón bueno y leal... ¿verdad?"

# game/script day2.rpy:2594
translate Spanish jestynotfollow_day2_d9c190cc:

    # "The irritation on his face vanished in an instant, replaced by pure surprise. I don't think he was expecting those words from me."
    "La irritación de su rostro se esfumó en un instante, reemplazada por pura sorpresa. No creo que esperara esas palabras de mi parte."

# game/script day2.rpy:2596
translate Spanish jestynotfollow_day2_8280a603:

    # "Maybe... Just maybe... A gentler approach would work after all."
    "Quizás... solo quizás... un enfoque más suave sí funcionaría después de todo."

# game/script day2.rpy:2597
translate Spanish jestynotfollow_day2_ca699d32:

    # "I took a few slow steps toward him."
    "Di unos pasos lentos hacia él."

# game/script day2.rpy:2600
translate Spanish jestynotfollow_day2_fb8b5953:

    # mc "I know you're trying your best to be a jester who's always loyal to their ruler."
    mc "Sé que estás haciendo todo lo posible por ser un bufón siempre leal a su gobernante."

# game/script day2.rpy:2601
translate Spanish jestynotfollow_day2_fe8626d5:

    # mc "And... I truly appreciate that."
    mc "Y... de verdad lo aprecio."

# game/script day2.rpy:2604
translate Spanish jestynotfollow_day2_c5856788:

    # "I reached up and gently cupped his cheek. My thumb softly stroked his skin, hoping to calm him down."
    "Levanté la mano y le acuné suavemente la mejilla. Mi pulgar acarició su piel con delicadeza, con la esperanza de calmarlo."

# game/script day2.rpy:2605
translate Spanish jestynotfollow_day2_330dccd3:

    # "A faint blush gradually spread across Jestyn's cheeks."
    "Un leve rubor se extendió poco a poco por las mejillas de Jestyn."

# game/script day2.rpy:2607
translate Spanish jestynotfollow_day2_e2d3b2ee:

    # mc "But I want to be alone right now."
    mc "Pero ahora quiero estar sol[letra]."

# game/script day2.rpy:2608
translate Spanish jestynotfollow_day2_43e46b4d:

    # mc "And as my loyal jester... I want you to leave me alone. Just for now."
    mc "Y como mi leal bufón... quiero que me dejes en paz. Solo por ahora."

# game/script day2.rpy:2609
translate Spanish jestynotfollow_day2_ab6c7d40:

    # mc "You understand... don't you?"
    mc "Lo entiendes... ¿verdad?"

# game/script day2.rpy:2612
translate Spanish jestynotfollow_day2_4ff7ee2b:

    # "His hands slowly reached for mine, gently enveloping them in his much larger ones."
    "Sus manos se estiraron lentamente hacia las mías, envolviéndolas con delicadeza en sus manos mucho más grandes."

# game/script day2.rpy:2613
translate Spanish jestynotfollow_day2_48b0e356:

    # "Yet his eyes never met mine."
    "Aun así, sus ojos nunca se encontraron con los míos."

# game/script day2.rpy:2614
translate Spanish jestynotfollow_day2_6226652d:

    # "Instead, he stared down at our joined hands."
    "En cambio, miró fijamente nuestras manos unidas."

# game/script day2.rpy:2615
translate Spanish jestynotfollow_day2_b45d79bf:

    # "He looked... conflicted."
    "Se veía... dividido."

# game/script day2.rpy:2617
translate Spanish jestynotfollow_day2_938ef16f:

    # jes "But..."
    jes "Pero..."

# game/script day2.rpy:2618
translate Spanish jestynotfollow_day2_a7d573dc:

    # mc "You're my good boy, aren't you, Jestyn?"
    mc "Eres mi buen chico, ¿verdad, Jestyn?"

# game/script day2.rpy:2621
translate Spanish jestynotfollow_day2_fdd4b4ab:

    # "His entire body shuddered the moment the words left my lips."
    "Todo su cuerpo se estremeció en cuanto las palabras salieron de mis labios."

# game/script day2.rpy:2622
translate Spanish jestynotfollow_day2_db7e0c3a:

    # "The blush on his face deepened, and his breathing became noticeably uneven."
    "El rubor de su rostro se intensificó, y su respiración se volvió notablemente irregular."

# game/script day2.rpy:2624
translate Spanish jestynotfollow_day2_6ca457bb:

    # mc "Tell me..."
    mc "Dime..."

# game/script day2.rpy:2625
translate Spanish jestynotfollow_day2_67e404c6:

    # mc "You're a good boy for me... aren't you?"
    mc "Eres un buen chico para mí... ¿verdad?"

# game/script day2.rpy:2627
translate Spanish jestynotfollow_day2_cda4212d:

    # "He gently took my other hand as well, cradling both of them together."
    "Con delicadeza tomó también mi otra mano, acunando ambas juntas."

# game/script day2.rpy:2628
translate Spanish jestynotfollow_day2_0586bf7b:

    # "Then he slowly lifted them to his lips."
    "Luego las levantó lentamente hasta sus labios."

# game/script day2.rpy:2631
translate Spanish jestynotfollow_day2_fd614201:

    # "Nuzzling into my palms, he pressed a soft kiss against them."
    "Frotándose contra mis palmas, les dio un suave beso."

# game/script day2.rpy:2633
translate Spanish jestynotfollow_day2_4e459a49:

    # jes "...Yes..."
    jes "...Sí..."

# game/script day2.rpy:2635
translate Spanish jestynotfollow_day2_77a3045b:

    # jes "Yes... I'm your good boy, Your Majesty..."
    jes "Sí... Soy su buen chico, Su Majestad..."

# game/script day2.rpy:2637
translate Spanish jestynotfollow_day2_0bbf56a0:

    # "His eyes gazed into mine with unmistakable affection."
    "Sus ojos me miraron con un afecto inconfundible."

# game/script day2.rpy:2638
translate Spanish jestynotfollow_day2_af684081:

    # "I hadn't expected him to react like this."
    "No esperaba que reaccionara así."

# game/script day2.rpy:2639
translate Spanish jestynotfollow_day2_6442f7ae:

    # "I couldn't deny it....He looked incredibly cute."
    "No podía negarlo....Se veía increíblemente tierno."

# game/script day2.rpy:2641
translate Spanish jestynotfollow_day2_ef118786:

    # mc "Then go get some rest, okay?"
    mc "Entonces ve a descansar, ¿de acuerdo?"

# game/script day2.rpy:2642
translate Spanish jestynotfollow_day2_76adb53a:

    # mc "I'm not going anywhere."
    mc "No voy a ir a ninguna parte."

# game/script day2.rpy:2643
translate Spanish jestynotfollow_day2_783df07c:

    # mc "I just want to be by myself for a little while."
    mc "Solo quiero estar a solas un ratito."

# game/script day2.rpy:2644
translate Spanish jestynotfollow_day2_9113d194:

    # jes ".........."
    jes ".........."

# game/script day2.rpy:2647
translate Spanish jestynotfollow_day2_60602b58:

    # "Jestyn gave a reluctant nod and slowly let go of my hands."
    "Jestyn asintió a regañadientes y lentamente soltó mis manos."

# game/script day2.rpy:2648
translate Spanish jestynotfollow_day2_c3ecc33c:

    # "Even though he'd agreed to leave, the sadness on his face made it painfully obvious he didn't actually want to."
    "Aunque había accedido a irse, la tristeza en su rostro dejaba dolorosamente claro que en realidad no quería hacerlo."

# game/script day2.rpy:2651
translate Spanish jestynotfollow_day2_ff1fb864:

    # jes "...If that's truly what Your Majesty wishes....Very well."
    jes "...Si eso es verdaderamente lo que Su Majestad desea....Muy bien."

# game/script day2.rpy:2652
translate Spanish jestynotfollow_day2_929734f0:

    # jes "I'll come back in.....maybe ten minutes."
    jes "Volveré en.....quizás diez minutos."

# game/script day2.rpy:2653
translate Spanish jestynotfollow_day2_5eecb723:

    # mc "Jestyn."
    mc "Jestyn."

# game/script day2.rpy:2654
translate Spanish jestynotfollow_day2_1085206c:

    # mc "...Fifteen, then."
    mc "...Quince, entonces."

# game/script day2.rpy:2655
translate Spanish jestynotfollow_day2_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:2656
translate Spanish jestynotfollow_day2_b2f0e595:

    # jes "...Thirty..."
    jes "...Treinta..."

# game/script day2.rpy:2657
translate Spanish jestynotfollow_day2_763cb627:

    # mc "Two hours and thirty minutes."
    mc "Dos horas y treinta minutos."

# game/script day2.rpy:2658
translate Spanish jestynotfollow_day2_88056451:

    # jes "......"
    jes "......"

# game/script day2.rpy:2659
translate Spanish jestynotfollow_day2_0d756d41:

    # jes "...Couldn't I at least watch over You from afar?"
    jes "...¿No podría al menos velar por usted desde lejos?"

# game/script day2.rpy:2660
translate Spanish jestynotfollow_day2_f28627fe:

    # mc "Then what's your definition of leaving me alone? No."
    mc "Entonces, ¿cuál es tu definición de dejarme en paz? No."

# game/script day2.rpy:2662
translate Spanish jestynotfollow_day2_988babb5:

    # jes "Mmmmmnnnghhhrrrghhh..."
    jes "Mmmmmnnnghhhrrrghhh..."

# game/script day2.rpy:2663
translate Spanish jestynotfollow_day2_3f2af826:

    # jes "....."
    jes "....."

# game/script day2.rpy:2665
translate Spanish jestynotfollow_day2_23aebcf0:

    # jes "...Very well... Until we meet again, Your Majesty..."
    jes "...Muy bien... Hasta que nos veamos de nuevo, Su Majestad..."

# game/script day2.rpy:2667
translate Spanish jestynotfollow_day2_447fc69f:

    # "He slowly walked away, pouting the entire time."
    "Se alejó lentamente, haciendo pucheros todo el camino."

# game/script day2.rpy:2668
translate Spanish jestynotfollow_day2_26ca4397:

    # "He opened the door to his room, then paused."
    "Abrió la puerta de su cuarto y luego se detuvo."

# game/script day2.rpy:2669
translate Spanish jestynotfollow_day2_7c0d6444:

    # "For a few moments, he simply looked back at me with a dejected expression. Only then did he quietly step inside and close the door behind him."
    "Por unos instantes, simplemente me miró con una expresión abatida. Solo entonces entró en silencio y cerró la puerta tras de sí."

# game/script day2.rpy:2671
translate Spanish jestynotfollow_day2_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:2672
translate Spanish jestynotfollow_day2_cad90042:

    # "...He did look like a sad puppy."
    "...Sí que parecía un cachorrito triste."

# game/script day2.rpy:2673
translate Spanish jestynotfollow_day2_790dec40:

    # "But...... This is my chance."
    "Pero...... esta es mi oportunidad."

# game/script day2.rpy:2674
translate Spanish jestynotfollow_day2_e5a53cb3:

    # "I need to find out what's really going on."
    "Necesito averiguar qué está pasando realmente."

# game/script day2.rpy:2675
translate Spanish jestynotfollow_day2_eeb41a61:

    # "My gaze then shifted toward the darker end of the puppets's hallway."
    "Mi mirada se dirigió entonces hacia el extremo más oscuro del pasillo de los títeres."

# game/script day2.rpy:2676
translate Spanish jestynotfollow_day2_a7839a14:

    # "I knew very well that this hallway was much longer than it appeared."
    "Sabía muy bien que este pasillo era mucho más largo de lo que parecía."

# game/script day2.rpy:2677
translate Spanish jestynotfollow_day2_5f53b799:

    # "Yesterday, I hadn't paid much attention to it. I just wanted to finish my duties. But now that my situation had started to feel like something straight out of a fantasy story, I figured I might as well explore it."
    "Ayer no le había prestado mucha atención. Solo quería terminar mis deberes. Pero ahora que mi situación había empezado a parecer sacada de una historia de fantasía, pensé que bien podría explorarlo."

# game/script day2.rpy:2678
translate Spanish jestynotfollow_day2_75d6cfc1:

    # "Damn, I forgot to bring my flashlight. Where did I put it?"
    "Maldición, olvidé traer mi linterna. ¿Dónde la habré puesto?"

# game/script day2.rpy:2679
translate Spanish jestynotfollow_day2_2223c4bf:

    # "I eventually decided to keep walking without one. It couldn't be that dark... right?"
    "Al final decidí seguir caminando sin ella. No podía estar tan oscuro... ¿o sí?"

# game/script day2.rpy:2680
translate Spanish jestynotfollow_day2_055c46b1:

    # "Then I walked deeper through the hallways lined with the puppet's rooms."
    "Entonces me adentré más por los pasillos flanqueados por los cuartos de los títeres."

# game/script day2.rpy:2683
translate Spanish jestynotfollow_day2_545e6d42:

    # "The farther I went, the darker the corridor became."
    "Cuanto más avanzaba, más oscuro se volvía el corredor."

# game/script day2.rpy:2684
translate Spanish jestynotfollow_day2_0c10af72:

    # "There weren't any lights this far in."
    "No había luces tan adentro."

# game/script day2.rpy:2685
translate Spanish jestynotfollow_day2_cd0cf1ba:

    # "I hadn't ventured this deep into the puppet room yesterday, so I had no idea the hallway stretched this far."
    "Ayer no me había aventurado tan hondo en la sala de los títeres, así que no tenía idea de que el pasillo llegara tan lejos."

# game/script day2.rpy:2686
translate Spanish jestynotfollow_day2_8cb595bc:

    # "I even started to wonder if it had an end at all."
    "Incluso empecé a preguntarme si tenía fin."

# game/script day2.rpy:2687
translate Spanish jestynotfollow_day2_ec892cbf:

    # "The farther I walked, the fewer puppet rooms there were..."
    "Cuanto más caminaba, menos cuartos de títeres había..."

# game/script day2.rpy:2688
translate Spanish jestynotfollow_day2_9e70e47c:

    # "...until eventually, there were no more puppet rooms, leaving nothing but bare stone walls."
    "...hasta que al final ya no hubo más cuartos de títeres, solo desnudas paredes de piedra."

# game/script day2.rpy:2689
translate Spanish jestynotfollow_day2_dd1526f2:

    # "Then I saw it."
    "Entonces lo vi."

# game/script day2.rpy:2691
translate Spanish jestynotfollow_day2_6558f7d9:

    # "At the end of the dark hallway stood a single black door."
    "Al final del oscuro pasillo se alzaba una única puerta negra."

# game/script day2.rpy:2692
translate Spanish jestynotfollow_day2_89288c2f:

    # "A sense of unease began to creep over me."
    "Una sensación de inquietud empezó a invadirme."

# game/script day2.rpy:2693
translate Spanish jestynotfollow_day2_e5a8840d:

    # "What door is that, I wonder...?"
    "¿Qué puerta es esa, me pregunto...?"

# game/script day2.rpy:2694
translate Spanish jestynotfollow_day2_8f7c80b1:

    # "Curiosity gnawed at me, tempered by an uneasy feeling in the pit of my stomach, as I slowly made my way toward it."
    "La curiosidad me carcomía, atemperada por una sensación inquietante en la boca del estómago, mientras me acercaba lentamente a ella."

# game/script day2.rpy:2695
translate Spanish jestynotfollow_day2_3b87f91b:

    # "Should I open it...?"
    "¿Debería abrirla...?"

# game/script day2.rpy:2696
translate Spanish jestynotfollow_day2_c683b391:

    # "My hand slowly reached for the doorknob."
    "Mi mano se estiró lentamente hacia el picaporte."

# game/script day2.rpy:2699
translate Spanish jestynotfollow_day2_46264151:

    # who "Your Majesty?"
    who "¿Su Majestad?"

# game/script day2.rpy:2701
translate Spanish jestynotfollow_day2_4e6525d4:

    # "I flinched as a voice suddenly called out from behind me."
    "Me estremecí cuando una voz me llamó de pronto desde atrás."

# game/script day2.rpy:2702
translate Spanish jestynotfollow_day2_6bccfdd3:

    # "I quickly turned toward the source of the voice."
    "Me giré rápidamente hacia el origen de la voz."

# game/script day2.rpy:2705
translate Spanish jestynotfollow_day2_1df1064c:

    # who "I noticed you walking through this hallway by yourself..."
    who "Noté que caminaba usted por este pasillo a solas..."

# game/script day2.rpy:2706
translate Spanish jestynotfollow_day2_33ecd539:

    # who "Is everything alright?"
    who "¿Está todo bien?"

# game/script day2.rpy:2708
translate Spanish jestynotfollow_day2_00bf520f:

    # "A puppet dressed as a butler approached me."
    "Un títere vestido de mayordomo se me acercó."

# game/script day2.rpy:2709
translate Spanish jestynotfollow_day2_99019720:

    # "Oh, he is the butler puppet from yesterday..."
    "Oh, es el títere mayordomo de ayer..."

# game/script day2.rpy:2710
translate Spanish jestynotfollow_day2_ef55b491:

    # "I didn't realize he wasn't in his room."
    "No me había dado cuenta de que no estaba en su cuarto."

# game/script day2.rpy:2713
translate Spanish jestynotfollow_day2_48b83356:

    # butpuppet "You'll end up walking into something in a hallway this dark, Your Majesty."
    butpuppet "Acabará chocando con algo en un pasillo tan oscuro, Su Majestad."

# game/script day2.rpy:2714
translate Spanish jestynotfollow_day2_7b3c30ef:

    # butpuppet "Where are you headed?"
    butpuppet "¿Adónde se dirige?"

# game/script day2.rpy:2715
translate Spanish jestynotfollow_day2_aab7e949:

    # mc "Oh- nowhere, really."
    mc "Oh- a ninguna parte, en realidad."

# game/script day2.rpy:2716
translate Spanish jestynotfollow_day2_1dcb4081:

    # mc "I was just exploring."
    mc "Solo estaba explorando."

# game/script day2.rpy:2717
translate Spanish jestynotfollow_day2_0fbe7faf:

    # mc "I didn't realize the puppet quarters went this far."
    mc "No sabía que los aposentos de los títeres llegaban tan lejos."

# game/script day2.rpy:2718
translate Spanish jestynotfollow_day2_6397692a:

    # butpuppet "Ah. They certainly are larger than they appear, Your Majesty."
    butpuppet "Ah. Ciertamente son más grandes de lo que parecen, Su Majestad."

# game/script day2.rpy:2722
translate Spanish jestynotfollow_day2_a1b98904:

    # but "Please forgive my intrusion, Your Majesty. Allow me to introduce myself. My name is Butley, and I am the puppet butler."
    but "Por favor, perdone mi intromisión, Su Majestad. Permítame presentarme. Me llamo Butley y soy el títere mayordomo."

# game/script day2.rpy:2723
translate Spanish jestynotfollow_day2_e63aebb4:

    # but "I haven't had the chance to meet Your Majesty yet, so I decided to leave my room and introduce myself properly."
    but "Aún no he tenido la oportunidad de conocer a Su Majestad, así que decidí salir de mi cuarto y presentarme como es debido."

# game/script day2.rpy:2725
translate Spanish jestynotfollow_day2_585d6eb5:

    # "I tilted my head in confusion."
    "Incliné la cabeza confundid[letra]."

# game/script day2.rpy:2727
translate Spanish jestynotfollow_day2_a518095c:

    # mc "What do you mean? We met yesterday, didn't we? During the roleplay."
    mc "¿A qué te refieres? Nos conocimos ayer, ¿no? Durante el juego de roles."

# game/script day2.rpy:2730
translate Spanish jestynotfollow_day2_e7bbcfec:

    # "Butley looked just as confused by my puzzled expression."
    "Butley parecía igual de confundido ante mi expresión desconcertada."

# game/script day2.rpy:2732
translate Spanish jestynotfollow_day2_ceaca989:

    # but "Forgive me, Your Majesty... I'm not sure I understand what you mean."
    but "Perdóneme, Su Majestad... no estoy seguro de entender a qué se refiere."

# game/script day2.rpy:2733
translate Spanish jestynotfollow_day2_ada964dd:

    # but "I never left my room yesterday. So I haven't met Your Majesty at all."
    but "Ayer nunca salí de mi cuarto. Así que no he conocido a Su Majestad en absoluto."

# game/script day2.rpy:2734
translate Spanish jestynotfollow_day2_be38ed6a:

    # mc "What? But... I could've sworn I saw you on the stage yesterday... standing beside Jestyn while we were roleplaying."
    mc "¿Qué? Pero... podría haber jurado que te vi en el escenario ayer... de pie junto a Jestyn mientras hacíamos el juego de roles."

# game/script day2.rpy:2736
translate Spanish jestynotfollow_day2_b949972d:

    # but "Ah... Jestyn did ask me to participate in the roleplay beforehand."
    but "Ah... Jestyn sí me pidió que participara en el juego de roles de antemano."

# game/script day2.rpy:2737
translate Spanish jestynotfollow_day2_84306b73:

    # but "But the next day, he told me he had other plans, so my part in the performance was cancelled."
    but "Pero al día siguiente me dijo que tenía otros planes, así que mi papel en la función fue cancelado."

# game/script day2.rpy:2738
translate Spanish jestynotfollow_day2_025bf8ca:

    # but "Perhaps Your Majesty simply remembered incorrectly and mistook someone else for me. Yesterday was your first day here, after all."
    but "Quizás Su Majestad simplemente recordó mal y confundió a alguien más conmigo. Ayer fue su primer día aquí, después de todo."

# game/script day2.rpy:2739
translate Spanish jestynotfollow_day2_196acb30:

    # mc "....Mmhh... I suppose that's possible..."
    mc "....Mmhh... supongo que es posible..."

# game/script day2.rpy:2741
translate Spanish jestynotfollow_day2_f644b0ff:

    # "But... is it really...?"
    "Pero... ¿de verdad lo es...?"

# game/script day2.rpy:2744
translate Spanish jestynotfollow_day2_910f2051:

    # but "......How about I keep You company? We haven't really had the chance to talk before."
    but "......¿Qué tal si le hago compañía? No hemos tenido la oportunidad de hablar antes."

# game/script day2.rpy:2748
translate Spanish jestynotfollow_day2_d64ab0b1:

    # "I hesitated for a moment before finally accepting his offer."
    "Dudé un momento antes de aceptar finalmente su oferta."

# game/script day2.rpy:2749
translate Spanish jestynotfollow_day2_33e5ee26:

    # "Maybe I could ask him a few questions."
    "Quizás podría hacerle unas cuantas preguntas."

# game/script day2.rpy:2750
translate Spanish jestynotfollow_day2_7d66839c:

    # "If anyone knew what was going on around here, it might be one of the other puppets."
    "Si alguien sabía qué estaba pasando por aquí, podría ser alguno de los otros títeres."

# game/script day2.rpy:2752
translate Spanish jestynotfollow_day2_3582cf99:

    # "The two of us began walking together, leaving the puppet quarters behind."
    "Los dos empezamos a caminar juntos, dejando atrás los aposentos de los títeres."

# game/script day2.rpy:2753
translate Spanish jestynotfollow_day2_79541d23:

    # "We exchanged a bit of small talk before I finally decided to ask the questions that had been lingering in my mind."
    "Intercambiamos un poco de charla trivial antes de que por fin me decidiera a hacer las preguntas que me rondaban la mente."

# game/script day2.rpy:2755
translate Spanish jestynotfollow_day2_51120ef7:

    # mc "Butley, may I ask you few questions?"
    mc "Butley, ¿puedo hacerte unas preguntas?"

# game/script day2.rpy:2757
translate Spanish jestynotfollow_day2_be13e38c:

    # but "Certainly, Your Majesty."
    but "Por supuesto, Su Majestad."

# game/script day2.rpy:2764
translate Spanish butley_askday2_d1a4e19f:

    # "His body suddenly went stiff for a moment."
    "Su cuerpo se puso rígido de repente por un momento."

# game/script day2.rpy:2766
translate Spanish butley_askday2_e13920c9:

    # but "Jestyn...? Mm..."
    but "¿Jestyn...? Mm..."

# game/script day2.rpy:2767
translate Spanish butley_askday2_d0c3a567:

    # but "He... is fine... I suppose."
    but "Él... está bien... supongo."

# game/script day2.rpy:2768
translate Spanish butley_askday2_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:2769
translate Spanish butley_askday2_a30446b0:

    # mc "You don't sound very convinced."
    mc "No suenas muy convencido."

# game/script day2.rpy:2770
translate Spanish butley_askday2_d31eba54:

    # but "......"
    but "......"

# game/script day2.rpy:2772
translate Spanish butley_askday2_1b7fbca0:

    # "Butley glanced around the room, his eyes wary as if making sure no one else was listening"
    "Butley miró alrededor de la sala, con ojos cautelosos como para asegurarse de que nadie más escuchaba"

# game/script day2.rpy:2774
translate Spanish butley_askday2_0e31d51b:

    # but "To be honest, Your Majesty... I shouldn't be telling you this..."
    but "Para ser sincero, Su Majestad... no debería estar diciéndole esto..."

# game/script day2.rpy:2775
translate Spanish butley_askday2_1c758fc3:

    # but "But... since you asked for my opinion..."
    but "Pero... ya que me pidió mi opinión..."

# game/script day2.rpy:2777
translate Spanish butley_askday2_eb698877:

    # but "I don't like Jestyn."
    but "No me agrada Jestyn."

# game/script day2.rpy:2779
translate Spanish butley_askday2_ab1c47e1:

    # "The answer caught me completely off guard, and I couldn't hide my surprise."
    "La respuesta me tomó completamente desprevenid[letra], y no pude ocultar mi sorpresa."

# game/script day2.rpy:2781
translate Spanish butley_askday2_2c14c9b1:

    # mc "...Why?"
    mc "...¿Por qué?"

# game/script day2.rpy:2782
translate Spanish butley_askday2_5d3aef76:

    # but "He in my eyes, he knows nothing."
    but "A mis ojos, él no sabe nada."

# game/script day2.rpy:2784
translate Spanish butley_askday2_b409bfa4:

    # but "Yet he acts as though he knows what's best for all of us."
    but "Aun así actúa como si supiera lo que es mejor para todos nosotros."

# game/script day2.rpy:2785
translate Spanish butley_askday2_f58e3b6b:

    # but "He carries himself like some wise and capable leader... but the truth is nothing like that."
    but "Se comporta como un líder sabio y capaz... pero la verdad no se parece en nada a eso."

# game/script day2.rpy:2787
translate Spanish butley_askday2_f18be321:

    # "Butley looked up at me. One hand clutched tightly at his shirt as a single drop of black liquid slipped from his eye."
    "Butley me miró. Una mano se aferraba con fuerza a su camisa mientras una sola gota de líquido negro se deslizaba de su ojo."

# game/script day2.rpy:2789
translate Spanish butley_askday2_a9d955ce:

    # but "He doesn't want us to have a better life."
    but "Él no quiere que tengamos una vida mejor."

# game/script day2.rpy:2790
translate Spanish butley_askday2_2af8298d:

    # but "To Your Majesty, Jestyn is a cheerful, kind, lovable puppet... isn't he?"
    but "Para Su Majestad, Jestyn es un títere alegre, amable y adorable... ¿no es así?"

# game/script day2.rpy:2791
translate Spanish butley_askday2_4935530e:

    # but "He's lying to you. It's all an act. He's only pretending so you'll put your trust in him."
    but "Le está mintiendo. Todo es un acto. Solo finge para que usted ponga su confianza en él."

# game/script day2.rpy:2793
translate Spanish butley_askday2_80835949:

    # "Jestyn...? Lying to me?"
    "¿Jestyn...? ¿Mintiéndome?"

# game/script day2.rpy:2794
translate Spanish butley_askday2_34f6d4ef:

    # "My mind struggled to process everything Butley had just told me."
    "Mi mente luchaba por procesar todo lo que Butley acababa de decirme."

# game/script day2.rpy:2795
translate Spanish butley_askday2_6c4862f3:

    # "...... So... he's been deceiving me this whole time? But why...?"
    "...... Entonces... ¿me ha estado engañando todo este tiempo? Pero ¿por qué...?"

# game/script day2.rpy:2796
translate Spanish butley_askday2_a37b8726:

    # "What exactly has he been lying about?"
    "¿Sobre qué exactamente ha estado mintiendo?"

# game/script day2.rpy:2798
translate Spanish butley_askday2_a1af6dc9:

    # but "I don't know what he's planning... but..."
    but "No sé qué está planeando... pero..."

# game/script day2.rpy:2799
translate Spanish butley_askday2_2e9ed964:

    # but "Sooner or later... he may try to use you, Your Majesty."
    but "Tarde o temprano... podría intentar usarle, Su Majestad."

# game/script day2.rpy:2801
translate Spanish butley_askday2_11ca7087:

    # "A chill of fear and unease slowly crept through my body."
    "Un escalofrío de miedo e inquietud se fue extendiendo por mi cuerpo."

# game/script day2.rpy:2803
translate Spanish butley_askday2_e81c511d:

    # but "....."
    but "....."

# game/script day2.rpy:2805
translate Spanish butley_askday2_da4cb515:

    # but "Ah... forgive me, Your Majesty. I didn't mean to frighten you... it's just..."
    but "Ah... perdóneme, Su Majestad. No quise asustarle... es solo que..."

# game/script day2.rpy:2806
translate Spanish butley_askday2_facbe132:

    # but "I wanted to warn you while I still could. Please... be careful."
    but "Quería advertirle mientras aún podía. Por favor... tenga cuidado."

# game/script day2.rpy:2813
translate Spanish butley_askday2_f90f29db:

    # "The moment I mentioned the King Puppet, Butley's head snapped toward me."
    "En cuanto mencioné al Rey Títere, la cabeza de Butley giró bruscamente hacia mí."

# game/script day2.rpy:2815
translate Spanish butley_askday2_a19a9776:

    # "His face lit up, and a broad smile spread across it."
    "Su rostro se iluminó y una amplia sonrisa se extendió por él."

# game/script day2.rpy:2817
translate Spanish butley_askday2_75e0541f:

    # but "Ah! You mean Lord Crownus, Your Majesty!"
    but "¡Ah! ¡Se refiere a Lord Crownus, Su Majestad!"

# game/script day2.rpy:2818
translate Spanish butley_askday2_677d6a2e:

    # but "He's the best!"
    but "¡Es el mejor!"

# game/script day2.rpy:2819
translate Spanish butley_askday2_563dda9b:

    # but "He wants what's best for all of us! He's helping each and every one of us find our way."
    but "¡Quiere lo mejor para todos nosotros! Está ayudando a cada uno de nosotros a encontrar nuestro camino."

# game/script day2.rpy:2820
translate Spanish butley_askday2_274c29ce:

    # but "And we're more than happy to give everything we have to Lord Crownus as a token of our immense gratitude!"
    but "¡Y estamos más que felices de darle todo lo que tenemos a Lord Crownus como muestra de nuestra inmensa gratitud!"

# game/script day2.rpy:2822
translate Spanish butley_askday2_d35c43e7:

    # but "Lord Crownus truly saved us... unlike... someone else..."
    but "Lord Crownus de verdad nos salvó... a diferencia de... cierto alguien..."

# game/script day2.rpy:2824
translate Spanish butley_askday2_a3833171:

    # "I listened carefully to everything Butley had to say."
    "Escuché con atención todo lo que Butley tenía que decir."

# game/script day2.rpy:2825
translate Spanish butley_askday2_47050867:

    # "From the way he spoke, it was clear that, in Butley's eyes, Crownus was nothing short of a savior."
    "Por su forma de hablar, estaba claro que, a los ojos de Butley, Crownus no era nada menos que un salvador."

# game/script day2.rpy:2827
translate Spanish butley_askday2_6fd88ccf:

    # mc "You seem to admire Crownus a lot."
    mc "Pareces admirar mucho a Crownus."

# game/script day2.rpy:2829
translate Spanish butley_askday2_0eaa0eac:

    # but "Of course I do!"
    but "¡Por supuesto que sí!"

# game/script day2.rpy:2830
translate Spanish butley_askday2_31f3632d:

    # but "And I'm not the only one. Many of the other puppets feel the same way."
    but "Y no soy el único. Muchos de los otros títeres sienten lo mismo."

# game/script day2.rpy:2832
translate Spanish butley_askday2_84d2e22d:

    # "The others think so too...?"
    "¿Los demás también lo piensan...?"

# game/script day2.rpy:2834
translate Spanish butley_askday2_7bb45120:

    # but "To most of the puppets here, Lord Crownus is a genius."
    but "Para la mayoría de los títeres de aquí, Lord Crownus es un genio."

# game/script day2.rpy:2835
translate Spanish butley_askday2_d9c91627:

    # but "Myself included."
    but "Yo incluido."

# game/script day2.rpy:2836
translate Spanish butley_askday2_a7bcf340:

    # mc "I see..."
    mc "Ya veo..."

# game/script day2.rpy:2842
translate Spanish butley_askday2_ff0797af:

    # mc "How about... your relationship with the other puppets? There aren't any problems, are there?"
    mc "¿Y... tu relación con los otros títeres? No hay ningún problema, ¿verdad?"

# game/script day2.rpy:2843
translate Spanish butley_askday2_e81c511d_1:

    # but "....."
    but "....."

# game/script day2.rpy:2845
translate Spanish butley_askday2_453adabf:

    # "Butley fell silent as we continued walking."
    "Butley guardó silencio mientras seguíamos caminando."

# game/script day2.rpy:2846
translate Spanish butley_askday2_996283ec:

    # "Did I say something I shouldn't have...?"
    "¿Dije algo que no debía...?"

# game/script day2.rpy:2848
translate Spanish butley_askday2_d57fe4db:

    # mc "Sorry if that's a sensitive topic."
    mc "Perdona si ese es un tema delicado."

# game/script day2.rpy:2850
translate Spanish butley_askday2_8d872f9b:

    # but "Not at all, Your Majesty."
    but "En absoluto, Su Majestad."

# game/script day2.rpy:2851
translate Spanish butley_askday2_d31eba54_1:

    # but "......"
    but "......"

# game/script day2.rpy:2853
translate Spanish butley_askday2_cffd7fd8:

    # but "I get along well with some of the other puppets... and not so well with others."
    but "Me llevo bien con algunos de los otros títeres... y no tan bien con otros."

# game/script day2.rpy:2854
translate Spanish butley_askday2_0c556f4f:

    # mc "...Why is that?"
    mc "...¿Por qué es eso?"

# game/script day2.rpy:2855
translate Spanish butley_askday2_bccfebcf:

    # but "..... You could say... we have different views."
    but "..... Digamos que... tenemos puntos de vista distintos."

# game/script day2.rpy:2856
translate Spanish butley_askday2_82e775f5:

    # but "...And... sadly, I don't see eye to eye with my older sisters, either."
    but "...Y... lamentablemente, tampoco me llevo bien con mis hermanas mayores."

# game/script day2.rpy:2858
translate Spanish butley_askday2_fc2e40f1:

    # "My curiosity immediately piqued when Butley mentioned his older sisters."
    "Mi curiosidad se despertó de inmediato cuando Butley mencionó a sus hermanas mayores."

# game/script day2.rpy:2860
translate Spanish butley_askday2_336c28bc:

    # mc "You have older sisters?"
    mc "¿Tienes hermanas mayores?"

# game/script day2.rpy:2861
translate Spanish butley_askday2_bc8bc628:

    # but "I do. They're triplets. If you've already met them, they're the maids."
    but "Sí. Son trillizas. Si ya las ha conocido, son las doncellas."

# game/script day2.rpy:2863
translate Spanish butley_askday2_fa9c20e8:

    # "Oh! So Maidelyn, Maidy, and Maidra are Butley's older sisters?"
    "¡Oh! ¿Así que Maidelyn, Maidy y Maidra son las hermanas mayores de Butley?"

# game/script day2.rpy:2865
translate Spanish butley_askday2_4d5e24b0:

    # mc "I've met all three of them, yes."
    mc "Sí, he conocido a las tres."

# game/script day2.rpy:2867
translate Spanish butley_askday2_cf39b74a:

    # but "I hope they made a good first impression on Your Majesty."
    but "Espero que hayan causado una buena primera impresión en Su Majestad."

# game/script day2.rpy:2868
translate Spanish butley_askday2_dbfec604:

    # but "The four of us used to be very close... but..."
    but "Los cuatro solíamos ser muy unidos... pero..."

# game/script day2.rpy:2870
translate Spanish butley_askday2_329f1853:

    # "Butley paused for a moment."
    "Butley hizo una pausa."

# game/script day2.rpy:2872
translate Spanish butley_askday2_37cadd84:

    # but "Not anymore. Ever since Lord Crownus died, we've gone our separate ways."
    but "Ya no. Desde que Lord Crownus murió, cada uno tomó su propio camino."

# game/script day2.rpy:2873
translate Spanish butley_askday2_eb814401:

    # but "We still talk from time to time... but it's nothing more than exchanging greetings. Like... strangers who coincidentally meet each other."
    but "Todavía hablamos de vez en cuando... pero no es más que intercambiar saludos. Como... desconocidos que se topan por casualidad."

# game/script day2.rpy:2874
translate Spanish butley_askday2_a537a70a:

    # but "To be honest... I wish we could be close again."
    but "Para ser sincero... desearía que pudiéramos volver a ser unidos."

# game/script day2.rpy:2877
translate Spanish butley_askday2_24089d30:

    # "I tried to comfort him by gently patting his back."
    "Intenté consolarlo dándole palmaditas suaves en la espalda."

# game/script day2.rpy:2878
translate Spanish butley_askday2_0c7d0285:

    # "At first, Butley flinched in surprise, but after a moment, he simply let me continue."
    "Al principio, Butley se sobresaltó, pero tras un momento simplemente me dejó continuar."

# game/script day2.rpy:2880
translate Spanish butley_askday2_9586aaeb:

    # mc "Mmm... What about Wizzy? He seems like a nice puppet. I would've thought he was close to everyone."
    mc "Mmm... ¿Y Wizzy? Parece un títere amable. Habría pensado que era cercano a todos."

# game/script day2.rpy:2883
translate Spanish butley_askday2_a3d0848a:

    # "The moment I mentioned Wizzy, Butley's expression immediately hardened."
    "En cuanto mencioné a Wizzy, la expresión de Butley se endureció de inmediato."

# game/script day2.rpy:2885
translate Spanish butley_askday2_312f9eaa:

    # but "Not anymore."
    but "Ya no."

# game/script day2.rpy:2886
translate Spanish butley_askday2_db501e60:

    # but "He really is a kind puppet. But... once again, we have very different beliefs. And those differences are so fundamental that I simply can't bring myself to be around him."
    but "De verdad es un títere amable. Pero... una vez más, tenemos creencias muy distintas. Y esas diferencias son tan fundamentales que simplemente no puedo soportar estar a su lado."

# game/script day2.rpy:2887
translate Spanish butley_askday2_428d7398:

    # but "And he isn't comfortable being around me either... so... we haven't spoken since."
    but "Y él tampoco se siente cómodo estando cerca de mí... así que... no hemos hablado desde entonces."

# game/script day2.rpy:2889
translate Spanish butley_askday2_e0011e15:

    # "What could've happened between Butley and Wizzy that made them so uncomfortable around each other...?"
    "¿Qué habría podido pasar entre Butley y Wizzy para que se sintieran tan incómodos el uno con el otro...?"

# game/script day2.rpy:2891
translate Spanish butley_askday2_d9dd23d8:

    # mc "What happened between you two actually?"
    mc "¿Qué pasó entre ustedes dos, en realidad?"

# game/script day2.rpy:2893
translate Spanish butley_askday2_e81c511d_2:

    # but "....."
    but "....."

# game/script day2.rpy:2894
translate Spanish butley_askday2_62db088c:

    # but "Just personal matters. Nothing important."
    but "Solo asuntos personales. Nada importante."

# game/script day2.rpy:2896
translate Spanish butley_askday2_db930dca:

    # "Seems like he doesn't want to talk about it."
    "Parece que no quiere hablar de ello."

# game/script day2.rpy:2898
translate Spanish butley_askday2_44129eb2:

    # mc "Then... are you close with Knighter?"
    mc "Entonces... ¿eres cercano a Knighter?"

# game/script day2.rpy:2900
translate Spanish butley_askday2_468c3367:

    # but "Ah... Knighter..."
    but "Ah... Knighter..."

# game/script day2.rpy:2901
translate Spanish butley_askday2_832b32e9:

    # but "To be honest, we're not particularly close. But we do respect each other."
    but "Para ser sincero, no somos particularmente cercanos. Pero nos respetamos."

# game/script day2.rpy:2902
translate Spanish butley_askday2_e77cd47f:

    # but "That said... I think Knighter is an extraordinary puppet."
    but "Dicho eso... creo que Knighter es un títere extraordinario."

# game/script day2.rpy:2904
translate Spanish butley_askday2_9e1c6ec2:

    # but "His loyalty is unwavering. Even now, he's still devoted to Lord Crownus, and I'm relieved that hasn't changed."
    but "Su lealtad es inquebrantable. Incluso ahora sigue devoto a Lord Crownus, y me tranquiliza que eso no haya cambiado."

# game/script day2.rpy:2905
translate Spanish butley_askday2_e929073d:

    # but "He inspires me to remain loyal to Lord Crownus as well. That's why I have so much respect for him."
    but "Me inspira a seguir siendo leal a Lord Crownus también. Por eso le tengo tanto respeto."

# game/script day2.rpy:2907
translate Spanish butley_askday2_414ea0fd:

    # "So, at least Butley and Knighter don't have any problems with each other. That's a relief... I think."
    "Así que, al menos Butley y Knighter no tienen problemas entre sí. Es un alivio... creo."

# game/script day2.rpy:2911
translate Spanish butley_askday2_07bdde05:

    # "....."
    "....."

# game/script day2.rpy:2913
translate Spanish butley_askday2_f73cfc38:

    # mc "What about the puppet named Prieston? Are you close with him?"
    mc "¿Y el títere llamado Prieston? ¿Eres cercano a él?"

# game/script day2.rpy:2916
translate Spanish butley_askday2_7aced1ee:

    # "The moment I mentioned Prieston's name, Butley turned to me with a puzzled expression."
    "En cuanto mencioné el nombre de Prieston, Butley se volvió hacia mí con una expresión desconcertada."

# game/script day2.rpy:2918
translate Spanish butley_askday2_d818f313:

    # but "...Your Majesty knows Prieston?"
    but "...¿Su Majestad conoce a Prieston?"

# game/script day2.rpy:2919
translate Spanish butley_askday2_bf1bf5a3:

    # mc "Not really... I haven't met him yet. Wizzy was the one who told me about him."
    mc "En realidad no... todavía no lo he conocido. Wizzy fue quien me habló de él."

# game/script day2.rpy:2920
translate Spanish butley_askday2_34cec937:

    # mc "Is something wrong?"
    mc "¿Pasa algo?"

# game/script day2.rpy:2921
translate Spanish butley_askday2_afb74447:

    # but "No, of course not..."
    but "No, claro que no..."

# game/script day2.rpy:2922
translate Spanish butley_askday2_cb3b91de:

    # but "It's just... I think he's... I don't know..."
    but "Es solo que... creo que es... no sé..."

# game/script day2.rpy:2923
translate Spanish butley_askday2_aa83cd3d:

    # but "Strange...? Though... I don't think 'strange' is quite the right word."
    but "¿Extraño...? Aunque... no creo que 'extraño' sea exactamente la palabra correcta."

# game/script day2.rpy:2924
translate Spanish butley_askday2_7e02bf55:

    # mc "What makes you say that?"
    mc "¿Por qué dices eso?"

# game/script day2.rpy:2926
translate Spanish butley_askday2_c8cbbc46:

    # but "On the day Lord Crownus died... many of the puppets were overcome with emotion..."
    but "El día que murió Lord Crownus... muchos de los títeres se vieron desbordados por la emoción..."

# game/script day2.rpy:2927
translate Spanish butley_askday2_c205a313:

    # but "There were tears... anger... fear... it was all mixed together."
    but "Había lágrimas... ira... miedo... todo mezclado."

# game/script day2.rpy:2928
translate Spanish butley_askday2_c6932fbb:

    # but "But him... I still remember it clearly..."
    but "Pero él... todavía lo recuerdo con claridad..."

# game/script day2.rpy:2929
translate Spanish butley_askday2_3b8bea20:

    # but "He was smiling from behind the curtains... while staring at Lord Crownus's body."
    but "Sonreía desde detrás de las cortinas... mientras miraba fijamente el cuerpo de Lord Crownus."

# game/script day2.rpy:2931
translate Spanish butley_askday2_cd6d4c1f:

    # "Wizzy's earlier description of Prieston suddenly felt much more believable. Whoever this puppet was, my curiosity about him only grew."
    "La descripción que Wizzy había hecho de Prieston antes de pronto me pareció mucho más creíble. Quienquiera que fuera este títere, mi curiosidad por él no hizo más que crecer."

# game/script day2.rpy:2933
translate Spanish butley_askday2_3b914a35:

    # mc "Have you ever talked to him?"
    mc "¿Has hablado alguna vez con él?"

# game/script day2.rpy:2934
translate Spanish butley_askday2_c267196e:

    # but "A few times, but very rarely. He almost never leaves his room."
    but "Un par de veces, pero muy rara vez. Casi nunca sale de su cuarto."

# game/script day2.rpy:2935
translate Spanish butley_askday2_3e4bc602:

    # but "The only way to meet Prieston is if he chooses to come out... or if someone goes to his room."
    but "La única forma de conocer a Prieston es que él decida salir... o que alguien vaya a su cuarto."

# game/script day2.rpy:2936
translate Spanish butley_askday2_9b16bbb5:

    # but "And... there was one time I happened to find him standing alone on the stage, surrounded by darkness."
    but "Y... hubo una vez que me lo encontré de pie a solas en el escenario, rodeado de oscuridad."

# game/script day2.rpy:2938
translate Spanish butley_askday2_1dabb730:

    # "For some reason, a chill ran down my spine."
    "Por alguna razón, un escalofrío me recorrió la espalda."

# game/script day2.rpy:2940
translate Spanish butley_askday2_928e5677:

    # mc "What was he doing there...?"
    mc "¿Qué hacía allí...?"

# game/script day2.rpy:2941
translate Spanish butley_askday2_be9825e2:

    # but "I don't know either. I asked him the same thing when I approached him."
    but "Yo tampoco lo sé. Le hice la misma pregunta cuando me acerqué a él."

# game/script day2.rpy:2942
translate Spanish butley_askday2_32868e02:

    # but "And he told me... that watching Lord Crownus's death was... fascinating."
    but "Y me dijo... que ver la muerte de Lord Crownus fue... fascinante."

# game/script day2.rpy:2943
translate Spanish butley_askday2_cd120ed7:

    # but "So... I think you can understand why my feelings toward Prieston are... complicated."
    but "Así que... creo que puede entender por qué mis sentimientos hacia Prieston son... complicados."

# game/script day2.rpy:2944
translate Spanish butley_askday2_55171819:

    # but "I'm not even sure whether I hate him or not."
    but "Ni siquiera sé si lo odio o no."

# game/script day2.rpy:2945
translate Spanish butley_askday2_054c5ee0:

    # mc "I see."
    mc "Ya veo."

# game/script day2.rpy:2947
translate Spanish butley_askday2_55b602a3:

    # "Interesting.... Now I wonder what he looks like..."
    "Interesante.... Ahora me pregunto cómo será..."

# game/script day2.rpy:2958
translate Spanish the_truth_route_2_6cb09b08:

    # "Before either of us realized it, we'd arrived at the stage."
    "Antes de que ninguno de los dos nos diéramos cuenta, habíamos llegado al escenario."

# game/script day2.rpy:2961
translate Spanish the_truth_route_2_f249669a:

    # but ".........."
    but ".........."

# game/script day2.rpy:2962
translate Spanish the_truth_route_2_ead283b4:

    # but "Your Majesty..."
    but "Su Majestad..."

# game/script day2.rpy:2963
translate Spanish the_truth_route_2_52d5f599:

    # but "...It's been a very long time since I last spoke to a human."
    but "...Hace muchísimo tiempo que no hablo con un humano."

# game/script day2.rpy:2965
translate Spanish the_truth_route_2_510a1e83:

    # "He paused."
    "Hizo una pausa."

# game/script day2.rpy:2967
translate Spanish the_truth_route_2_7fd7da17:

    # but "I... don't hold any grudge against humans."
    but "Yo... no guardo ningún rencor hacia los humanos."

# game/script day2.rpy:2968
translate Spanish the_truth_route_2_defad43d:

    # but "It's just..."
    but "Es solo que..."

# game/script day2.rpy:2973
translate Spanish the_truth_route_2_d75365bc:

    # "Butley fell silent again, struggling to find the right words."
    "Butley volvió a guardar silencio, luchando por encontrar las palabras adecuadas."

# game/script day2.rpy:2976
translate Spanish the_truth_route_2_b538f32f:

    # but "King Crownus..."
    but "El Rey Crownus..."

# game/script day2.rpy:2977
translate Spanish the_truth_route_2_91f61111:

    # but "...he gave us hope."
    but "...nos dio esperanza."

# game/script day2.rpy:2979
translate Spanish the_truth_route_2_14540d24:

    # but "He showed us a way for us puppets to live better lives."
    but "Nos mostró un camino para que los títeres viviéramos mejores vidas."

# game/script day2.rpy:2980
translate Spanish the_truth_route_2_c448d33b:

    # but "I thought..."
    but "Yo pensé..."

# game/script day2.rpy:2981
translate Spanish the_truth_route_2_00cdd5df:

    # but "...we all thought..."
    but "...todos pensamos..."

# game/script day2.rpy:2982
translate Spanish the_truth_route_2_d30a0998:

    # but "...everything was finally going to be alright."
    but "...que por fin todo iba a salir bien."

# game/script day2.rpy:2984
translate Spanish the_truth_route_2_39049da9:

    # but "But it all fell apart in an instant..."
    but "Pero todo se vino abajo en un instante..."

# game/script day2.rpy:2985
translate Spanish the_truth_route_2_89aab0b5:

    # but "Our hope was shattered..."
    but "Nuestra esperanza se hizo añicos..."

# game/script day2.rpy:2986
translate Spanish the_truth_route_2_def984dd:

    # but "Everything was..."
    but "Todo fue..."

# game/script day2.rpy:2987
translate Spanish the_truth_route_2_818ae0ad:

    # but "...because of Jestyn."
    but "...por culpa de Jestyn."

# game/script day2.rpy:2990
translate Spanish the_truth_route_2_fdb1f559:

    # "I froze as Butley's voice grew noticeably heavier when he spoke Jestyn's name."
    "Me quedé helad[letra] cuando la voz de Butley se volvió notablemente más grave al pronunciar el nombre de Jestyn."

# game/script day2.rpy:2991
translate Spanish the_truth_route_2_6ef36b8b:

    # "An uneasy feeling crept through my body."
    "Una sensación de inquietud se fue extendiendo por mi cuerpo."

# game/script day2.rpy:2992
translate Spanish the_truth_route_2_1d5abeab:

    # "I instinctively took a small step back."
    "Instintivamente retrocedí un pequeño paso."

# game/script day2.rpy:2994
translate Spanish the_truth_route_2_094cc80a:

    # but "He's the one who destroyed everything."
    but "Él es quien lo destruyó todo."

# game/script day2.rpy:2997
translate Spanish the_truth_route_2_d77349ca:

    # but "I hate him."
    but "Lo odio."

# game/script day2.rpy:2998
translate Spanish the_truth_route_2_8ab3b6ec:

    # but "And I hate the fact that he's so much stronger than I am..."
    but "Y odio el hecho de que sea mucho más fuerte que yo..."

# game/script day2.rpy:2999
translate Spanish the_truth_route_2_e8360cab:

    # but "It means I can't do anything."
    but "Significa que no puedo hacer nada."

# game/script day2.rpy:3000
translate Spanish the_truth_route_2_2e0b18d5:

    # but "...The truth is..."
    but "...La verdad es que..."

# game/script day2.rpy:3001
translate Spanish the_truth_route_2_b52428ce:

    # but "...I've wanted to kill him for a very long time."
    but "...He querido matarlo desde hace muchísimo tiempo."

# game/script day2.rpy:3003
translate Spanish the_truth_route_2_2b9a7e9e:

    # "This isn't good."
    "Esto no es bueno."

# game/script day2.rpy:3005
translate Spanish the_truth_route_2_47689d5e:

    # but "And then..."
    but "Y luego..."

# game/script day2.rpy:3006
translate Spanish the_truth_route_2_a8806304:

    # but "...he had the audacity to crown a human as our ruler..."
    but "...tuvo la desfachatez de coronar a un humano como nuestro gobernante..."

# game/script day2.rpy:3007
translate Spanish the_truth_route_2_a3754eb2:

    # but "As if he could simply replace King Crownus..."
    but "Como si pudiera reemplazar sin más al Rey Crownus..."

# game/script day2.rpy:3009
translate Spanish the_truth_route_2_c059d575:

    # "After muttering to himself for a while, Butley slowly raised his head and looked at me."
    "Tras murmurar para sí mismo un rato, Butley alzó lentamente la cabeza y me miró."

# game/script day2.rpy:3010
translate Spanish the_truth_route_2_30ee2f26:

    # "A strange black liquid trickled from his eyes and the corners of his mouth."
    "Un extraño líquido negro le resbalaba de los ojos y de las comisuras de la boca."

# game/script day2.rpy:3013
translate Spanish the_truth_route_2_c747e3af:

    # "Before I could react, he suddenly grabbed my wrist."
    "Antes de que pudiera reaccionar, me agarró de repente la muñeca."

# game/script day2.rpy:3015
translate Spanish the_truth_route_2_c1e2f385:

    # "I immediately struggled to pull myself free from his grip."
    "De inmediato forcejeé para zafarme de su agarre."

# game/script day2.rpy:3017
translate Spanish the_truth_route_2_2d4e7af1:

    # but "But that's alright..."
    but "Pero no importa..."

# game/script day2.rpy:3018
translate Spanish the_truth_route_2_53a64c2c:

    # but "You're human."
    but "Eres human[letra]."

# game/script day2.rpy:3019
translate Spanish the_truth_route_2_83a2ca4c:

    # but "That means you can still be useful to us."
    but "Eso significa que todavía puedes sernos útil."

# game/script day2.rpy:3020
translate Spanish the_truth_route_2_c29d08c5:

    # but "King Crownus discovered a way for us puppets to have better lives..."
    but "El Rey Crownus descubrió una manera de que los títeres tuviéramos vidas mejores..."

# game/script day2.rpy:3021
translate Spanish the_truth_route_2_b3caee68:

    # but "All I have to do..."
    but "Todo lo que tengo que hacer..."

# game/script day2.rpy:3022
translate Spanish the_truth_route_2_06fc31eb:

    # but "...is follow the same path he did."
    but "...es seguir el mismo camino que él siguió."

# game/script day2.rpy:3023
translate Spanish the_truth_route_2_85772554:

    # mc "B-Butley, let me go!"
    mc "¡B-Butley, suéltame!"

# game/script day2.rpy:3026
translate Spanish the_truth_route_2_94e3bc96:

    # "I kicked at him with all the strength I had, trying to break free."
    "Lo pateé con todas mis fuerzas, intentando liberarme."

# game/script day2.rpy:3029
translate Spanish the_truth_route_2_6d44199c:

    # "But little by little, my body began to weaken."
    "Pero poco a poco, mi cuerpo empezó a debilitarse."

# game/script day2.rpy:3030
translate Spanish the_truth_route_2_4e2a6ad7:

    # "A wave of dizziness washed over me."
    "Una oleada de mareo me invadió."

# game/script day2.rpy:3031
translate Spanish the_truth_route_2_280c1657:

    # "It felt as though....something inside me was being forcibly pulled out."
    "Se sentía como si....algo dentro de mí estuviera siendo arrancado a la fuerza."

# game/script day2.rpy:3032
translate Spanish the_truth_route_2_c106290a:

    # "My vision blurred and I could no longer focus."
    "Mi vista se nubló y ya no podía enfocar."

# game/script day2.rpy:3036
translate Spanish the_truth_route_2_0725d7cb:

    # who "Butley! So you finally caught that human! Hahaha!"
    who "¡Butley! ¡Así que por fin atrapaste a ese humano! ¡Jajaja!"

# game/script day2.rpy:3037
translate Spanish the_truth_route_2_7fd5d3ab:

    # who "I can't believe your plan actually worked!"
    who "¡No puedo creer que tu plan realmente funcionara!"

# game/script day2.rpy:3038
translate Spanish the_truth_route_2_fdaf54cf:

    # but "Yes..."
    but "Sí..."

# game/script day2.rpy:3040
translate Spanish the_truth_route_2_753b20be:

    # "Faintly, I could hear other voices talking to Butley."
    "Débilmente, pude oír otras voces hablando con Butley."

# game/script day2.rpy:3041
translate Spanish the_truth_route_2_50e0b07b:

    # "Were those... other puppets?"
    "¿Eran esos... otros títeres?"

# game/script day2.rpy:3043
translate Spanish the_truth_route_2_bff3544e:

    # pup1 "Hey, Butley, share some with us! I need that human too!"
    pup1 "¡Oye, Butley, comparte con nosotros! ¡Yo también necesito a ese humano!"

# game/script day2.rpy:3044
translate Spanish the_truth_route_2_5862c0f6:

    # pup2 "Why are you taking so long? Hurry up!"
    pup2 "¿Por qué tardas tanto? ¡Date prisa!"

# game/script day2.rpy:3045
translate Spanish the_truth_route_2_839bae27:

    # but "........."
    but "........."

# game/script day2.rpy:3046
translate Spanish the_truth_route_2_779f8168:

    # but "I... I..."
    but "Yo... yo..."

# game/script day2.rpy:3048
translate Spanish the_truth_route_2_736ced4e:

    # "For some reason, I gradually stopped feeling that invisible force pulling at me."
    "Por alguna razón, poco a poco dejé de sentir esa fuerza invisible que tiraba de mí."

# game/script day2.rpy:3051
translate Spanish the_truth_route_2_d127c233:

    # but "I... I can't..."
    but "Yo... no puedo..."

# game/script day2.rpy:3052
translate Spanish the_truth_route_2_da3efe23:

    # pup3 "What do you mean you can't?! Hurry, before-"
    pup3 "¡¿Qué quieres decir con que no puedes?! ¡Date prisa, antes de que-"

# game/script day2.rpy:3061
translate Spanish jestyn_route_day2_732cd4e7:

    # mc "JESTYN!!"
    mc "¡¡JESTYN!!"

# game/script day2.rpy:3065
translate Spanish jestyn_route_day2_3a648ef1:

    # but "?!"
    but "¡¿?!"

# game/script day2.rpy:3070
translate Spanish jestyn_route_day2_52c5c9e2:

    # "I didn't know what had happened, but all of a sudden, I was torn free from Butley's grasp."
    "No supe qué había pasado, pero de repente fui arrancad[letra] de las garras de Butley."

# game/script day2.rpy:3072
translate Spanish jestyn_route_day2_b2d8abd9:

    # "Then I heard a loud crash."
    "Entonces oí un fuerte estruendo."

# game/script day2.rpy:3076
translate Spanish jestyn_route_day2_7d1f99e9:

    # but "AGH-!"
    but "¡AGH-!"

# game/script day2.rpy:3078
translate Spanish jestyn_route_day2_b8ccd583:

    # "My vision slowly came back into focus, and there I saw Jestyn pinning Butley to the floor."
    "Mi vista fue volviendo poco a poco a enfocarse, y ahí vi a Jestyn inmovilizando a Butley contra el suelo."

# game/script day2.rpy:3081
translate Spanish jestyn_route_day2_e4e18305:

    # "Jestyn's face was twisted with rage."
    "El rostro de Jestyn estaba desfigurado por la rabia."

# game/script day2.rpy:3084
translate Spanish jestyn_route_day2_d5fd1a7d:

    # jes "Butley."
    jes "Butley."

# game/script day2.rpy:3085
translate Spanish jestyn_route_day2_71463dbf:

    # jes "What were you trying to do just now?"
    jes "¿Qué intentabas hacer hace un momento?"

# game/script day2.rpy:3086
translate Spanish jestyn_route_day2_ca555396:

    # but "I-I wasn't doing anything-"
    but "Y-yo no estaba haciendo nada-"

# game/script day2.rpy:3090
translate Spanish jestyn_route_day2_360bf5e5:

    # "Jestyn pressed Butley harder against the floor, making him cry out in pain."
    "Jestyn presionó a Butley con más fuerza contra el suelo, haciéndolo gritar de dolor."

# game/script day2.rpy:3093
translate Spanish jestyn_route_day2_042ff381:

    # but "ALRIGHT! I-I was trying to eat [obj]! I'm sorry!"
    but "¡DE ACUERDO! ¡Y-yo intentaba comerl[letra]! ¡Lo siento!"

# game/script day2.rpy:3094
translate Spanish jestyn_route_day2_fc74024a:

    # jes "........"
    jes "........"

# game/script day2.rpy:3097
translate Spanish jestyn_route_day2_82c0945f:

    # "Jestyn finally let go, allowing Butley to breathe again."
    "Jestyn por fin lo soltó, permitiendo que Butley volviera a respirar."

# game/script day2.rpy:3100
translate Spanish jestyn_route_day2_c405553e:

    # jes "Go back to your room. All of you. NOW."
    jes "Vuelvan a sus cuartos. Todos ustedes. AHORA."

# game/script day2.rpy:3103
translate Spanish jestyn_route_day2_0feb42ef:

    # "Without another word, Butley hurried off the stage, followed by the other puppets."
    "Sin decir otra palabra, Butley salió apresurado del escenario, seguido por los demás títeres."

# game/script day2.rpy:3105
translate Spanish jestyn_route_day2_0988b50b:

    # "I remained frozen in place, trying to process everything that had just happened."
    "Me quedé congelad[letra] en el sitio, intentando procesar todo lo que acababa de ocurrir."

# game/script day2.rpy:3106
translate Spanish jestyn_route_day2_36eb21e4:

    # "I snapped out of my thoughts when Jestyn suddenly pulled me into a tight embrace."
    "Salí de mis pensamientos cuando Jestyn me atrajo de repente en un abrazo apretado."

# game/script day2.rpy:3107
translate Spanish jestyn_route_day2_9507cc05:

    # "I didn't know what to do, but my arms instinctively wrapped around him."
    "No sabía qué hacer, pero mis brazos lo rodearon por instinto."

# game/script day2.rpy:3108
translate Spanish jestyn_route_day2_17636312:

    # "...He's trembling?"
    "...¿Está temblando?"

# game/script day2.rpy:3110
translate Spanish jestyn_route_day2_957de271:

    # mc "...Jestyn... thank you..."
    mc "...Jestyn... gracias..."

# game/script day2.rpy:3112
translate Spanish jestyn_route_day2_596bdad6:

    # "Jestyn slowly pulled away and looked at me. His face was filled with fear."
    "Jestyn se apartó lentamente y me miró. Su rostro estaba lleno de miedo."

# game/script day2.rpy:3113
translate Spanish jestyn_route_day2_33ac581a:

    # "I didn't know he was capable of making an expression like that."
    "No sabía que era capaz de poner una expresión así."

# game/script day2.rpy:3116
translate Spanish jestyn_route_day2_ff0462fe:

    # jes "Your Majesty... you have no idea how relieved I am..."
    jes "Su Majestad... no tiene idea de lo aliviado que estoy..."

# game/script day2.rpy:3117
translate Spanish jestyn_route_day2_553ecbf9:

    # jes "I haven't been able to stop overthinking since then..."
    jes "No he podido dejar de darle vueltas desde entonces..."

# game/script day2.rpy:3118
translate Spanish jestyn_route_day2_e87cc425:

    # jes "I just couldn't calm myself down."
    jes "Simplemente no lograba calmarme."

# game/script day2.rpy:3119
translate Spanish jestyn_route_day2_f20df961:

    # jes "...Then I heard you calling my name."
    jes "...Entonces oí que llamaba mi nombre."

# game/script day2.rpy:3121
translate Spanish jestyn_route_day2_725511b9:

    # jes "If I had been late even a moment later... you would have..."
    jes "Si hubiera llegado siquiera un instante tarde... usted habría..."

# game/script day2.rpy:3123
translate Spanish jestyn_route_day2_e49bb605:

    # "His breathing grew ragged as the terrible possibilities ran through his mind."
    "Su respiración se volvió entrecortada mientras las terribles posibilidades pasaban por su mente."

# game/script day2.rpy:3125
translate Spanish jestyn_route_day2_888a61f9:

    # mc "Jestyn, I'm here... Everything's alright."
    mc "Jestyn, estoy aquí... Todo está bien."

# game/script day2.rpy:3127
translate Spanish jestyn_route_day2_05233111:

    # "He wasn't listening to me. He was too lost in his own thoughts."
    "No me escuchaba. Estaba demasiado perdido en sus propios pensamientos."

# game/script day2.rpy:3128
translate Spanish jestyn_route_day2_a1dc70f3:

    # "I gently cupped his cheeks, trying to bring him back to his senses."
    "Le acuné suavemente las mejillas, intentando hacerlo reaccionar."

# game/script day2.rpy:3130
translate Spanish jestyn_route_day2_4083af77:

    # "He flinched slightly, but soon snapped out of his thoughts."
    "Se estremeció un poco, pero pronto salió de sus pensamientos."

# game/script day2.rpy:3132
translate Spanish jestyn_route_day2_226ba13a:

    # jes "...Your Majesty...?"
    jes "...¿Su Majestad...?"

# game/script day2.rpy:3133
translate Spanish jestyn_route_day2_4802530a:

    # mc "Jestyn, I'm here. Isn't that what matters most?"
    mc "Jestyn, estoy aquí. ¿No es eso lo que más importa?"

# game/script day2.rpy:3134
translate Spanish jestyn_route_day2_88a54675:

    # jes "........."
    jes "........."

# game/script day2.rpy:3136
translate Spanish jestyn_route_day2_2a78d6c2:

    # jes "...Yes... You're right, Your Majesty."
    jes "...Sí... Tiene razón, Su Majestad."

# game/script day2.rpy:3138
translate Spanish jestyn_route_day2_ab58d673:

    # "He leaned into my palm."
    "Se apoyó contra mi palma."

# game/script day2.rpy:3140
translate Spanish jestyn_route_day2_de44f556:

    # jes "...I'm so grateful."
    jes "...Estoy tan agradecido."

# game/script day2.rpy:3141
translate Spanish jestyn_route_day2_352fd558:

    # jes "...I feel much calmer now... Thank you."
    jes "...Me siento mucho más tranquilo ahora... Gracias."

# game/script day2.rpy:3143
translate Spanish jestyn_route_day2_5b82ec08:

    # "As I tried to stand, the dizziness and weakness made me lose my balance."
    "Al intentar ponerme de pie, el mareo y la debilidad me hicieron perder el equilibrio."

# game/script day2.rpy:3144
translate Spanish jestyn_route_day2_7720b263:

    # "Jestyn caught me before I could fall."
    "Jestyn me sostuvo antes de que pudiera caer."

# game/script day2.rpy:3148
translate Spanish jestyn_route_day2_5cc747f1:

    # jes "Your Majesty!"
    jes "¡Su Majestad!"

# game/script day2.rpy:3150
translate Spanish jestyn_route_day2_a675d0d2:

    # mc "I... I just feel so dizzy... and weak..."
    mc "Yo... solo me siento muy maread[letra]... y débil..."

# game/script day2.rpy:3152
translate Spanish jestyn_route_day2_ff70d121:

    # jes "...Of course. It's the aftereffects of what happened earlier..."
    jes "...Por supuesto. Son las secuelas de lo que pasó antes..."

# game/script day2.rpy:3154
translate Spanish jestyn_route_day2_0b916d1c:

    # "Jestyn then scooped me into his arms, and I didn't protest. I was far too weak to even lift my gaze."
    "Jestyn me tomó entonces en brazos, y no protesté. Estaba demasiado débil incluso para alzar la mirada."

# game/script day2.rpy:3156
translate Spanish jestyn_route_day2_27f34368:

    # jes "I'll take you back to your room..."
    jes "Le llevaré de vuelta a su cuarto..."

# game/script day2.rpy:3161
translate Spanish jestyn_route_day2_2c8d8bb1:

    # "Jestyn snapped his fingers, and in an instant, we were back in my room."
    "Jestyn chasqueó los dedos y, en un instante, estábamos de vuelta en mi cuarto."

# game/script day2.rpy:3162
translate Spanish jestyn_route_day2_37d747a4:

    # "He gently laid me down on the bed."
    "Me recostó con delicadeza en la cama."

# game/script day2.rpy:3165
translate Spanish jestyn_route_day2_1917b595:

    # jes "Is there anything you would like, Your Majesty? Perhaps something warm to drink?"
    jes "¿Hay algo que desee, Su Majestad? ¿Quizás algo caliente para beber?"

# game/script day2.rpy:3167
translate Spanish jestyn_route_day2_35bf5a71:

    # "I nodded."
    "Asentí."

# game/script day2.rpy:3168
translate Spanish jestyn_route_day2_35a5a973:

    # "Jestyn walked over to the door and locked it."
    "Jestyn caminó hasta la puerta y le puso el seguro."

# game/script day2.rpy:3170
translate Spanish jestyn_route_day2_3fb4455e:

    # jes "Please wait here, Your Majesty."
    jes "Por favor, espere aquí, Su Majestad."

# game/script day2.rpy:3174
translate Spanish jestyn_route_day2_d236e96b:

    # "With another snap of his fingers, he vanished."
    "Con otro chasquido de dedos, desapareció."

# game/script day2.rpy:3175
translate Spanish jestyn_route_day2_91047a3a:

    # ".........."
    ".........."

# game/script day2.rpy:3176
translate Spanish jestyn_route_day2_3deaceb3:

    # "My head was still pounding with dizziness... but no matter how hard I tried, I couldn't stop thinking about everything that had just happened."
    "Mi cabeza aún palpitaba de mareo... pero por más que lo intentaba, no podía dejar de pensar en todo lo que acababa de pasar."

# game/script day2.rpy:3177
translate Spanish jestyn_route_day2_8eaf04dd:

    # "A sense of horror crept through my body every time I imagined what could have happened to me."
    "Una sensación de horror me recorría el cuerpo cada vez que imaginaba lo que podría haberme pasado."

# game/script day2.rpy:3178
translate Spanish jestyn_route_day2_056c3509:

    # "A few moments later, Jestyn returned with a cup of hot chocolate in his hands."
    "Unos momentos después, Jestyn regresó con una taza de chocolate caliente en las manos."

# game/script day2.rpy:3179
translate Spanish jestyn_route_day2_48033596:

    # "He helped me sit up and placed a pillow behind my back to support me."
    "Me ayudó a sentarme y colocó una almohada detrás de mi espalda para sostenerme."

# game/script day2.rpy:3182
translate Spanish jestyn_route_day2_073193ca:

    # jes "Careful, Your Majesty. It's still hot."
    jes "Cuidado, Su Majestad. Todavía está caliente."

# game/script day2.rpy:3184
translate Spanish jestyn_route_day2_e4087c1f:

    # "I blew on the hot chocolate before taking a small sip."
    "Soplé sobre el chocolate caliente antes de tomar un pequeño sorbo."

# game/script day2.rpy:3186
translate Spanish jestyn_route_day2_a8246896:

    # "Its rich, velvety flavor spread across my tongue, and the warmth slowly seeped through my body."
    "Su sabor rico y aterciopelado se extendió por mi lengua, y la calidez se fue filtrando lentamente por mi cuerpo."

# game/script day2.rpy:3187
translate Spanish jestyn_route_day2_1f1379e4:

    # "That warmth gradually soothed the storm of thoughts swirling in my mind."
    "Esa calidez fue calmando poco a poco la tormenta de pensamientos que se agitaba en mi mente."

# game/script day2.rpy:3188
translate Spanish jestyn_route_day2_92c2d679:

    # "...I felt a little better now, even though my body was still weak."
    "...Me sentía un poco mejor ahora, aunque mi cuerpo seguía débil."

# game/script day2.rpy:3189
translate Spanish jestyn_route_day2_84649cab:

    # "Sitting beside me, Jestyn never once took his eyes off me."
    "Sentado a mi lado, Jestyn no me quitó los ojos de encima ni una sola vez."

# game/script day2.rpy:3190
translate Spanish jestyn_route_day2_b87adad8:

    # "I had a feeling he was still shaken by what had happened earlier."
    "Tenía la sensación de que todavía estaba afectado por lo que había pasado antes."

# game/script day2.rpy:3191
translate Spanish jestyn_route_day2_6dad5e88:

    # "It felt strange not hearing Jestyn yap like he usually did. Normally, he'd never stop talking, teasing me, making sarcastic remarks, or saying whatever came to mind just to keep the conversation going."
    "Se me hacía raro no oír a Jestyn parlotear como siempre. Normalmente, nunca dejaba de hablar, de burlarse de mí, de hacer comentarios sarcásticos o de decir lo primero que se le ocurriera solo para mantener la conversación."

# game/script day2.rpy:3192
translate Spanish jestyn_route_day2_7b3d97cb:

    # "But not this time. He simply sat there, silently watching me."
    "Pero esta vez no. Simplemente se quedó sentado, observándome en silencio."

# game/script day2.rpy:3194
translate Spanish jestyn_route_day2_17f2ebd7:

    # mc "Jestyn?"
    mc "¿Jestyn?"

# game/script day2.rpy:3195
translate Spanish jestyn_route_day2_32797f5c:

    # jes "Yes, Your Majesty?"
    jes "¿Sí, Su Majestad?"

# game/script day2.rpy:3196
translate Spanish jestyn_route_day2_15fa3fdb:

    # mc "Are you still scared?"
    mc "¿Sigues asustado?"

# game/script day2.rpy:3198
translate Spanish jestyn_route_day2_9113d194:

    # jes ".........."
    jes ".........."

# game/script day2.rpy:3199
translate Spanish jestyn_route_day2_07d18750:

    # jes "...Yes."
    jes "...Sí."

# game/script day2.rpy:3201
translate Spanish jestyn_route_day2_e3cfc670:

    # "So I was right."
    "Así que tenía razón."

# game/script day2.rpy:3203
translate Spanish jestyn_route_day2_112e0b82:

    # mc "... You scares me"
    mc "... Me asustas"

# game/script day2.rpy:3205
translate Spanish jestyn_route_day2_5edaef28:

    # jes "...What makes you think that, Your Majesty...?"
    jes "...¿Qué le hace pensar eso, Su Majestad...?"

# game/script day2.rpy:3207
translate Spanish jestyn_route_day2_6193b28b:

    # jes "Is it because of... how I acted earlier...?"
    jes "¿Es por... cómo actué antes...?"

# game/script day2.rpy:3208
translate Spanish jestyn_route_day2_2b691a7b:

    # mc "No. You've just been so quiet."
    mc "No. Es solo que has estado tan callado."

# game/script day2.rpy:3209
translate Spanish jestyn_route_day2_acfd20e6:

    # mc "I actually prefer it when you're yapping like you usually do."
    mc "En realidad prefiero cuando parloteas como siempre."

# game/script day2.rpy:3211
translate Spanish jestyn_route_day2_f4db06a7:

    # jes "Ah..."
    jes "Ah..."

# game/script day2.rpy:3212
translate Spanish jestyn_route_day2_b754c898:

    # mc "Say something. Anything. You can even mock me like you always do."
    mc "Di algo. Lo que sea. Puedes incluso burlarte de mí como siempre."

# game/script day2.rpy:3213
translate Spanish jestyn_route_day2_88056451:

    # jes "......"
    jes "......"

# game/script day2.rpy:3215
translate Spanish jestyn_route_day2_3fc98065:

    # jes "Pfft... Hahaha..."
    jes "Pfft... Jajaja..."

# game/script day2.rpy:3217
translate Spanish jestyn_route_day2_f5811821:

    # "Slowly, I could see the usual Jestyn returning."
    "Poco a poco, pude ver cómo el Jestyn de siempre regresaba."

# game/script day2.rpy:3220
translate Spanish jestyn_route_day2_4e0b1017:

    # jes "Ohh~? You want me to mock you, Your Majesty? I had no idea you were into being degraded..."
    jes "¿Ohh~? ¿Quiere que me burle de usted, Su Majestad? No tenía idea de que le gustara ser degradad[letra]..."

# game/script day2.rpy:3221
translate Spanish jestyn_route_day2_5a9eaaa3:

    # jes "You little masochist..."
    jes "Pequeñ[letra] masoquista..."

# game/script day2.rpy:3223
translate Spanish jestyn_route_day2_e7dc0c41:

    # "...Yep. This asshole was completely back."
    "...Sí. Este cabrón había vuelto por completo."

# game/script day2.rpy:3225
translate Spanish jestyn_route_day2_5d9949ec:

    # mc "Go find a mirror, Jestyn."
    mc "Ve a buscar un espejo, Jestyn."

# game/script day2.rpy:3228
translate Spanish jestyn_route_day2_ba844125:

    # "He laughed, and somehow, hearing his laughter made me laugh too."
    "Rio, y de algún modo oír su risa también me hizo reír a mí."

# game/script day2.rpy:3229
translate Spanish jestyn_route_day2_f2ac5252:

    # "Then... the thought from earlier came back."
    "Entonces... el pensamiento de antes volvió."

# game/script day2.rpy:3231
translate Spanish jestyn_route_day2_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:3232
translate Spanish jestyn_route_day2_6298c202:

    # mc "Jestyn, I have a question."
    mc "Jestyn, tengo una pregunta."

# game/script day2.rpy:3233
translate Spanish jestyn_route_day2_0ab4708e:

    # mc "It's about Butley... and the other puppets."
    mc "Es sobre Butley... y los demás títeres."

# game/script day2.rpy:3236
translate Spanish jestyn_route_day2_ce51587d:

    # "Jestyn's expression immediately turned serious."
    "La expresión de Jestyn se tornó seria de inmediato."

# game/script day2.rpy:3238
translate Spanish jestyn_route_day2_3862a191:

    # mc "Before you arrived, Butley kept talking about how loyal he was to Crow-"
    mc "Antes de que llegaras, Butley no paraba de hablar de lo leal que era a Crow-"

# game/script day2.rpy:3240
translate Spanish jestyn_route_day2_e02282a1:

    # "Before I could finish saying the name, Jestyn pressed his index finger against my lips, silencing me at once."
    "Antes de que pudiera terminar de decir el nombre, Jestyn presionó su dedo índice contra mis labios, silenciándome al instante."

# game/script day2.rpy:3242
translate Spanish jestyn_route_day2_91cfe5b8:

    # jes "I know what you mean, Your Majesty. You don't need to say another word."
    jes "Sé a qué se refiere, Su Majestad. No necesita decir una palabra más."

# game/script day2.rpy:3244
translate Spanish jestyn_route_day2_75f7e811:

    # "Jestyn slowly pulled his finger away from my lips. Then he fell silent once again."
    "Jestyn retiró lentamente el dedo de mis labios. Luego volvió a quedarse en silencio."

# game/script day2.rpy:3246
translate Spanish jestyn_route_day2_88a54675_1:

    # jes "........."
    jes "........."

# game/script day2.rpy:3248
translate Spanish jestyn_route_day2_8916a1cf:

    # jes "..........."
    jes "..........."

# game/script day2.rpy:3250
translate Spanish jestyn_route_day2_d239ee43:

    # "His eyes darted nervously around the room, scanning every corner he could see."
    "Sus ojos recorrían nerviosos la habitación, escudriñando cada rincón que podía ver."

# game/script day2.rpy:3252
translate Spanish jestyn_route_day2_c4f316e6:

    # "He gripped his own neck as his breathing gradually became faster."
    "Se aferró al cuello mientras su respiración se aceleraba poco a poco."

# game/script day2.rpy:3254
translate Spanish jestyn_route_day2_6b5650ad:

    # mc "JESTYN?!"
    mc "¡¿JESTYN?!"

# game/script day2.rpy:3256
translate Spanish jestyn_route_day2_638ec736:

    # "I immediately grabbed his hand."
    "Le agarré la mano de inmediato."

# game/script day2.rpy:3258
translate Spanish jestyn_route_day2_7d1a0d94:

    # mc "What's wrong?!"
    mc "¡¿Qué pasa?!"

# game/script day2.rpy:3260
translate Spanish jestyn_route_day2_834a90d4:

    # "He slowly came back to his senses and began to steady his breathing."
    "Poco a poco volvió en sí y comenzó a estabilizar su respiración."

# game/script day2.rpy:3263
translate Spanish jestyn_route_day2_90e65c4b:

    # jes "...My apologies, Your Majesty..."
    jes "...Mis disculpas, Su Majestad..."

# game/script day2.rpy:3265
translate Spanish jestyn_route_day2_58a57ed5:

    # "Even after he calmed down, I still couldn't stop worrying about him."
    "Incluso después de que se calmó, no podía dejar de preocuparme por él."

# game/script day2.rpy:3267
translate Spanish jestyn_route_day2_879a8514:

    # mc "...Lie down with me."
    mc "...Acuéstate conmigo."

# game/script day2.rpy:3270
translate Spanish jestyn_route_day2_b9bf963b:

    # "His eyes widened in surprise."
    "Sus ojos se abrieron de sorpresa."

# game/script day2.rpy:3272
translate Spanish jestyn_route_day2_acda9fa7:

    # jes "...Pardon?"
    jes "...¿Perdón?"

# game/script day2.rpy:3273
translate Spanish jestyn_route_day2_deaf7b17:

    # mc "I think both of us need some rest, don't you? So... lie down with me."
    mc "Creo que los dos necesitamos descansar, ¿no crees? Así que... acuéstate conmigo."

# game/script day2.rpy:3276
translate Spanish jestyn_route_day2_d8fe8c6d:

    # "A faint blush slowly spread across Jestyn's cheeks."
    "Un leve rubor se extendió lentamente por las mejillas de Jestyn."

# game/script day2.rpy:3278
translate Spanish jestyn_route_day2_01c8adc0:

    # jes "Hehe... my, my... Are you making a move on me, Your Majesty~?"
    jes "Jeje... vaya, vaya... ¿Me está insinuando algo, Su Majestad~?"

# game/script day2.rpy:3279
translate Spanish jestyn_route_day2_f9ccba88:

    # mc "That's an order."
    mc "Es una orden."

# game/script day2.rpy:3280
translate Spanish jestyn_route_day2_d9faff05:

    # jes "...As you wish, Your Majesty."
    jes "...Como desee, Su Majestad."

# game/script day2.rpy:3283
translate Spanish jestyn_route_day2_34541d35:

    # "What I didn't expect was for him to remove his crown... followed by his hood."
    "Lo que no esperaba era que se quitara la corona... seguida de la capucha."

# game/script day2.rpy:3284
translate Spanish jestyn_route_day2_8b7665c7:

    # "Then he lay down beside me, facing me."
    "Luego se recostó a mi lado, de cara a mí."

# game/script day2.rpy:3285
translate Spanish jestyn_route_day2_0472ed44:

    # "...This is my first time seeing his hair. It was long and wavy. And the deep maroon color suited him beautifully."
    "...Es la primera vez que veo su cabello. Era largo y ondulado. Y el granate oscuro le quedaba precioso."

# game/script day2.rpy:3288
translate Spanish jestyn_route_day2_bbb8e373:

    # jes "...Do you like it, Your Majesty?"
    jes "...¿Le gusta, Su Majestad?"

# game/script day2.rpy:3290
translate Spanish jestyn_route_day2_73465ea9:

    # "He noticed me staring at his hair."
    "Notó que le miraba el cabello."

# game/script day2.rpy:3292
translate Spanish jestyn_route_day2_1951efbf:

    # mc "...You look beautiful."
    mc "...Te ves hermoso."

# game/script day2.rpy:3295
translate Spanish jestyn_route_day2_331a0c07:

    # "The blush on his cheeks deepened."
    "El rubor de sus mejillas se intensificó."

# game/script day2.rpy:3297
translate Spanish jestyn_route_day2_076d0554:

    # jes "Are you trying to flirt with me, Your Majesty~?"
    jes "¿Está intentando coquetear conmigo, Su Majestad~?"

# game/script day2.rpy:3298
translate Spanish jestyn_route_day2_84eee1c5:

    # mc "Alright. You're ugly."
    mc "Bien. Eres feo."

# game/script day2.rpy:3300
translate Spanish jestyn_route_day2_084bb10f:

    # jes "Hmph... cruel."
    jes "Hmph... cruel."

# game/script day2.rpy:3302
translate Spanish jestyn_route_day2_d1ddaffa:

    # "........"
    "........"

# game/script day2.rpy:3305
translate Spanish jestyn_route_day2_e0612013:

    # jes "...Your Majesty... I want to know if I've done something wrong."
    jes "...Su Majestad... quiero saber si he hecho algo malo."

# game/script day2.rpy:3307
translate Spanish jestyn_route_day2_2f227a5d:

    # "I perked up. Why was he asking that all of a sudden?"
    "Me puse alerta. ¿Por qué preguntaba eso de repente?"

# game/script day2.rpy:3309
translate Spanish jestyn_route_day2_b2b9e19d:

    # mc "What do you mean?"
    mc "¿A qué te refieres?"

# game/script day2.rpy:3311
translate Spanish jestyn_route_day2_270aaeeb:

    # jes "Dragging you into all of this... and..."
    jes "Arrastrarle a todo esto... y..."

# game/script day2.rpy:3313
translate Spanish jestyn_route_day2_16a04ecd:

    # "He paused, unable to finish his sentence."
    "Se detuvo, incapaz de terminar la frase."

# game/script day2.rpy:3315
translate Spanish jestyn_route_day2_5c9c7aa3:

    # mc "...Well... I work here. That means I've already become involved in the kingdom's affairs, whether I like it or not... doesn't it?"
    mc "...Bueno... yo trabajo aquí. Eso significa que ya me he involucrado en los asuntos del reino, quiera o no... ¿no es así?"

# game/script day2.rpy:3317
translate Spanish jestyn_route_day2_88056451_1:

    # jes "......"
    jes "......"

# game/script day2.rpy:3318
translate Spanish jestyn_route_day2_4e459a49:

    # jes "...Yes..."
    jes "...Sí..."

# game/script day2.rpy:3319
translate Spanish jestyn_route_day2_c65cfbae:

    # mc "...Tell me what's on your mind. Isn't that a ruler's duty? To listen to the voices of their people."
    mc "...Dime qué tienes en mente. ¿No es ese el deber de un gobernante? Escuchar las voces de su gente."

# game/script day2.rpy:3322
translate Spanish jestyn_route_day2_89ff8e4b:

    # "Jestyn smiled at me once again."
    "Jestyn volvió a sonreírme."

# game/script day2.rpy:3324
translate Spanish jestyn_route_day2_0fe449e6:

    # jes "You're getting better at playing your role, Your Majesty."
    jes "Está mejorando en su papel, Su Majestad."

# game/script day2.rpy:3326
translate Spanish jestyn_route_day2_88a54675_2:

    # jes "........."
    jes "........."

# game/script day2.rpy:3329
translate Spanish jestyn_route_day2_d47ea68e:

    # "Jestyn let out a long, weary sigh."
    "Jestyn soltó un largo y cansado suspiro."

# game/script day2.rpy:3331
translate Spanish jestyn_route_day2_7e740b4f:

    # jes "I... honestly, I'm not quite comfortable talking about this topic yet, Your Majesty..."
    jes "Yo... sinceramente, todavía no me siento del todo cómodo hablando de este tema, Su Majestad..."

# game/script day2.rpy:3332
translate Spanish jestyn_route_day2_93deaf69:

    # mc "Ah..."
    mc "Ah..."

# game/script day2.rpy:3334
translate Spanish jestyn_route_day2_f7ebeefb:

    # "Just from his words, I could sense the trauma he carried, even though I had no idea what had caused it."
    "Solo por sus palabras, pude percibir el trauma que cargaba, aunque no tenía idea de qué lo había causado."

# game/script day2.rpy:3335
translate Spanish jestyn_route_day2_194c324b:

    # "It only made me more curious... but at the same time, seeing Jestyn so uncomfortable made me feel sad."
    "Solo me dio más curiosidad... pero al mismo tiempo, ver a Jestyn tan incómodo me entristeció."

# game/script day2.rpy:3337
translate Spanish jestyn_route_day2_98aa28d2:

    # mc "...If it's really that unpleasant, you don't have to tell me about it, Jestyn."
    mc "...Si de verdad es tan desagradable, no tienes que contármelo, Jestyn."

# game/script day2.rpy:3338
translate Spanish jestyn_route_day2_a5293201:

    # mc "We can just relax here."
    mc "Podemos simplemente relajarnos aquí."

# game/script day2.rpy:3339
translate Spanish jestyn_route_day2_fc74024a_1:

    # jes "........"
    jes "........"

# game/script day2.rpy:3340
translate Spanish jestyn_route_day2_ece179de:

    # jes "But... since we've already come this far, Your Majesty has the right to know..."
    jes "Pero... ya que hemos llegado tan lejos, Su Majestad tiene derecho a saber..."

# game/script day2.rpy:3342
translate Spanish jestyn_route_day2_75dcddf3:

    # jes "Perhaps... I can only tell you part of it, in a different way....."
    jes "Quizás... solo pueda contarle una parte, de otra manera....."

# game/script day2.rpy:3351
translate Spanish jestyn_route_day2_0d60c8f3:

    # jes "Once, there was a forest wrapped in silk and shade, Where every creature played the part the moonlight gave."
    jes "Érase una vez un bosque envuelto en seda y sombra, donde cada criatura hacía el papel que la luz de la luna le daba."

# game/script day2.rpy:3360
translate Spanish jestyn_route_day2_60822dc3:

    # jes "At the center sat a Lion king with a sunless mane,"
    jes "En el centro se sentaba un rey León de melena sin sol,"

# game/script day2.rpy:3361
translate Spanish jestyn_route_day2_2fb7fcf3:

    # jes "He promised, 'We will rise together!', again and again!"
    jes "¡Prometía 'Juntos nos alzaremos', una y otra vez!"

# game/script day2.rpy:3371
translate Spanish jestyn_route_day2_cdfe2965:

    # jes "The deer ran till their legs gave way,"
    jes "Los ciervos corrían hasta que las patas les fallaban,"

# game/script day2.rpy:3373
translate Spanish jestyn_route_day2_9b434c58:

    # jes "The owl read stars he told them to obey."
    jes "El búho leía las estrellas que él les mandaba obedecer."

# game/script day2.rpy:3375
translate Spanish jestyn_route_day2_d83742e7:

    # jes "The dog stood guard with unblinking eyes,"
    jes "El perro montaba guardia con ojos que no parpadeaban,"

# game/script day2.rpy:3377
translate Spanish jestyn_route_day2_096eba2c:

    # jes "While the lion fed fat on borrowed lies."
    jes "mientras el león engordaba con mentiras prestadas."

# game/script day2.rpy:3385
translate Spanish jestyn_route_day2_07289860:

    # jes "Among the roots, beneath the stage of trees,"
    jes "Entre las raíces, bajo el escenario de los árboles,"

# game/script day2.rpy:3386
translate Spanish jestyn_route_day2_fc31796e:

    # jes "A rabbit danced with bells made of glass and teeth."
    jes "Un conejo bailaba con cascabeles de vidrio y dientes."

# game/script day2.rpy:3388
translate Spanish jestyn_route_day2_59556b7d:

    # jes "The lion laughed and pulled him near,"
    jes "El león rio y lo atrajo hacia sí,"

# game/script day2.rpy:3389
translate Spanish jestyn_route_day2_b2aa8159:

    # jes "Called pain a joke, called fear 'sincere.'"
    jes "Llamó broma al dolor y 'sincero' al miedo."

# game/script day2.rpy:3392
translate Spanish jestyn_route_day2_da65498b:

    # jes "Oh, the forest listened, or chose to pretend,"
    jes "Oh, el bosque escuchó, o fingió no hacerlo,"

# game/script day2.rpy:3393
translate Spanish jestyn_route_day2_0f4d4311:

    # jes "That this was the way all stories must end."
    jes "Creyendo que así debían terminar todas las historias."

# game/script day2.rpy:3395
translate Spanish jestyn_route_day2_e49fadf7:

    # jes "They whispered low, 'Endure, endure,'"
    jes "Susurraron bajo: 'Aguanta, aguanta',"

# game/script day2.rpy:3396
translate Spanish jestyn_route_day2_595b0e6c:

    # jes "As if silence could make the cruelty pure."
    jes "Como si el silencio pudiera volver pura la crueldad."

# game/script day2.rpy:3400
translate Spanish jestyn_route_day2_266bc78b:

    # jes "One night, the moon held its breath in the trees,"
    jes "Una noche, la luna contuvo el aliento entre los árboles,"

# game/script day2.rpy:3402
translate Spanish jestyn_route_day2_384a051b:

    # jes "When the rabbit chose truth over begging on knees."
    jes "Cuando el conejo eligió la verdad antes que rogar de rodillas."

# game/script day2.rpy:3404
translate Spanish jestyn_route_day2_4d137ded:

    # jes "The lion never noticed, drunk on his own name,"
    jes "El león jamás lo notó, ebrio de su propio nombre,"

# game/script day2.rpy:3405
translate Spanish jestyn_route_day2_b1f9f2b5:

    # jes "When venom slowly met the heartbeat of the forest's shame."
    jes "Cuando el veneno alcanzó despacio el latido de la vergüenza del bosque."

# game/script day2.rpy:3412
translate Spanish jestyn_route_day2_1f82ecef:

    # jes "The dogs barked mad at the crimson ground,"
    jes "Los perros ladraron enloquecidos sobre el suelo carmesí,"

# game/script day2.rpy:3413
translate Spanish jestyn_route_day2_6493ad6d:

    # jes "The deer froze stiff, made not a sound."
    jes "Los ciervos se helaron rígidos, sin emitir sonido."

# game/script day2.rpy:3414
translate Spanish jestyn_route_day2_e3b110e5:

    # jes "The owls looked down, then looked away,"
    jes "Los búhos miraron abajo, luego desviaron la mirada,"

# game/script day2.rpy:3416
translate Spanish jestyn_route_day2_fc4920e3:

    # jes "But the rabbit smiled, calm and clean,"
    jes "Pero el conejo sonrió, sereno y limpio,"

# game/script day2.rpy:3417
translate Spanish jestyn_route_day2_b2441b0b:

    # jes "For freedom rarely looks serene."
    jes "Pues la libertad pocas veces luce serena."

# game/script day2.rpy:3430
translate Spanish jestyn_route_day2_3928a113:

    # "......."
    "......."

# game/script day2.rpy:3432
translate Spanish jestyn_route_day2_58a8482a:

    # jes "...Are you feeling sleepy, Your Majesty?"
    jes "...¿Tiene sueño, Su Majestad?"

# game/script day2.rpy:3434
translate Spanish jestyn_route_day2_15558466:

    # mc "Maybe a little..."
    mc "Quizás un poco..."

# game/script day2.rpy:3437
translate Spanish jestyn_route_day2_d5956aa4:

    # "My eyelids grew heavier as I listened to Jestyn's story."
    "Mis párpados se fueron haciendo más pesados mientras escuchaba la historia de Jestyn."

# game/script day2.rpy:3438
translate Spanish jestyn_route_day2_747790f8:

    # "That story... was so painfully sad."
    "Esa historia... era tan dolorosamente triste."

# game/script day2.rpy:3440
translate Spanish jestyn_route_day2_6e8e9e4a:

    # mc "Jestyn... are you alright...?"
    mc "Jestyn... ¿estás bien...?"

# game/script day2.rpy:3441
translate Spanish jestyn_route_day2_9113d194_1:

    # jes ".........."
    jes ".........."

# game/script day2.rpy:3443
translate Spanish jestyn_route_day2_3af878fa:

    # jes "...To be honest... I can't say that I am, Your Majesty."
    jes "...Para ser sincero... no puedo decir que lo esté, Su Majestad."

# game/script day2.rpy:3447
translate Spanish jestyn_route_day2_f77e25ee:

    # voice "JESTYN04_DAY2.ogg"
    # jes "It all happened a long time ago... but every time I remember it... it feels as if I'm living through it all over again."
    voice "JESTYN04_DAY2.ogg"
    jes "Todo ocurrió hace mucho tiempo... pero cada vez que lo recuerdo... siento que lo estoy viviendo todo de nuevo."

# game/script day2.rpy:3451
translate Spanish jestyn_route_day2_3e1512ca:

    # "He drifted off for a moment before looking back at me with a gentle smile."
    "Se perdió en sus pensamientos un instante antes de volver a mirarme con una sonrisa suave."

# game/script day2.rpy:3454
translate Spanish jestyn_route_day2_152d6ee2:

    # voice "JESTYN05_DAY2.ogg"
    # jes "But at least... I feel a little better knowing that you're here with me, Your Majesty."
    voice "JESTYN05_DAY2.ogg"
    jes "Pero al menos... me siento un poco mejor sabiendo que está aquí conmigo, Su Majestad."

# game/script day2.rpy:3456
translate Spanish jestyn_route_day2_91b9624d:

    # voice "JESTYN06_DAY2.ogg"
    # jes "...May I touch you?"
    voice "JESTYN06_DAY2.ogg"
    jes "...¿Puedo tocarle?"

# game/script day2.rpy:3463
translate Spanish jestyn_route_day2_3b54d175:

    # "Jestyn gently stroked my hair. It felt so comforting that my eyelids grew even heavier."
    "Jestyn me acarició suavemente el cabello. Era tan reconfortante que mis párpados se hicieron aún más pesados."

# game/script day2.rpy:3465
translate Spanish jestyn_route_day2_c2e622d7:

    # jes "Then get some sleep. Those dark circles looks ugly on you... though I have to admit, you still look adorable, Your Majesty."
    jes "Entonces duerma un poco. Esas ojeras le quedan feas... aunque debo admitir que aun así se ve adorable, Su Majestad."

# game/script day2.rpy:3467
translate Spanish jestyn_route_day2_7c2d25d9:

    # mc "Mmmmm...asshole..."
    mc "Mmmmm... cabrón..."

# game/script day2.rpy:3469
translate Spanish jestyn_route_day2_3077e7bf:

    # "He chuckled softly."
    "Soltó una risita suave."

# game/script day2.rpy:3471
translate Spanish jestyn_route_day2_7cc826e6:

    # jes "Sweet dreams, Your Majesty... I'll be here when you wake up."
    jes "Dulces sueños, Su Majestad... Estaré aquí cuando despierte."

# game/script day2.rpy:3475
translate Spanish jestyn_route_day2_cb580c3d:

    # "Jestyn's expression fell into a sad pout, but it was soon replaced by a gentle smile."
    "La expresión de Jestyn cayó en un triste puchero, pero pronto fue reemplazada por una sonrisa suave."

# game/script day2.rpy:3478
translate Spanish jestyn_route_day2_c2e622d7_1:

    # jes "Then get some sleep. Those dark circles looks ugly on you... though I have to admit, you still look adorable, Your Majesty."
    jes "Entonces duerma un poco. Esas ojeras le quedan feas... aunque debo admitir que aun así se ve adorable, Su Majestad."

# game/script day2.rpy:3480
translate Spanish jestyn_route_day2_7c2d25d9_1:

    # mc "Mmmmm...asshole..."
    mc "Mmmmm... cabrón..."

# game/script day2.rpy:3482
translate Spanish jestyn_route_day2_3077e7bf_1:

    # "He chuckled softly."
    "Soltó una risita suave."

# game/script day2.rpy:3484
translate Spanish jestyn_route_day2_289ab7f5:

    # jes "Now, sweet dreams, Your Majesty... I'll be here when you wake up..."
    jes "Ahora, dulces sueños, Su Majestad... Estaré aquí cuando despierte..."

# game/script day2.rpy:3499
translate Spanish prieston_route_day2_0de32ee8:

    # who "Butley."
    who "Butley."

# game/script day2.rpy:3504
translate Spanish prieston_route_day2_2b66c956:

    # but "...?!"
    but "...¡¿?!"

# game/script day2.rpy:3506
translate Spanish prieston_route_day2_67bdbed5:

    # "Through my fading consciousness, I heard a familiar voice."
    "A través de mi conciencia que se desvanecía, oí una voz familiar."

# game/script day2.rpy:3508
translate Spanish prieston_route_day2_cb862202:

    # mc "... Jestyn...?"
    mc "... ¿Jestyn...?"

# game/script day2.rpy:3510
translate Spanish prieston_route_day2_7d812dab:

    # "The moment Butley realized who it was, he immediately let go of me."
    "En cuanto Butley se dio cuenta de quién era, me soltó de inmediato."

# game/script day2.rpy:3511
translate Spanish prieston_route_day2_20522326:

    # "Jestyn caught me before I could collapse to the floor."
    "Jestyn me sostuvo antes de que me desplomara al suelo."

# game/script day2.rpy:3513
translate Spanish prieston_route_day2_700b171e:

    # pup4 "Shit... he is here!"
    pup4 "Mierda... ¡está aquí!"

# game/script day2.rpy:3516
translate Spanish prieston_route_day2_b141327f:

    # but "J-J-Jestyn... I..."
    but "J-J-Jestyn... Yo..."

# game/script day2.rpy:3517
translate Spanish prieston_route_day2_a4b95915:

    # but "I was just... I didn't mean to-"
    but "Yo solo... no quería-"

# game/script day2.rpy:3520
translate Spanish prieston_route_day2_b4a9a5cb:

    # jes "I understand what you're trying to say, Butley my dear."
    jes "Entiendo lo que intentas decir, mi querido Butley."

# game/script day2.rpy:3521
translate Spanish prieston_route_day2_ad4744ee:

    # jes "Unfortunately for you... I have eyes."
    jes "Por desgracia para ti... tengo ojos."

# game/script day2.rpy:3524
translate Spanish prieston_route_day2_3265d37d:

    # jes "And I know exactly what you were trying to do."
    jes "Y sé exactamente lo que intentabas hacer."

# game/script day2.rpy:3525
translate Spanish prieston_route_day2_e6177f2b:

    # but "I-I..."
    but "Y-Yo..."

# game/script day2.rpy:3527
translate Spanish prieston_route_day2_9ec3d6b2:

    # "Butley fidgeted nervously where he stood, unable to find the words."
    "Butley se removió nervioso en su sitio, incapaz de encontrar las palabras."

# game/script day2.rpy:3529
translate Spanish prieston_route_day2_4a32d7ef:

    # jes "I suggest all of you return to your rooms."
    jes "Les sugiero a todos que vuelvan a sus cuartos."

# game/script day2.rpy:3530
translate Spanish prieston_route_day2_ed37a4c4:

    # jes "...Before I decide to do something you'll regret."
    jes "...Antes de que decida hacer algo de lo que se arrepentirán."

# game/script day2.rpy:3533
translate Spanish prieston_route_day2_ad1c8183:

    # "The other puppets quickly grab his shoulder, signaling them to leave quickly. And without another word, Butley and other puppets turned and fled back toward their own rooms."
    "Los otros títeres le agarraron rápidamente el hombro, indicándole que se fueran de inmediato. Y sin decir otra palabra, Butley y los demás títeres se dieron la vuelta y huyeron de vuelta a sus cuartos."

# game/script day2.rpy:3534
translate Spanish prieston_route_day2_3f540fde:

    # "Jestyn turned his attention back to me, offering a gentle smile."
    "Jestyn volvió su atención hacia mí, ofreciéndome una sonrisa suave."

# game/script day2.rpy:3537
translate Spanish prieston_route_day2_098da708:

    # jes "Are you alright now, Your Majesty?"
    jes "¿Está bien ahora, Su Majestad?"

# game/script day2.rpy:3539
translate Spanish prieston_route_day2_4d497557:

    # "He helped me back onto my feet."
    "Me ayudó a ponerme de pie."

# game/script day2.rpy:3540
translate Spanish prieston_route_day2_2b8b079e:

    # "My body was still too weak to stand on its own, so Jestyn took my hand and steadied me with a hand against my back."
    "Mi cuerpo seguía demasiado débil para sostenerse solo, así que Jestyn tomó mi mano y me estabilizó con una mano en la espalda."

# game/script day2.rpy:3541
translate Spanish prieston_route_day2_23b7411b:

    # "If Jestyn hadn't shown up....I didn't even want to imagine what would've happened to me."
    "Si Jestyn no hubiera aparecido....ni siquiera quería imaginar lo que me habría pasado."

# game/script day2.rpy:3544
translate Spanish prieston_route_day2_ccd5ba6f:

    # mc "Jestyn..."
    mc "Jestyn..."

# game/script day2.rpy:3545
translate Spanish prieston_route_day2_d2efecf2:

    # mc "Thank you..."
    mc "Gracias..."

# game/script day2.rpy:3546
translate Spanish prieston_route_day2_76761398:

    # jes "Think nothing of it, Your Majesty."
    jes "No es nada, Su Majestad."

# game/script day2.rpy:3547
translate Spanish prieston_route_day2_b91c379b:

    # jes "It seems Butley and other puppets caused You quite a bit of trouble."
    jes "Parece que Butley y los otros títeres le causaron bastantes problemas."

# game/script day2.rpy:3548
translate Spanish prieston_route_day2_7558d6da:

    # jes "Please forgive them."
    jes "Por favor, perdónelos."

# game/script day2.rpy:3551
translate Spanish prieston_route_day2_4fcd66c2:

    # "I didn't think I'd be able to act normally around them, especially Butley, the next time we met."
    "No creía que pudiera comportarme con normalidad frente a ellos, especialmente frente a Butley, la próxima vez que nos viéramos."

# game/script day2.rpy:3552
translate Spanish prieston_route_day2_ae423fd8:

    # "But... Why did he act like that so suddenly?"
    "Pero... ¿Por qué actuó así tan de repente?"

# game/script day2.rpy:3553
translate Spanish prieston_route_day2_8561af1c:

    # "Is it because... he doesn't want me to replace the king puppet..?"
    "¿Será porque... no quiere que reemplace al Rey Títere..?"

# game/script day2.rpy:3555
translate Spanish prieston_route_day2_ccd5ba6f_1:

    # mc "Jestyn..."
    mc "Jestyn..."

# game/script day2.rpy:3556
translate Spanish prieston_route_day2_88892b3c:

    # mc "Why...? Why did he do that?"
    mc "¿Por qué...? ¿Por qué hizo eso?"

# game/script day2.rpy:3557
translate Spanish prieston_route_day2_a9002ab8:

    # jes "...Why did Butley behave that way?"
    jes "...¿Por qué se comportó Butley de esa manera?"

# game/script day2.rpy:3558
translate Spanish prieston_route_day2_82693a08:

    # jes "It's a long story."
    jes "Es una larga historia."

# game/script day2.rpy:3560
translate Spanish prieston_route_day2_510a1e83:

    # "He paused."
    "Hizo una pausa."

# game/script day2.rpy:3562
translate Spanish prieston_route_day2_10180954:

    # jes "But I'm afraid Your Majesty is still in no condition to stand. Would you do me the honor of resting in my room for a while?"
    jes "Pero me temo que Su Majestad aún no está en condiciones de ponerse de pie. ¿Me haría el honor de descansar en mi cuarto un rato?"

# game/script day2.rpy:3563
translate Spanish prieston_route_day2_44977a95:

    # mc "...Alright."
    mc "...De acuerdo."

# game/script day2.rpy:3566
translate Spanish prieston_route_day2_102c01d6:

    # "Jestyn gave me a small nod and gestured for me to walk ahead."
    "Jestyn me hizo un pequeño gesto con la cabeza y me indicó que caminara adelante."

# game/script day2.rpy:3568
translate Spanish prieston_route_day2_df8e8d51:

    # "As we walked, my mind kept drifting back to what had just happened."
    "Mientras caminábamos, mi mente seguía volviendo a lo que acababa de pasar."

# game/script day2.rpy:3569
translate Spanish prieston_route_day2_bccb9baf:

    # "I'm trying to remember what Butley said. From what Butley had said...he didn't want the King Puppet to be replaced."
    "Intento recordar lo que dijo Butley. Por lo que Butley había dicho... no quería que el Rey Títere fuera reemplazado."

# game/script day2.rpy:3570
translate Spanish prieston_route_day2_03ddc1d8:

    # "That meant he was fiercely loyal to King Crownus."
    "Eso significaba que era ferozmente leal al Rey Crownus."

# game/script day2.rpy:3571
translate Spanish prieston_route_day2_417a71fc:

    # "And not only Butley felt that way... There could be several puppets like the puppets who stood with him while he attacked me..."
    "Y no solo Butley pensaba así... Podría haber varios títeres como los que lo acompañaron mientras me atacaba..."

# game/script day2.rpy:3572
translate Spanish prieston_route_day2_71f4cf03:

    # "...or perhaps many more of them who remained loyal to the King Puppet and refused to accept me as his successor."
    "...o quizás muchos más que seguían leales al Rey Títere y se negaban a aceptarme como su sucesor."

# game/script day2.rpy:3573
translate Spanish prieston_route_day2_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:3574
translate Spanish prieston_route_day2_075088ba:

    # "...They'd do anything to get rid of me."
    "...Harían lo que fuera por deshacerse de mí."

# game/script day2.rpy:3575
translate Spanish prieston_route_day2_cd1ca11d:

    # "A cold sweat spread across my body as one horrible possibility after another filled my mind."
    "Un sudor frío me recorrió el cuerpo mientras una terrible posibilidad tras otra llenaba mi mente."

# game/script day2.rpy:3576
translate Spanish prieston_route_day2_7d13b8a3:

    # "Lost in my thoughts, I wandered forward without really paying attention to where I was going."
    "Perdid[letra] en mis pensamientos, avancé sin prestar realmente atención a adónde iba."

# game/script day2.rpy:3577
translate Spanish prieston_route_day2_319bf9a5:

    # "My feet simply moved on their own."
    "Mis pies simplemente se movían solos."

# game/script day2.rpy:3579
translate Spanish prieston_route_day2_032c16fa:

    # "Suddenly, I flinched as a hand gently covered my eyes, pulling me out of my spiral of thoughts."
    "De repente me sobresalté cuando una mano me cubrió suavemente los ojos, sacándome de mi espiral de pensamientos."

# game/script day2.rpy:3581
translate Spanish prieston_route_day2_2a195295:

    # jes "It seems Your Majesty has quite a lot on Your mind..."
    jes "Parece que Su Majestad tiene muchas cosas en la cabeza..."

# game/script day2.rpy:3583
translate Spanish prieston_route_day2_fa95e18e:

    # "he said softly."
    "dijo con suavidad."

# game/script day2.rpy:3586
translate Spanish prieston_route_day2_0322b0ec:

    # jes "I'd like You to clear Your mind before we talk."
    jes "Me gustaría que despeje su mente antes de que hablemos."

# game/script day2.rpy:3587
translate Spanish prieston_route_day2_d3a0eae2:

    # jes "So....relax. Take a slow, deep breath..."
    jes "Así que....relájese. Respire hondo y despacio..."

# game/script day2.rpy:3589
translate Spanish prieston_route_day2_6494d184:

    # "I followed his instructions and slowly inhaled."
    "Seguí sus instrucciones e inhalé lentamente."

# game/script day2.rpy:3591
translate Spanish prieston_route_day2_2b513529:

    # jes "Now....let it out gently through Your mouth."
    jes "Ahora....suéltelo con suavidad por la boca."

# game/script day2.rpy:3593
translate Spanish prieston_route_day2_7a94d931:

    # "I slowly exhaled."
    "Exhalé lentamente."

# game/script day2.rpy:3595
translate Spanish prieston_route_day2_c6a209f4:

    # jes "Good [gend]."
    jes "Eso es, [gend!t]."

# game/script day2.rpy:3596
translate Spanish prieston_route_day2_28d06d0c:

    # jes "Now.. Allow me to guide You to my room."
    jes "Ahora.. Permítame guiarle hasta mi cuarto."

# game/script day2.rpy:3598
translate Spanish prieston_route_day2_4cef5cbc:

    # "Keeping one hand over my eyes, Jestyn gently led me toward his room."
    "Manteniendo una mano sobre mis ojos, Jestyn me condujo con delicadeza hacia su cuarto."

# game/script day2.rpy:3599
translate Spanish prieston_route_day2_4967718d:

    # "And after walking for a while, I heard a door creak open. I assumed it was the entrance to the puppet quarters."
    "Y tras caminar un rato, oí que una puerta crujía al abrirse. Supuse que era la entrada a los aposentos de los títeres."

# game/script day2.rpy:3600
translate Spanish prieston_route_day2_780f2ec7:

    # "Once we were inside, Jestyn continued guiding me forward."
    "Una vez dentro, Jestyn siguió guiándome hacia delante."

# game/script day2.rpy:3602
translate Spanish prieston_route_day2_5c0435cc:

    # "A moment later, I heard another door open. And I figured it must've been the door to Jestyn's room."
    "Un momento después, oí que se abría otra puerta. Y me imaginé que sería la puerta del cuarto de Jestyn."

# game/script day2.rpy:3603
translate Spanish prieston_route_day2_298de83f:

    # "He gently led me inside."
    "Me condujo con delicadeza al interior."

# game/script day2.rpy:3605
translate Spanish prieston_route_day2_68f919aa:

    # "As soon as I heard the door click shut behind us, Jestyn removed his hand from my eyes, allowing me to see again."
    "En cuanto oí que la puerta se cerraba con un clic detrás de nosotros, Jestyn retiró la mano de mis ojos, permitiéndome ver otra vez."

# game/script day2.rpy:3608
translate Spanish prieston_route_day2_33dba9aa:

    # "And that's when I finally got a look at... Jestyn's room..."
    "Y fue entonces cuando por fin vi... el cuarto de Jestyn..."

# game/script day2.rpy:3610
translate Spanish prieston_route_day2_0fd4d656_1:

    # "......"
    "......"

# game/script day2.rpy:3611
translate Spanish prieston_route_day2_c8802edc:

    # "It was impeccably tidy. Shelves of books lined the walls, and crosses adorned nearly every corner."
    "Estaba impecablemente ordenado. Estantes llenos de libros recubrían las paredes, y cruces adornaban casi todos los rincones."

# game/script day2.rpy:3612
translate Spanish prieston_route_day2_0520edb1:

    # "The room carried an almost sacred atmosphere."
    "La habitación tenía una atmósfera casi sagrada."

# game/script day2.rpy:3613
translate Spanish prieston_route_day2_0ec30174:

    # "...Wait.. this doesn't feel like Jestyn's room..."
    "...Espera.. esto no se siente como el cuarto de Jestyn..."

# game/script day2.rpy:3614
translate Spanish prieston_route_day2_1232d901:

    # "No, this isn't Jestyn's room..."
    "No, este no es el cuarto de Jestyn..."

# game/script day2.rpy:3616
translate Spanish prieston_route_day2_389a4ec2:

    # mc "Jestyn... this is..."
    mc "Jestyn... esto es..."

# game/script day2.rpy:3618
translate Spanish prieston_route_day2_4930e4ac:

    # "Before I could turn around to face him, he gently stopped me by placing a hand on my shoulder."
    "Antes de que pudiera girarme para mirarlo, me detuvo con suavidad poniéndome una mano en el hombro."

# game/script day2.rpy:3620
translate Spanish prieston_route_day2_56730e10:

    # "My heart began pounding."
    "Mi corazón empezó a latir con fuerza."

# game/script day2.rpy:3621
translate Spanish prieston_route_day2_b9f0c119:

    # "Cold sweat once again ran down my back."
    "El sudor frío volvió a recorrerme la espalda."

# game/script day2.rpy:3622
translate Spanish prieston_route_day2_94598945:

    # "Something was terribly wrong."
    "Algo andaba terriblemente mal."

# game/script day2.rpy:3624
translate Spanish prieston_route_day2_0a0b62d1:

    # mc ".........."
    mc ".........."

# game/script day2.rpy:3625
translate Spanish prieston_route_day2_cf0fbdeb:

    # mc "...Who..."
    mc "...Quién..."

# game/script day2.rpy:3626
translate Spanish prieston_route_day2_5b149d17:

    # mc "...Who are you?"
    mc "...¿Quién eres?"

# game/script day2.rpy:3627
translate Spanish prieston_route_day2_6a8e9cb2:

    # voice "PRIESTON01_DAY2.ogg"
    # who "I've been looking forward to meeting You... my child."
    voice "PRIESTON01_DAY2.ogg"
    who "He estado esperando con ansias conocerte... hij[letra] mí[letra]."

# game/script day2.rpy:3640
translate Spanish prieston_route_day2_8f68d28d:

    # voice "PRIESTON02_DAY2.ogg"
    # who "You've certainly caught my attention..."
    voice "PRIESTON02_DAY2.ogg"
    who "Ciertamente has captado mi atención..."

# game/script day2.rpy:3642
translate Spanish prieston_route_day2_50620613:

    # voice "PRIESTON03_DAY2.ogg"
    # who "Like a curious little rabbit, You've been trying to uncover what truly happened to this kingdom... Have You not?"
    voice "PRIESTON03_DAY2.ogg"
    who "Como un curioso conejito, has estado intentando descubrir qué le ocurrió realmente a este reino... ¿no es así?"

# game/script day2.rpy:3647
translate Spanish prieston_route_day2_2e3e1ce3:

    # "Gathering every ounce of courage I had, I slowly turned around."
    "Reuniendo cada gramo de valor que tenía, me giré lentamente."

# game/script day2.rpy:3649
translate Spanish prieston_route_day2_7c77e967:

    # "And there he was..."
    "Y allí estaba..."

# game/script day2.rpy:3650
translate Spanish prieston_route_day2_24b1aeb4:

    # "A puppet with glowing violet eyes staring right into my soul."
    "Un títere de ojos violeta brillantes que me miraba directo al alma."

# game/script day2.rpy:3652
translate Spanish prieston_route_day2_fb15f26f:

    # "He let out a soft chuckle."
    "Soltó una risita suave."

# game/script day2.rpy:3655
translate Spanish prieston_route_day2_aeab538a:

    # who "I do adore that curious look in Your eyes."
    who "Adoro esa mirada curiosa en tus ojos."

# game/script day2.rpy:3657
translate Spanish prieston_route_day2_83c96cbf:

    # "He withdrew his hand from my shoulder before stepping around to stand in front of me, allowing me to see him clearly."
    "Retiró la mano de mi hombro antes de rodearme para colocarse frente a mí, permitiéndome verlo con claridad."

# game/script day2.rpy:3660
translate Spanish prieston_route_day2_41044202:

    # "Standing before me was a puppet dressed as a priest."
    "Ante mí había un títere vestido de sacerdote."

# game/script day2.rpy:3661
translate Spanish prieston_route_day2_6c0a766c:

    # "His long black hair was neatly kept, and a single horn protruded from the left side of his head."
    "Su largo cabello negro estaba pulcramente peinado, y un solo cuerno le sobresalía del lado izquierdo de la cabeza."

# game/script day2.rpy:3662
translate Spanish prieston_route_day2_355d1dd0:

    # "Every movement he made was composed and deliberate."
    "Cada movimiento que hacía era sereno y deliberado."

# game/script day2.rpy:3663
translate Spanish prieston_route_day2_29a207b2:

    # "Just by the way he carried himself, I could tell he was someone who always maintained a flawless image in front of others."
    "Solo por su manera de conducirse, supe que era alguien que siempre mantenía una imagen impecable ante los demás."

# game/script day2.rpy:3664
translate Spanish prieston_route_day2_745023f1:

    # "And somehow, it made me nervous."
    "Y de algún modo, eso me puso nervios[letra]."

# game/script day2.rpy:3666
translate Spanish prieston_route_day2_a37ffa00:

    # who "Judging by my appearance alone, I imagine you've already guessed the role I serve within this kingdom. Even so, before we continue, allow me to introduce myself, my child."
    who "A juzgar por mi apariencia, imagino que ya habrás adivinado el papel que desempeño en este reino. Aun así, antes de continuar, permíteme presentarme, hij[letra] mí[letra]."

# game/script day2.rpy:3668
translate Spanish prieston_route_day2_4565756b:

    # pri "You may call me Prieston. I am the kingdom's Priest Puppet."
    pri "Puedes llamarme Prieston. Soy el Títere Sacerdote del reino."

# game/script day2.rpy:3670
translate Spanish prieston_route_day2_6a8773b2:

    # "He took a few measured steps toward me, and simply stared at me for a few moments."
    "Dio unos pasos medidos hacia mí, y simplemente me miró fijamente durante unos instantes."

# game/script day2.rpy:3671
translate Spanish prieston_route_day2_d3b99cc5:

    # "Looking closer, I noticed that his pupils resembled those of a goat."
    "Al mirarlo más de cerca, noté que sus pupilas se parecían a las de una cabra."

# game/script day2.rpy:3673
translate Spanish prieston_route_day2_82e556ca:

    # "His gaze slowly traveled over me, from head to toe, carefully examining every detail of my appearance."
    "Su mirada recorrió lentamente mi cuerpo, de la cabeza a los pies, examinando con cuidado cada detalle de mi apariencia."

# game/script day2.rpy:3675
translate Spanish prieston_route_day2_ce052a7e:

    # "After a brief silence, he finally spoke. His smile widened."
    "Tras un breve silencio, por fin habló. Su sonrisa se ensanchó."

# game/script day2.rpy:3677
translate Spanish prieston_route_day2_42a25e37:

    # pri "Interesting..."
    pri "Interesante..."

# game/script day2.rpy:3678
translate Spanish prieston_route_day2_444b1f77:

    # mc "?"
    mc "?"

# game/script day2.rpy:3679
translate Spanish prieston_route_day2_a3f3280f:

    # pri "Such a small... fragile human. And yet, despite all those frailties....Jestyn still chose you."
    pri "Qué human[letra] tan pequeñ[letra]... y tan frágil. Y, sin embargo, a pesar de todas esas fragilidades....Jestyn aun así te eligió."

# game/script day2.rpy:3680
translate Spanish prieston_route_day2_67ff2c06:

    # pri "Intriguing... Truly intriguing... Oh, how I wonder why it is."
    pri "Intrigante... Verdaderamente intrigante... Oh, cómo me pregunto por qué será."

# game/script day2.rpy:3682
translate Spanish prieston_route_day2_163ea3ac:

    # pri "This has become far more fascinating than I had anticipated."
    pri "Esto se ha vuelto mucho más fascinante de lo que había previsto."

# game/script day2.rpy:3684
translate Spanish prieston_route_day2_25cf773e:

    # pri "I've been watching you. Ever since the moment you first stepped into this kingdom. Right up until the moment Jestyn crowned you as our new ruler."
    pri "Te he estado observando. Desde el momento en que pisaste por primera vez este reino. Hasta el momento en que Jestyn te coronó como nuestr[letra] nuev[letra] [title!t]."

# game/script day2.rpy:3685
translate Spanish prieston_route_day2_13161ac1:

    # pri "And as I said before, you're like a curious little rabbit, eager to uncover everything around you."
    pri "Y como dije antes, eres como un curioso conejito, ansioso por descubrir todo lo que te rodea."

# game/script day2.rpy:3687
translate Spanish prieston_route_day2_41279b71:

    # pri "Unfortunately... Jestyn has no intention of letting you discover what truly happened here."
    pri "Por desgracia... Jestyn no tiene intención de dejar que descubras lo que realmente ocurrió aquí."

# game/script day2.rpy:3689
translate Spanish prieston_route_day2_177e7735:

    # pri "You've sensed that yourself... haven't you?"
    pri "Tú mism[letra] lo has intuido... ¿no es así?"

# game/script day2.rpy:3691
translate Spanish prieston_route_day2_6ca61886:

    # "My thoughts drifted back to everything that had happened with Jestyn today."
    "Mis pensamientos volvieron a todo lo que había pasado con Jestyn hoy."

# game/script day2.rpy:3692
translate Spanish prieston_route_day2_ebca1ac8:

    # "He really had been steering me away from certain things."
    "De verdad me había estado desviando de ciertas cosas."

# game/script day2.rpy:3693
translate Spanish prieston_route_day2_8aaffa81:

    # "As if...there was something he desperately didn't want me to know."
    "Como si...hubiera algo que desesperadamente no quería que supiera."

# game/script day2.rpy:3694
translate Spanish prieston_route_day2_3a587ee6:

    # "I tried to think things through, but the dizziness from earlier still lingered, and my body felt far too weak."
    "Intenté pensar con claridad, pero el mareo de antes seguía ahí, y mi cuerpo se sentía demasiado débil."

# game/script day2.rpy:3696
translate Spanish prieston_route_day2_5c552db7:

    # "Seeing how weak I was, Prieston offered me his hand to help me up."
    "Al ver lo débil que estaba, Prieston me ofreció la mano para ayudarme a levantarme."

# game/script day2.rpy:3699
translate Spanish prieston_route_day2_a6919868:

    # pri "Come, my child. Allow me to guide you the chair. You need to rest."
    pri "Ven, hij[letra] mí[letra]. Permíteme guiarte a la silla. Necesitas descansar."

# game/script day2.rpy:3701
translate Spanish prieston_route_day2_d974e8d8:

    # "After a brief moment of hesitation..."
    "Tras un breve momento de duda..."

# game/script day2.rpy:3702
translate Spanish prieston_route_day2_e43ceb5d:

    # "...I reached out and took his hand."
    "...extendí la mano y tomé la suya."

# game/script day2.rpy:3704
translate Spanish prieston_route_day2_525d91cb:

    # pri "Excuse me."
    pri "Con permiso."

# game/script day2.rpy:3708
translate Spanish prieston_route_day2_aea4a73c:

    # "I flinched in surprise when Prieston suddenly scooped me into his arms. But I was far too weak to question it, so I simply let him carry me."
    "Me estremecí de sorpresa cuando Prieston me tomó de repente en brazos. Pero estaba demasiado débil para cuestionarlo, así que simplemente dejé que me cargara."

# game/script day2.rpy:3710
translate Spanish prieston_route_day2_8f0a7867:

    # "He gently put me down on the soft chair."
    "Me dejó con delicadeza sobre la silla blanda."

# game/script day2.rpy:3713
translate Spanish prieston_route_day2_4b58b967:

    # pri "Would you like some warm tea?"
    pri "¿Te gustaría un té caliente?"

# game/script day2.rpy:3715
translate Spanish prieston_route_day2_8bef3b52:

    # "Warm tea sounded comforting in my current state, so I nodded."
    "Un té caliente sonaba reconfortante en mi estado actual, así que asentí."

# game/script day2.rpy:3717
translate Spanish prieston_route_day2_332afc5f:

    # "Prieston then walked over to what I assumed was his work desk and began preparing a cup of warm tea for me."
    "Prieston caminó entonces hasta lo que supuse que era su escritorio de trabajo y empezó a preparar una taza de té caliente para mí."

# game/script day2.rpy:3718
translate Spanish prieston_route_day2_376c04f4:

    # "As he busied himself preparing the tea, Prieston glanced over at me every now and then to check on me."
    "Mientras se ocupaba de preparar el té, Prieston me miraba de vez en cuando para ver cómo estaba."

# game/script day2.rpy:3719
translate Spanish prieston_route_day2_cb5da5ae:

    # "A few moments later, Prieston returned with a steaming cup of tea."
    "Unos momentos después, Prieston regresó con una taza de té humeante."

# game/script day2.rpy:3720
translate Spanish prieston_route_day2_f31d2a39:

    # "Before taking a sip, I caught the delicate scent of jasmine drifting from the tea. As I drank, its floral warmth lingered on my tongue before gently soothing my throat."
    "Antes de tomar un sorbo, percibí el delicado aroma a jazmín que emanaba del té. Al beber, su calidez floral persistió en mi lengua antes de aliviarme suavemente la garganta."

# game/script day2.rpy:3723
translate Spanish prieston_route_day2_d730dec7:

    # pri "Feeling better?"
    pri "¿Te sientes mejor?"

# game/script day2.rpy:3725
translate Spanish prieston_route_day2_35bf5a71:

    # "I nodded."
    "Asentí."

# game/script day2.rpy:3728
translate Spanish prieston_route_day2_5dd294d5:

    # pri "Are you still feeling dizzy?"
    pri "¿Todavía te sientes maread[letra]?"

# game/script day2.rpy:3729
translate Spanish prieston_route_day2_8f63a16d:

    # mc "Not really... But I'm still too weak..."
    mc "No mucho... Pero sigo demasiado débil..."

# game/script day2.rpy:3732
translate Spanish prieston_route_day2_070d9c51:

    # "Prieston gave me a gentle smile before softly stroking my head."
    "Prieston me regaló una sonrisa suave antes de acariciarme con ternura la cabeza."

# game/script day2.rpy:3735
translate Spanish prieston_route_day2_27d3604f:

    # pri "What a poor little lamb..."
    pri "Pobre corderito..."

# game/script day2.rpy:3736
translate Spanish prieston_route_day2_5c3e5b4b:

    # "It was strange. I'd only met this puppet a few minutes ago, yet somehow... I felt at ease around him."
    "Era extraño. Hacía solo unos minutos que conocía a este títere, y aun así... me sentía a gusto a su lado."

# game/script day2.rpy:3737
translate Spanish prieston_route_day2_422e7b63:

    # "... Is it really safe to feel this way...? Since this is the first time I've met him..."
    "... ¿De verdad es seguro sentirme así...? Siendo la primera vez que lo conozco..."

# game/script day2.rpy:3740
translate Spanish prieston_route_day2_52e65838:

    # "Then he took a seat as well from across the table."
    "Luego él también tomó asiento al otro lado de la mesa."

# game/script day2.rpy:3741
translate Spanish prieston_route_day2_bbc30b63:

    # "This puppet... for some reason, I couldn't shake the feeling that he was shrouded in mystery."
    "Este títere... por alguna razón, no podía quitarme la sensación de que estaba envuelto en misterio."

# game/script day2.rpy:3742
translate Spanish prieston_route_day2_b391c212:

    # "Just as Wizzy, Knighter, and Butley had described, the way his mind worked was hard to predict."
    "Tal como lo habían descrito Wizzy, Knighter y Butley, la forma en que funcionaba su mente era difícil de predecir."

# game/script day2.rpy:3743
translate Spanish prieston_route_day2_519d45e6:

    # "And that only made me want to know what was really going on inside his head."
    "Y eso solo me hacía querer saber qué sucedía realmente dentro de su cabeza."

# game/script day2.rpy:3752
translate Spanish prieston_ask_8ae515d9:

    # mc "Why did you help me?"
    mc "¿Por qué me ayudaste?"

# game/script day2.rpy:3754
translate Spanish prieston_ask_ad19dff1:

    # "He chuckled."
    "Soltó una risita."

# game/script day2.rpy:3757
translate Spanish prieston_ask_3cd4865e:

    # pri "Do I not have the right to help someone here?"
    pri "¿Acaso no tengo derecho a ayudar a alguien aquí?"

# game/script day2.rpy:3758
translate Spanish prieston_ask_030c0ea3:

    # pri "My child... I must admit, I didn't expect a question like that after I so willingly gave up my time to help you."
    pri "Hij[letra] mí[letra]... debo admitir que no esperaba una pregunta así después de haber cedido tan de buen grado mi tiempo para ayudarte."

# game/script day2.rpy:3760
translate Spanish prieston_ask_7ce30a38:

    # "Damn... Now I feel guilty for asking something so bluntly..."
    "Maldición... Ahora me siento culpable por haber preguntado algo tan a quemarropa..."

# game/script day2.rpy:3762
translate Spanish prieston_ask_7fa32ade:

    # mc "...I'm sorry. And... thank you for helping me earlier."
    mc "...Lo siento. Y... gracias por haberme ayudado antes."

# game/script day2.rpy:3764
translate Spanish prieston_ask_8be71f67:

    # pri "Haha... My child, I was only teasing you a little. Of course you deserve to know why."
    pri "Jaja... Hij[letra] mí[letra], solo te estaba tomando un poco el pelo. Por supuesto que mereces saber por qué."

# game/script day2.rpy:3765
translate Spanish prieston_ask_8f7d271e:

    # pri "Besides... you are the [title] of this kingdom now."
    pri "Además... ahora eres [arti] [title!t] de este reino."

# game/script day2.rpy:3766
translate Spanish prieston_ask_4a7e3af5:

    # pri "Now then, back to your question. You asked why I helped you?"
    pri "Ahora bien, volviendo a tu pregunta. ¿Preguntabas por qué te ayudé?"

# game/script day2.rpy:3767
translate Spanish prieston_ask_ec0e2a48:

    # pri "There wasn't any particular reason."
    pri "No hubo ninguna razón en particular."

# game/script day2.rpy:3768
translate Spanish prieston_ask_7d89f78f:

    # pri "I simply saw you... standing alone on that stage, surrounded by a crowd of starving puppets."
    pri "Simplemente te vi... de pie a solas en ese escenario, rodead[letra] por una multitud de títeres hambrientos."

# game/script day2.rpy:3769
translate Spanish prieston_ask_97585a28:

    # pri "And there you were, right in the middle of them... helpless, in need of someone to reach out a hand."
    pri "Y ahí estabas, justo en medio de ellos... indefens[letra], necesitando que alguien te tendiera una mano."

# game/script day2.rpy:3772
translate Spanish prieston_ask_1ae2bc46:

    # "Prieston placed a hand over his chest, a quiet gesture that spoke of his sincerity."
    "Prieston se llevó una mano al pecho, un gesto silencioso que hablaba de su sinceridad."

# game/script day2.rpy:3773
translate Spanish prieston_ask_09848ab7:

    # "The smile on his face faded, replaced by a solemn expression."
    "La sonrisa de su rostro se desvaneció, reemplazada por una expresión solemne."

# game/script day2.rpy:3775
translate Spanish prieston_ask_34b3de93:

    # pri "I simply couldn't, my child."
    pri "Simplemente no pude, hij[letra] mí[letra]."

# game/script day2.rpy:3777
translate Spanish prieston_ask_fe79e9c6:

    # voice "PRIESTON04_DAY2.ogg"
    # pri "I couldn't bear to watch someone as vulnerable... and as pure as you... be left in such danger."
    voice "PRIESTON04_DAY2.ogg"
    pri "No pude soportar ver a alguien tan vulnerable... y tan pur[letra] como tú... quedar expuest[letra] a tal peligro."

# game/script day2.rpy:3781
translate Spanish prieston_ask_6ae74f21:

    # pri "I am a priest puppet."
    pri "Soy un títere sacerdote."

# game/script day2.rpy:3782
translate Spanish prieston_ask_1851cb1a:

    # pri "It is my duty to help those who are suffering."
    pri "Es mi deber ayudar a quienes sufren."

# game/script day2.rpy:3783
translate Spanish prieston_ask_59bc7c7e:

    # pri "Without exception."
    pri "Sin excepción."

# game/script day2.rpy:3786
translate Spanish prieston_ask_00693d4b:

    # "His gentle smile returned as though it had never left."
    "Su suave sonrisa regresó como si jamás se hubiera ido."

# game/script day2.rpy:3788
translate Spanish prieston_ask_ba05596e:

    # pri "Does that answer your question, my child?"
    pri "¿Eso responde tu pregunta, hij[letra] mí[letra]?"

# game/script day2.rpy:3792
translate Spanish prieston_ask_3c9ec2b4:

    # "Come to think of it... his explanation made perfect sense. Why would he need some deeper reason just to help me...?"
    "Ahora que lo pienso... su explicación tenía todo el sentido. ¿Por qué necesitaría una razón más profunda solo para ayudarme...?"

# game/script day2.rpy:3793
translate Spanish prieston_ask_e3117a0b:

    # "It felt like I was being unfairly suspicious of him."
    "Sentí que estaba siendo injustamente desconfiad[letra] con él."

# game/script day2.rpy:3795
translate Spanish prieston_ask_7651e782:

    # mc "Yeah... that answers my question."
    mc "Sí... eso responde mi pregunta."

# game/script day2.rpy:3796
translate Spanish prieston_ask_d439a85e:

    # mc "I'm sorry if I sounded like I didn't trust you."
    mc "Perdona si di la impresión de que no confiaba en ti."

# game/script day2.rpy:3798
translate Spanish prieston_ask_df9324f3:

    # pri "It's quite alright, my child. I understand why you're so cautious. We've only just met. It's only natural."
    pri "No hay problema, hij[letra] mí[letra]. Entiendo por qué eres tan cautelos[letra]. Apenas nos conocemos. Es natural."

# game/script day2.rpy:3799
translate Spanish prieston_ask_dd2a1ad7:

    # pri "One shouldn't place their trust in someone they've only just met. Even so, I can assure you... I mean you no harm."
    pri "Uno no debería depositar su confianza en alguien a quien apenas conoce. Aun así, puedo asegurarte... que no te deseo ningún mal."

# game/script day2.rpy:3800
translate Spanish prieston_ask_c33473b5:

    # pri "We have plenty of time to get to know one another."
    pri "Tenemos mucho tiempo para llegar a conocernos."

# game/script day2.rpy:3806
translate Spanish prieston_ask_d80e4f76:

    # "As much as I wanted to believe him, I couldn't shake the feeling that something was... off."
    "Por más que quería creerle, no podía quitarme la sensación de que algo andaba... mal."

# game/script day2.rpy:3807
translate Spanish prieston_ask_5a5ed29c:

    # "It felt as though there was another reason... one hidden beneath the explanation he'd just given me."
    "Se sentía como si hubiera otra razón... una oculta bajo la explicación que acababa de darme."

# game/script day2.rpy:3808
translate Spanish prieston_ask_d4eecbc0:

    # "Something wasn't right."
    "Algo no estaba bien."

# game/script day2.rpy:3810
translate Spanish prieston_ask_234a8c30:

    # "Prieston noticed the doubt written across my face. His expression softened almost immediately."
    "Prieston notó la duda escrita en mi rostro. Su expresión se suavizó casi de inmediato."

# game/script day2.rpy:3812
translate Spanish prieston_ask_8b853942:

    # pri "It's alright, my child. I understand if you don't trust me yet. We only just met, after all."
    pri "Está bien, hij[letra] mí[letra]. Entiendo si todavía no confías en mí. Después de todo, apenas nos conocemos."

# game/script day2.rpy:3813
translate Spanish prieston_ask_dd2a1ad7_1:

    # pri "One shouldn't place their trust in someone they've only just met. Even so, I can assure you... I mean you no harm."
    pri "Uno no debería depositar su confianza en alguien a quien apenas conoce. Aun así, puedo asegurarte... que no te deseo ningún mal."

# game/script day2.rpy:3814
translate Spanish prieston_ask_c33473b5_1:

    # pri "We have plenty of time to get to know one another."
    pri "Tenemos mucho tiempo para llegar a conocernos."

# game/script day2.rpy:3819
translate Spanish prieston_ask_b75abed0:

    # mc "What do you think of Crownus?"
    mc "¿Qué piensas de Crownus?"

# game/script day2.rpy:3821
translate Spanish prieston_ask_dc4044a3:

    # pri "You seem quite interested in Crownus, my child."
    pri "Pareces bastante interesad[letra] en Crownus, hij[letra] mí[letra]."

# game/script day2.rpy:3822
translate Spanish prieston_ask_e4e54d5d:

    # mc "I am... and it's not just that..."
    mc "Lo estoy... y no es solo eso..."

# game/script day2.rpy:3823
translate Spanish prieston_ask_1d3e580f:

    # mc "What happened earlier made me realize that some of the puppets in this theater are still fiercely loyal to Crownus."
    mc "Lo que pasó antes me hizo darme cuenta de que algunos de los títeres de este teatro siguen siendo ferozmente leales a Crownus."

# game/script day2.rpy:3824
translate Spanish prieston_ask_009d7ede:

    # mc "So loyal, in fact... that they were willing to kill me."
    mc "Tan leales, de hecho... que estaban dispuestos a matarme."

# game/script day2.rpy:3826
translate Spanish prieston_ask_4ed52613:

    # "I paused for a moment, carefully choosing my words, or at least, the ones that felt safest to say in front of Prieston."
    "Hice una pausa, escogiendo cuidadosamente mis palabras, o al menos, las que me parecían más seguras de decir frente a Prieston."

# game/script day2.rpy:3828
translate Spanish prieston_ask_aba43eb9:

    # mc "So... I wanted to ask... what do you think of Crownus?"
    mc "Así que... quería preguntarte... ¿qué piensas de Crownus?"

# game/script day2.rpy:3829
translate Spanish prieston_ask_814a153c:

    # mc "And... are you one of the puppets who's loyal to him?"
    mc "Y... ¿eres uno de los títeres que le son leales?"

# game/script day2.rpy:3831
translate Spanish prieston_ask_f23b642f:

    # pri "Hmm... I see."
    pri "Hmm... ya veo."

# game/script day2.rpy:3833
translate Spanish prieston_ask_2443067c:

    # "He paused for a moment, eyes staring at me without a single glance before he finally started to speak."
    "Hizo una pausa, con los ojos fijos en mí sin un solo parpadeo antes de comenzar por fin a hablar."

# game/script day2.rpy:3835
translate Spanish prieston_ask_d1a7df54:

    # pri "When I think of Crownus..."
    pri "Cuando pienso en Crownus..."

# game/script day2.rpy:3836
translate Spanish prieston_ask_1134f806:

    # pri "Only one word comes to mind."
    pri "Solo una palabra me viene a la mente."

# game/script day2.rpy:3837
translate Spanish prieston_ask_b9ec8092:

    # pri "Fascinating."
    pri "Fascinante."

# game/script day2.rpy:3838
translate Spanish prieston_ask_5548acfe:

    # mc "...Fascinating?"
    mc "...¿Fascinante?"

# game/script day2.rpy:3839
translate Spanish prieston_ask_f4e22a4d:

    # pri "Indeed."
    pri "En efecto."

# game/script day2.rpy:3841
translate Spanish prieston_ask_bf70e9b6:

    # pri "How he was able to capture the hearts of so many..."
    pri "Cómo logró capturar el corazón de tantos..."

# game/script day2.rpy:3843
translate Spanish prieston_ask_f81a10bb:

    # pri "How he managed to gather so many followers..."
    pri "Cómo logró reunir a tantos seguidores..."

# game/script day2.rpy:3845
translate Spanish prieston_ask_f43555de:

    # pri "How he inspired such unwavering loyalty within them..."
    pri "Cómo inspiró en ellos una lealtad inquebrantable..."

# game/script day2.rpy:3847
translate Spanish prieston_ask_f10ddb74:

    # pri "And... where he intended to lead those followers in the end."
    pri "Y... adónde pretendía llevar a esos seguidores al final."

# game/script day2.rpy:3848
translate Spanish prieston_ask_e40aded2:

    # pri "I find all of it... utterly fascinating."
    pri "Todo eso me parece... absolutamente fascinante."

# game/script day2.rpy:3849
translate Spanish prieston_ask_b70c9bdc:

    # pri "Back then... I wanted to see how Crownus's ambitions would come to an end."
    pri "En aquel entonces... quería ver cómo terminarían las ambiciones de Crownus."

# game/script day2.rpy:3852
translate Spanish prieston_ask_0fd4d656:

    # "......"
    "......"

# game/script day2.rpy:3854
translate Spanish prieston_ask_6c21e76a:

    # mc "Does that mean... you're one of the puppets who's loyal to Crownus?"
    mc "¿Eso significa... que eres uno de los títeres leales a Crownus?"

# game/script day2.rpy:3856
translate Spanish prieston_ask_abd0dd09:

    # pri "Then allow me to return that question to you, my child."
    pri "Entonces permíteme devolverte esa pregunta, hij[letra] mí[letra]."

# game/script day2.rpy:3857
translate Spanish prieston_ask_836d1305:

    # pri "What do YOU think?"
    pri "¿Qué piensas TÚ?"

# game/script day2.rpy:3861
translate Spanish prieston_ask_3b21f354:

    # mc "......"
    mc "......"

# game/script day2.rpy:3862
translate Spanish prieston_ask_c6862727:

    # mc "I think... you're one of Crownus's loyal followers."
    mc "Creo que... eres uno de los leales seguidores de Crownus."

# game/script day2.rpy:3865
translate Spanish prieston_ask_a98b5580:

    # "Prieston's smile widened, and one of his brows lifted with genuine interest at my answer."
    "La sonrisa de Prieston se ensanchó, y una de sus cejas se alzó con genuino interés ante mi respuesta."

# game/script day2.rpy:3867
translate Spanish prieston_ask_aa3fad61:

    # pri "Is that so?"
    pri "¿Es así?"

# game/script day2.rpy:3868
translate Spanish prieston_ask_f0413ae6:

    # pri "Then would you mind telling me why you think that?"
    pri "Entonces, ¿te importaría decirme por qué lo crees?"

# game/script day2.rpy:3869
translate Spanish prieston_ask_baa7e919:

    # mc "From the way you talk about Crownus..."
    mc "Por la forma en que hablas de Crownus..."

# game/script day2.rpy:3870
translate Spanish prieston_ask_224d4911:

    # mc "And from the things you find so fascinating about him..."
    mc "Y por las cosas que te resultan tan fascinantes de él..."

# game/script day2.rpy:3871
translate Spanish prieston_ask_398d4860:

    # mc "I get the feeling you're one of his most loyal followers."
    mc "Tengo la sensación de que eres uno de sus seguidores más leales."

# game/script day2.rpy:3872
translate Spanish prieston_ask_4eb7dd45:

    # mc "You seem like... you admire him."
    mc "Parece que... lo admiras."

# game/script day2.rpy:3876
translate Spanish prieston_ask_3b21f354_1:

    # mc "......"
    mc "......"

# game/script day2.rpy:3877
translate Spanish prieston_ask_14e76b79:

    # mc "I think... you're not one of Crownus's loyal followers."
    mc "Creo que... no eres uno de los leales seguidores de Crownus."

# game/script day2.rpy:3880
translate Spanish prieston_ask_a98b5580_1:

    # "Prieston's smile widened, and one of his brows lifted with genuine interest at my answer."
    "La sonrisa de Prieston se ensanchó, y una de sus cejas se alzó con genuino interés ante mi respuesta."

# game/script day2.rpy:3882
translate Spanish prieston_ask_aa3fad61_1:

    # pri "Is that so?"
    pri "¿Es así?"

# game/script day2.rpy:3883
translate Spanish prieston_ask_f0413ae6_1:

    # pri "Then would you mind telling me why you think that?"
    pri "Entonces, ¿te importaría decirme por qué lo crees?"

# game/script day2.rpy:3884
translate Spanish prieston_ask_96da4f71:

    # mc "Because... if you really were one of Crownus's loyal followers, you wouldn't have saved me."
    mc "Porque... si de verdad fueras uno de los leales seguidores de Crownus, no me habrías salvado."

# game/script day2.rpy:3885
translate Spanish prieston_ask_6cfa64bf:

    # mc "I mean... when Butley and the other puppets attacked me and tried to devour me... you didn't join them."
    mc "Es decir... cuando Butley y los otros títeres me atacaron e intentaron devorarme... no te uniste a ellos."

# game/script day2.rpy:3886
translate Spanish prieston_ask_6f128967:

    # mc "So even though you find Crownus fascinating... the fact that you chose to save me makes it hard for me to see you as one of them."
    mc "Así que aunque te parezca fascinante Crownus... el hecho de que eligieras salvarme me hace difícil verte como uno de ellos."

# game/script day2.rpy:3888
translate Spanish prieston_ask_df845f35:

    # mc "Sorry... I'm not sure if I'm explaining myself very well."
    mc "Perdona... no sé si me estoy explicando muy bien."

# game/script day2.rpy:3890
translate Spanish prieston_ask_48e7b16c:

    # pri "There's no need to apologize, my child. I understand exactly what you mean."
    pri "No hace falta que te disculpes, hij[letra] mí[letra]. Entiendo perfectamente a qué te refieres."

# game/script day2.rpy:3891
translate Spanish prieston_ask_6f9aad4d:

    # pri "And I must say... I appreciate both your answer and your observation."
    pri "Y debo decir... que agradezco tanto tu respuesta como tu observación."

# game/script day2.rpy:3892
translate Spanish prieston_ask_8df91a34:

    # mc "So... was I right?"
    mc "Entonces... ¿tenía razón?"

# game/script day2.rpy:3894
translate Spanish prieston_ask_92c82531:

    # pri "The answer, my child... is patience."
    pri "La respuesta, hij[letra] mí[letra]... es paciencia."

# game/script day2.rpy:3896
translate Spanish prieston_ask_5746fc2e:

    # "I couldn't help but pout."
    "No pude evitar hacer un puchero."

# game/script day2.rpy:3898
translate Spanish prieston_ask_53d15499:

    # mc "....That is not answering my question..."
    mc "....Eso no responde mi pregunta..."

# game/script day2.rpy:3901
translate Spanish prieston_ask_d1fbbd15:

    # "He chuckled at my reaction."
    "Soltó una risita ante mi reacción."

# game/script day2.rpy:3903
translate Spanish prieston_ask_e5c37613:

    # pri "Hmm... what an adorable, curious little thing."
    pri "Hmm... qué cosita tan adorable y curiosa."

# game/script day2.rpy:3904
translate Spanish prieston_ask_65dfecfa:

    # pri "But sometimes... patience is the key."
    pri "Pero a veces... la paciencia es la clave."

# game/script day2.rpy:3906
translate Spanish prieston_ask_357c8401:

    # "What does that even mean..."
    "¿Qué demonios significa eso..."

# game/script day2.rpy:3911
translate Spanish prieston_ask_77e2d565:

    # mc "What do you think of Jestyn?"
    mc "¿Qué piensas de Jestyn?"

# game/script day2.rpy:3913
translate Spanish prieston_ask_db8436de:

    # pri "Ah... Jestyn. The kingdom's beloved jester puppet."
    pri "Ah... Jestyn. El querido títere bufón del reino."

# game/script day2.rpy:3914
translate Spanish prieston_ask_bee7fb5a:

    # pri "A puppet who's nearly impossible to rein in... yet somehow keeps the spirit of this kingdom alive."
    pri "Un títere casi imposible de controlar... y sin embargo, de algún modo, mantiene vivo el espíritu de este reino."

# game/script day2.rpy:3916
translate Spanish prieston_ask_fcaec49a:

    # pri "Are you curious about him?"
    pri "¿Sientes curiosidad por él?"

# game/script day2.rpy:3918
translate Spanish prieston_ask_fb20d84f:

    # "I nodded without hesitation."
    "Asentí sin dudarlo."

# game/script day2.rpy:3920
translate Spanish prieston_ask_776bc806:

    # mc "Earlier, you said that Jestyn doesn't want me to learn certain things... and I've had the feeling he's hiding something from me."
    mc "Antes dijiste que Jestyn no quiere que me entere de ciertas cosas... y yo he tenido la sensación de que me oculta algo."

# game/script day2.rpy:3921
translate Spanish prieston_ask_fa60dae1:

    # mc "And then there's what Butley told me... that Jestyn is only using me. Manipulating me."
    mc "Y luego está lo que me dijo Butley... que Jestyn solo me está usando. Manipulándome."

# game/script day2.rpy:3922
translate Spanish prieston_ask_19e7f8cf:

    # mc "So... I don't know what to believe anymore. Is that all true?"
    mc "Así que... ya no sé qué creer. ¿Es todo eso cierto?"

# game/script day2.rpy:3923
translate Spanish prieston_ask_e8aab700:

    # pri "I see."
    pri "Ya veo."

# game/script day2.rpy:3924
translate Spanish prieston_ask_d97677dc:

    # pri "I'm afraid I can only tell you one fact about that man."
    pri "Me temo que solo puedo decirte un hecho sobre ese hombre."

# game/script day2.rpy:3925
translate Spanish prieston_ask_fc4c8868:

    # pri "Jestyn hates Crownus."
    pri "Jestyn odia a Crownus."

# game/script day2.rpy:3927
translate Spanish prieston_ask_84d0e2b6:

    # "My eyes widened at those words. So all this time..."
    "Mis ojos se abrieron de par en par ante esas palabras. Así que todo este tiempo..."

# game/script day2.rpy:3930
translate Spanish prieston_ask_82e4a22f:

    # pri "If you've been paying attention to his behavior, you've probably noticed that he always avoids saying Crownus's name..."
    pri "Si has estado prestando atención a su comportamiento, probablemente hayas notado que siempre evita decir el nombre de Crownus..."

# game/script day2.rpy:3931
translate Spanish prieston_ask_4deb0e48:

    # pri "And he insists that the other puppets avoid speaking it as well."
    pri "Y que insiste en que los otros títeres también eviten pronunciarlo."

# game/script day2.rpy:3933
translate Spanish prieston_ask_3b21f354_2:

    # mc "......"
    mc "......"

# game/script day2.rpy:3934
translate Spanish prieston_ask_6f38e505:

    # mc "Why does he hate Crownus? From what Wizzy told me, Crownus was a liar. Is that why?"
    mc "¿Por qué odia a Crownus? Según lo que me dijo Wizzy, Crownus era un mentiroso. ¿Es por eso?"

# game/script day2.rpy:3935
translate Spanish prieston_ask_659aed60:

    # mc "But Butley said he was their savior... so... who's telling the truth?"
    mc "Pero Butley dijo que era su salvador... así que... ¿quién dice la verdad?"

# game/script day2.rpy:3936
translate Spanish prieston_ask_2fee49c2:

    # pri "I can see your mind is overflowing with questions."
    pri "Veo que tu mente rebosa de preguntas."

# game/script day2.rpy:3937
translate Spanish prieston_ask_a690635e:

    # pri "But first, I suggest you calm yourself."
    pri "Pero primero, te sugiero que te calmes."

# game/script day2.rpy:3938
translate Spanish prieston_ask_aebe5653:

    # pri "It's difficult to think clearly when you're overwhelmed, isn't it?"
    pri "Es difícil pensar con claridad cuando uno está abrumado, ¿no es cierto?"

# game/script day2.rpy:3940
translate Spanish prieston_ask_2d50da73:

    # pri "Take a slow, deep breath."
    pri "Respira hondo y despacio."

# game/script day2.rpy:3942
translate Spanish prieston_ask_ae7029f8:

    # "Following Prieston's instruction, I inhaled deeply through my nose, then slowly exhaled through my mouth."
    "Siguiendo la indicación de Prieston, inhalé profundamente por la nariz y luego exhalé lentamente por la boca."

# game/script day2.rpy:3943
translate Spanish prieston_ask_feba0663:

    # "He was right... There was no way I could think straight while my mind was so full of noise."
    "Tenía razón... No había forma de que pudiera pensar con claridad con la mente tan llena de ruido."

# game/script day2.rpy:3945
translate Spanish prieston_ask_2b7d4e67:

    # "Once he saw that I'd calmed down, Prieston gave a small nod before continuing."
    "Una vez que vio que me había calmado, Prieston asintió levemente antes de continuar."

# game/script day2.rpy:3947
translate Spanish prieston_ask_a522c37d:

    # pri "You asked which of them is telling the truth."
    pri "Preguntaste cuál de ellos dice la verdad."

# game/script day2.rpy:3948
translate Spanish prieston_ask_375e3e62:

    # pri "The only answer that truly matters... is the one you arrive at yourself."
    pri "La única respuesta que de verdad importa... es la que tú mism[letra] alcances."

# game/script day2.rpy:3949
translate Spanish prieston_ask_a8822b1e:

    # pri "You are the one who must decide what is true... and what is false."
    pri "Eres tú quien debe decidir qué es verdadero... y qué es falso."

# game/script day2.rpy:3951
translate Spanish prieston_ask_0e1835d3:

    # "His words only left me even more confused."
    "Sus palabras solo me dejaron aún más confundid[letra]."

# game/script day2.rpy:3952
translate Spanish prieston_ask_24ee6f04:

    # "Why did it have to be me? Why was I the one who had to decide what was right and what was wrong?"
    "¿Por qué tenía que ser yo? ¿Por qué era yo quien tenía que decidir qué estaba bien y qué estaba mal?"

# game/script day2.rpy:3953
translate Spanish prieston_ask_c338bfdf:

    # "I needed to know more."
    "Necesitaba saber más."

# game/script day2.rpy:3955
translate Spanish prieston_ask_a18d2323:

    # mc "Then... let's get back to the original question."
    mc "Entonces... volvamos a la pregunta original."

# game/script day2.rpy:3956
translate Spanish prieston_ask_77e2d565_1:

    # mc "What do you think of Jestyn?"
    mc "¿Qué piensas de Jestyn?"

# game/script day2.rpy:3959
translate Spanish prieston_ask_ad19dff1_1:

    # "He chuckled."
    "Soltó una risita."

# game/script day2.rpy:3961
translate Spanish prieston_ask_1b7992d5:

    # pri "What do I think of Jestyn...?"
    pri "¿Qué pienso de Jestyn...?"

# game/script day2.rpy:3962
translate Spanish prieston_ask_9d0da414:

    # pri "He's like a caterpillar."
    pri "Es como una oruga."

# game/script day2.rpy:3963
translate Spanish prieston_ask_d2e04ca5:

    # mc "A what?? Caterpillar?"
    mc "¿¿Una qué?? ¿Una oruga?"

# game/script day2.rpy:3964
translate Spanish prieston_ask_387df382:

    # pri "Yes."
    pri "Sí."

# game/script day2.rpy:3965
translate Spanish prieston_ask_badf424c:

    # pri "A harmless little caterpillar... innocent, naive, knowing nothing beyond eating leaves."
    pri "Una pequeña oruga inofensiva... inocente, ingenua, que no sabe nada más allá de comer hojas."

# game/script day2.rpy:3966
translate Spanish prieston_ask_6b58eb53:

    # pri "Then, little by little, that innocent caterpillar wraps itself in a cocoon."
    pri "Luego, poco a poco, esa inocente oruga se envuelve en un capullo."

# game/script day2.rpy:3967
translate Spanish prieston_ask_8c7f9eb9:

    # pri "And when the cocoon finally opens... the caterpillar emerges as something entirely different."
    pri "Y cuando el capullo por fin se abre... la oruga emerge convertida en algo completamente distinto."

# game/script day2.rpy:3969
translate Spanish prieston_ask_3287f4ba:

    # pri "A butterfly."
    pri "Una mariposa."

# game/script day2.rpy:3971
translate Spanish prieston_ask_75b393ae:

    # pri "That's how I see Jestyn."
    pri "Así es como veo a Jestyn."

# game/script day2.rpy:3973
translate Spanish prieston_ask_70f02357:

    # "Prieston spoke with such philosophical conviction that I had to think carefully just to keep up with what he was saying."
    "Prieston habló con tal convicción filosófica que tuve que pensar con cuidado solo para seguir lo que decía."

# game/script day2.rpy:3974
translate Spanish prieston_ask_08114bdd:

    # "He studied my expression for a moment. Seemingly satisfied by what he saw, he continued."
    "Estudió mi expresión un momento. Aparentemente satisfecho con lo que vio, continuó."

# game/script day2.rpy:3976
translate Spanish prieston_ask_e416c6bb:

    # pri "Jestyn... is the kindest and most innocent man I've ever met."
    pri "Jestyn... es el hombre más amable e inocente que he conocido."

# game/script day2.rpy:3977
translate Spanish prieston_ask_be48fdbd:

    # pri "All he's ever wanted... is for everyone to be happy."
    pri "Todo lo que ha querido siempre... es que todos sean felices."

# game/script day2.rpy:3978
translate Spanish prieston_ask_1ec6268b:

    # pri "Perhaps, from where you're standing now, you see Jestyn as a mischievous puppet... sarcastic... fond of mocking others... perhaps even a little evil."
    pri "Quizás, desde donde estás ahora, ves a Jestyn como un títere travieso... sarcástico... aficionado a burlarse de los demás... quizás incluso un poco malvado."

# game/script day2.rpy:3980
translate Spanish prieston_ask_2b193ee2:

    # pri "But the Jestyn you know... is not the same Jestyn that I know, my child."
    pri "Pero el Jestyn que tú conoces... no es el mismo Jestyn que yo conozco, hij[letra] mí[letra]."

# game/script day2.rpy:3981
translate Spanish prieston_ask_56d15d43:

    # pri "After all... I've lived far longer than you have."
    pri "Después de todo... yo he vivido mucho más que tú."

# game/script day2.rpy:3982
translate Spanish prieston_ask_c24cc0d8:

    # pri "To me, he's still the same Jestyn I've always known..."
    pri "Para mí, sigue siendo el mismo Jestyn de siempre..."

# game/script day2.rpy:3983
translate Spanish prieston_ask_08e4a917:

    # pri "He's simply wearing... a different face."
    pri "Simplemente lleva... un rostro distinto."

# game/script day2.rpy:3985
translate Spanish prieston_ask_75855eb8:

    # pri "And that's precisely what makes that man so fascinating."
    pri "Y eso es precisamente lo que hace a ese hombre tan fascinante."

# game/script day2.rpy:3987
translate Spanish prieston_ask_542bb61c:

    # pri "That is all of what I think about Jestyn. I hope that feeds your curiosity, my child."
    pri "Eso es todo lo que pienso sobre Jestyn. Espero que eso alimente tu curiosidad, hij[letra] mí[letra]."

# game/script day2.rpy:3989
translate Spanish prieston_ask_8f235a99:

    # "No. That just adds more t my curiosity."
    "No. Eso solo añade más a mi curiosidad."

# game/script day2.rpy:3990
translate Spanish prieston_ask_bde3b53a:

    # "But even if I ask again, I don't think he will give me to the point answer."
    "Pero aunque pregunte otra vez, no creo que me dé una respuesta directa."

# game/script day2.rpy:3995
translate Spanish prieston_ask_b575f5fd:

    # mc "I'd like to know more about you."
    mc "Me gustaría saber más sobre ti."

# game/script day2.rpy:3997
translate Spanish prieston_ask_4e1b379e:

    # pri "Hmm~?"
    pri "¿Hmm~?"

# game/script day2.rpy:3999
translate Spanish prieston_ask_e2d3e50a:

    # "Prieston's smile widened. His eyes narrowed as he looked at me, sharp yet amused, while he rested his chin comfortably on one hand."
    "La sonrisa de Prieston se ensanchó. Sus ojos se entrecerraron al mirarme, agudos pero divertidos, mientras apoyaba cómodamente la barbilla en una mano."

# game/script day2.rpy:4001
translate Spanish prieston_ask_40f573cd:

    # pri "My, my..."
    pri "Vaya, vaya..."

# game/script day2.rpy:4002
translate Spanish prieston_ask_0545cc46:

    # pri "You want to know more about me?"
    pri "¿Quieres saber más sobre mí?"

# game/script day2.rpy:4003
translate Spanish prieston_ask_c13486bc:

    # pri "I had no idea I was that mysterious in your eyes, my child."
    pri "No tenía idea de que fuera tan misterioso a tus ojos, hij[letra] mí[letra]."

# game/script day2.rpy:4005
translate Spanish prieston_ask_5d8924ba:

    # pri "The two of us, sitting here at the same table... alone... quietly enjoying each other's company.. Someone might get the wrong idea, don't you think?."
    pri "Nosotros dos, sentados aquí en la misma mesa... a solas... disfrutando tranquilamente de la compañía del otro... Alguien podría malinterpretarlo, ¿no crees?"

# game/script day2.rpy:4007
translate Spanish prieston_ask_72941cf5:

    # pri "...Though I wouldn't exactly mind if they did."
    pri "...Aunque tampoco me molestaría si lo hicieran."

# game/script day2.rpy:4009
translate Spanish prieston_ask_30c4444b:

    # "My face grew warm from his words alone... and, truthfully... he wasn't entirely wrong."
    "Mi rostro se calentó solo por sus palabras... y, a decir verdad... no andaba del todo errado."

# game/script day2.rpy:4010
translate Spanish prieston_ask_1d6c82bd:

    # "I never expected a puppet, let alone one with the role of a priest, to flirt so shamelessly."
    "Nunca esperé que un títere, y menos uno con el rol de sacerdote, coqueteara tan descaradamente."

# game/script day2.rpy:4011
translate Spanish prieston_ask_459c5ac3:

    # "...Or was I simply reading too much into it?"
    "...¿O simplemente le estaba dando demasiadas vueltas?"

# game/script day2.rpy:4013
translate Spanish prieston_ask_55613040:

    # pri "Now then... what is it you'd like to know about me, my child?"
    pri "Ahora bien... ¿qué quieres saber sobre mí, hij[letra] mí[letra]?"

# game/script day2.rpy:4014
translate Spanish prieston_ask_35b938d0:

    # mc "Just... simple things."
    mc "Solo... cosas sencillas."

# game/script day2.rpy:4015
translate Spanish prieston_ask_3dee290b:

    # mc "The other puppets told me you rarely leave your room, so I was wondering why."
    mc "Los otros títeres me dijeron que rara vez sales de tu cuarto, así que me preguntaba por qué."

# game/script day2.rpy:4016
translate Spanish prieston_ask_6a4df1e8:

    # mc "Are you an introvert?"
    mc "¿Eres introvertido?"

# game/script day2.rpy:4019
translate Spanish prieston_ask_0353c33d:

    # "Prieston paused to think for a moment."
    "Prieston se detuvo a pensar un momento."

# game/script day2.rpy:4021
translate Spanish prieston_ask_97cdebd6:

    # pri "Hm? An introvert?"
    pri "¿Hm? ¿Introvertido?"

# game/script day2.rpy:4023
translate Spanish prieston_ask_d794996d:

    # pri "I'm not sure I understand what that means, my child."
    pri "No estoy seguro de entender qué significa eso, hij[letra] mí[letra]."

# game/script day2.rpy:4024
translate Spanish prieston_ask_fa5a5bac:

    # pri "But the reason I rarely leave my room is quite simple. I just don't have much reason to go outside."
    pri "Pero la razón por la que rara vez salgo de mi cuarto es bastante simple. Simplemente no tengo muchos motivos para salir."

# game/script day2.rpy:4025
translate Spanish prieston_ask_9d7c91c0:

    # pri "I'd much rather enjoy a cup of tea in the comfort of my room."
    pri "Prefiero mucho más disfrutar una taza de té en la comodidad de mi cuarto."

# game/script day2.rpy:4026
translate Spanish prieston_ask_bba8bb8a:

    # pri "Though I'm not always in here. From time to time, I do go out to chat with the other puppets. But even that, I still not so very often I go outside."
    pri "Aunque no siempre estoy aquí dentro. De vez en cuando salgo a charlar con los otros títeres. Pero incluso eso, aun así no salgo muy a menudo."

# game/script day2.rpy:4027
translate Spanish prieston_ask_f9aff890:

    # mc "Are you close with many of the other puppets?"
    mc "¿Eres cercano a muchos de los otros títeres?"

# game/script day2.rpy:4028
translate Spanish prieston_ask_b9aa0e82:

    # pri "Not particularly. I respect them all as ordinary friends."
    pri "No particularmente. Los respeto a todos como a amigos corrientes."

# game/script day2.rpy:4029
translate Spanish prieston_ask_435bccc5:

    # pri "The one I speak with most often is Wizzy. He's naturally kind and gets along with almost everyone."
    pri "Con quien más hablo es con Wizzy. Es amable por naturaleza y se lleva bien con casi todos."

# game/script day2.rpy:4030
translate Spanish prieston_ask_f918c17c:

    # pri "So... you could say I'm not especially close to the others."
    pri "Así que... se podría decir que no soy especialmente cercano a los demás."

# game/script day2.rpy:4032
translate Spanish prieston_ask_5e639809:

    # "Then it would be difficult to learn much about him from the other puppets if even they barely knew him."
    "Entonces sería difícil enterarme de mucho sobre él por medio de los otros títeres si ni siquiera ellos lo conocían apenas."

# game/script day2.rpy:4033
translate Spanish prieston_ask_893e448f:

    # "Whether I liked it or not, I'd have to uncover the answers myself."
    "Quisiera o no, tendría que descubrir las respuestas por mi cuenta."

# game/script day2.rpy:4034
translate Spanish prieston_ask_918a4e32:

    # "Still, I didn't want it to seem like I was interrogating him."
    "Aun así, no quería que pareciera que lo estaba interrogando."

# game/script day2.rpy:4035
translate Spanish prieston_ask_9c844943:

    # "So I did my best to keep the conversation casual."
    "Así que hice lo posible por mantener la conversación informal."

# game/script day2.rpy:4037
translate Spanish prieston_ask_dc2e4eed:

    # mc "You're quite mysterious, aren't you?"
    mc "Eres bastante misterioso, ¿no?"

# game/script day2.rpy:4039
translate Spanish prieston_ask_6b2bc8ae:

    # pri "I'll take that as a compliment. Thank you very much."
    pri "Lo tomaré como un cumplido. Muchas gracias."

# game/script day2.rpy:4040
translate Spanish prieston_ask_acc2e488:

    # mc "If you spend most of your time in your room... what do you usually do in there?"
    mc "Si pasas la mayor parte del tiempo en tu cuarto... ¿qué sueles hacer allí dentro?"

# game/script day2.rpy:4042
translate Spanish prieston_ask_601b6c65:

    # pri "Not much."
    pri "No mucho."

# game/script day2.rpy:4043
translate Spanish prieston_ask_c1bfabb5:

    # pri "I drink tea... read books, write, tidy my room, knit...That's about it, I suppose. I'd be lying if I said there was much for me to do in my room."
    pri "Tomo té... leo libros, escribo, ordeno mi cuarto, tejo... Eso es más o menos todo, supongo. Mentiría si dijera que hay mucho que hacer en mi cuarto."

# game/script day2.rpy:4044
translate Spanish prieston_ask_98d6d2a1:

    # pri "The truth is... there really isn't."
    pri "La verdad es que... realmente no lo hay."

# game/script day2.rpy:4046
translate Spanish prieston_ask_a4cdb3e9:

    # "It was almost amusing. Of all the puppets I'd spoken to, most of them spent their days reading, writing, or drinking tea."
    "Era casi gracioso. De todos los títeres con los que había hablado, la mayoría pasaba los días leyendo, escribiendo o tomando té."

# game/script day2.rpy:4047
translate Spanish prieston_ask_b3c1cd03:

    # "It seemed there really wasn't much else for them to do huh? But that makes sense."
    "Parecía que realmente no había mucho más que hacer, ¿eh? Pero tiene sentido."

# game/script day2.rpy:4048
translate Spanish prieston_ask_74da5266:

    # "Lost in thought, I suddenly realized that Prieston hadn't looked away from me even once."
    "Perdid[letra] en mis pensamientos, de repente me di cuenta de que Prieston no había apartado la mirada de mí ni una sola vez."

# game/script day2.rpy:4051
translate Spanish prieston_ask_688a3f1b:

    # pri "You know, my child..."
    pri "Sabes, hij[letra] mí[letra]..."

# game/script day2.rpy:4052
translate Spanish prieston_ask_7bfecdb0:

    # pri "There isn't much for me to do in my room."
    pri "No hay mucho que hacer en mi cuarto."

# game/script day2.rpy:4053
translate Spanish prieston_ask_59b96ad4:

    # pri "But now that you're here..."
    pri "Pero ahora que estás aquí..."

# game/script day2.rpy:4055
translate Spanish prieston_ask_ff940f6f:

    # pri "Perhaps you could become my new pastime."
    pri "Quizás podrías convertirte en mi nuevo pasatiempo."

# game/script day2.rpy:4057
translate Spanish prieston_ask_2054e561:

    # "His words were so ambiguous that I couldn't help but feel a flutter of anticipation."
    "Sus palabras eran tan ambiguas que no pude evitar sentir un aleteo de expectación."

# game/script day2.rpy:4059
translate Spanish prieston_ask_41572e4f:

    # mc "W-What do you mean...?"
    mc "¿Q-Qué quieres decir...?"

# game/script day2.rpy:4063
translate Spanish prieston_ask_cc51f778:

    # pri "What i mean is... we should talk more often, Your Majesty."
    pri "Lo que quiero decir es... que deberíamos hablar más a menudo, Su Majestad."

# game/script day2.rpy:4064
translate Spanish prieston_ask_e8c2483e:

    # pri "You're the [title] of this kingdom now. And as its [title], it's only natural that you should know how your subjects are doing, wouldn't you agree?"
    pri "Ahora eres [arti] [title!t] de este reino. Y como tal, es natural que sepas cómo están tus súbditos, ¿no estás de acuerdo?"

# game/script day2.rpy:4066
translate Spanish prieston_ask_f8184343:

    # pri "I'm no exception."
    pri "No soy la excepción."

# game/script day2.rpy:4068
translate Spanish prieston_ask_8d683880:

    # pri "Still... it hardly seems fair if you're the only one who knows about me... and how I'm doing."
    pri "Aun así... no parece justo que seas [arti] únic[letra] que sabe de mí... y de cómo estoy."

# game/script day2.rpy:4069
translate Spanish prieston_ask_c01fcdd8:

    # pri "So, as one of your subjects... I'd like the chance to get to know you as well."
    pri "Así que, como uno de tus súbditos... me gustaría tener la oportunidad de conocerte a ti también."

# game/script day2.rpy:4072
translate Spanish prieston_ask_9e467919:

    # voice "PRIESTON05_DAY2.ogg"
    # pri "After all, it's my duty to understand every part of you... your thoughts, your worries, your desires. I'll listen to every word without judgment."
    voice "PRIESTON05_DAY2.ogg"
    pri "Después de todo, es mi deber comprender cada parte de ti... tus pensamientos, tus preocupaciones, tus deseos. Escucharé cada palabra sin juzgar."

# game/script day2.rpy:4075
translate Spanish prieston_ask_23e8fb7f:

    # pri "Guiding those who've lost their way is what I was made to do."
    pri "Guiar a quienes han perdido el camino es para lo que fui hecho."

# game/script day2.rpy:4076
translate Spanish prieston_ask_adccdb22:

    # pri "So... if you ever wish to talk about anything... Come to me. Knock on my door... and I'll always open it for you."
    pri "Así que... si alguna vez deseas hablar de cualquier cosa... Ven a mí. Llama a mi puerta... y siempre te la abriré."

# game/script day2.rpy:4078
translate Spanish prieston_ask_d6c50e71:

    # "Prieston's voice grew lower with each word. Hypnotic, inviting... almost seductive enough to make it difficult to refuse."
    "La voz de Prieston se hacía más grave con cada palabra. Hipnótica, seductora... casi lo bastante como para hacer difícil negarse."

# game/script day2.rpy:4079
translate Spanish prieston_ask_944de0e9:

    # "...But if this was the only way to truly understand how Prieston thought... then I didn't mind at all."
    "...Pero si esta era la única manera de comprender de verdad cómo pensaba Prieston... entonces no me importaba en absoluto."

# game/script day2.rpy:4088
translate Spanish prieston_convo2_218ca5c9:

    # "Suddenly... my eyelids began to feel heavy."
    "De repente... mis párpados empezaron a sentirse pesados."

# game/script day2.rpy:4090
translate Spanish prieston_convo2_cadde1f7:

    # pri "Ah... it seems you're getting sleepy, my child."
    pri "Ah... parece que te está dando sueño, hij[letra] mí[letra]."

# game/script day2.rpy:4091
translate Spanish prieston_convo2_a8c47ef2:

    # pri "That's only natural after everything you've been through. You need to regain your strength."
    pri "Es natural después de todo lo que has pasado. Necesitas recuperar fuerzas."

# game/script day2.rpy:4095
translate Spanish prieston_convo2_aee6fc62:

    # "Prieston rose from his chair and walked over to me."
    "Prieston se levantó de su silla y caminó hacia mí."

# game/script day2.rpy:4097
translate Spanish prieston_convo2_525d91cb:

    # pri "Excuse me."
    pri "Con permiso."

# game/script day2.rpy:4100
translate Spanish prieston_convo2_b0774f44:

    # "He gently scooped me into his arms once again and laid me down on his bed."
    "Con delicadeza volvió a tomarme en brazos y me acostó en su cama."

# game/script day2.rpy:4102
translate Spanish prieston_convo2_30c005cd:

    # "The mattress was soft and comfortable. It felt like I could fall asleep at any moment."
    "El colchón era suave y cómodo. Se sentía como si pudiera quedarme dormid[letra] en cualquier momento."

# game/script day2.rpy:4104
translate Spanish prieston_convo2_ac6e37eb:

    # pri "Hmm... How about I tell you a fairytale, my child?"
    pri "Hmm... ¿Qué tal si te cuento un cuento de hadas, hij[letra] mí[letra]?"

# game/script day2.rpy:4106
translate Spanish prieston_convo2_07bdde05:

    # "....."
    "....."

# game/script day2.rpy:4108
translate Spanish prieston_convo2_bf26d63a:

    # mc "That... sounds nice."
    mc "Eso... suena bien."

# game/script day2.rpy:4110
translate Spanish prieston_convo2_9b3f63d9:

    # "He walked back to the table and removed his scarf before returning to the bed."
    "Regresó a la mesa y se quitó la bufanda antes de volver a la cama."

# game/script day2.rpy:4112
translate Spanish prieston_convo2_b166eb98:

    # "The last thing I expected was for Prieston to suddenly lie down beside me."
    "Lo último que esperaba era que Prieston se tumbara de pronto a mi lado."

# game/script day2.rpy:4113
translate Spanish prieston_convo2_5e6c7152:

    # "He turned to face me, propping his head up with one hand as he looked at me."
    "Se volvió para mirarme, apoyando la cabeza en una mano mientras me observaba."

# game/script day2.rpy:4114
translate Spanish prieston_convo2_8d8131a6:

    # "His left hand rested against my back, giving it slow, gentle pats as if trying to lull me to sleep."
    "Su mano izquierda descansaba sobre mi espalda, dándome palmaditas lentas y suaves como si intentara arrullarme."

# game/script day2.rpy:4115
translate Spanish prieston_convo2_b418d34e:

    # "A normal person would probably be startled or even frightened if someone they'd only met a few minutes ago suddenly lay down beside them and gently patted their back."
    "Una persona normal probablemente se sobresaltaría o incluso se asustaría si alguien a quien acaba de conocer hace unos minutos se acostara de repente a su lado y le diera palmaditas suaves en la espalda."

# game/script day2.rpy:4116
translate Spanish prieston_convo2_0dbd33b7:

    # "But I think I was far too sleepy to feel any of that. This time, my exhaustion and drowsiness had truly won."
    "Pero creo que yo tenía demasiado sueño como para sentir nada de eso. Esta vez, mi agotamiento y mi somnolencia habían ganado de verdad."

# game/script day2.rpy:4119
translate Spanish prieston_convo2_4ea9844c:

    # pri "Do you like animals, my child?"
    pri "¿Te gustan los animales, hij[letra] mí[letra]?"

# game/script day2.rpy:4120
translate Spanish prieston_convo2_8a229cf6:

    # mc "I think so..."
    mc "Creo que sí..."

# game/script day2.rpy:4121
translate Spanish prieston_convo2_830fe93d:

    # pri "Then perhaps you'll enjoy this fairy tale."
    pri "Entonces quizás disfrutes de este cuento de hadas."

# game/script day2.rpy:4124
translate Spanish prieston_convo2_2e6f8315:

    # pri "Back when this kingdom was still alive, we puppets would often tell this story to the children."
    pri "Cuando este reino aún estaba vivo, los títeres solíamos contar esta historia a los niños."

# game/script day2.rpy:4125
translate Spanish prieston_convo2_5a68cb6a:

    # mc "...Children used to come here too?"
    mc "...¿También venían niños aquí?"

# game/script day2.rpy:4127
translate Spanish prieston_convo2_18e94c3c:

    # pri "They did. Though they had their own sessions, of course. The stories we told the adults would have been far too difficult for children to understand."
    pri "Sí venían. Aunque tenían sus propias funciones, por supuesto. Las historias que contábamos a los adultos habrían sido demasiado difíciles de entender para los niños."

# game/script day2.rpy:4128
translate Spanish prieston_convo2_24b3479f:

    # pri "So, from time to time, we'd tell them fairy tales about animals instead."
    pri "Así que, de vez en cuando, les contábamos cuentos de hadas sobre animales."

# game/script day2.rpy:4130
translate Spanish prieston_convo2_38547093:

    # "I couldn't help but wonder what the Kingdom of Marionettes had been like back when it was still full of life."
    "No podía evitar preguntarme cómo habría sido el Reino de las Marionetas cuando aún estaba lleno de vida."

# game/script day2.rpy:4133
translate Spanish prieston_convo2_607888a5:

    # pri "Close your eyes, my child. I'll begin the story."
    pri "Cierra los ojos, hij[letra] mí[letra]. Comenzaré el cuento."

# game/script day2.rpy:4137
translate Spanish prieston_convo2_953e3fcb:

    # "I followed his instruction and closed my eyes."
    "Seguí su indicación y cerré los ojos."

# game/script day2.rpy:4138
translate Spanish prieston_convo2_278c7e29:

    # "........."
    "........."

# game/script day2.rpy:4140
translate Spanish prieston_convo2_e3a50677:

    # pri "Feeling comfortable?"
    pri "¿Te sientes cómod[letra]?"

# game/script day2.rpy:4141
translate Spanish prieston_convo2_577f33b3:

    # mc "Mmm..."
    mc "Mmm..."

# game/script day2.rpy:4142
translate Spanish prieston_convo2_253407bc:

    # voice "PRIESTON06_DAY2.ogg"
    # pri "Now... I want you to imagine something for me. Can you do that, my child?"
    voice "PRIESTON06_DAY2.ogg"
    pri "Ahora... quiero que imagines algo por mí. ¿Puedes hacerlo, hij[letra] mí[letra]?"

# game/script day2.rpy:4144
translate Spanish prieston_convo2_38a8c528:

    # mc "Yes...."
    mc "Sí...."

# game/script day2.rpy:4145
translate Spanish prieston_convo2_5050a262:

    # pri "Good..."
    pri "Bien..."

# game/script day2.rpy:4146
translate Spanish prieston_convo2_8b053ff4:

    # pri "Now picture a forest."
    pri "Ahora imagina un bosque."

# game/script day2.rpy:4149
translate Spanish prieston_convo2_d9d98480:

    # pri "A vast, beautiful forest... lush and green, with trees stretching high above your head."
    pri "Un bosque vasto y hermoso... exuberante y verde, con árboles que se elevan muy por encima de tu cabeza."

# game/script day2.rpy:4150
translate Spanish prieston_convo2_ce6bd4fd:

    # pri "Can you see it?"
    pri "¿Puedes verlo?"

# game/script day2.rpy:4151
translate Spanish prieston_convo2_f800bed0:

    # mc "Yes."
    mc "Sí."

# game/script day2.rpy:4152
translate Spanish prieston_convo2_5050a262_1:

    # pri "Good..."
    pri "Bien..."

# game/script day2.rpy:4153
translate Spanish prieston_convo2_15be912f:

    # pri "Now... listen carefully. What do you think you'd find in a forest like that?"
    pri "Ahora... escucha con atención. ¿Qué crees que encontrarías en un bosque así?"

# game/script day2.rpy:4154
translate Spanish prieston_convo2_b5f96762:

    # mc "mmmm...."
    mc "mmmm...."

# game/script day2.rpy:4156
translate Spanish prieston_convo2_10d75ae8:

    # pri "Perhaps a dog?"
    pri "¿Quizás un perro?"

# game/script day2.rpy:4158
translate Spanish prieston_convo2_7a30cedf:

    # pri "Owl?"
    pri "¿Un búho?"

# game/script day2.rpy:4160
translate Spanish prieston_convo2_a5bcdff2:

    # pri "Snake?"
    pri "¿Una serpiente?"

# game/script day2.rpy:4163
translate Spanish prieston_convo2_ae010993:

    # pri "Or... elephants, squirrels and other animals?"
    pri "¿O... elefantes, ardillas y otros animales?"

# game/script day2.rpy:4164
translate Spanish prieston_convo2_3a78065c:

    # pri "So many little creatures, each living their own quiet lives."
    pri "Tantas criaturitas, cada una viviendo su propia vida tranquila."

# game/script day2.rpy:4165
translate Spanish prieston_convo2_4e841af0:

    # pri "Can you picture them, my child?"
    pri "¿Puedes imaginarlas, hij[letra] mí[letra]?"

# game/script day2.rpy:4166
translate Spanish prieston_convo2_6caabb53:

    # mc "I can."
    mc "Puedo."

# game/script day2.rpy:4167
translate Spanish prieston_convo2_6e5616ae:

    # pri "Wonderful."
    pri "Maravilloso."

# game/script day2.rpy:4168
translate Spanish prieston_convo2_be26dc56:

    # pri "Now... let us turn our attention to two creatures in particular. First... a lion."
    pri "Ahora... centremos nuestra atención en dos criaturas en particular. Primero... un león."

# game/script day2.rpy:4169
translate Spanish prieston_convo2_07d86206:

    # pri "Strong. Proud. A creature that commands attention simply by entering the room."
    pri "Fuerte. Orgulloso. Una criatura que atrae la atención con solo entrar en la habitación."

# game/script day2.rpy:4171
translate Spanish prieston_convo2_dcddfb20:

    # pri "Ah, yes. And the lion has pink fur."
    pri "Ah, sí. Y el león tiene pelaje rosa."

# game/script day2.rpy:4172
translate Spanish prieston_convo2_f6834970:

    # mc "How absurd..."
    mc "Qué absurdo..."

# game/script day2.rpy:4173
translate Spanish prieston_convo2_3d340e05:

    # pri "But adorable, yes?"
    pri "Pero adorable, ¿verdad?"

# game/script day2.rpy:4174
translate Spanish prieston_convo2_69c25b65:

    # mc "Yeah..."
    mc "Sí..."

# game/script day2.rpy:4176
translate Spanish prieston_convo2_567b38c1:

    # pri "And beside him... A little rabbit. Small... gentle... seemingly harmless."
    pri "Y a su lado... Un pequeño conejo. Pequeño... gentil... aparentemente inofensivo."

# game/script day2.rpy:4177
translate Spanish prieston_convo2_e69619ca:

    # pri "Can you see them?"
    pri "¿Puedes verlos?"

# game/script day2.rpy:4178
translate Spanish prieston_convo2_84d9991b:

    # mc "Yes..."
    mc "Sí..."

# game/script day2.rpy:4179
translate Spanish prieston_convo2_4a4a380f:

    # pri "Good."
    pri "Bien."

# game/script day2.rpy:4188
translate Spanish prieston_convo2_944cbd76:

    # pri "Now, my child... I want you to imagine something amazing. That lion... is wearing a crown."
    pri "Ahora, hij[letra] mí[letra]... quiero que imagines algo asombroso. Ese león... lleva una corona."

# game/script day2.rpy:4189
translate Spanish prieston_convo2_aea4cff7:

    # mc "Hehe... that's cool."
    mc "Jeje... eso es genial."

# game/script day2.rpy:4190
translate Spanish prieston_convo2_977f2c3b:

    # pri "Isn't it?"
    pri "¿Verdad que sí?"

# game/script day2.rpy:4192
translate Spanish prieston_convo2_d5459cfc:

    # pri "Now, let us begin our tale."
    pri "Ahora, comencemos nuestro cuento."

# game/script day2.rpy:4195
translate Spanish prieston_convo2_7397d14b:

    # pri "Once upon a time, deep within a lush forest... there lived a great many animals."
    pri "Érase una vez, en lo profundo de un bosque exuberante... una gran cantidad de animales."

# game/script day2.rpy:4201
translate Spanish prieston_convo2_bbd7eb1c:

    # pri "There were dogs, owls, lions, snakes, and countless other creatures."
    pri "Había perros, búhos, leones, serpientes y muchas otras criaturas."

# game/script day2.rpy:4203
translate Spanish prieston_convo2_a6d90184:

    # pri "And they were all ruled by one mighty king... the Lion King."
    pri "Y todos eran gobernados por un poderoso rey... el Rey León."

# game/script day2.rpy:4206
translate Spanish prieston_convo2_44a33b9e:

    # pri "Under the Lion King's reign, the animals of the forest lived prosperous lives, never wanting for food."
    pri "Bajo el reinado del Rey León, los animales del bosque vivían vidas prósperas, sin carecer jamás de alimento."

# game/script day2.rpy:4207
translate Spanish prieston_convo2_1543d9fc:

    # pri "The Lion King was dearly loved by his subjects, for he always wished to give them the best life he could."
    pri "El Rey León era muy querido por sus súbditos, pues siempre deseaba darles la mejor vida posible."

# game/script day2.rpy:4208
translate Spanish prieston_convo2_a9449886:

    # pri "Every animal in the forest was happy."
    pri "Todos los animales del bosque eran felices."

# game/script day2.rpy:4216
translate Spanish prieston_convo2_e2535a9d:

    # pri "One day, the time came for the forest's annual feast."
    pri "Un día llegó el momento del banquete anual del bosque."

# game/script day2.rpy:4217
translate Spanish prieston_convo2_aeb88f87:

    # pri "Unfortunately, the feast was always the same year after year. The menu never changed."
    pri "Por desgracia, el banquete era siempre el mismo año tras año. El menú nunca cambiaba."

# game/script day2.rpy:4220
translate Spanish prieston_convo2_b799845e:

    # pri "The rabbit believed their food could be even better than it already was."
    pri "El Conejo creía que su comida podía ser aún mejor de lo que ya era."

# game/script day2.rpy:4222
translate Spanish prieston_convo2_ddb52e2d:

    # pri "And... he found a way to make that happen. At least, he believed it was a brilliant idea."
    pri "Y... encontró una manera de lograrlo. Al menos, creía que era una idea brillante."

# game/script day2.rpy:4223
translate Spanish prieston_convo2_4319b9ae:

    # pri "So the Rabbit brought his brilliant idea before the Lion King."
    pri "Así que el Conejo llevó su brillante idea ante el Rey León."

# game/script day2.rpy:4227
translate Spanish prieston_convo2_41ed6ee3:

    # pri "'Your Majesty! I know how we can have a brand-new feast this year!' the Rabbit exclaimed."
    pri "'¡Su Majestad! ¡Sé cómo podemos tener un banquete totalmente nuevo este año!', exclamó el Conejo."

# game/script day2.rpy:4230
translate Spanish prieston_convo2_612b0891:

    # pri "But sadly, the Lion King refused. He dismissed the Rabbit's idea as foolish, insisting that the food they already had was more than enough."
    pri "Pero, por desgracia, el Rey León se negó. Descartó la idea del Conejo por necia, insistiendo en que la comida que ya tenían era más que suficiente."

# game/script day2.rpy:4231
translate Spanish prieston_convo2_06b4888e:

    # pri "'This year's feast will remain exactly as it is. There will be no changes. I will not entertain such a ridiculous idea,' said the Lion King."
    pri "'El banquete de este año seguirá exactamente igual. No habrá cambios. No pienso entretener una idea tan ridícula', dijo el Rey León."

# game/script day2.rpy:4232
translate Spanish prieston_convo2_5b6569b0:

    # pri "But the Rabbit continued to plead with the Lion King, insisting that every animal in the forest deserved better food."
    pri "Pero el Conejo siguió suplicándole al Rey León, insistiendo en que todos los animales del bosque merecían mejor comida."

# game/script day2.rpy:4233
translate Spanish prieston_convo2_81839d6f:

    # pri "Unfortunately... the Lion King still refused."
    pri "Por desgracia... el Rey León volvió a negarse."

# game/script day2.rpy:4236
translate Spanish prieston_convo2_3031b0f9:

    # pri "As time went on, the Rabbit's frustration slowly turned into anger. But he had another idea."
    pri "Con el paso del tiempo, la frustración del Conejo se fue convirtiendo poco a poco en ira. Pero tenía otra idea."

# game/script day2.rpy:4237
translate Spanish prieston_convo2_a4e57ef1:

    # pri "Since he had failed to convince the Lion King, he decided to present his idea to the animals of the forest instead."
    pri "Como no había logrado convencer al Rey León, decidió presentar su idea a los animales del bosque."

# game/script day2.rpy:4239
translate Spanish prieston_convo2_01a91411:

    # pri "'If I cannot convince the Lion King, then I shall convince the animals of the forest,' said the Rabbit."
    pri "'Si no puedo convencer al Rey León, entonces convenceré a los animales del bosque', dijo el Conejo."

# game/script day2.rpy:4245
translate Spanish prieston_convo2_d2e69cbb:

    # pri "And just as he had expected, the entire forest was amazed when the rabbit served a new kind of food. A meal unlike anything they had ever tasted before."
    pri "Y tal como había esperado, todo el bosque quedó asombrado cuando el conejo sirvió un nuevo tipo de comida. Una comida distinta a todo lo que habían probado antes."

# game/script day2.rpy:4249
translate Spanish prieston_convo2_45788162:

    # pri "Some called him a genius. Others hailed him as a savior. And one by one... the animals began to follow the Rabbit."
    pri "Algunos lo llamaron genio. Otros lo aclamaron como salvador. Y uno por uno... los animales comenzaron a seguir al Conejo."

# game/script day2.rpy:4251
translate Spanish prieston_convo2_53e2fff7:

    # pri "When the Lion King heard what had happened, he was furious. He warned the animals that this was not food they should be eating."
    pri "Cuando el Rey León se enteró de lo sucedido, se puso furioso. Advirtió a los animales que esa no era comida que debieran comer."

# game/script day2.rpy:4253
translate Spanish prieston_convo2_38a47478:

    # pri "'Stop! This isn't food we're meant to eat! This is wrong!' the Lion King cried out to his subjects."
    pri "'¡Alto! ¡Esta no es comida que debamos comer! ¡Esto está mal!', clamó el Rey León a sus súbditos."

# game/script day2.rpy:4254
translate Spanish prieston_convo2_0e219159:

    # pri "But sadly, the Lion King failed to convince them. Instead, the Rabbit turned the blame back on the king in front of everyone."
    pri "Pero, por desgracia, el Rey León no logró convencerlos. En cambio, el Conejo le devolvió la culpa al rey frente a todos."

# game/script day2.rpy:4255
translate Spanish prieston_convo2_2e18d2a6:

    # pri "'The Lion King doesn't want us to have better food! He has never truly cared about any of us! That's why he rejected my plan!'"
    pri "'¡El Rey León no quiere que tengamos mejor comida! ¡Nunca se ha preocupado de verdad por ninguno de nosotros! ¡Por eso rechazó mi plan!'"

# game/script day2.rpy:4256
translate Spanish prieston_convo2_e40c7623:

    # pri "'Listen to me, everyone! I only want us to have better food than what we've always had! Isn't that what all of you want too? Aren't you tired of eating the same thing over and over again? So what's wrong with wanting something better?' the Rabbit declared."
    pri "'¡Escúchenme, todos! ¡Yo solo quiero que tengamos mejor comida que la de siempre! ¿No es eso lo que todos ustedes también quieren? ¿No están cansados de comer lo mismo una y otra vez? Entonces, ¿qué tiene de malo desear algo mejor?', declaró el Conejo."

# game/script day2.rpy:4257
translate Spanish prieston_convo2_e3f53cb4:

    # pri "THE LION KING IS THE TRAITOR!"
    pri "¡EL REY LEÓN ES EL TRAIDOR!"

# game/script day2.rpy:4261
translate Spanish prieston_convo2_af827810:

    # pri "At that very moment... every pair of eyes in the kingdom turned toward the king with cold, accusing stares."
    pri "En ese mismo instante... todos los ojos del reino se volvieron hacia el rey con miradas frías y acusadoras."

# game/script day2.rpy:4263
translate Spanish prieston_convo2_9a91b543:

    # pri "In the end, the people denounced the king and overthrew him... casting him down from his throne."
    pri "Al final, el pueblo denunció al rey y lo derrocó... arrojándolo de su trono."

# game/script day2.rpy:4264
translate Spanish prieston_convo2_c3d18526:

    # pri "And in his place, they crowned the Rabbit... as their new Lion King."
    pri "Y en su lugar, coronaron al Conejo... como su nuevo Rey León."

# game/script day2.rpy:4265
translate Spanish prieston_convo2_defaf5b5:

    # pri "As for the former Lion King?... he became the new Lion King's toy."
    pri "¿Y el antiguo Rey León?... se convirtió en el juguete del nuevo Rey León."

# game/script day2.rpy:4268
translate Spanish prieston_convo2_b65370a2:

    # pri "What a tragic fate for the poor former Lion King..."
    pri "Qué trágico destino el del pobre antiguo Rey León..."

# game/script day2.rpy:4271
translate Spanish prieston_convo2_d1ddaffa:

    # "........"
    "........"

# game/script day2.rpy:4273
translate Spanish prieston_convo2_f1197f89:

    # pri "...It seems you've fallen asleep, my child. I'm glad this story was able to lull you to sleep."
    pri "...Parece que te has dormido, hij[letra] mí[letra]. Me alegra que este cuento haya logrado arrullarte."

# game/script day2.rpy:4275
translate Spanish prieston_convo2_fb15f26f:

    # "He let out a soft chuckle."
    "Soltó una risita suave."

# game/script day2.rpy:4277
translate Spanish prieston_convo2_b2647da2:

    # pri "Hmm~... I do wonder what your answer will be..."
    pri "Hmm~... Me pregunto cuál será tu respuesta..."

# game/script day2.rpy:4278
translate Spanish prieston_convo2_cc146187:

    # pri "Who was truly in the wrong... and who was in the right?"
    pri "¿Quién estaba realmente equivocado... y quién tenía la razón?"

# game/script day2.rpy:4279
translate Spanish prieston_convo2_2036f590:

    # pri "The Lion... or the Rabbit..."
    pri "El León... o el Conejo..."

# game/script day2.rpy:4280
translate Spanish prieston_convo2_f9b57a22:

    # pri "My child... as you can see, in the end... everyone has their own desires."
    pri "Hij[letra] mí[letra]... como puedes ver, al final... todos tienen sus propios deseos."

# game/script day2.rpy:4281
translate Spanish prieston_convo2_b4e0b88c:

    # pri "But now... you are our [title]."
    pri "Pero ahora... tú eres nuestr[letra] [title!t]."

# game/script day2.rpy:4282
translate Spanish prieston_convo2_594acf5d:

    # pri "The future of us all rests in your hands."
    pri "El futuro de todos nosotros descansa en tus manos."

# game/script day2.rpy:4283
translate Spanish prieston_convo2_96a1a4c8:

    # pri "Such a powerful little thing... All that power rests within your tiny hands."
    pri "Qué cosita tan poderosa... Todo ese poder descansa en tus diminutas manos."

# game/script day2.rpy:4284
translate Spanish prieston_convo2_9bff5c1e:

    # pri "The choice is yours. And I will guide you whenever you need me."
    pri "La elección es tuya. Y yo te guiaré cuando me necesites."

# game/script day2.rpy:4285
translate Spanish prieston_convo2_89ca1f69:

    # pri "And I look forward to seeing how your story ends..."
    pri "Y espero con ansias ver cómo termina tu historia..."

# game/script day2.rpy:4287
translate Spanish prieston_convo2_d1ddaffa_1:

    # "........"
    "........"

# game/script day2.rpy:4288
translate Spanish prieston_convo2_8b8ceb72:

    # "............"
    "............"

# game/script day2.rpy:4293
translate Spanish prieston_convo2_c999ce88:

    # pri "........."
    pri "........."

# game/script day2.rpy:4295
translate Spanish prieston_convo2_81a087b6:

    # pri "So... you've finally arrived, Jestyn."
    pri "Así que... por fin has llegado, Jestyn."

# game/script day2.rpy:4300
translate Spanish prieston_convo2_766d3889:

    # "Jestyn glared at Prieston, his eyes burning with anger. Especially when he saw the [player_call] lying beside him."
    "Jestyn miró a Prieston con furia, los ojos ardiendo de ira. Especialmente al ver a [player_call] acostad[letra] a su lado."

# game/script day2.rpy:4301
translate Spanish prieston_convo2_436e13f5:

    # "Jealousy and rage were written all over his face."
    "Los celos y la rabia estaban escritos por todo su rostro."

# game/script day2.rpy:4303
translate Spanish prieston_convo2_a6abf371:

    # jes "Prieston."
    jes "Prieston."

# game/script day2.rpy:4304
translate Spanish prieston_convo2_7001e6a9:

    # jes "What did you do to [player_call]...?"
    jes "¿Qué le hiciste a [player_call]...?"

# game/script day2.rpy:4308
translate Spanish prieston_convo2_aa5fb6d5:

    # "Prieston answered Jestyn's murderous glare with nothing more than a smile."
    "Prieston respondió a la mirada asesina de Jestyn con nada más que una sonrisa."

# game/script day2.rpy:4309
translate Spanish prieston_convo2_4d669c65:

    # "He then rose from the bed and carefully lifted the MC into his arms."
    "Luego se levantó de la cama y alzó con cuidado a [player_call] en brazos."

# game/script day2.rpy:4310
translate Spanish prieston_convo2_8a1894b7:

    # "After that, Prieston walked over to Jestyn."
    "Después, Prieston caminó hacia Jestyn."

# game/script day2.rpy:4313
translate Spanish prieston_convo2_566f8b43:

    # pri "I didn't do anything. I simply let [player_call] rest. [subj] nearly died after being eaten by Butley and other puppets."
    pri "No hice nada. Solo dejé que [player_call] descansara. [subj!c!t] casi muere tras ser devorad[letra] por Butley y los otros títeres."

# game/script day2.rpy:4316
translate Spanish prieston_convo2_4353e0de:

    # "Jestyn's eyes widened as he clenched his teeth."
    "Los ojos de Jestyn se abrieron de par en par mientras apretaba los dientes."

# game/script day2.rpy:4319
translate Spanish prieston_convo2_d0443dc8:

    # pri "Everything is alright now."
    pri "Ahora todo está bien."

# game/script day2.rpy:4321
translate Spanish prieston_convo2_eba46258:

    # "Prieston gently handed [player_call] over to Jestyn."
    "Prieston entregó con delicadeza a [player_call] a Jestyn."

# game/script day2.rpy:4323
translate Spanish prieston_convo2_989936cf:

    # pri "I have a feeling things will only become more complicated from here."
    pri "Tengo la sensación de que las cosas solo se complicarán más a partir de aquí."

# game/script day2.rpy:4325
translate Spanish prieston_convo2_e61be94a:

    # pri "So, take good care of our Majesty, Jestyn."
    pri "Así que cuida bien de nuestra Majestad, Jestyn."

# game/script day2.rpy:4328
translate Spanish prieston_convo2_9d01e73f:

    # "Holding the MC tightly in his arms, Jestyn quietly walked out of Prieston's room."
    "Sosteniendo con fuerza a [player_call] en sus brazos, Jestyn salió en silencio del cuarto de Prieston."

# game/script day2.rpy:4331
translate Spanish prieston_convo2_5a329a41:

    # "Just as he reached the door, Jestyn suddenly came to a stop."
    "Justo al llegar a la puerta, Jestyn se detuvo de repente."

# game/script day2.rpy:4334
translate Spanish prieston_convo2_a6abf371_1:

    # jes "Prieston."
    jes "Prieston."

# game/script day2.rpy:4335
translate Spanish prieston_convo2_4e73e41c:

    # jes "I'm grateful that you saved Your Majesty."
    jes "Te agradezco que hayas salvado a Su Majestad."

# game/script day2.rpy:4336
translate Spanish prieston_convo2_938ef16f:

    # jes "But..."
    jes "Pero..."

# game/script day2.rpy:4339
translate Spanish prieston_convo2_24790083:

    # "Jestyn turned back, fixing Prieston with a grave stare."
    "Jestyn se volvió, fijando en Prieston una mirada grave."

# game/script day2.rpy:4341
translate Spanish prieston_convo2_7924934d:

    # jes "That doesn't mean I trust you."
    jes "Eso no significa que confíe en ti."

# game/script day2.rpy:4345
translate Spanish prieston_convo2_efe5ab9f:

    # "Prieston answered both Jestyn's suspicious gaze and his words with nothing more than a relaxed chuckle."
    "Prieston respondió tanto a la mirada suspicaz de Jestyn como a sus palabras con nada más que una risita relajada."

# game/script day2.rpy:4347
translate Spanish prieston_convo2_dadb4597:

    # pri "Of course, Jestyn."
    pri "Por supuesto, Jestyn."

# game/script day2.rpy:4349
translate Spanish prieston_convo2_b46642e1:

    # pri "You're free to be as suspicious of me as you like. I don't mind."
    pri "Eres libre de sospechar de mí todo lo que quieras. No me importa."

# game/script day2.rpy:4351
translate Spanish prieston_convo2_ff630ee8:

    # pri "Until we meet again."
    pri "Hasta que nos veamos de nuevo."

# game/script day2.rpy:4357
translate Spanish prieston_convo2_3928a113:

    # "......."
    "......."

# game/script day2.rpy:4358
translate Spanish prieston_convo2_d1ddaffa_2:

    # "........"
    "........"

# game/script day2.rpy:4360
translate Spanish prieston_convo2_88056451:

    # jes "......"
    jes "......"

# game/script day2.rpy:4362
translate Spanish prieston_convo2_3fcbc55b:

    # jes "...Here you go...."
    jes "...Aquí tiene...."

# game/script day2.rpy:4363
translate Spanish prieston_convo2_7b222940:

    # jes "You're safe here..."
    jes "Está a salvo aquí..."

# game/script day2.rpy:4364
translate Spanish prieston_convo2_ac52f839:

    # jes "In my room..."
    jes "En mi cuarto..."

# game/script day2.rpy:4365
translate Spanish prieston_convo2_3f2af826:

    # jes "....."
    jes "....."

# game/script day2.rpy:4367
translate Spanish prieston_convo2_605dfe52:

    # jes "...I'm sorry, Your Majesty... I'm sorry."
    jes "...Lo siento, Su Majestad... lo siento."

# game/script day2.rpy:4368
translate Spanish prieston_convo2_c657b663:

    # jes "I should never have left you alone... I should've ignored you and kept being the brat I always am..."
    jes "Nunca debí haberle dejado sol[letra]... Debí haberle ignorado y haber seguido siendo el malcriado que siempre soy..."

# game/script day2.rpy:4370
translate Spanish prieston_convo2_6f0b3060:

    # voice "JESTYN07_DAY2.ogg"
    # jes "Just imagining them devouring you... pant... your lifeless body lying there... nothing left but your frozen shell, as cold as the Arctic ice... I... pant... I can't... pant..."
    voice "JESTYN07_DAY2.ogg"
    jes "Solo de imaginarlos devorándole... jadeo... su cuerpo sin vida tendido ahí... sin nada más que su cascarón helado, tan frío como el hielo del Ártico... Yo... jadeo... no puedo... jadeo..."

# game/script day2.rpy:4373
translate Spanish prieston_convo2_7ea0a8b4:

    # jes "I won't make the same mistake again."
    jes "No cometeré el mismo error otra vez."

# game/script day2.rpy:4374
translate Spanish prieston_convo2_8d774a09:

    # jes "...I... just didn't want you to be frightened... and leave..."
    jes "...Yo... solo no quería que se asustara... y se fuera..."

# game/script day2.rpy:4375
translate Spanish prieston_convo2_276b825c:

    # jes ".....I do not want you to know more than what you should have know..."
    jes ".....No quiero que sepa más de lo que debería saber..."

# game/script day2.rpy:4376
translate Spanish prieston_convo2_2dee00c9:

    # jes "I didn't know how I was supposed to tell you..."
    jes "No sabía cómo se suponía que debía decírselo..."

# game/script day2.rpy:4377
translate Spanish prieston_convo2_00b24481:

    # jes "I......"
    jes "Yo......"

# game/script day2.rpy:4378
translate Spanish prieston_convo2_50611cc0:

    # jes "......."
    jes "......."

# game/script day2.rpy:4380
translate Spanish prieston_convo2_4d4b8eda:

    # jes "I was planning to tell you everything... after you became our [title]... but..."
    jes "Planeaba contárselo todo... después de que se convirtiera en nuestr[letra] [title!t]... pero..."

# game/script day2.rpy:4381
translate Spanish prieston_convo2_deb88d93:

    # jes "...The more time I spend with you... the more I fear for your safety."
    jes "...Cuanto más tiempo paso con usted... más temo por su seguridad."

# game/script day2.rpy:4382
translate Spanish prieston_convo2_c2b196ae:

    # jes "What if you were to disappear simply because you learned too much...? What would happen to you if you kept digging deeper?"
    jes "¿Y si usted desapareciera simplemente por haber sabido demasiado...? ¿Qué sería de usted si siguiera indagando más hondo?"

# game/script day2.rpy:4384
translate Spanish prieston_convo2_614706bc:

    # jes "I'm scared."
    jes "Tengo miedo."

# game/script day2.rpy:4385
translate Spanish prieston_convo2_02701c2c:

    # jes "It's been so long since I've felt fear... anxiety... and paranoia all tangled together like this..."
    jes "Hace tanto tiempo que no sentía miedo... ansiedad... y paranoia enredados así..."

# game/script day2.rpy:4386
translate Spanish prieston_convo2_d0cf7621:

    # jes "And now.... this feeling... this new, strange feeling..."
    jes "Y ahora.... esta sensación... esta nueva y extraña sensación..."

# game/script day2.rpy:4387
translate Spanish prieston_convo2_39a9731f:

    # jes "When you don't want someone precious to you to be in danger... and you always find yourself wanting to stay by their side..."
    jes "Cuando no quieres que alguien precioso para ti esté en peligro... y siempre te encuentras deseando permanecer a su lado..."

# game/script day2.rpy:4388
translate Spanish prieston_convo2_e8ab4dc4:

    # jes "...I understand now... this must be the feeling they call love... isn't it?"
    jes "...Ahora lo entiendo... esto debe de ser el sentimiento que llaman amor... ¿no es así?"

# game/script day2.rpy:4389
translate Spanish prieston_convo2_4568ca86:

    # jes "Of course... of course that is the reason... yes..."
    jes "Claro... claro que esa es la razón... sí..."

# game/script day2.rpy:4390
translate Spanish prieston_convo2_84aa8d41:

    # jes "All because my love for you has grown far stronger than I ever imagined..."
    jes "Todo porque mi amor por usted ha crecido mucho más fuerte de lo que jamás imaginé..."

# game/script day2.rpy:4391
translate Spanish prieston_convo2_552f85db:

    # jes "I know these feelings came far too quickly. I know they don't make any sense."
    jes "Sé que estos sentimientos llegaron demasiado rápido. Sé que no tienen ningún sentido."

# game/script day2.rpy:4392
translate Spanish prieston_convo2_7f637021:

    # jes "But please... believe me. I can feel, deep in my heart, that every one of them is genuine."
    jes "Pero por favor... créame. Puedo sentir, en lo más profundo de mi corazón, que cada uno de ellos es genuino."

# game/script day2.rpy:4393
translate Spanish prieston_convo2_9eb2dd20:

    # jes "You're the only love I've ever had... and I want you to stay by my side forever."
    jes "Es el único amor que he tenido... y quiero que se quede a mi lado para siempre."

# game/script day2.rpy:4394
translate Spanish prieston_convo2_34251e0f:

    # jes "That's why..."
    jes "Por eso..."

# game/script day2.rpy:4395
translate Spanish prieston_convo2_2f2995cc:

    # jes "..... "
    jes "..... "

# game/script day2.rpy:4397
translate Spanish prieston_convo2_3f2af826_1:

    # jes "....."
    jes "....."

# game/script day2.rpy:4403
translate Spanish prieston_convo2_3f2af826_2:

    # jes "....."
    jes "....."

# game/script day2.rpy:4404
translate Spanish prieston_convo2_78a31c16:

    # jes "No.... Don't..."
    jes "No.... No..."

# game/script day2.rpy:4405
translate Spanish prieston_convo2_58d7a1b0:

    # jes "Be patient, Jestyn. You can't do that while [poss] majesty is asleep.. [poss] majesty never give your permission to do so... you can wait."
    jes "Sé paciente, Jestyn. No puedes hacer eso mientras Su Majestad duerme.. Su Majestad nunca te dio su permiso para hacerlo... puedes esperar."

# game/script day2.rpy:4406
translate Spanish prieston_convo2_65daff9f:

    # jes "Just a little longer."
    jes "Solo un poco más."

# game/script day2.rpy:4407
translate Spanish prieston_convo2_77076849:

    # jes "...Restrain thyself, thou foolish jester."
    jes "...Refrénate, necio bufón."

# game/script day2.rpy:4409
translate Spanish prieston_convo2_88056451_1:

    # jes "......"
    jes "......"

# game/script day2.rpy:4411
translate Spanish prieston_convo2_8b72033b:

    # jes "Yes... yes, I can wait."
    jes "Sí... sí, puedo esperar."

# game/script day2.rpy:4412
translate Spanish prieston_convo2_bb757487:

    # jes "Until that day comes, I'll keep protecting you."
    jes "Hasta que llegue ese día, seguiré protegiéndole."

# game/script day2.rpy:4413
translate Spanish prieston_convo2_a38ab3a1:

    # jes "As long as I'm here, I won't let anyone lay a finger on you..."
    jes "Mientras yo esté aquí, no dejaré que nadie le ponga un dedo encima..."

# game/script day2.rpy:4415
translate Spanish prieston_convo2_e77d914c:

    # jes "My love."
    jes "Mi amor."

translate Spanish strings:

    # game/script day2.rpy:98
    old "Look at the window"
    new "Mirar por la ventana"

    # game/script day2.rpy:101
    old "Look at the TV"
    new "Mirar la tele"

    # game/script day2.rpy:104
    old "Look at the phone"
    new "Mirar el teléfono"

    # game/script day2.rpy:107
    old "Nothing interesting to me"
    new "Nada me interesa"

    # game/script day2.rpy:175
    old "No thank you"
    new "No, gracias"

    # game/script day2.rpy:178
    old "Brat"
    new "Malcriado"

    # game/script day2.rpy:181
    old "I'll do it. Hard"
    new "Lo haré. Fuerte"

    # game/script day2.rpy:439
    old "Talk to Maidelyn"
    new "Hablar con Maidelyn"

    # game/script day2.rpy:442
    old "Talk to Maidy"
    new "Hablar con Maidy"

    # game/script day2.rpy:445
    old "Talk to Maidra"
    new "Hablar con Maidra"

    # game/script day2.rpy:448
    old "That is enough"
    new "Ya basta"

    # game/script day2.rpy:529
    old "Knighter's room"
    new "Cuarto de Knighter"

    # game/script day2.rpy:532
    old "Wizzy's room"
    new "Cuarto de Wizzy"

    # game/script day2.rpy:535
    old "[crownus_text]"
    new "[crownus_text]"

    # game/script day2.rpy:1172
    old "I like Jestyn"
    new "Me gusta Jestyn"

    # game/script day2.rpy:1176
    old "I'm not sure"
    new "No estoy segur[letra]"

    # game/script day2.rpy:1229
    old "Punish him"
    new "Castigarlo"

    # game/script day2.rpy:1232
    old "Let it slide"
    new "Dejarlo pasar"

    # game/script day2.rpy:1304
    old "Slap his cheek"
    new "Abofetearle la mejilla"

    # game/script day2.rpy:1345
    old "Slap him"
    new "Abofetearlo"

    # game/script day2.rpy:1362
    old "Slap him harder"
    new "Abofetearlo más fuerte"

    # game/script day2.rpy:1378
    old "Again"
    new "Otra vez"

    # game/script day2.rpy:1396
    old "AGAIN"
    new "OTRA VEZ"

    # game/script day2.rpy:1506
    old "Spank him"
    new "Darle una nalgada"

    # game/script day2.rpy:1574
    old "Spank him harder"
    new "Darle una nalgada más fuerte"

    # game/script day2.rpy:2530
    old "Let Jestyn follow"
    new "Dejar que Jestyn me siga"

    # game/script day2.rpy:2534
    old "Don't let Jestyn follow"
    new "No dejar que Jestyn me siga"

    # game/script day2.rpy:2762
    old "What do you think about Jestyn?"
    new "¿Qué piensas de Jestyn?"

    # game/script day2.rpy:2811
    old "What do you think about king puppet?"
    new "¿Qué piensas del Rey Títere?"

    # game/script day2.rpy:2841
    old "Do you have a good relationship with every puppet?"
    new "¿Te llevas bien con todos los títeres?"

    # game/script day2.rpy:3751
    old "Why did you help me?"
    new "¿Por qué me ayudaste?"

    # game/script day2.rpy:3818
    old "What do you think about Crownus?"
    new "¿Qué piensas de Crownus?"

    # game/script day2.rpy:3860
    old "He is Crownus's loyal follower"
    new "Es un seguidor leal de Crownus"

    # game/script day2.rpy:3875
    old "He is not Crownus's loyal follower"
    new "No es un seguidor leal de Crownus"

    # game/script day2.rpy:3994
    old "I want to know more about you"
    new "Quiero saber más sobre ti"

    # game/script day2.rpy:4084
    old "I'm feeling sleepy.."
    new "Tengo sueño.."

