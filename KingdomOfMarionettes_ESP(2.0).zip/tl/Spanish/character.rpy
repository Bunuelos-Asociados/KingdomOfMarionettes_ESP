# TODO: Translation updated at 2026-11-09 22:40

# game/character.rpy:67
translate Spanish ask_player_name_f1b999d0:

    # jes "Oh, sweet tart and cream. We share the same name! What a truly marvelous miracle."
    jes "Oh, dulce tarta de crema. ¡Compartimos el mismo nombre! Qué milagro tan verdaderamente maravilloso."

# game/character.rpy:69
translate Spanish ask_player_name_9ea78486:

    # jes "Mmm... in that case, calling you by your name would be rather troublesome. It would feel strange to be calling myself."
    jes "Mmm... en ese caso, llamarte por tu nombre sería bastante problemático. Se sentiría extraño estar llamándome a mí mismo."

# game/character.rpy:70
translate Spanish ask_player_name_a290dce2:

    # jes "So instead, I shall bestow upon you a nickname. Sweety! Doesn't it sound delightful? Sweet, just like a strawberry tart."
    jes "Así que, en su lugar, te otorgaré un apodo. ¡Sweety! ¿No suena encantador? Dulce, como una tarta de fresa."

# game/character.rpy:72
translate Spanish ask_player_name_ba56d5a3:

    # jes "And what's more, it even shares the same ending letters. sweeTY, JesTYn. Don't I sound like a genius?"
    jes "Y lo que es más, incluso comparte las mismas letras finales. sweeTY, JesTYn. ¿No sueno como un genio?"

# game/character.rpy:73
translate Spanish ask_player_name_2f0fdc91:

    # mc "Um... actually, it's missing an 'N'."
    mc "Um... en realidad, le falta una 'N'."

# game/character.rpy:75
translate Spanish ask_player_name_b2120850:

    # jes "Then Sweetyn."
    jes "Entonces, Sweetyn."

# game/character.rpy:76
translate Spanish ask_player_name_dcb6e45a:

    # "... I suppose that will do."
    "... Supongo que eso servirá."

# game/character.rpy:85
translate Spanish ask_player_name_39b7cb58:

    # jes "...What? Knighter?? Pffft Ahhhahahahahhahaa!! ohhh!, are the heavens and earth trying to play a joke on me?!"
    jes "...¿Qué? ¿Knighter?? Pffft ¡Ajjjajajajajjajaa! ¡Ohhh!, ¿¡los cielos y la tierra están tratando de gastarme una broma?!"

# game/character.rpy:87
translate Spanish ask_player_name_3d40b84a:

    # jes "It's certainly a bold and heroic sounding name, I'll grant you that. But I simply can't allow you to keep it."
    jes "Sin duda es un nombre audaz y con un aire heroico, te lo concedo. Pero simplemente no puedo permitirte conservarlo."

# game/character.rpy:88
translate Spanish ask_player_name_bc8b1ccb:

    # jes "If the grumpy master were to find out... oh, I dread to imagine how many pieces you'd end up in."
    jes "Si el gruñón maestro llegara a enterarse... oh, temo imaginar en cuántos pedazos terminarías."

# game/character.rpy:90
translate Spanish ask_player_name_2ce068df:

    # jes "So I suggest you choose another name."
    jes "Así que te sugiero que elijas otro nombre."

# game/character.rpy:94
translate Spanish ask_player_name_8e28f667:

    # mc "But my name truly is Knighter..."
    mc "Pero mi nombre realmente es Knighter..."

# game/character.rpy:96
translate Spanish ask_player_name_89c76285:

    # jes "And I am telling you that you may no longer use that name."
    jes "Y yo te digo que ya no puedes usar ese nombre."

# game/character.rpy:97
translate Spanish ask_player_name_cbd182b0:

    # jes "Or as I stated a few seconds ago... you would become nothing more than scattered fragments in the blink of an eye."
    jes "O como dije hace unos segundos... te convertirías en nada más que fragmentos dispersos en un abrir y cerrar de ojos."

# game/character.rpy:99
translate Spanish ask_player_name_888f0c8a:

    # jes "So I strongly suggest you choose a new name. Immediately."
    jes "Así que te sugiero encarecidamente que elijas un nuevo nombre. Inmediatamente."

# game/character.rpy:104
translate Spanish ask_player_name_447bf2f1:

    # jes "Hmm... I find myself wondering, sweet human."
    jes "Hmm... me encuentro preguntándome, dulce ser humano."

# game/character.rpy:105
translate Spanish ask_player_name_339d8616:

    # jes "Is it that your ears fail to function and did not hear what I said earlier, or are you simply stubborn? There is hardly any difference."
    jes "¿Es que tus oídos no funcionan y no escuchaste lo que dije antes, o simplemente eres terc[letra]? Apenas hay diferencia."

# game/character.rpy:107
translate Spanish ask_player_name_8a79e23c:

    # jes "Very well. Since you insist on being so obstinate, I shall give you a name myself."
    jes "Muy bien. Ya que insistes en ser tan obstinad[letra], te daré un nombre yo mismo."

# game/character.rpy:109
translate Spanish ask_player_name_9fccd482:

    # jes "From this moment on, your name shall be... Stubbornelle."
    jes "A partir de este momento, tu nombre será... Stubbornelle."

# game/character.rpy:110
translate Spanish ask_player_name_e0715dbc:

    # mc "But-"
    mc "Pero—"

# game/character.rpy:112
translate Spanish ask_player_name_babbb6eb:

    # jes "Tatatatat~ No complaints."
    jes "Tatatatat~ Sin quejas."

# game/character.rpy:120
translate Spanish ask_player_name_759260e6:

    # jes "Oh my goodness! Wizzy? Did I hear that correctly?"
    jes "¡Oh, por Dios! ¿Wizzy? ¿Escuché bien?"

# game/character.rpy:122
translate Spanish ask_player_name_5686fc26:

    # jes "How adorable. Just wait until Wizzy, the royal mage, hears about this."
    jes "Qué adorable. Solo espera a que Wizzy, el mago real, se entere de esto."

# game/character.rpy:124
translate Spanish ask_player_name_1a745ae6:

    # jes "I'm absolutely certain, one thousand and one percent that his heart will shine like a star when he learns he has a brand new twin."
    jes "Estoy absolutamente seguro, mil y un por ciento, de que su corazón brillará como una estrella cuando sepa que tiene un gemelo completamente nuevo."

# game/character.rpy:133
translate Spanish ask_player_name_1acc92f3:

    # "{color=#FF2727}......{/color}"
    "{color=#FF2727}......{/color}"

# game/character.rpy:134
translate Spanish ask_player_name_a49f3494:

    # "{color=#FF2727}oh..... really...?{/color}"
    "{color=#FF2727}oh..... ¿en serio...?{/color}"

# game/character.rpy:135
translate Spanish ask_player_name_5345f543:

    # "{color=#FF2727}ha....haha....{/color}"
    "{color=#FF2727}ja....jaja....{/color}"

# game/character.rpy:138
translate Spanish ask_player_name_9d05eb66:

    # "{color=#FF2727}{cps=220}HAHAHAHAHHAHAHHAHAHAHAHAHAHAHHAHHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHA HAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHHAHAHAHAH AHAHAHAHAHAHAHAHAHAHAHHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHHAHA HAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAHAH{/cps}{/color}"
    "{color=#FF2727}{cps=220}JAJAJAJAJJAJAJJAJAJAJAJAJAJAJJAJJAJAJAJAJAJAJAJAJAJAJAJAJJAJAJAJAJA JAJAJAJAJAJAJAJAJAJAJJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJJAJAJAJAJAJJAJAJAJAJ AJAJAJAJAJAJAJAJAJAJAJJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJJAJA JAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJAJ{/cps}{/color}"

# game/character.rpy:140
translate Spanish ask_player_name_0fd4d656:

    # "......"
    "......"

# game/character.rpy:141
translate Spanish ask_player_name_278c7e29:

    # "........."
    "........."

# game/character.rpy:147
translate Spanish ask_player_name_2f4f0bc8:

    # jes "Ah... it's really an honour to be meeting you [player_call]"
    jes "Ah... es realmente un honor conocerte, [player_call]"

translate Spanish strings:

    # game/character.rpy:1
    old "Jestyn"
    new "Jestyn"

    # game/character.rpy:3
    old "Jester puppet"
    new "Bufón Marioneta"

    # game/character.rpy:5
    old "Knighter"
    new "Knighter"

    # game/character.rpy:7
    old "Wizzy"
    new "Wizzy"

    # game/character.rpy:9
    old "Knight puppet"
    new "Caballero Marioneta"

    # game/character.rpy:11
    old "???"
    new "???"

    # game/character.rpy:13
    old "You"
    new "Tú"

    # game/character.rpy:15
    old "Farmer"
    new "Granjero"

    # game/character.rpy:17
    old "Debt collector"
    new "Cobrador de deudas"

    # game/character.rpy:19
    old "Narrator"
    new "Narrador"

    # game/character.rpy:21
    old "Puppet??"
    new "¿¿Marioneta??"

    # game/character.rpy:23
    old "Maidy"
    new "Maidy"

    # game/character.rpy:25
    old "Maidra"
    new "Maidra"

    # game/character.rpy:27
    old "Maidelyn"
    new "Maidelyn"

    # game/character.rpy:29
    old "The Maids"
    new "Las Doncellas"

    # game/character.rpy:31
    old "Jestyn & Knighter"
    new "Jestyn & Knighter"

    # game/character.rpy:33
    old "Butler Puppet"
    new "Mayordomo Marioneta"

    # game/character.rpy:35
    old "Butley"
    new "Butley"

    # game/character.rpy:37
    old "Puppet 1"
    new "Marioneta 1"

    # game/character.rpy:39
    old "Puppet 2"
    new "Marioneta 2"

    # game/character.rpy:41
    old "Puppet 3"
    new "Marioneta 3"

    # game/character.rpy:43
    old "Puppet 4"
    new "Marioneta 4"

    # game/character.rpy:45
    old "Prieston"
    new "Prieston"

    # game/character.rpy:47
    old "Everyone"
    new "Todos"

    # game/character.rpy:163
    old "She / Her"
    new "Ella"

    # game/character.rpy:171
    old "He / Him"
    new "Él"

    # game/character.rpy:179
    old "They / Them"
    new "Elle"
    
    old "queen"
    new "reina"

    old "king"
    new "rey"

    old "ruler"
    new "gobernante"

    old "girl"
    new "chica"

    old "boy"
    new "chico"

    old "kid"
    new "chique"
    
    old "she"
    new "ella"
    
    old "he"
    new "él"
    
    old "they"
    new "elle"
    
    old "What is your name?"
    new "¿Cuál es tu nombre?"
    


