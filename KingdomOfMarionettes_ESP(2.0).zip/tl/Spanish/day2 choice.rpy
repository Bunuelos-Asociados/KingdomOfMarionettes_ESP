# TODO: Translation updated at 2026-11-09 22:40

# game/day2 choice.rpy:10
translate Spanish lookwindow_day2_96e13a5e:

    # "My gaze wandered to the large window."
    "Mi mirada vagó hacia el gran ventanal."

# game/day2 choice.rpy:11
translate Spanish lookwindow_day2_77abb917:

    # "There wasn't much to see outside. Just crowds of people making their way home after a long day of work."
    "No había mucho que ver afuera. Solo se veían grupos de personas que volvían a casa después de una larga jornada de trabajo."

# game/day2 choice.rpy:12
translate Spanish lookwindow_day2_fc43b4b9:

    # "A few others lingered around the convenience store, minding their own business."
    "Unas cuantas personas más rondaban la tienda de conveniencia, a lo suyo."

# game/day2 choice.rpy:13
translate Spanish lookwindow_day2_66d2bcc2:

    # "At least, that's what I thought at first."
    "Al menos, eso pensé al principio."

# game/day2 choice.rpy:14
translate Spanish lookwindow_day2_a4069cd5:

    # "Several people kept glancing in the same direction."
    "Varias personas no dejaban de mirar en la misma dirección."

# game/day2 choice.rpy:15
translate Spanish lookwindow_day2_bcdaf301:

    # "Some looked surprised. Others seemed confused."
    "Algunos parecían sorprendidos. Otros, confundidos."

# game/day2 choice.rpy:16
translate Spanish lookwindow_day2_5f90032e:

    # "Curious, I followed their gaze and found myself staring at a... man?"
    "Intrigad[letra], seguí sus miradas y terminé contemplando a un... ¿hombre?"

# game/day2 choice.rpy:17
translate Spanish lookwindow_day2_1f743b92:

    # "Ah. That explained it."
    "Ah. Eso lo explicaba."

# game/day2 choice.rpy:18
translate Spanish lookwindow_day2_03d704f3:

    # "He towered over everyone around him, making him impossible to miss."
    "Era más alto que todos los que lo rodeaban, imposible de no notar."

# game/day2 choice.rpy:19
translate Spanish lookwindow_day2_ea69e7d8:

    # "And for a brief moment, I felt a strange sense of familiarity."
    "Y por un breve instante, sentí una extraña sensación de familiaridad."

# game/day2 choice.rpy:25
translate Spanish tv_day2_432fb6f1:

    # "My gaze drifted toward the TV inside the convenience store."
    "Mi mirada se desvió hacia el televisor dentro de la tienda."

# game/day2 choice.rpy:26
translate Spanish tv_day2_2a9d8b33:

    # "The morning news was playing."
    "Estaban pasando las noticias de la mañana."

# game/day2 choice.rpy:27
translate Spanish tv_day2_381ca983:

    # "From what I could gather, they were covering a murder case."
    "Por lo que pude entender, cubrían un caso de asesinato."

# game/day2 choice.rpy:28
translate Spanish tv_day2_f4daf8d7:

    # "A man had been discovered dead in an alley."
    "Habían encontrado a un hombre muerto en un callejón."

# game/day2 choice.rpy:29
translate Spanish tv_day2_70d1133e:

    # "His body had been split cleanly in two."
    "Su cuerpo había sido partido limpiamente en dos."

# game/day2 choice.rpy:30
translate Spanish tv_day2_0b026d98:

    # "Oh God."
    "Dios mío."

# game/day2 choice.rpy:31
translate Spanish tv_day2_d87ede75:

    # "I'd heard of plenty of murder cases before, each with its own gruesome details, but being cut in half?"
    "Había oído hablar de muchos casos de asesinato, cada uno con sus propios detalles macabros, pero ¿que a alguien lo partieran por la mitad?"

# game/day2 choice.rpy:32
translate Spanish tv_day2_e0b36053:

    # "That was horrifying."
    "Era horrible."

# game/day2 choice.rpy:33
translate Spanish tv_day2_38c47475:

    # "What kind of sick person could even do something like that...?"
    "¿Qué clase de enfermo podría hacer algo así...?"

# game/day2 choice.rpy:39
translate Spanish phone_day2_fe438bc5:

    # "I pulled out my phone to check if I'd received any new messages."
    "Saqué el celular para ver si tenía mensajes nuevos."

# game/day2 choice.rpy:40
translate Spanish phone_day2_9850f53c:

    # "Nothing."
    "Nada."

# game/day2 choice.rpy:41
translate Spanish phone_day2_6c277cc9:

    # "I checked again."
    "Volví a revisar."

# game/day2 choice.rpy:42
translate Spanish phone_day2_cbc4269d:

    # "Still nothing."
    "Seguía sin haber nada."

# game/day2 choice.rpy:43
translate Spanish phone_day2_3da9e9fb:

    # "I'd been expecting another message from the debt collectors, but so far, they hadn't contacted me."
    "Esperaba otro mensaje de los cobradores de deudas, pero hasta ahora no se habían puesto en contacto conmigo."

# game/day2 choice.rpy:44
translate Spanish phone_day2_5cb0659e:

    # "For now, that brought me some relief."
    "Por ahora, eso me dio algo de alivio."

# game/day2 choice.rpy:45
translate Spanish phone_day2_3c7dcd8b:

    # "Though I had no idea how long that relief would last."
    "Aunque no tenía idea de cuánto duraría."

# game/day2 choice.rpy:46
translate Spanish phone_day2_4cd41e9c:

    # "Well, no point worrying about it right now."
    "En fin, no tiene sentido preocuparme por eso ahora."

# game/day2 choice.rpy:47
translate Spanish phone_day2_7d750eab:

    # "For the time being, I'd just enjoy the feeling while it lasted."
    "Por el momento, simplemente disfrutaría de la sensación mientras durara."

# game/day2 choice.rpy:53
translate Spanish nothx_day2_d4f90dc8:

    # "Of course, the perverted puppet was asking for something more than that to keep him quiet."
    "Claro que la marioneta pervertida pedía algo más que eso para mantenerlo callado."

# game/day2 choice.rpy:55
translate Spanish nothx_day2_f4b32692:

    # mc "No, thank you."
    mc "No, gracias."

# game/day2 choice.rpy:59
translate Spanish nothx_day2_223c11cf:

    # "Jestyn puffed out his cheeks in an exaggerated pout."
    "Jestyn infló las mejillas y puso un puchero exagerado."

# game/day2 choice.rpy:61
translate Spanish nothx_day2_b679342a:

    # jes "Mmmhh... why ever not? I graciously made you an offer."
    jes "Mmmhh... ¿por qué no? Con toda gentileza le hice una oferta."

# game/day2 choice.rpy:62
translate Spanish nothx_day2_709c5b6d:

    # mc "Because whenever you make an offer, it turns into something weird."
    mc "Porque cada vez que haces una oferta, termina siendo algo raro."

# game/day2 choice.rpy:63
translate Spanish nothx_day2_6fd9c706:

    # jes "Mmmrrghhhh... how cruel, Your Majesty..."
    jes "Mmmrrghhhh... qué crueldad, Majestad..."

# game/day2 choice.rpy:71
translate Spanish brat_day2_3bfd88ab:

    # "........Okay."
    "........Está bien."

# game/day2 choice.rpy:72
translate Spanish brat_day2_b21d8ce7:

    # "I wasn't exactly experienced with this sort of thing, but from what I'd read in fanfics and comics, the more dominant person usually said..."
    "No tenía mucha experiencia en este tipo de cosas, pero por lo que había leído en fanfics y cómics, la persona más dominante solía decir..."

# game/day2 choice.rpy:73
translate Spanish brat_day2_35879300:

    # "'Brat.'"
    "'Malcriado.'"

# game/day2 choice.rpy:74
translate Spanish brat_day2_67a9bdaa:

    # "...Should I really say it?"
    "...¿De verdad debería decirlo?"

# game/day2 choice.rpy:75
translate Spanish brat_day2_6c70f25f:

    # "Ah, whatever. Screw it."
    "Ah, qué más da. Al diablo."

# game/day2 choice.rpy:77
translate Spanish brat_day2_ccd5ba6f:

    # mc "Jestyn..."
    mc "Jestyn..."

# game/day2 choice.rpy:81
translate Spanish brat_day2_6422f662:

    # mc "You're being a brat."
    mc "Te estás portando como un malcriado."

# game/day2 choice.rpy:85
translate Spanish brat_day2_731adca2:

    # "Jestyn burst into laughter at my pathetic attempt to act like one of those dominant characters from a fanfic."
    "Jestyn estalló en carcajadas ante mi patético intento de actuar como uno de esos personajes dominantes de fanfic."

# game/day2 choice.rpy:86
translate Spanish brat_day2_d11bc1e4:

    # "I could feel my cheeks burning with embarrassment. Damn it."
    "Sentí que las mejillas me ardían de vergüenza. Maldición."

# game/day2 choice.rpy:87
translate Spanish brat_day2_467d4659:

    # "I looked like an idiot."
    "Parecía [arti_2] idiota."

# game/day2 choice.rpy:91
translate Spanish brat_day2_1b9f8c81:

    # jes "My, my... Is Your Majesty attempting to make this poor jester lose his composure~?"
    jes "Vaya, vaya... ¿Acaso Su Majestad intenta hacer perder la compostura a este pobre bufón~?"

# game/day2 choice.rpy:92
translate Spanish brat_day2_1bcf448a:

    # jes "A valiant effort... though I must admit, Your Majesty is still rather hopeless at it."
    jes "Un esfuerzo valeroso... aunque debo admitir que Su Majestad sigue siendo bastante inútil en esto."

# game/day2 choice.rpy:93
translate Spanish brat_day2_f1e3616d:

    # mc ".....You didn't have to tell me."
    mc ".....No hacía falta que me lo dijeras."

# game/day2 choice.rpy:94
translate Spanish brat_day2_1fdbef0d:

    # jes "Now, now. Don't pout."
    jes "Vamos, vamos. No haga pucheros."

# game/day2 choice.rpy:98
translate Spanish brat_day2_09d7f9bd:

    # jes "No puzzle is complete from the very beginning."
    jes "Ningún rompecabezas está completo desde el principio."

# game/day2 choice.rpy:99
translate Spanish brat_day2_bd424f87:

    # jes "Everyone spends a little while searching for the piece they've been missing."
    jes "Todos pasan un tiempo buscando la pieza que les falta."

# game/day2 choice.rpy:100
translate Spanish brat_day2_b788d197:

    # jes "Much like a puzzle, You simply need the missing piece to become whole."
    jes "Igual que un rompecabezas, Usted solo necesita la pieza que le falta para completarse."

# game/day2 choice.rpy:102
translate Spanish brat_day2_9e989d2e:

    # "He leaned in until our faces were only inches apart, his expression calm and relaxed."
    "Se inclinó hasta que nuestros rostros quedaron a pocos centímetros, con una expresión calmada y relajada."

# game/day2 choice.rpy:106
translate Spanish brat_day2_7a20222d:

    # jes "In other words... I could be your missing piece, Your Majesty."
    jes "En otras palabras... yo podría ser su pieza faltante, Majestad."

# game/day2 choice.rpy:108
translate Spanish brat_day2_39b23405:

    # "My face grew even hotter."
    "Sentí la cara aún más caliente."

# game/day2 choice.rpy:109
translate Spanish brat_day2_54cb5957:

    # "Though this time, it wasn't from embarrassment."
    "Aunque esta vez no fue por vergüenza."

# game/day2 choice.rpy:110
translate Spanish brat_day2_fb9ea5ee:

    # "My heart was pounding."
    "Mi corazón latía con fuerza."

# game/day2 choice.rpy:114
translate Spanish brat_day2_1c4dd153:

    # jes "And TA-DAA~! Behold! The art of flustering, performed to perfection by this humble jester~"
    jes "¡Y TA-CHÁAN~! ¡Contemplen! El arte de hacer sonrojar, ejecutado a la perfección por este humilde bufón~"

# game/day2 choice.rpy:115
translate Spanish brat_day2_42e0096f:

    # jes "Mmm~ Just look at You now... Your face is as red as a little tomato left out in the summer sun."
    jes "Mmm~ Mírese ahora... Tiene la cara roja como un tomatito dejado al sol del verano."

# game/day2 choice.rpy:116
translate Spanish brat_day2_a76b3ed5:

    # jes "Hehe... Another flawless performance by Yours Truly Jestyn the Jester! I do so love an audience that blushes on cue~"
    jes "Jeje... ¡Otra actuación impecable de su seguro servidor, Jestyn el Bufón! Me encanta un público que se sonroja a la orden~"

# game/day2 choice.rpy:118
translate Spanish brat_day2_39a94e6d:

    # "I blinked once, then twice after realizing he was only teasing me."
    "Parpadeé una vez, luego dos, al darme cuenta de que solo me estaba tomando el pelo."

# game/day2 choice.rpy:119
translate Spanish brat_day2_3f7cc408:

    # "I instinctively pushed against his chest and put some distance between us before my face could grow any hotter."
    "Instintivamente apoyé las manos en su pecho para empujarlo y puse algo de distancia entre nosotros antes de que mi cara se calentara más."

# game/day2 choice.rpy:120
translate Spanish brat_day2_a45ca83b:

    # "Jestyn responded the same way he always did, with a teasing laugh."
    "Jestyn respondió como siempre, con una risa burlona."

# game/day2 choice.rpy:122
translate Spanish brat_day2_95afd7df:

    # jes "Your Majesty blushes so easily. How utterly adorable~"
    jes "Su Majestad se sonroja con tanta facilidad. Qué absolutamente adorable~"

# game/day2 choice.rpy:123
translate Spanish brat_day2_dc7a60e5:

    # jes "My, my... What a fragile little [title]. Are You truly the sovereign of this kingdom... or merely a speck of dust? One tiny puff and off You go! Hahaha!"
    jes "Vaya, vaya... Qué frágil [title!t]. ¿Es usted de verdad quien gobierna este reino... o solo una mota de polvo? ¡Un solo soplido y sale volando! ¡Jajaja!"

# game/day2 choice.rpy:125
translate Spanish brat_day2_0365e8cb:

    # "I answered him with nothing more than a strained smile. I was far too tired to entertain his teasing."
    "Le respondí con nada más que una sonrisa forzada. Estaba demasiado cansad[letra] para seguirle el juego a sus burlas."

# game/day2 choice.rpy:126
translate Spanish brat_day2_e5f9359e:

    # "This puppet really had a remarkable talent for getting on my nerves. Constantly."
    "Esta marioneta tenía un talento notable para sacarme de quicio. Constantemente."

# game/day2 choice.rpy:134
translate Spanish dohard_day2_1835bd23:

    # "His teasing words only made my emotions more complicated."
    "Sus burlas solo hacían que mis emociones fueran más complicadas."

# game/day2 choice.rpy:135
translate Spanish dohard_day2_54747e56:

    # "They irritated me, and yet..."
    "Me irritaban, y sin embargo..."

# game/day2 choice.rpy:136
translate Spanish dohard_day2_21cf468b:

    # "They also made me feel strangely bold."
    "También me hacían sentir extrañamente atrevid[letra]."

# game/day2 choice.rpy:137
translate Spanish dohard_day2_230cab0d:

    # "For some reason, I felt as though I could actually get the upper hand for once."
    "Por alguna razón, sentía que por una vez podía llevar la ventaja."

# game/day2 choice.rpy:138
translate Spanish dohard_day2_d20161ea:

    # "The thought of putting him in his place was unexpectedly exciting."
    "La idea de ponerlo en su lugar era inesperadamente emocionante."

# game/day2 choice.rpy:139
translate Spanish dohard_day2_07bdde05:

    # "....."
    "....."

# game/day2 choice.rpy:141
translate Spanish dohard_day2_3c42a2e1:

    # mc "You know, Jestyn?"
    mc "¿Sabes qué, Jestyn?"

# game/day2 choice.rpy:142
translate Spanish dohard_day2_e2905d1a:

    # mc "If that's what you're asking for, then alright."
    mc "Si eso es lo que estás pidiendo, de acuerdo."

# game/day2 choice.rpy:143
translate Spanish dohard_day2_3d769fed:

    # mc "For a brat like you... I'd be happy to teach you how to stay quiet."
    mc "A un malcriado como tú... con gusto te enseñaría a quedarte callado."

# game/day2 choice.rpy:144
translate Spanish dohard_day2_1343f8a6:

    # mc "In a harder way."
    mc "De una forma más dura."

# game/day2 choice.rpy:147
translate Spanish dohard_day2_18f210c1:

    # "Jestyn's eyes widened in surprise at the tone of my voice and the words that had just come out of my mouth."
    "Los ojos de Jestyn se abrieron de sorpresa ante el tono de mi voz y las palabras que acababan de salir de mi boca."

# game/day2 choice.rpy:150
translate Spanish dohard_day2_27515055:

    # "A moment later, a wide grin spread across his face as the blush on his cheeks deepened."
    "Un instante después, una amplia sonrisa se extendió por su rostro mientras el rubor de sus mejillas se intensificaba."

# game/day2 choice.rpy:152
translate Spanish dohard_day2_9d79ee46:

    # jes "Mmhh... saying such scandalous things in public..."
    jes "Mmhh... decir cosas tan escandalosas en público..."

# game/day2 choice.rpy:153
translate Spanish dohard_day2_f45ea6e1:

    # jes "... How shameless~"
    jes "... Qué desvergüenza~"

# game/day2 choice.rpy:154
translate Spanish dohard_day2_117def60:

    # mc "WHA-? You're the one who started saying all that freaky stuff!"
    mc "¿¡QUÉ-!? ¡Tú fuiste quien empezó a decir todas esas cosas raras!"

# game/day2 choice.rpy:155
translate Spanish dohard_day2_1822a4ed:

    # mc "And there's no one in here other than us!"
    mc "¡Y aquí no hay nadie más que nosotros!"

# game/day2 choice.rpy:156
translate Spanish dohard_day2_fffd44cd:

    # jes "And yet I never imagined such naughty words would come from my sweet and innocent little [title]~"
    jes "Y aun así jamás imaginé que palabras tan traviesas saldrían de mi dulce e inocente [title!t]~"

# game/day2 choice.rpy:157
translate Spanish dohard_day2_93915e70:

    # jes "You continue to surprise me, Your Majesty..."
    jes "Sigue sorprendiéndome, Majestad..."

# game/day2 choice.rpy:160
translate Spanish dohard_day2_2d5b9ebd:

    # jes "Me likey~"
    jes "Me gusta, me gusta~"

# game/day2 choice.rpy:162
translate Spanish dohard_day2_59c85b50:

    # "THIS ABSOLUTE MENACE."
    "ESTE ABSOLUTO PELIGRO PÚBLICO."

# game/day2 choice.rpy:173
translate Spanish maidy_day2_9d88fad1:

    # "I decided to talk to Maidy."
    "Decidí hablar con Maidy."

# game/day2 choice.rpy:174
translate Spanish maidy_day2_132add1c:

    # "She was busy wiping down a dirty section of the wall while humming a cheerful tune and swaying from side to side."
    "Estaba muy ocupada limpiando una parte sucia de la pared mientras tarareaba una alegre melodía y se balanceaba de lado a lado."

# game/day2 choice.rpy:175
translate Spanish maidy_day2_7b08c122:

    # "She looked like she was genuinely enjoying her work."
    "Parecía estar disfrutando de verdad su trabajo."

# game/day2 choice.rpy:176
translate Spanish maidy_day2_8b418089:

    # "The moment I approached, she noticed me and immediately stopped what she was doing."
    "En cuanto me acerqué, me notó y dejó de hacer lo que estaba haciendo de inmediato."

# game/day2 choice.rpy:179
translate Spanish maidy_day2_5eedc315:

    # maidy "AHHH! IT'S CUTIE MAJESTY!!"
    maidy "¡¡AHHH!! ¡¡ES SU MAJESTAD MONADA!!"

# game/day2 choice.rpy:180
translate Spanish maidy_day2_4f2680cf:

    # maidy "What brings you here~?"
    maidy "¿Qué te trae por aquí~?"

# game/day2 choice.rpy:182
translate Spanish maidy_day2_e5ea8e05:

    # maidy "Wait, wait, wait... I know!"
    maidy "Espera, espera, espera... ¡ya sé!"

# game/day2 choice.rpy:184
translate Spanish maidy_day2_f242e6c9:

    # maidy "Don't tell me you've already fallen victim to Maidy's charm and wanted to see Maidy again?"
    maidy "¿No me digas que ya caíste víctima del encanto de Maidy y querías volver a ver a Maidy?"

# game/day2 choice.rpy:186
translate Spanish maidy_day2_a20cefa7:

    # "..."
    "..."

# game/day2 choice.rpy:187
translate Spanish maidy_day2_c0b06805:

    # "......She really likes talking, doesn't she?"
    "......Le encanta hablar, ¿verdad?"

# game/day2 choice.rpy:188
translate Spanish maidy_day2_ba96d8ec:

    # "She kind of reminds me of Jestyn."
    "Me recuerda un poco a Jestyn."

# game/day2 choice.rpy:190
translate Spanish maidy_day2_1939c617:

    # mc "Uh... no. Wait no I mean-..."
    mc "Eh... no. Espera, no, quiero decir-..."

# game/day2 choice.rpy:192
translate Spanish maidy_day2_c07c9823:

    # maidy "Ehehehe! Just kiddinggg~"
    maidy "¡Jejeje! ¡Es broooma~!"

# game/day2 choice.rpy:193
translate Spanish maidy_day2_4b32c657:

    # maidy "I know you probably just wanted to chat with me. I'd be happy to!"
    maidy "Supongo que solo querías charlar conmigo. ¡Con gusto!"

# game/day2 choice.rpy:195
translate Spanish maidy_day2_beac8af0:

    # maidy "I hope you don't mind if I keep cleaning while we talk, Cutie Majesty~"
    maidy "Espero que no te moleste que siga limpiando mientras hablamos, Majestad Monada~"

# game/day2 choice.rpy:196
translate Spanish maidy_day2_ac0c18cf:

    # maidy "Besides, Tyntyn seemed really eager for the two of us to talk."
    maidy "Además, Tyntyn parecía muy ansioso de que hablemos."

# game/day2 choice.rpy:198
translate Spanish maidy_day2_9b79e36f:

    # maidy "And honestly? I'd do anything for Tyntyn. Hehe~"
    maidy "Y la verdad, ¿sabes? Haría cualquier cosa por Tyntyn. Jeje~"

# game/day2 choice.rpy:200
translate Spanish maidy_day2_f8b9ad3e:

    # "Tyntyn?"
    "¿Tyntyn?"

# game/day2 choice.rpy:201
translate Spanish maidy_day2_7075d093:

    # "So that's the nickname she uses for Jestyn?"
    "¿Así que ese es el apodo que usa para Jestyn?"

# game/day2 choice.rpy:202
translate Spanish maidy_day2_bbbdda3e:

    # "She seems really close to him."
    "Parece que es muy cercana a él."

# game/day2 choice.rpy:204
translate Spanish maidy_day2_ffddaa9a:

    # mc "You seem pretty close to Jestyn."
    mc "Parece que eres muy cercana a Jestyn."

# game/day2 choice.rpy:207
translate Spanish maidy_day2_6323ef3d:

    # "The moment she heard his name, Maidy's eyes practically sparkled."
    "En cuanto oyó su nombre, a Maidy prácticamente se le iluminaron los ojos."

# game/day2 choice.rpy:209
translate Spanish maidy_day2_282fea97:

    # maidy "OH, TYNTYN IS THE CUTEST JESTER EVER!!"
    maidy "¡¡OH, TYNTYN ES EL BUFÓN MÁS LINDO DEL MUNDO!!"

# game/day2 choice.rpy:211
translate Spanish maidy_day2_58ebc412:

    # maidy "Let's see... cute, cheerful, silly, handsome..."
    maidy "A ver... lindo, alegre, bobo, guapo..."

# game/day2 choice.rpy:214
translate Spanish maidy_day2_b140370f:

    # maidy "AHHHH! THERE ARE TOO MANY THINGS TO LIST!"
    maidy "¡¡AHHHH!! ¡HAY DEMASIADAS COSAS PARA ENUMERAR!"

# game/day2 choice.rpy:216
translate Spanish maidy_day2_5a8cd365:

    # maidy "IF I NEED TO CHOOSE, HE'S THE MOST PERFECT JESTYN EVER!!"
    maidy "¡¡SI TENGO QUE ELEGIR, ES EL JESTYN MÁS PERFECTO DE TODOS!!"

# game/day2 choice.rpy:218
translate Spanish maidy_day2_52090297:

    # "Maidy continued rambling on and on, showering Jestyn with praise."
    "Maidy siguió y siguió parloteando, cubriendo a Jestyn de elogios."

# game/day2 choice.rpy:219
translate Spanish maidy_day2_d030ffbb:

    # "Beside me, Jestyn wore a wide grin as he listened to every word."
    "A mi lado, Jestyn lucía una amplia sonrisa mientras escuchaba cada palabra."

# game/day2 choice.rpy:223
translate Spanish maidy_day2_de01771b:

    # jes "Oh, stop it. You're far too generous, Maidy."
    jes "Oh, basta. Eres demasiado generosa, Maidy."

# game/day2 choice.rpy:224
translate Spanish maidy_day2_1c7bd86d:

    # jes "...Though I am rather amazing~"
    jes "...Aunque sí soy bastante asombroso~"

# game/day2 choice.rpy:226
translate Spanish maidy_day2_dcfff188:

    # maidy "YEAH, YEAH! YOU ARE AMAZING, TYNTYN!!"
    maidy "¡¡SÍ, SÍ!! ¡¡ERES ASOMBROSO, TYNTYN!!"

# game/day2 choice.rpy:229
translate Spanish maidy_day2_6797c966:

    # "Without warning, Maidy wrapped her arms tightly around one of Jestyn's."
    "Sin previo aviso, Maidy rodeó con fuerza uno de los brazos de Jestyn con los suyos."

# game/day2 choice.rpy:232
translate Spanish maidy_day2_65229357:

    # "Jestyn responded by gently patting her on the head."
    "Jestyn respondió dándole unas suaves palmaditas en la cabeza."

# game/day2 choice.rpy:233
translate Spanish maidy_day2_a20cefa7_1:

    # "..."
    "..."

# game/day2 choice.rpy:234
translate Spanish maidy_day2_04e8a9a2:

    # "I felt..."
    "Sentí..."

# game/day2 choice.rpy:246
translate Spanish jealous_maidy_07bdde05:

    # "....."
    "....."

# game/day2 choice.rpy:247
translate Spanish jealous_maidy_0f3c8b8f:

    # "I felt... something."
    "Sentí... algo."

# game/day2 choice.rpy:248
translate Spanish jealous_maidy_d1bcd6ce:

    # "....I was oddly bothered by the sight."
    "....Aquella escena me incomodó de una forma extraña."

# game/day2 choice.rpy:249
translate Spanish jealous_maidy_d0f74a0d:

    # "The way Maidy clung so tightly to Jestyn's arm..."
    "La forma en que Maidy se aferraba al brazo de Jestyn..."

# game/day2 choice.rpy:250
translate Spanish jealous_maidy_1af47fab:

    # "The way he affectionately stroked her head..."
    "La forma en que él le acariciaba la cabeza con cariño..."

# game/day2 choice.rpy:251
translate Spanish jealous_maidy_6d3b8437:

    # "The way they smiled at each other..."
    "La forma en que se sonreían..."

# game/day2 choice.rpy:252
translate Spanish jealous_maidy_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:253
translate Spanish jealous_maidy_ef38d967:

    # "A painful weight settled in my chest."
    "Un peso doloroso se instaló en mi pecho."

# game/day2 choice.rpy:254
translate Spanish jealous_maidy_77f20ecc:

    # "It felt as though an invisible hand was squeezing my heart."
    "Era como si una mano invisible me estrujara el corazón."

# game/day2 choice.rpy:255
translate Spanish jealous_maidy_344a2017:

    # "Damn it... Was this jealousy?"
    "Maldición... ¿eran celos?"

# game/day2 choice.rpy:256
translate Spanish jealous_maidy_bd240eb2:

    # "My frown deepened before I even realized it."
    "Mi ceño se frunció aún más antes de que me diera cuenta."

# game/day2 choice.rpy:257
translate Spanish jealous_maidy_9b104812:

    # "The last thing I wanted was for Jestyn to see me looking like this."
    "Lo último que quería era que Jestyn me viera así."

# game/day2 choice.rpy:259
translate Spanish jealous_maidy_526cb8d2:

    # "Unfortunately, it seemed Jestyn had caught sight of my expression. His grin widened instantly."
    "Por desgracia, parecía que Jestyn había visto mi expresión. Su sonrisa se ensanchó al instante."

# game/day2 choice.rpy:260
translate Spanish jealous_maidy_a20cefa7:

    # "..."
    "..."

# game/day2 choice.rpy:261
translate Spanish jealous_maidy_a8cf0420:

    # "That bastard. He knew."
    "Ese desgraciado. Lo sabía."

# game/day2 choice.rpy:262
translate Spanish jealous_maidy_da963971:

    # "And judging by that smile, he was thoroughly enjoying it."
    "Y a juzgar por esa sonrisa, lo estaba disfrutando enormemente."

# game/day2 choice.rpy:267
translate Spanish nothing_maidy_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:268
translate Spanish nothing_maidy_6d22664a:

    # "I couldn't help but wonder about the nature of their relationship."
    "No pude evitar preguntarme cómo era su relación."

# game/day2 choice.rpy:269
translate Spanish nothing_maidy_2bf5821e:

    # "They seemed incredibly close. Maybe they were a couple?"
    "Parecían increíblemente cercanos. ¿Serían pareja?"

# game/day2 choice.rpy:270
translate Spanish nothing_maidy_719450a6:

    # "If that was the case, then I was genuinely happy for them."
    "Si ese era el caso, me alegraba sinceramente por ellos."

# game/day2 choice.rpy:272
translate Spanish nothing_maidy_7a639453:

    # "Out of the corner of my eye, I noticed Jestyn looking at me. His gaze lingered."
    "Por el rabillo del ojo, noté que Jestyn me miraba. Su mirada se demoró."

# game/day2 choice.rpy:273
translate Spanish nothing_maidy_8b5fca80:

    # "He seemed to be searching my face for something."
    "Parecía estar buscando algo en mi rostro."

# game/day2 choice.rpy:275
translate Spanish nothing_maidy_08b5a3ba:

    # "Then, little by little, his expression darkened. His brows knit together, and his smile disappeared into a thin line."
    "Entonces, poco a poco, su expresión se ensombreció. Frunció el ceño y su sonrisa se redujo a una línea fina."

# game/day2 choice.rpy:276
translate Spanish nothing_maidy_50762ea8:

    # "He looked displeased."
    "Parecía molesto."

# game/day2 choice.rpy:277
translate Spanish nothing_maidy_3ccadf76:

    # "For some reason, that expression was directed at me."
    "Por alguna razón, esa expresión iba dirigida a mí."

# game/day2 choice.rpy:278
translate Spanish nothing_maidy_cc34bea2:

    # "What??? What did I do?"
    "¿¿¿Qué??? ¿Qué hice?"

# game/day2 choice.rpy:285
translate Spanish maidy_convo2_3c912b9a:

    # jes "Maidy, darling~"
    jes "Maidy, querida~"

# game/day2 choice.rpy:286
translate Spanish maidy_convo2_472052cf:

    # jes "As delighted as I am by your affection, perhaps we should refrain from such displays in front of [poss] Majesty."
    jes "Por más que me encante tu cariño, quizá deberíamos abstenernos de tales muestras frente a Su Majestad."

# game/day2 choice.rpy:288
translate Spanish maidy_convo2_62c4113c:

    # "Maidy gasped and immediately released his arm."
    "Maidy ahogó un grito y soltó su brazo de inmediato."

# game/day2 choice.rpy:292
translate Spanish maidy_convo2_16048cf0:

    # maidy "AHHHH! I'm so sorry, Your Majesty!"
    maidy "¡AHHHH! ¡Lo siento mucho, Majestad!"

# game/day2 choice.rpy:294
translate Spanish maidy_convo2_aecb4ef5:

    # maidy "I got a little too excited!"
    maidy "¡Me emocioné un poquito de más!"

# game/day2 choice.rpy:295
translate Spanish maidy_convo2_4866334f:

    # mc "Oh... it's okay. Really."
    mc "Oh... no pasa nada. De verdad."

# game/day2 choice.rpy:299
translate Spanish maidy_convo2_ce0c53e1:

    # maidy "Eeeeh! You're so adorable, Your Majesty!"
    maidy "¡Eeeeh! ¡Qué adorable eres, Majestad!"

# game/day2 choice.rpy:301
translate Spanish maidy_convo2_8592a23b:

    # maidy "But... may I be honest?"
    maidy "Pero... ¿puedo ser sincera?"

# game/day2 choice.rpy:302
translate Spanish maidy_convo2_d425daa3:

    # mc "Sure?"
    mc "¿Claro?"

# game/day2 choice.rpy:303
translate Spanish maidy_convo2_e4a51f59:

    # maidy "At the first time I saw you, what's on my head is... I've wanted to dress you up so badly!"
    maidy "Desde la primera vez que te vi, pensé... ¡que tenía muchísimas ganas de vestirte!"

# game/day2 choice.rpy:305
translate Spanish maidy_convo2_44297153:

    # maidy "But Maidelyn would never allow it. She keeps saying it wouldn't be proper."
    maidy "Pero Maidelyn jamás lo permitiría. Siempre dice que no sería apropiado."

# game/day2 choice.rpy:306
translate Spanish maidy_convo2_bb394f19:

    # maidy "And yeah... I know she's right, but still..."
    maidy "Y sí... sé que tiene razón, pero aun así..."

# game/day2 choice.rpy:307
translate Spanish maidy_convo2_6f11e938:

    # maidy "How can our ruler walk around wearing clothes like that when you're the [title] of this kingdom?! Ughhh!!"
    maidy "¡¿Cómo puede nuestr[letra] [title!t] andar por ahí vestido así, siendo la máxima autoridad de este reino?! ¡Ughhh!"

# game/day2 choice.rpy:308
translate Spanish maidy_convo2_e315ec41:

    # maidy "But... ah, of course! I wouldn't force you."
    maidy "Pero... ¡ah, claro! No te obligaría."

# game/day2 choice.rpy:310
translate Spanish maidy_convo2_fed41402:

    # "Maidy puffed out her cheeks in a pout."
    "Maidy infló las mejillas en un puchero."

# game/day2 choice.rpy:311
translate Spanish maidy_convo2_e49caea9:

    # "She wants to dress me up...?"
    "¿Quiere vestirme...?"

# game/day2 choice.rpy:312
translate Spanish maidy_convo2_a8e212ea:

    # "Uh... I don't think I'd actually mind that."
    "Eh... creo que en realidad no me molestaría."

# game/day2 choice.rpy:314
translate Spanish maidy_convo2_b88a7824:

    # mc "Well, I guess there's no harm in it."
    mc "Bueno, supongo que no hay problema."

# game/day2 choice.rpy:317
translate Spanish maidy_convo2_c3ebfa18:

    # "Maidy's face instantly lit up."
    "El rostro de Maidy se iluminó al instante."

# game/day2 choice.rpy:319
translate Spanish maidy_convo2_70354493:

    # maidy "REALLY?!?!?!"
    maidy "¡¿DE VERDAD?!?!?!"

# game/day2 choice.rpy:320
translate Spanish maidy_convo2_5fa8c829:

    # maidy "OH, I CAN'T WAIT!!"
    maidy "¡¡OH, NO PUEDO ESPERAR!!"

# game/day2 choice.rpy:321
translate Spanish maidy_convo2_2cfa3571:

    # mc "Mmm... does that mean you like dressing other people up?"
    mc "Mmm... ¿eso significa que te gusta vestir a otras personas?"

# game/day2 choice.rpy:323
translate Spanish maidy_convo2_c1944153:

    # maidy "Yup! If I could, I'd dress up every single puppet in this kingdom!"
    maidy "¡Sip! Si pudiera, ¡vestiría a todas las marionetas de este reino!"

# game/day2 choice.rpy:324
translate Spanish maidy_convo2_0dadfe5d:

    # maidy "I'd put them all in pink clothes! Pretty, right?"
    maidy "¡Las pondría a todas con ropa rosa! ¡Qué bonito!, ¿no?"

# game/day2 choice.rpy:325
translate Spanish maidy_convo2_933bd1d3:

    # mc "Errr... yeah...?"
    mc "Emm... ¿sí...?"

# game/day2 choice.rpy:327
translate Spanish maidy_convo2_5693fae1:

    # maidy "But Your Majesty probably wouldn't allow that... Plus, Maidra would hate me."
    maidy "Pero Su Majestad probablemente no lo permitiría... Además, Maidra me odiaría."

# game/day2 choice.rpy:330
translate Spanish maidy_convo2_3fa84680:

    # maidra "I heard that."
    maidra "Lo oí."

# game/day2 choice.rpy:331
translate Spanish maidy_convo2_2b77cc57:

    # maidy "That's because I wanted you to hear me!"
    maidy "¡Es que quería que me oyeras!"

# game/day2 choice.rpy:333
translate Spanish maidy_convo2_1e5dc815:

    # maidra "How about you dye your brain pink instead? Then everything would look pink to you."
    maidra "¿Y si mejor te tiñes el cerebro de rosa? Así todo se te vería rosa."

# game/day2 choice.rpy:335
translate Spanish maidy_convo2_ff13d0cf:

    # maidy "Oh! Good idea- wait... isn't the brain already pink?"
    maidy "¡Oh! Buena idea... espera... ¿el cerebro no es ya rosa?"

# game/day2 choice.rpy:336
translate Spanish maidy_convo2_ccd3dc6b:

    # maidra "Who knows? Maybe ours are black."
    maidra "¿Quién sabe? Quizá los nuestros sean negros."

# game/day2 choice.rpy:338
translate Spanish maidy_convo2_00c9f1d8:

    # maidy "But... do we even have brains?"
    maidy "Pero... ¿acaso tenemos cerebro?"

# game/day2 choice.rpy:340
translate Spanish maidy_convo2_e6411a6d:

    # maidra "......"
    maidra "......"

# game/day2 choice.rpy:341
translate Spanish maidy_convo2_663fc7da:

    # maidy "......"
    maidy "......"

# game/day2 choice.rpy:344
translate Spanish maidy_convo2_230bf410:

    # "Somehow, the conversation had completely gone off the rails... and all I'd done was ask Maidy about fashion."
    "De algún modo, la conversación se había desviado por completo... y yo solo le había preguntado a Maidy sobre moda."

# game/day2 choice.rpy:345
translate Spanish maidy_convo2_79064d34:

    # "Maidy eventually shooed Maidra away and told her to get back to work. Finally, her attention returned to me."
    "Maidy terminó espantando a Maidra y le dijo que volviera al trabajo. Por fin, su atención volvió a mí."

# game/day2 choice.rpy:347
translate Spanish maidy_convo2_931b4c4a:

    # mc "But you must have dressed up some of the puppets here before, right?"
    mc "Pero seguro que ya has vestido a algunas de las marionetas de aquí, ¿no?"

# game/day2 choice.rpy:349
translate Spanish maidy_convo2_1840cc53:

    # maidy "Oh, of course! A few of them, actually. Maidra, for example. She's the hardest one to dress up."
    maidy "¡Oh, claro! Algunas, de hecho. Maidra, por ejemplo. Es la más difícil de vestir."

# game/day2 choice.rpy:351
translate Spanish maidy_convo2_51afc2bf:

    # maidy "She says getting dressed up makes her feel like Jestyn. You know... like a clown."
    maidy "Dice que arreglarse la hace sentir como Jestyn. Ya sabes... como un payaso."

# game/day2 choice.rpy:352
translate Spanish maidy_convo2_a18cb7d6:

    # maidy "Even though Jestyn is cool. Hmph!"
    maidy "¡Aunque Jestyn es genial! ¡Hmph!"

# game/day2 choice.rpy:354
translate Spanish maidy_convo2_4ddcf163:

    # maidy "And then there's Butl-"
    maidy "Y luego está Butl-"

# game/day2 choice.rpy:355
translate Spanish maidy_convo2_9a38bdb6:

    # maidy "........."
    maidy "........."

# game/day2 choice.rpy:359
translate Spanish maidy_convo2_11b50577:

    # "I was confused when Maidy suddenly stopped mid-sentence."
    "Me desconcertó que Maidy se detuviera de pronto a media frase."

# game/day2 choice.rpy:360
translate Spanish maidy_convo2_d92a2539:

    # "Her cheerful expression vanished, replaced by a sad one. The sudden change in her mood only left me even more confused."
    "Su expresión alegre se esfumó, reemplazada por una triste. El cambio repentino de ánimo solo me dejó más confundid[letra]."

# game/day2 choice.rpy:362
translate Spanish maidy_convo2_ab8a6a32:

    # mc "What's wrong, Maidy?"
    mc "¿Qué pasa, Maidy?"

# game/day2 choice.rpy:365
translate Spanish maidy_convo2_e525d943:

    # maidy "I mean! Yes! Maidra is one of the puppets I've dressed up before!"
    maidy "¡Quiero decir! ¡Sí! ¡Maidra es una de las marionetas que he vestido antes!"

# game/day2 choice.rpy:367
translate Spanish maidy_convo2_b693645a:

    # maidy "For now, though, I still have to finish cleaning this corridor."
    maidy "Por ahora, todavía tengo que terminar de limpiar este pasillo."

# game/day2 choice.rpy:368
translate Spanish maidy_convo2_6364632e:

    # maidy "If Your Majesty ever needs anything... orrrr wants me to dress you up, just come by my room, okay??"
    maidy "Si necesitas algo, Majestad... ooo quieres que te vista, pásate por mi cuarto, ¿sí??"

# game/day2 choice.rpy:370
translate Spanish maidy_convo2_3cdac3b1:

    # maidy "So I'll see you another time, Your Majesty~!"
    maidy "¡Así que nos vemos otro día, Majestad~!"

# game/day2 choice.rpy:381
translate Spanish maidelyn_day2_bd48e02a:

    # "I walked over to Maidelyn."
    "Me acerqué a Maidelyn."

# game/day2 choice.rpy:382
translate Spanish maidelyn_day2_dcee0cd5:

    # "From what I'd seen so far, she seemed to be the calmest of the three maids."
    "Por lo que había visto hasta ahora, parecía la más tranquila de las tres criadas."

# game/day2 choice.rpy:383
translate Spanish maidelyn_day2_a0c841ba:

    # "She was busy dusting the shelves, completely focused on her work."
    "Estaba ocupada quitando el polvo de los estantes, totalmente concentrada en su trabajo."

# game/day2 choice.rpy:384
translate Spanish maidelyn_day2_6cea0dec:

    # "I decided to quietly watch her for a moment."
    "Decidí observarla en silencio un momento."

# game/day2 choice.rpy:385
translate Spanish maidelyn_day2_3607f325:

    # "Before long, however, Maidelyn noticed my presence and offered me a gentle smile."
    "Sin embargo, al poco rato Maidelyn notó mi presencia y me dedicó una sonrisa amable."

# game/day2 choice.rpy:387
translate Spanish maidelyn_day2_4dd682fa:

    # maidelyn "Your Majesty, is there something I can help you with?"
    maidelyn "Su Majestad, ¿puedo ayudarle en algo?"

# game/day2 choice.rpy:389
translate Spanish maidelyn_day2_b7c34902:

    # "She bowed respectfully."
    "Hizo una reverencia respetuosa."

# game/day2 choice.rpy:391
translate Spanish maidelyn_day2_4899fea0:

    # mc "Mm... you looked very focused, so I didn't want to interrupt your work."
    mc "Mm... parecías muy concentrada, así que no quise interrumpir tu trabajo."

# game/day2 choice.rpy:394
translate Spanish maidelyn_day2_75e6835b:

    # "She let out a soft chuckle."
    "Soltó una suave risita."

# game/day2 choice.rpy:396
translate Spanish maidelyn_day2_de5e8f72:

    # maidelyn "Your Majesty, you are not disturbing me in the slightest, so please don't worry about that."
    maidelyn "Majestad, no me molesta en lo más mínimo, así que por favor no se preocupe por eso."

# game/day2 choice.rpy:397
translate Spanish maidelyn_day2_bb10a919:

    # maidelyn "I assume Your Majesty approached me because you wished to have a conversation?"
    maidelyn "Supongo que Su Majestad se me acercó porque deseaba conversar."

# game/day2 choice.rpy:399
translate Spanish maidelyn_day2_a7c8954c:

    # "Oh. She was quite observant."
    "Oh. Era bastante observadora."

# game/day2 choice.rpy:401
translate Spanish maidelyn_day2_74ece181:

    # mc "Actually, yes. If you don't mind."
    mc "En realidad, sí. Si no te molesta."

# game/day2 choice.rpy:403
translate Spanish maidelyn_day2_0efd518d:

    # maidelyn "Of course, Your Majesty."
    maidelyn "Por supuesto, Majestad."

# game/day2 choice.rpy:404
translate Spanish maidelyn_day2_0bcfafca:

    # mc "......So..."
    mc "......Entonces..."

# game/day2 choice.rpy:406
translate Spanish maidelyn_day2_50442411:

    # "I glanced around the room while trying to think of a topic."
    "Eché un vistazo a la habitación mientras intentaba pensar en un tema."

# game/day2 choice.rpy:407
translate Spanish maidelyn_day2_c709f4f8:

    # "I should probably start with something simple."
    "Probablemente debería empezar por algo sencillo."

# game/day2 choice.rpy:409
translate Spanish maidelyn_day2_c69b8cbd:

    # mc "Do you have any hobbies?"
    mc "¿Tienes algún pasatiempo?"

# game/day2 choice.rpy:411
translate Spanish maidelyn_day2_1750d5e9:

    # maidelyn "Hobbies?"
    maidelyn "¿Pasatiempos?"

# game/day2 choice.rpy:412
translate Spanish maidelyn_day2_2abe06a8:

    # mc "Yes. I'd like to get to know you better... I mean, as the ruler of this kingdom."
    mc "Sí. Me gustaría conocerte mejor... quiero decir, como gobernante de este reino."

# game/day2 choice.rpy:413
translate Spanish maidelyn_day2_e4511cf9:

    # maidelyn "I see."
    maidelyn "Ya veo."

# game/day2 choice.rpy:415
translate Spanish maidelyn_day2_958524f7:

    # "She fell silent for a moment, thoughtfully tapping her chin."
    "Guardó silencio un momento, golpeándose pensativamente la barbilla con un dedo."

# game/day2 choice.rpy:417
translate Spanish maidelyn_day2_e09bc715:

    # maidelyn "Do you enjoy tea parties, Your Majesty?"
    maidelyn "¿Le gustan las fiestas del té, Majestad?"

# game/day2 choice.rpy:419
translate Spanish maidelyn_day2_3a2b30a1:

    # "I perked up."
    "Me animé."

# game/day2 choice.rpy:421
translate Spanish maidelyn_day2_7e519527:

    # mc "Tea parties?"
    mc "¿Fiestas del té?"

# game/day2 choice.rpy:422
translate Spanish maidelyn_day2_0249172d:

    # maidelyn "Yes."
    maidelyn "Sí."

# game/day2 choice.rpy:423
translate Spanish maidelyn_day2_b5e1ef6d:

    # maidelyn "I occasionally host tea parties with my sisters or the other puppets."
    maidelyn "De vez en cuando organizo fiestas del té con mis hermanas o con las otras marionetas."

# game/day2 choice.rpy:424
translate Spanish maidelyn_day2_96324996:

    # maidelyn "Sometimes, I even hold them by myself."
    maidelyn "A veces, incluso las hago yo sola."

# game/day2 choice.rpy:425
translate Spanish maidelyn_day2_bd85eec7:

    # maidelyn "Now that I think about it, I suppose that would be my hobby."
    maidelyn "Pensándolo bien, supongo que ese sería mi pasatiempo."

# game/day2 choice.rpy:427
translate Spanish maidelyn_day2_83911cce:

    # maidelyn "If it pleases Your Majesty, perhaps we could share tea together someday?"
    maidelyn "Si a Su Majestad le place, ¿quizá podríamos compartir un té algún día?"

# game/day2 choice.rpy:429
translate Spanish maidelyn_day2_d700afde:

    # "The idea of attending a tea party sounded incredibly elegant."
    "La idea de asistir a una fiesta del té sonaba increíblemente elegante."

# game/day2 choice.rpy:430
translate Spanish maidelyn_day2_f65e9fd3:

    # "To me, tea parties were the sort of thing only wealthy nobles and high society people held."
    "Para mí, las fiestas del té eran cosa de nobles adinerados y gente de la alta sociedad."

# game/day2 choice.rpy:431
translate Spanish maidelyn_day2_ffe57a30:

    # "At least, that's how they were always portrayed in the books I'd read."
    "Al menos, así las retrataban siempre los libros que había leído."

# game/day2 choice.rpy:432
translate Spanish maidelyn_day2_076a5f50:

    # "Because of that, I'd never once imagined myself attending one."
    "Por eso, jamás me había imaginado asistiendo a una."

# game/day2 choice.rpy:433
translate Spanish maidelyn_day2_b3e12ea5:

    # "Still..."
    "Aun así..."

# game/day2 choice.rpy:434
translate Spanish maidelyn_day2_10fcb14b:

    # "I couldn't deny that the thought made me feel strangely sophisticated."
    "No podía negar que la idea me hacía sentir extrañamente sofisticad[letra]."

# game/day2 choice.rpy:436
translate Spanish maidelyn_day2_fb76d793:

    # mc "To be honest, I've never attended a tea party in my entire life."
    mc "Para ser sincer[letra], nunca he ido a una fiesta del té en toda mi vida."

# game/day2 choice.rpy:437
translate Spanish maidelyn_day2_37a0ce8f:

    # mc "But it sounds fun, so why not?"
    mc "Pero suena divertido, así que ¿por qué no?"

# game/day2 choice.rpy:440
translate Spanish maidelyn_day2_e957ef88:

    # "Maidelyn's smile widened, and she nodded approvingly."
    "La sonrisa de Maidelyn se ensanchó y asintió con aprobación."

# game/day2 choice.rpy:442
translate Spanish maidelyn_day2_6d3eecfe:

    # maidelyn "I'm delighted to hear that, Your Majesty."
    maidelyn "Me alegra mucho oírlo, Majestad."

# game/day2 choice.rpy:444
translate Spanish maidelyn_day2_87602379:

    # maidelyn "And please don't worry if you've never attended one before."
    maidelyn "Y por favor, no se preocupe si nunca ha asistido a una."

# game/day2 choice.rpy:445
translate Spanish maidelyn_day2_82c6c0b5:

    # maidelyn "I'd be more than happy to teach you proper tea party etiquette when the time comes."
    maidelyn "Con muchísimo gusto le enseñaré la etiqueta adecuada para las fiestas del té cuando llegue el momento."

# game/day2 choice.rpy:447
translate Spanish maidelyn_day2_0df08c12:

    # "I nodded enthusiastically."
    "Asentí con entusiasmo."

# game/day2 choice.rpy:448
translate Spanish maidelyn_day2_ba9a2053:

    # "The two of us spent the next few minutes chatting about tea parties."
    "Pasamos los siguientes minutos charlando sobre fiestas del té."

# game/day2 choice.rpy:450
translate Spanish maidelyn_day2_a6adcc62:

    # maidelyn "...Something just crossed my mind, Your Majesty."
    maidelyn "...Se me acaba de ocurrir algo, Majestad."

# game/day2 choice.rpy:451
translate Spanish maidelyn_day2_dac46297:

    # mc "Oh? What is it?"
    mc "¿Oh? ¿Qué cosa?"

# game/day2 choice.rpy:453
translate Spanish maidelyn_day2_04def0bc:

    # "Maidelyn stopped dusting the area around her. Her gaze shifted toward me, fully focused."
    "Maidelyn dejó de quitar el polvo a su alrededor. Su mirada se dirigió hacia mí, completamente enfocada."

# game/day2 choice.rpy:454
translate Spanish maidelyn_day2_b2889bdb:

    # "For some reason, the atmosphere around us suddenly felt a little more tense... more serious."
    "Por alguna razón, el ambiente a nuestro alrededor se volvió de pronto un poco más tenso... más serio."

# game/day2 choice.rpy:455
translate Spanish maidelyn_day2_2453eaef:

    # "And somehow, that made me feel a little nervous."
    "Y de algún modo, eso me puso un poco nervios[letra]."

# game/day2 choice.rpy:457
translate Spanish maidelyn_day2_33ea51c7:

    # maidelyn "Will you drink the tea I serve you when Your Majesty attends my tea party later?"
    maidelyn "¿Beberá el té que le sirva cuando Su Majestad asista más adelante a mi fiesta del té?"

# game/day2 choice.rpy:458
translate Spanish maidelyn_day2_05500ff6:

    # mc "Huh?"
    mc "¿Eh?"

# game/day2 choice.rpy:460
translate Spanish maidelyn_day2_2d5ec8fa:

    # "Her sudden question made me wonder."
    "Su repentina pregunta me dejó pensando."

# game/day2 choice.rpy:461
translate Spanish maidelyn_day2_e8641605:

    # "I mean... why would she think I wouldn't drink the tea she served me?"
    "Quiero decir... ¿por qué pensaría ella que no me bebería el té que me sirviera?"

# game/day2 choice.rpy:462
translate Spanish maidelyn_day2_13c5246e:

    # "But... was this a trick question? Was she testing me?"
    "Pero... ¿era una pregunta trampa? ¿Me estaba poniendo a prueba?"

# game/day2 choice.rpy:466
translate Spanish maidelyn_day2_01de6b39:

    # mc "Of course. Why wouldn't I? You went through all that trouble to make it for me, after all."
    mc "Claro. ¿Por qué no iba a hacerlo? Te tomaste todo ese trabajo para prepararlo para mí, después de todo."

# game/day2 choice.rpy:468
translate Spanish maidelyn_day2_adc21bdc:

    # "Maidelyn let out a soft chuckle."
    "Maidelyn soltó una suave risita."

# game/day2 choice.rpy:470
translate Spanish maidelyn_day2_af6cd924:

    # maidelyn "Is that so? You're a kind person, Your Majesty."
    maidelyn "¿De veras? Es usted una persona amable, Majestad."

# game/day2 choice.rpy:473
translate Spanish maidelyn_day2_07bdde05:

    # "....."
    "....."

# game/day2 choice.rpy:474
translate Spanish maidelyn_day2_ee2ad411:

    # "Now that I thought about it... I couldn't shake the feeling that something was off. A sense of caution began to settle over me."
    "Ahora que lo pensaba... no podía quitarme la sensación de que algo andaba mal. Una sensación de cautela empezó a instalarse en mí."

# game/day2 choice.rpy:475
translate Spanish maidelyn_day2_c890f208:

    # "Of course... she must have had another reason for asking me that question."
    "Claro... ella debía de tener otra razón para hacerme esa pregunta."

# game/day2 choice.rpy:477
translate Spanish maidelyn_day2_4f6a91fb:

    # mc "After you asked me that... honestly, you made me think twice..."
    mc "Después de que me preguntaras eso... la verdad es que me hiciste pensarlo dos veces..."

# game/day2 choice.rpy:478
translate Spanish maidelyn_day2_918fea83:

    # mc "I'm sorry."
    mc "Lo siento."

# game/day2 choice.rpy:480
translate Spanish maidelyn_day2_1db57963:

    # "Maidelyn simply answered with a smile before going back to dusting."
    "Maidelyn solo respondió con una sonrisa antes de volver a quitar el polvo."

# game/day2 choice.rpy:482
translate Spanish maidelyn_day2_4ed2016a:

    # maidelyn "It's alright, Your Majesty. It's good to be cautious."
    maidelyn "No pasa nada, Majestad. Es bueno andarse con cuidado."

# game/day2 choice.rpy:485
translate Spanish maidelyn_day2_30db703f:

    # maidelyn "I didn't mean to frighten you. I wouldn't put anything in your tea, so don't worry."
    maidelyn "No era mi intención asustarle. No pondría nada en su té, así que no se preocupe."

# game/day2 choice.rpy:486
translate Spanish maidelyn_day2_dc5b65ef:

    # maidelyn "I only wanted to remind you that there are many two-faced people in this world, Your Majesty."
    maidelyn "Solo quería recordarle que en este mundo hay muchas personas de doble cara, Majestad."

# game/day2 choice.rpy:487
translate Spanish maidelyn_day2_33ff1fe0:

    # maidelyn "They're everywhere. In friendships, in our homes..."
    maidelyn "Están por todas partes. En las amistades, en nuestros hogares..."

# game/day2 choice.rpy:488
translate Spanish maidelyn_day2_3e6339a2:

    # maidelyn "Or even... in this kingdom."
    maidelyn "O incluso... en este reino."

# game/day2 choice.rpy:490
translate Spanish maidelyn_day2_fed1b6db:

    # "Maidelyn's gaze returned to me."
    "La mirada de Maidelyn volvió a mí."

# game/day2 choice.rpy:492
translate Spanish maidelyn_day2_258f5d0b:

    # maidelyn "Don't be too quick to trust the people around you."
    maidelyn "No confíe demasiado rápido en quienes le rodean."

# game/day2 choice.rpy:493
translate Spanish maidelyn_day2_61474f28:

    # mc "T-thank you for the advice... but... why are you suddenly telling me this...?"
    mc "G-gracias por el consejo... pero... ¿por qué me dices esto de repente...?"

# game/day2 choice.rpy:495
translate Spanish maidelyn_day2_5a8b851f:

    # "Maidelyn simply smiled."
    "Maidelyn solo sonrió."

# game/day2 choice.rpy:497
translate Spanish maidelyn_day2_777567e0:

    # maidelyn "You'll find out... if you're not careful."
    maidelyn "Lo descubrirá... si no tiene cuidado."

# game/day2 choice.rpy:498
translate Spanish maidelyn_day2_25191456:

    # mc "Hey, don't scare me like that!"
    mc "¡Oye, no me asustes así!"

# game/day2 choice.rpy:500
translate Spanish maidelyn_day2_a6c9cb7e:

    # maidelyn "Hahaha, forgive me. I was only teasing, Your Majesty."
    maidelyn "Jajaja, perdóneme. Solo bromeaba, Majestad."

# game/day2 choice.rpy:501
translate Spanish maidelyn_day2_f076fe73:

    # mc "Were you teasing, or were you being serious??"
    mc "¿¿Bromeabas o hablabas en serio??"

# game/day2 choice.rpy:503
translate Spanish maidelyn_day2_a4e11a34:

    # maidelyn "Maybe I was~ Maybe I wasn't~"
    maidelyn "Quizá sí~ Quizá no~"

# game/day2 choice.rpy:504
translate Spanish maidelyn_day2_699878f6:

    # mc "Hey!"
    mc "¡Oye!"

# game/day2 choice.rpy:507
translate Spanish maidelyn_day2_afb65dd1:

    # "By the end of our conversation, I found myself genuinely looking forward to attending one."
    "Al final de nuestra conversación, me descubrí con verdaderas ganas de asistir a una."

# game/day2 choice.rpy:520
translate Spanish maidra_day2_267ab8c4:

    # "I made my way over to Maidra."
    "Me dirigí hacia Maidra."

# game/day2 choice.rpy:521
translate Spanish maidra_day2_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:522
translate Spanish maidra_day2_e37734f3:

    # "To be honest, this maid scared me a little."
    "Para ser sincer[letra], esta criada me daba un poco de miedo."

# game/day2 choice.rpy:523
translate Spanish maidra_day2_b812d894:

    # "I mean, just looking at her face made me feel like she might punch me if I said the wrong thing..."
    "Es decir, solo con ver su cara sentía que podría darme un puñetazo si decía algo equivocado..."

# game/day2 choice.rpy:524
translate Spanish maidra_day2_469cd171:

    # "Maybe."
    "Quizá."

# game/day2 choice.rpy:525
translate Spanish maidra_day2_b4bfa8af:

    # "She was busy sweeping the floor, completely focused on her work."
    "Estaba barriendo el suelo, completamente concentrada en su trabajo."

# game/day2 choice.rpy:526
translate Spanish maidra_day2_8a30987a:

    # "My body hesitated before I could approach her. In the end, I stopped in my tracks."
    "Mi cuerpo dudó antes de que pudiera acercarme a ella. Al final, me detuve en seco."

# game/day2 choice.rpy:527
translate Spanish maidra_day2_3ae4db7e:

    # "Was this really a good idea?"
    "¿Era de verdad una buena idea?"

# game/day2 choice.rpy:528
translate Spanish maidra_day2_afa7d8f4:

    # "Jestyn placed a hand on my back, encouraging me forward."
    "Jestyn me puso una mano en la espalda, animándome a avanzar."

# game/day2 choice.rpy:530
translate Spanish maidra_day2_fcb6176c:

    # jes "It's alright, Your Majesty."
    jes "No pasa nada, Majestad."

# game/day2 choice.rpy:531
translate Spanish maidra_day2_eea4ed1f:

    # jes "Maidra may look intimidating, but she's actually quite fun."
    jes "Maidra puede parecer intimidante, pero en realidad es bastante divertida."

# game/day2 choice.rpy:533
translate Spanish maidra_day2_cd4fc26b:

    # jes "...Well. Somewhat."
    jes "...Bueno. Más o menos."

# game/day2 choice.rpy:537
translate Spanish maidra_day2_bcb40e36:

    # maidra "The hell do you mean 'somewhat,' you idiot clown?"
    maidra "¿Qué demonios quieres decir con 'más o menos', payaso idiota?"

# game/day2 choice.rpy:539
translate Spanish maidra_day2_8b4f4587:

    # "I jumped when Maidra suddenly shouted at Jestyn."
    "Me sobresalté cuando Maidra le gritó de repente a Jestyn."

# game/day2 choice.rpy:545
translate Spanish maidra_day2_99b306df:

    # jes "Yeesh... Could that voice of yours be any louder? The royal trumpets are getting jealous."
    jes "Uf... ¿Podría esa voz tuya ser más fuerte? Las trompetas reales se están poniendo celosas."

# game/day2 choice.rpy:547
translate Spanish maidra_day2_171f4cf7:

    # maidra "I SAID WHAT THE HELL DID YOU MEAN, YOU IDIOT CLOWN?!"
    maidra "¡DIJE QUÉ DEMONIOS QUISISTE DECIR, PAYASO IDIOTA!"

# game/day2 choice.rpy:550
translate Spanish maidra_day2_6b82cc97:

    # "Jestyn let out a weary sigh."
    "Jestyn soltó un suspiro cansado."

# game/day2 choice.rpy:553
translate Spanish maidra_day2_b9fa6422:

    # jes "Tsk. You're even more troublesome than Knighter."
    jes "Tsk. Eres aún más problemática que Knighter."

# game/day2 choice.rpy:555
translate Spanish maidra_day2_bdaa5708:

    # maidra "Why, thank you."
    maidra "Gracias, qué amable."

# game/day2 choice.rpy:556
translate Spanish maidra_day2_10ab8ba1:

    # maidra "I do enjoy being able to rival that hotheaded bastard."
    maidra "Me gusta poder rivalizar con ese bastardo cabeza caliente."

# game/day2 choice.rpy:558
translate Spanish maidra_day2_3c89fae4:

    # jes "Heh. At least he doesn't scream like a lunatic every five minutes."
    jes "Je. Al menos él no grita como un lunático cada cinco minutos."

# game/day2 choice.rpy:561
translate Spanish maidra_day2_66ef6c5b:

    # maidra "WHAT?!"
    maidra "¡¿QUÉ?!"

# game/day2 choice.rpy:564
translate Spanish maidra_day2_29165815:

    # "Jestyn merely laughed in response to Maidra's outraged yell."
    "Jestyn simplemente se rio en respuesta al furioso grito de Maidra."

# game/day2 choice.rpy:565
translate Spanish maidra_day2_85830bc3:

    # "Eventually, he turned back to me."
    "Al final, se volvió hacia mí."

# game/day2 choice.rpy:568
translate Spanish maidra_day2_9c6703b7:

    # jes "Now shut that mouth of yours."
    jes "Ahora cierra esa boca tuya."

# game/day2 choice.rpy:569
translate Spanish maidra_day2_190a4ccd:

    # jes "You're going to scare [poss] Majesty away."
    jes "Vas a asustar a Su Majestad."

# game/day2 choice.rpy:571
translate Spanish maidra_day2_7332e674:

    # "Maidra's gaze shifted toward me."
    "La mirada de Maidra se dirigió hacia mí."

# game/day2 choice.rpy:572
translate Spanish maidra_day2_70f416c3:

    # "She looked me over, one eyebrow raised."
    "Me repasó de arriba abajo, con una ceja levantada."

# game/day2 choice.rpy:574
translate Spanish maidra_day2_c08d113f:

    # "Then she smirked."
    "Entonces sonrió con suficiencia."

# game/day2 choice.rpy:576
translate Spanish maidra_day2_ce58d524:

    # maidra "Ohhhh..."
    maidra "Ohhhh..."

# game/day2 choice.rpy:577
translate Spanish maidra_day2_084b35d4:

    # maidra "Scare away [poss] Majesty, huh?"
    maidra "¿Asustar a Su Majestad, eh?"

# game/day2 choice.rpy:578
translate Spanish maidra_day2_6a92131e:

    # maidra "What kind of [title] gets intimidated so easily?"
    maidra "¿Qué clase de [title!t] se intimida tan fácil?"

# game/day2 choice.rpy:579
translate Spanish maidra_day2_c31967cd:

    # maidra "One little growl and they run off like a frightened rabbit?"
    maidra "¿Un pequeño gruñido y salen huyendo como un conejo asustado?"

# game/day2 choice.rpy:581
translate Spanish maidra_day2_bc575e04:

    # "I frowned."
    "Fruncí el ceño."

# game/day2 choice.rpy:583
translate Spanish maidra_day2_dd089b3f:

    # maidra "What's wrong, Your Majesty?"
    maidra "¿Qué pasa, Majestad?"

# game/day2 choice.rpy:584
translate Spanish maidra_day2_27fc4204:

    # maidra "Don't tell me you're offended?"
    maidra "No me digas que te ofendiste."

# game/day2 choice.rpy:586
translate Spanish maidra_day2_86b5fc92:

    # "Her words irritated me."
    "Sus palabras me irritaron."

# game/day2 choice.rpy:587
translate Spanish maidra_day2_315bf3b3:

    # "I knew I was scared of her, but..."
    "Sabía que le tenía miedo, pero..."

# game/day2 choice.rpy:588
translate Spanish maidra_day2_de309ed9:

    # "For some reason, being called a coward bothered me far more than it should have."
    "Por alguna razón, que me llamara cobarde me molestaba mucho más de lo debido."

# game/day2 choice.rpy:589
translate Spanish maidra_day2_0821122a:

    # "I didn't want to be seen as someone weak. So I took a deep breath."
    "No quería que me vieran como alguien débil. Así que respiré hondo."

# game/day2 choice.rpy:591
translate Spanish maidra_day2_3d8f9aab:

    # mc "You..."
    mc "Tú..."

# game/day2 choice.rpy:592
translate Spanish maidra_day2_2c827340:

    # mc "What gives you the right to call me a coward?"
    mc "¿Qué te da derecho a llamarme cobarde?"

# game/day2 choice.rpy:595
translate Spanish maidra_day2_60203bf9:

    # "One of Maidra's eyebrows rose."
    "Una de las cejas de Maidra se arqueó."

# game/day2 choice.rpy:597
translate Spanish maidra_day2_90415c7f:

    # mc "You can't judge a person just by looking at them."
    mc "No puedes juzgar a una persona solo por su apariencia."

# game/day2 choice.rpy:598
translate Spanish maidra_day2_786d9145:

    # mc "So don't go around calling me a coward."
    mc "Así que no vayas por ahí llamándome cobarde."

# game/day2 choice.rpy:599
translate Spanish maidra_day2_053d1dfd:

    # mc "If you're so confident, then come fight me."
    mc "Si tienes tanta confianza, entonces ven a pelear conmigo."

# game/day2 choice.rpy:602
translate Spanish maidra_day2_380afc8c:

    # maidra "..................."
    maidra "..................."

# game/day2 choice.rpy:603
translate Spanish maidra_day2_aec4aaa4:

    # jes "..................."
    jes "..................."

# game/day2 choice.rpy:604
translate Spanish maidra_day2_f802a4c9:

    # mc "................"
    mc "................"

# game/day2 choice.rpy:606
translate Spanish maidra_day2_a24ae866:

    # "What the hell did I just say?!"
    "¡¿Qué demonios acabo de decir?!"

# game/day2 choice.rpy:610
translate Spanish maidra_day2_a35ab0df:

    # maidra "Pfft..."
    maidra "Pfft..."

# game/day2 choice.rpy:614
translate Spanish maidra_day2_8cc871f2:

    # "After hearing my ridiculous challenge, Maidra burst out laughing as though it was the funniest thing she'd ever heard."
    "Tras oír mi ridículo desafío, Maidra estalló en carcajadas como si fuera lo más gracioso que hubiera oído jamás."

# game/day2 choice.rpy:615
translate Spanish maidra_day2_c1cf1f36:

    # "Beside me, Jestyn was clearly struggling to keep a straight face."
    "A mi lado, Jestyn se esforzaba claramente por mantener la cara seria."

# game/day2 choice.rpy:618
translate Spanish maidra_day2_606aa9c3:

    # maidra "Hahaha! Your Majesty, you're actually pretty funny."
    maidra "¡Jajaja! Majestad, la verdad es que tienes gracia."

# game/day2 choice.rpy:619
translate Spanish maidra_day2_af1caede:

    # maidra "Heh, I was only teasing you."
    maidra "Je, solo te estaba molestando."

# game/day2 choice.rpy:620
translate Spanish maidra_day2_6776f236:

    # maidra "But after that reaction, now I kind of want to keep messing with you."
    maidra "Pero después de esa reacción, ahora casi quiero seguir fastidiándote."

# game/day2 choice.rpy:621
translate Spanish maidra_day2_b53ab35c:

    # maidra "Challenging a puppet who's twice your size takes guts."
    maidra "Desafiar a una marioneta del doble de tu tamaño requiere agallas."

# game/day2 choice.rpy:622
translate Spanish maidra_day2_324ac92d:

    # maidra "Stupid guts, but guts nonetheless."
    maidra "Agallas estúpidas, pero agallas al fin."

# game/day2 choice.rpy:624
translate Spanish maidra_day2_f4fc6531:

    # "I could feel my face burning with embarrassment."
    "Sentí que mi cara ardía de vergüenza."

# game/day2 choice.rpy:625
translate Spanish maidra_day2_c09437eb:

    # "At that moment, I wanted nothing more than to dig the deepest hole imaginable and throw myself into it."
    "En ese momento, lo único que quería era cavar el hoyo más profundo imaginable y arrojarme dentro."

# game/day2 choice.rpy:627
translate Spanish maidra_day2_522329bf:

    # maidra "But sure, Your Majesty. Why not?"
    maidra "Pero claro, Majestad. ¿Por qué no?"

# game/day2 choice.rpy:628
translate Spanish maidra_day2_079d3e3a:

    # maidra "Maybe someday we can arm wrestle. Or have a race."
    maidra "Quizá algún día podamos echar un pulso. O una carrera."

# game/day2 choice.rpy:629
translate Spanish maidra_day2_70437e1b:

    # maidra "Or wrestle."
    maidra "O luchar."

# game/day2 choice.rpy:631
translate Spanish maidra_day2_f23645c7:

    # "I was beginning to regret challenging her."
    "Empezaba a arrepentirme de haberla desafiado."

# game/day2 choice.rpy:632
translate Spanish maidra_day2_423889cb:

    # "I was absolutely going to die."
    "Iba a morir sin ninguna duda."

# game/day2 choice.rpy:635
translate Spanish maidra_day2_5820a515:

    # maidra "And if you win, maybe I'll grant you whatever you want."
    maidra "Y si ganas, quizá te conceda lo que quieras."

# game/day2 choice.rpy:636
translate Spanish maidra_day2_ec3ac3a3:

    # maidra "But if I win..."
    maidra "Pero si gano yo..."

# game/day2 choice.rpy:639
translate Spanish maidra_day2_dc99128d:

    # maidra "You have to let me eat you."
    maidra "Tienes que dejar que te coma."

# game/day2 choice.rpy:641
translate Spanish maidra_day2_0fd4d656_1:

    # "......"
    "......"

# game/day2 choice.rpy:643
translate Spanish maidra_day2_bc9eef2a:

    # mc "I'm sorry, what?"
    mc "Perdón, ¿qué?"

# game/day2 choice.rpy:646
translate Spanish maidra_day2_40d8c3d2:

    # "I stared at Maidra in confusion."
    "Miré a Maidra con confusión."

# game/day2 choice.rpy:647
translate Spanish maidra_day2_cbc818a1:

    # "For a moment, I thought I must have misheard her."
    "Por un momento pensé que había oído mal."

# game/day2 choice.rpy:648
translate Spanish maidra_day2_a6676534:

    # "But judging by the grin still plastered across her face, I definitely hadn't."
    "Pero a juzgar por la sonrisa que seguía pegada en su cara, definitivamente no."

# game/day2 choice.rpy:650
translate Spanish maidra_day2_894ed06b:

    # jes "Maidra."
    jes "Maidra."

# game/day2 choice.rpy:652
translate Spanish maidra_day2_f143d650:

    # "I felt Jestyn's hand settle against my shoulder blade, gently pulling me a little closer to him."
    "Sentí la mano de Jestyn posarse en mi omóplato, acercándome suavemente hacia él."

# game/day2 choice.rpy:656
translate Spanish maidra_day2_37091239:

    # jes "Those are rather inappropriate things to say to Your Majesty, don't you think?"
    jes "Esas son cosas bastante inapropiadas para decirle a Su Majestad, ¿no crees?"

# game/day2 choice.rpy:660
translate Spanish maidra_day2_067a2a7e:

    # "Maidra rolled her eyes and clicked her tongue."
    "Maidra puso los ojos en blanco y chasqueó la lengua."

# game/day2 choice.rpy:663
translate Spanish maidra_day2_6cba3706:

    # maidra "Obviously I was joking, you idiot clown."
    maidra "Obviamente estaba bromeando, payaso idiota."

# game/day2 choice.rpy:664
translate Spanish maidra_day2_3927f6d0:

    # maidra "No need to get all possessive like that."
    maidra "No hace falta que te pongas tan posesivo."

# game/day2 choice.rpy:665
translate Spanish maidra_day2_d053b528:

    # maidra "Seriously, it's embarrassing to watch."
    maidra "En serio, da vergüenza ajena verlo."

# game/day2 choice.rpy:667
translate Spanish maidra_day2_c68ba068:

    # jes "Possessive? Me?"
    jes "¿Posesivo? ¿Yo?"

# game/day2 choice.rpy:669
translate Spanish maidra_day2_1940c243:

    # maidra "Please. You're about as subtle as a brick to the face."
    maidra "Por favor. Eres tan sutil como un ladrillazo en la cara."

# game/day2 choice.rpy:673
translate Spanish maidra_day2_64202584:

    # "Maidra waved him off."
    "Maidra le restó importancia con un gesto."

# game/day2 choice.rpy:676
translate Spanish maidra_day2_ebe76903:

    # maidra "Ahhh, alright. So, why have you come to see me, Your Majesty? I assume you wanted to have a little chat with me?"
    maidra "Ahhh, bien. Entonces, ¿por qué has venido a verme, Majestad? Supongo que querías charlar un rato conmigo."

# game/day2 choice.rpy:677
translate Spanish maidra_day2_17e5d073:

    # mc "Yeah. Is it that obvious?"
    mc "Sí. ¿Tan obvio es?"

# game/day2 choice.rpy:678
translate Spanish maidra_day2_e1e7a3a9:

    # maidra "Not really. I wasn't paying much attention. It's just that Jestyn did plan on having you talk to me, so..."
    maidra "No mucho. No estaba prestando mucha atención. Es solo que Jestyn tenía planeado que hablaras conmigo, así que..."

# game/day2 choice.rpy:679
translate Spanish maidra_day2_aad81a1d:

    # maidra "What do you want to know about me?"
    maidra "¿Qué quieres saber de mí?"

# game/day2 choice.rpy:681
translate Spanish maidra_day2_ccbe7755:

    # maidra "If you're asking about my hobbies or things I like, that's fine... but that's kind of mainstream."
    maidra "Si preguntas por mis pasatiempos o cosas que me gustan, está bien... pero eso es algo muy común."

# game/day2 choice.rpy:683
translate Spanish maidra_day2_d936528a:

    # "......Actually, that was exactly what I was about to ask."
    "......En realidad, eso era justo lo que iba a preguntar."

# game/day2 choice.rpy:684
translate Spanish maidra_day2_a7842b24:

    # "What kind of topic would Maidra actually find interesting...? I'm not very good at coming up with unusual conversation topics."
    "¿Qué tema le parecería realmente interesante a Maidra...? No se me da bien pensar en temas de conversación inusuales."

# game/day2 choice.rpy:685
translate Spanish maidra_day2_8355b6c4:

    # "Was I seriously going to ask, 'What if you were a worm?'"
    "¿De verdad iba a preguntarle: '¿Qué pasaría si fueras un gusano?'?"

# game/day2 choice.rpy:687
translate Spanish maidra_day2_c5c23b9f:

    # maidra "And don't ask me, 'What if I'm a worm?' That's weird, and I don't like it. WTF, I'm not a worm. There is no 'what if'."
    maidra "Y no me preguntes: '¿Y si fuera un gusano?'. Es raro y no me gusta. ¡¿Qué carajos?! No soy un gusano. No existe ningún 'y si'."

# game/day2 choice.rpy:689
translate Spanish maidra_day2_807f9fea:

    # "......Ok.."
    "......Ok.."

# game/day2 choice.rpy:690
translate Spanish maidra_day2_93de6e5a:

    # "Maidra continued sweeping the floor."
    "Maidra siguió barriendo el suelo."

# game/day2 choice.rpy:691
translate Spanish maidra_day2_2eec1ff4:

    # "I noticed that she occasionally looked annoyed with her maid dress."
    "Noté que de vez en cuando parecía fastidiada con su vestido de criada."

# game/day2 choice.rpy:694
translate Spanish maidra_day2_3c812bed:

    # maidra "Ugh, this maid dress keeps getting in the way when I'm sweeping... How do Maidelyn and Maidy even clean in outfits like this? Ugh, so annoying..."
    maidra "Ugh, este vestido de criada me estorba al barrer... ¿Cómo hacen Maidelyn y Maidy para limpiar con ropa así? Ugh, qué fastidio..."

# game/day2 choice.rpy:696
translate Spanish maidra_day2_166a8443:

    # maidra "Anyway, I'll keep sweeping while I wait for your question, Your Majesty."
    maidra "En fin, seguiré barriendo mientras espero tu pregunta, Majestad."

# game/day2 choice.rpy:697
translate Spanish maidra_day2_cfc020d9:

    # mc "Oh... uh... you don't like your maid dress?"
    mc "Oh... eh... ¿no te gusta tu vestido de criada?"

# game/day2 choice.rpy:698
translate Spanish maidra_day2_0a29702c:

    # maidra "What? Oh... yeah. You could say that."
    maidra "¿Qué? Oh... sí. Se podría decir que sí."

# game/day2 choice.rpy:699
translate Spanish maidra_day2_2876efd9:

    # mc "Why?"
    mc "¿Por qué?"

# game/day2 choice.rpy:701
translate Spanish maidra_day2_e2233952:

    # maidra "Well... it's hard to move in! I mean... I want to be able to run around as much as I want without having to lift my dress first."
    maidra "Pues... ¡es difícil moverse con él! Es decir... quiero poder correr todo lo que quiera sin tener que levantarme el vestido primero."

# game/day2 choice.rpy:702
translate Spanish maidra_day2_4a589bdb:

    # maidra "Like, pants. If you wanna run, you just run. It's way less troublesome than a dress."
    maidra "Como los pantalones. Si quieres correr, simplemente corres. Es mucho menos complicado que un vestido."

# game/day2 choice.rpy:703
translate Spanish maidra_day2_170de5cd:

    # mc "I see... Maybe you'd like your maid uniform more if it had pants instead of a skirt."
    mc "Ya veo... Quizá te gustaría más tu uniforme de criada si tuviera pantalones en vez de falda."

# game/day2 choice.rpy:705
translate Spanish maidra_day2_316f2aeb:

    # maidra "........"
    maidra "........"

# game/day2 choice.rpy:707
translate Spanish maidra_day2_f49b8666:

    # maidra "Honestly, I don't really like my role as a maid."
    maidra "La verdad, no me gusta mucho mi papel de criada."

# game/day2 choice.rpy:708
translate Spanish maidra_day2_c452e054:

    # maidra "I don't know... the maid outfit just feels too feminine to me. And I'd rather wear something cool!"
    maidra "No sé... el uniforme de criada me parece demasiado femenino. ¡Y preferiría llevar algo genial!"

# game/day2 choice.rpy:709
translate Spanish maidra_day2_96d4380d:

    # maidra "Like armor..."
    maidra "Como una armadura..."

# game/day2 choice.rpy:710
translate Spanish maidra_day2_e6411a6d:

    # maidra "......"
    maidra "......"

# game/day2 choice.rpy:711
translate Spanish maidra_day2_8b0deb8b:

    # maidra "Why couldn't I have gotten Knighter's role instead...? If I could, I'd switch places with him. He could be Maidra, and I'd be Knighter..."
    maidra "¿Por qué no pude quedarme con el papel de Knighter...? Si pudiera, cambiaría de lugar con él. Él podría ser Maidra y yo sería Knighter..."

# game/day2 choice.rpy:712
translate Spanish maidra_day2_a31270fc:

    # mc "Huh? Is switching roles like that even possible?"
    mc "¿Eh? ¿Es posible cambiar de rol así?"

# game/day2 choice.rpy:715
translate Spanish maidra_day2_1376eac3:

    # "Maidra glanced at me for a moment before continuing."
    "Maidra me miró un momento antes de continuar."

# game/day2 choice.rpy:717
translate Spanish maidra_day2_13212bd2:

    # maidra "...Yes and no. It could happen, but the way to do it is... uh... not exactly a good one. I mean, we'd basically have to take each other down."
    maidra "...Sí y no. Podría pasar, pero la manera de hacerlo es... eh... no muy buena. Es decir, básicamente tendríamos que derribarnos el uno al otro."

# game/day2 choice.rpy:718
translate Spanish maidra_day2_d8411ada:

    # maidra "It's like the food chain in the wild. The strongest one is the one that reaches the top."
    maidra "Es como la cadena alimenticia en la naturaleza. El más fuerte es el que llega a la cima."

# game/day2 choice.rpy:719
translate Spanish maidra_day2_86fc22ab:

    # maidra "And... hahh. It's not a good idea. So for now, I have no choice but to accept my role as Maidra the Maid."
    maidra "Y... hahh. No es buena idea. Así que por ahora no me queda más remedio que aceptar mi papel de Maidra la Criada."

# game/day2 choice.rpy:721
translate Spanish maidra_day2_7cfe1624:

    # "Honestly, her reaction wasn't all that surprising to me."
    "Sinceramente, su reacción no me sorprendió demasiado."

# game/day2 choice.rpy:722
translate Spanish maidra_day2_52212e74:

    # "From the moment I first met her, I could tell that Maidra wasn't exactly the feminine type."
    "Desde el momento en que la conocí, supe que Maidra no era exactamente del tipo femenino."

# game/day2 choice.rpy:723
translate Spanish maidra_day2_d926c742:

    # "It made sense that she didn't like her role."
    "Tenía sentido que no le gustara su papel."

# game/day2 choice.rpy:724
translate Spanish maidra_day2_8f050b1a:

    # "Still... I couldn't help but feel a little sorry for her. She had to live with something she didn't like."
    "Aun así... no pude evitar sentir algo de lástima por ella. Tenía que vivir con algo que no le gustaba."

# game/day2 choice.rpy:725
translate Spanish maidra_day2_0fd4d656_2:

    # "......"
    "......"

# game/day2 choice.rpy:726
translate Spanish maidra_day2_aa5ac475:

    # "But... honestly, I thought being a maid was pretty cool."
    "Pero... sinceramente, yo pensaba que ser criada era bastante genial."

# game/day2 choice.rpy:728
translate Spanish maidra_day2_55b93dd1:

    # mc "I'm sorry about that, Maidra."
    mc "Lo siento por eso, Maidra."

# game/day2 choice.rpy:729
translate Spanish maidra_day2_aab6771c:

    # mc "But... I think you already look pretty cool as a maid."
    mc "Pero... creo que ya te ves bastante genial de criada."

# game/day2 choice.rpy:731
translate Spanish maidra_day2_ffb4dd37:

    # maidra "Mmh... thanks for the compliment... but I still don't like this dress."
    maidra "Mmh... gracias por el cumplido... pero sigue sin gustarme este vestido."

# game/day2 choice.rpy:732
translate Spanish maidra_day2_804e97c5:

    # mc "Of course. But... have you ever heard of spies who disguise themselves as maids?"
    mc "Claro. Pero... ¿has oído hablar de espías que se disfrazan de criadas?"

# game/day2 choice.rpy:734
translate Spanish maidra_day2_e9bcf983:

    # maidra "Huh?"
    maidra "¿Eh?"

# game/day2 choice.rpy:736
translate Spanish maidra_day2_32e45a98:

    # "I drew upon everything I'd learned from the novels, comics, and movies I'd consumed over the years. All those stories had given my imagination quite a bit of room to work with."
    "Recurrí a todo lo que había aprendido de las novelas, cómics y películas que había consumido a lo largo de los años. Todas esas historias le habían dado a mi imaginación bastante margen de maniobra."

# game/day2 choice.rpy:737
translate Spanish maidra_day2_579fa1ac:

    # "or once, all that seemingly useless knowledge might actually come in handy."
    "Por una vez, todo ese conocimiento aparentemente inútil podría resultar útil."

# game/day2 choice.rpy:739
translate Spanish maidra_day2_7f819137:

    # mc "I once read a comic about a female spy who sneaked into an enemy palace and disguised herself as a maid."
    mc "Una vez leí un cómic sobre una espía que se infiltró en un palacio enemigo y se disfrazó de criada."

# game/day2 choice.rpy:740
translate Spanish maidra_day2_efce39b8:

    # maidra "What? I've never heard of that."
    maidra "¿Qué? Nunca he oído hablar de eso."

# game/day2 choice.rpy:741
translate Spanish maidra_day2_da9e0978:

    # mc "She was really cool. While she was working as a maid, she acted all graceful and gentle. But when it was time for her to make her move, she became incredibly skilled and strong."
    mc "Era genial. Mientras trabajaba de criada, actuaba con gracia y dulzura. Pero cuando llegaba el momento de actuar, se volvía increíblemente hábil y fuerte."

# game/day2 choice.rpy:742
translate Spanish maidra_day2_3c59bf12:

    # mc "She even kept small weapons hidden around her thighs, underneath her maid dress."
    mc "Incluso llevaba pequeñas armas escondidas en los muslos, bajo su vestido de criada."

# game/day2 choice.rpy:743
translate Spanish maidra_day2_17221195:

    # mc "And whenever she used them, she looked incredibly cool, even though her weapons weren't some huge axe or giant weapon."
    mc "Y cada vez que las usaba, se veía increíblemente genial, aunque sus armas no fueran un hacha enorme ni un arma gigante."

# game/day2 choice.rpy:745
translate Spanish maidra_day2_8284632b:

    # "As I explained the story, Maidra's eyes slowly began to sparkle with admiration."
    "Mientras explicaba la historia, los ojos de Maidra empezaron poco a poco a brillar de admiración."

# game/day2 choice.rpy:746
translate Spanish maidra_day2_dcb96104:

    # "Did I actually manage to make her feel a little better?"
    "¿De verdad había logrado que se sintiera un poco mejor?"

# game/day2 choice.rpy:748
translate Spanish maidra_day2_4d84b302:

    # maidra ".....So..."
    maidra ".....Entonces..."

# game/day2 choice.rpy:749
translate Spanish maidra_day2_559f3095:

    # maidra "I... could be cool like that...?"
    maidra "¿Yo... podría ser genial así...?"

# game/day2 choice.rpy:750
translate Spanish maidra_day2_bc9e66d1:

    # mc "Why not? I mean, I'm sure you can still look strong and cool, and be yourself, even in something feminine."
    mc "¿Por qué no? Es decir, seguro que puedes verte fuerte y genial, y ser tú misma, incluso con algo femenino."

# game/day2 choice.rpy:751
translate Spanish maidra_day2_b34b3dfd:

    # maidra "I....."
    maidra "Yo....."

# game/day2 choice.rpy:752
translate Spanish maidra_day2_7808a29a:

    # maidra "...Yeah. Maybe I can."
    maidra "...Sí. Quizá pueda."

# game/day2 choice.rpy:753
translate Spanish maidra_day2_99fb5d1e:

    # maidra "....."
    maidra "....."

# game/day2 choice.rpy:754
translate Spanish maidra_day2_3046fd07:

    # maidra "Yeah, I can!"
    maidra "¡Sí, puedo!"

# game/day2 choice.rpy:757
translate Spanish maidra_day2_3c3a4ebc:

    # maidra "I-I mean... yeah... that sounds pretty cool... ahem."
    maidra "Q-quiero decir... sí... eso suena bastante genial... ejem."

# game/day2 choice.rpy:760
translate Spanish maidra_day2_382c5274:

    # "I couldn't help but laugh at how hard Maidra was trying to keep her cool."
    "No pude evitar reírme de lo mucho que se esforzaba Maidra por mantener la compostura."

# game/day2 choice.rpy:762
translate Spanish maidra_day2_c5a15cb0:

    # maidra "Mmh... okay... Your Majesty... you actually made me feel a little better now... uhm..."
    maidra "Mmh... bueno... Majestad... en realidad me hiciste sentir un poco mejor ahora... emm..."

# game/day2 choice.rpy:763
translate Spanish maidra_day2_cc08f80d:

    # maidra "....Thank you... I guess..."
    maidra "....Gracias... supongo..."

# game/day2 choice.rpy:764
translate Spanish maidra_day2_a7a92e8f:

    # mc "No problem."
    mc "De nada."

# game/day2 choice.rpy:765
translate Spanish maidra_day2_8e7225f2:

    # maidra "U-uhm... anyway, I'd better get back to work."
    maidra "E-eh... bueno, mejor vuelvo al trabajo."

# game/day2 choice.rpy:766
translate Spanish maidra_day2_b5ff180e:

    # maidra "The sooner I finish, the sooner I get to sleep."
    maidra "Cuanto antes termine, antes podré dormir."

# game/day2 choice.rpy:767
translate Spanish maidra_day2_1c79b74d:

    # maidra "... T-thank you again for today, Your Majesty.."
    maidra "... G-gracias de nuevo por hoy, Majestad.."

# game/day2 choice.rpy:769
translate Spanish maidra_day2_2060e5a7:

    # "She returned her attention to sweeping the floor, leaving me standing here alongside Jestyn."
    "Volvió a barrer el suelo, dejándome aquí junto a Jestyn."

# game/day2 choice.rpy:778
translate Spanish crownus_room1_7d45b822:

    # "My attention drifted toward the King Puppet's door."
    "Mi atención se desvió hacia la puerta de la Marioneta Rey."

# game/day2 choice.rpy:779
translate Spanish crownus_room1_d0017183:

    # "Compared to the other puppet rooms, that one looked the most..."
    "Comparada con las otras habitaciones de marionetas, esa era la más..."

# game/day2 choice.rpy:780
translate Spanish crownus_room1_79e9e6ea:

    # "...chaotic?"
    "...¿caótica?"

# game/day2 choice.rpy:781
translate Spanish crownus_room1_7d42671d:

    # "A name had been scrawled across the front door with 'Crownus.'"
    "Habían garabateado un nombre en la puerta principal: 'Crownus'."

# game/day2 choice.rpy:782
translate Spanish crownus_room1_1117b999:

    # "Was that the King Puppet's name?"
    "¿Ese era el nombre de la Marioneta Rey?"

# game/day2 choice.rpy:783
translate Spanish crownus_room1_5966b324:

    # "I found myself curious about what was inside."
    "Sentí curiosidad por lo que había dentro."

# game/day2 choice.rpy:785
translate Spanish crownus_room1_cbae8792:

    # mc "Uhm... I'd like to take a look at the King Puppet's room for a moment."
    mc "Emm... me gustaría echar un vistazo a la habitación de la Marioneta Rey un momento."

# game/day2 choice.rpy:788
translate Spanish crownus_room1_b6e86597:

    # "Jestyn froze."
    "Jestyn se quedó helado."

# game/day2 choice.rpy:789
translate Spanish crownus_room1_64052ff6:

    # "His eyes widened, and for the briefest moment, his smile disappeared."
    "Sus ojos se abrieron de par en par y, por un breve instante, su sonrisa desapareció."

# game/day2 choice.rpy:792
translate Spanish crownus_room1_12129ac6:

    # "Then it returned."
    "Luego volvió."

# game/day2 choice.rpy:793
translate Spanish crownus_room1_b72d0c42:

    # "But this time, it looked forced."
    "Pero esta vez, parecía forzada."

# game/day2 choice.rpy:795
translate Spanish crownus_room1_a0c5ae7d:

    # jes "Ah, the King Puppet's room?"
    jes "Ah, ¿la habitación de la Marioneta Rey?"

# game/day2 choice.rpy:796
translate Spanish crownus_room1_3af2cc9f:

    # jes "It's quite messy, and there's really nothing interesting in there."
    jes "Está bastante desordenada y la verdad es que no hay nada interesante allí."

# game/day2 choice.rpy:797
translate Spanish crownus_room1_fbd97b8e:

    # jes "Truly."
    jes "De verdad."

# game/day2 choice.rpy:800
translate Spanish crownus_room1_778fb17a:

    # jes "I would advise Your Majesty not to bother with that room."
    jes "Aconsejaría a Su Majestad que no se moleste con esa habitación."

# game/day2 choice.rpy:805
translate Spanish crownus_room2_91047a3a:

    # ".........."
    ".........."

# game/day2 choice.rpy:806
translate Spanish crownus_room2_01b1ace8:

    # "My eyes kept drifting back to the King Puppet's room."
    "Mis ojos no dejaban de volver a la habitación de la Marioneta Rey."

# game/day2 choice.rpy:807
translate Spanish crownus_room2_73e0ce33:

    # "The more Jestyn tried to discourage me, the more curious I became."
    "Cuanto más intentaba Jestyn disuadirme, más curiosidad sentía."

# game/day2 choice.rpy:809
translate Spanish crownus_room2_849d0d13:

    # mc "I'll only take a quick look."
    mc "Solo echaré un vistazo rápido."

# game/day2 choice.rpy:810
translate Spanish crownus_room2_55458739:

    # mc "I don't mind if it's messy."
    mc "No me importa si está desordenada."

# game/day2 choice.rpy:811
translate Spanish crownus_room2_073b3b5b:

    # mc "I just want to see what's inside."
    mc "Solo quiero ver qué hay dentro."

# game/day2 choice.rpy:814
translate Spanish crownus_room2_07a2e684:

    # jes "Your Majesty may do so later."
    jes "Su Majestad podrá hacerlo más tarde."

# game/day2 choice.rpy:815
translate Spanish crownus_room2_d1f3da4a:

    # jes "For now, however, I believe it would be best for us to meet the other puppets first."
    jes "Por ahora, sin embargo, creo que sería mejor que conozcamos primero a las demás marionetas."

# game/day2 choice.rpy:816
translate Spanish crownus_room2_10dbca2c:

    # jes "That is the more important matter at the moment."
    jes "Ese es el asunto más importante en este momento."

# game/day2 choice.rpy:826
translate Spanish crownus_room3_94db37ab:

    # who "{color=#FFC04C}You can look inside that room.{/color}"
    who "{color=#FFC04C}Puedes echar un vistazo dentro de esa habitación.{/color}"

# game/day2 choice.rpy:827
translate Spanish crownus_room3_a08b53c5:

    # who "{color=#FFC04C}Go on...{/color}"
    who "{color=#FFC04C}Adelante...{/color}"

# game/day2 choice.rpy:828
translate Spanish crownus_room3_d89ddd90:

    # who "{color=#FFC04C}Take a step forward...{/color}"
    who "{color=#FFC04C}Da un paso al frente...{/color}"

# game/day2 choice.rpy:829
translate Spanish crownus_room3_7c6a7f30:

    # who "{color=#FFC04C}Now...{/color}"
    who "{color=#FFC04C}Ahora...{/color}"

# game/day2 choice.rpy:830
translate Spanish crownus_room3_cf2317c3:

    # who "{color=#FFC04C}Open it...{/color}"
    who "{color=#FFC04C}Ábrela...{/color}"

# game/day2 choice.rpy:831
translate Spanish crownus_room3_33ddeab4:

    # jes "I said..."
    jes "Dije..."

# game/day2 choice.rpy:836
translate Spanish crownus_room3_16351792:

    # jes "{color=#FF253E}{cps=15}NO!!{/cps}{/color}"
    jes "{color=#FF253E}{cps=15}¡¡NO!!{/cps}{/color}"

# game/day2 choice.rpy:838
translate Spanish crownus_room3_07bdde05:

    # "....."
    "....."

# game/day2 choice.rpy:839
translate Spanish crownus_room3_898a909f:

    # "...Huh...?"
    "...¿Eh...?"

# game/day2 choice.rpy:840
translate Spanish crownus_room3_650c8580:

    # "I flinched when Jestyn suddenly grabbed my hand and pulled it away from the King Puppet's doorknob."
    "Me sobresalté cuando Jestyn de pronto me agarró la mano y la apartó del pomo de la puerta de la Marioneta Rey."

# game/day2 choice.rpy:841
translate Spanish crownus_room3_5541122e:

    # "His grip was so tight that it hurt."
    "Su agarre era tan fuerte que dolía."

# game/day2 choice.rpy:843
translate Spanish crownus_room3_2d4448fe:

    # "Pain shot through my arm where his fingers were wrapped around it."
    "Un dolor me recorrió el brazo allí donde sus dedos lo rodeaban."

# game/day2 choice.rpy:844
translate Spanish crownus_room3_597b7955:

    # "His gaze was sharp. Deadly."
    "Su mirada era afilada. Letal."

# game/day2 choice.rpy:845
translate Spanish crownus_room3_b7772b8f:

    # "There was no mistaking it. Jestyn was angry."
    "No había duda. Jestyn estaba enojado."

# game/day2 choice.rpy:846
translate Spanish crownus_room3_3440caa5:

    # "But why?"
    "Pero ¿por qué?"

# game/day2 choice.rpy:849
translate Spanish crownus_room3_90a0fc62:

    # mc "Ugh- Jestyn..."
    mc "Ugh... Jestyn..."

# game/day2 choice.rpy:850
translate Spanish crownus_room3_27ff9a30:

    # mc "Y-You're hurting me...."
    mc "M-me estás lastimando...."

# game/day2 choice.rpy:853
translate Spanish crownus_room3_55aaef77:

    # "Jestyn immediately seemed to realize what he was doing."
    "Jestyn pareció darse cuenta de inmediato de lo que estaba haciendo."

# game/day2 choice.rpy:854
translate Spanish crownus_room3_81cfd253:

    # "His grip loosened at once."
    "Su agarre se aflojó al instante."

# game/day2 choice.rpy:855
translate Spanish crownus_room3_8574cb4b:

    # "But he didn't let go of my arm."
    "Pero no me soltó el brazo."

# game/day2 choice.rpy:859
translate Spanish crownus_room3_9053ad82:

    # jes "Forgive me, Your Majesty..."
    jes "Perdóneme, Majestad..."

# game/day2 choice.rpy:860
translate Spanish crownus_room3_8c717986:

    # jes "It's just..."
    jes "Es solo que..."

# game/day2 choice.rpy:862
translate Spanish crownus_room3_8afdcabb:

    # "He stopped speaking."
    "Dejó de hablar."

# game/day2 choice.rpy:863
translate Spanish crownus_room3_7cb13ed8:

    # "For several moments, he remained silent, trying to compose himself."
    "Durante varios instantes permaneció en silencio, tratando de recomponerse."

# game/day2 choice.rpy:865
translate Spanish crownus_room3_681c117a:

    # jes "Your Majesty, please forgive my impertinence, but..."
    jes "Majestad, perdone mi impertinencia, pero..."

# game/day2 choice.rpy:866
translate Spanish crownus_room3_e52a2de2:

    # jes "Please don't go into that room."
    jes "Por favor, no entre en esa habitación."

# game/day2 choice.rpy:869
translate Spanish crownus_room3_b8553763:

    # jes "Please."
    jes "Por favor."

# game/day2 choice.rpy:870
translate Spanish crownus_room3_fef5c419:

    # jes "Let's return our attention to the matter at hand, alright?"
    jes "Volvamos a centrar nuestra atención en el asunto que nos ocupa, ¿de acuerdo?"

# game/day2 choice.rpy:873
translate Spanish crownus_room3_35bf5a71:

    # "I nodded."
    "Asentí."

# game/day2 choice.rpy:874
translate Spanish crownus_room3_5ad0033d:

    # "I didn't want to escalate the situation any further."
    "No quería agravar más la situación."

# game/day2 choice.rpy:875
translate Spanish crownus_room3_07bdde05_1:

    # "....."
    "....."

# game/day2 choice.rpy:876
translate Spanish crownus_room3_71846403:

    # "Wait."
    "Espera."

# game/day2 choice.rpy:877
translate Spanish crownus_room3_c6486fc1:

    # "Since when was I reaching for the doorknob?"
    "¿Desde cuándo estaba extendiendo la mano hacia el pomo?"

# game/day2 choice.rpy:878
translate Spanish crownus_room3_a027394e:

    # "I only wanted to look inside."
    "Solo quería echar un vistazo adentro."

# game/day2 choice.rpy:879
translate Spanish crownus_room3_b5716357:

    # "I didn't remember deciding to open the door."
    "No recordaba haber decidido abrir la puerta."

# game/day2 choice.rpy:880
translate Spanish crownus_room3_1e3920df:

    # "So why had my hand been reaching for it?"
    "Entonces, ¿por qué mi mano se había estirado hacia ella?"

# game/day2 choice.rpy:891
translate Spanish wizzyroom_day2_f4968540:

    # "My gaze shifted to the orange door. The nameplate on it simply read: 'Wizard.'"
    "Mi mirada se desvió hacia la puerta naranja. La placa decía simplemente: 'Mago'."

# game/day2 choice.rpy:892
translate Spanish wizzyroom_day2_10dd8ac8:

    # "If I remembered correctly, the wizard puppet's name was Wizzy."
    "Si mal no recordaba, la marioneta mago se llamaba Wizzy."

# game/day2 choice.rpy:893
translate Spanish wizzyroom_day2_fb9769d9:

    # "I'm pretty sure Jestyn mentioned that name yesterday. Well, I suppose I'll try meeting him first."
    "Estoy bastante segur[letra] de que Jestyn mencionó ese nombre ayer. Bueno, supongo que intentaré conocerlo a él primero."

# game/day2 choice.rpy:894
translate Spanish wizzyroom_day2_592eb188:

    # "I pointed toward the Wizard Puppet's room."
    "Señalé la habitación de la Marioneta Mago."

# game/day2 choice.rpy:896
translate Spanish wizzyroom_day2_297ec359:

    # mc "I think I'd like to meet him."
    mc "Creo que me gustaría conocerlo."

# game/day2 choice.rpy:899
translate Spanish wizzyroom_day2_93a972fd:

    # "Jestyn's smile widened."
    "La sonrisa de Jestyn se ensanchó."

# game/day2 choice.rpy:901
translate Spanish wizzyroom_day2_15ae3431:

    # jes "A wise choice, Your Majesty."
    jes "Una sabia elección, Majestad."

# game/day2 choice.rpy:902
translate Spanish wizzyroom_day2_a1380cf7:

    # jes "Come along."
    jes "Venga conmigo."

# game/day2 choice.rpy:905
translate Spanish wizzyroom_day2_663849f0:

    # "Jestyn led me to the Wizard Puppet's door."
    "Jestyn me condujo hasta la puerta de la Marioneta Mago."

# game/day2 choice.rpy:908
translate Spanish wizzyroom_day2_68729584:

    # "He placed a hand on my shoulder and positioned me directly in front of it."
    "Me puso una mano en el hombro y me colocó justo frente a ella."

# game/day2 choice.rpy:909
translate Spanish wizzyroom_day2_83916f6b:

    # "Then he casually stepped to the left side of the doorway."
    "Luego se hizo a un lado con naturalidad, junto al lado izquierdo del marco."

# game/day2 choice.rpy:910
translate Spanish wizzyroom_day2_90334881:

    # "...Why was he standing over there?"
    "...¿Por qué se ponía allí?"

# game/day2 choice.rpy:912
translate Spanish wizzyroom_day2_0c7acd8d:

    # mc "Jestyn, why are you standing beside the door like that?"
    mc "Jestyn, ¿por qué te pones al lado de la puerta así?"

# game/day2 choice.rpy:913
translate Spanish wizzyroom_day2_b1e7e2f4:

    # mc "Won't you just get in the way when it opens?"
    mc "¿No estorbarás cuando se abra?"

# game/day2 choice.rpy:916
translate Spanish wizzyroom_day2_ad7489fd:

    # jes "That's the point."
    jes "Ese es el punto."

# game/day2 choice.rpy:917
translate Spanish wizzyroom_day2_2876efd9:

    # mc "Why?"
    mc "¿Por qué?"

# game/day2 choice.rpy:920
translate Spanish wizzyroom_day2_de655859:

    # jes "... Let's just say..."
    jes "... Digamos que..."

# game/day2 choice.rpy:921
translate Spanish wizzyroom_day2_c4d6c008:

    # jes "...For suprise."
    jes "...Para dar una sorpresa."

# game/day2 choice.rpy:923
translate Spanish wizzyroom_day2_a20cefa7:

    # "..."
    "..."

# game/day2 choice.rpy:924
translate Spanish wizzyroom_day2_048af5a0:

    # "Very convincing."
    "Muy convincente."

# game/day2 choice.rpy:927
translate Spanish wizzyroom_day2_d5b1a6a8:

    # "Once Jestyn made sure I was ready, he knocked on Wizzy's door."
    "Una vez que Jestyn se aseguró de que estaba list[letra], llamó a la puerta de Wizzy."

# game/day2 choice.rpy:928
translate Spanish wizzyroom_day2_b86d6031:

    # ".... Nothing happened for around few seconds."
    ".... No pasó nada durante unos segundos."

# game/day2 choice.rpy:929
translate Spanish wizzyroom_day2_cf464681:

    # "Then, I heard footsteps approaching from the other side of the door."
    "Entonces oí pasos que se acercaban desde el otro lado de la puerta."

# game/day2 choice.rpy:930
translate Spanish wizzyroom_day2_e36f5bac:

    # "They came closer..."
    "Se acercaron más..."

# game/day2 choice.rpy:931
translate Spanish wizzyroom_day2_d8e78870:

    # "...and stopped right in front of it."
    "...y se detuvieron justo frente a ella."

# game/day2 choice.rpy:932
translate Spanish wizzyroom_day2_d1ddaffa:

    # "........"
    "........"

# game/day2 choice.rpy:933
translate Spanish wizzyroom_day2_16b8cb94:

    # "Silence."
    "Silencio."

# game/day2 choice.rpy:934
translate Spanish wizzyroom_day2_1846c7db:

    # "What's he doing-"
    "¿Qué estará haciendo-"

# game/day2 choice.rpy:941
translate Spanish wizzyroom_day2_95dc747e:

    # "The door suddenly flew open, revealing a puppet dressed as a wizard."
    "La puerta se abrió de golpe, revelando a una marioneta vestida de mago."

# game/day2 choice.rpy:943
translate Spanish wizzyroom_day2_b6164b21:

    # "He was holding a staff that looked every bit like a wizard's staff, and-"
    "Sostenía un bastón que parecía en todo sentido el bastón de un mago, y-"

# game/day2 choice.rpy:944
translate Spanish wizzyroom_day2_66690708:

    # "HE WAS SWINGING IT AT ME?!"
    "¡¿ME ESTABA ATACANDO CON ÉL?!"

# game/day2 choice.rpy:949
translate Spanish wizzyroom_day2_28d29fe3:

    # wiz "JESTYN WHERE'S MY-"
    wiz "¡JESTYN, ¿DÓNDE ESTÁ MI-"

# game/day2 choice.rpy:954
translate Spanish wizzyroom_day2_f625bcf8:

    # jes "WIZZY, STOP!!"
    jes "¡WIZZY, ALTO!"

# game/day2 choice.rpy:957
translate Spanish wizzyroom_day2_901a08b2:

    # "Jestyn immediately stepped in and caught Wizzy's staff before it could hit me."
    "Jestyn intervino de inmediato y atrapó el bastón de Wizzy antes de que me golpeara."

# game/day2 choice.rpy:958
translate Spanish wizzyroom_day2_1c551c66:

    # "Wizzy stopped his move in shock."
    "Wizzy detuvo su movimiento, atónito."

# game/day2 choice.rpy:961
translate Spanish wizzyroom_day2_a44528d2:

    # wiz "WHAT THE-?!"
    wiz "¡¿QUÉ DEMO-?!"

# game/day2 choice.rpy:963
translate Spanish wizzyroom_day2_50f2e9ce:

    # "Wizzy immediately pulled his staff back and stared at Jestyn in shock."
    "Wizzy retiró enseguida su bastón y miró a Jestyn con asombro."

# game/day2 choice.rpy:964
translate Spanish wizzyroom_day2_021d72b0:

    # "A moment later, his attention shifted to me."
    "Un momento después, su atención se dirigió a mí."

# game/day2 choice.rpy:969
translate Spanish wizzyroom_day2_0b4ace37:

    # jes "Why did you suddenly try to attack someone like that??"
    jes "¿¿Por qué intentaste atacar a alguien así de repente??"

# game/day2 choice.rpy:972
translate Spanish wizzyroom_day2_d70d2900:

    # wiz "BECAUSE I WAS TRYING TO HIT YOU!"
    wiz "¡PORQUE INTENTABA GOLPEARTE A TI!"

# game/day2 choice.rpy:973
translate Spanish wizzyroom_day2_1c754d31:

    # wiz "I THOUGHT IT WAS YOU!"
    wiz "¡PENSÉ QUE ERAS TÚ!"

# game/day2 choice.rpy:976
translate Spanish wizzyroom_day2_c99460c1:

    # wiz "WHERE'S THE POTION I JUST FINISHED MAKING?!"
    wiz "¡¿DÓNDE ESTÁ LA POCIÓN QUE ACABO DE TERMINAR?!"

# game/day2 choice.rpy:979
translate Spanish wizzyroom_day2_55bc7f82:

    # "Jestyn merely shrugged."
    "Jestyn solo se encogió de hombros."

# game/day2 choice.rpy:981
translate Spanish wizzyroom_day2_d20733eb:

    # jes "Who knows~?"
    jes "¿Quién sabe~?"

# game/day2 choice.rpy:982
translate Spanish wizzyroom_day2_15c0f28f:

    # wiz "I JUST MADE IT- UGH!!"
    wiz "¡ACABO DE HACERLA- UGH!!"

# game/day2 choice.rpy:985
translate Spanish wizzyroom_day2_c3495313:

    # "Jestyn answered Wizzy's outrage with nothing but his usual maniacal laughter."
    "Jestyn respondió a la indignación de Wizzy con nada más que su habitual risa maniática."

# game/day2 choice.rpy:988
translate Spanish wizzyroom_day2_475b0db2:

    # "Eventually, Wizzy turned back to me."
    "Finalmente, Wizzy se volvió hacia mí."

# game/day2 choice.rpy:989
translate Spanish wizzyroom_day2_82c67af1:

    # "As he noticed me he quickly apologized."
    "Al notarme, se disculpó rápidamente."

# game/day2 choice.rpy:992
translate Spanish wizzyroom_day2_ce01ed5c:

    # wiz "Ah, I'm sorry! I didn't know there was someone other than Jestyn here."
    wiz "¡Ah, lo siento! No sabía que había alguien más que Jestyn aquí."

# game/day2 choice.rpy:993
translate Spanish wizzyroom_day2_64e7972c:

    # wiz "I'm so sorry for the chaos-"
    wiz "Lamento mucho el caos-"

# game/day2 choice.rpy:996
translate Spanish wizzyroom_day2_cb87981d:

    # "He stopped mid-sentence."
    "Se detuvo a media frase."

# game/day2 choice.rpy:999
translate Spanish wizzyroom_day2_fde4e665:

    # wiz "...Wait..."
    wiz "...Espera..."

# game/day2 choice.rpy:1000
translate Spanish wizzyroom_day2_7fc5805e:

    # wiz "Who are you...?"
    wiz "¿Quién eres...?"

# game/day2 choice.rpy:1003
translate Spanish wizzyroom_day2_205fa76e:

    # jes "This is [player_name]."
    jes "Te presento a [player_name]."

# game/day2 choice.rpy:1004
translate Spanish wizzyroom_day2_27106144:

    # jes "Our new [title]. The one I told you about this morning."
    jes "Nuestr[letra] nuev[letra] [title!t]. De quien te hablé esta mañana."

# game/day2 choice.rpy:1006
translate Spanish wizzyroom_day2_5f06ca41:

    # "Even though Wizzy's eyes were hidden beneath the cloth covering them, I could still read the surprise on his face from the way his mouth fell open."
    "Aunque los ojos de Wizzy estaban ocultos bajo la tela que los cubría, aun así pude leer la sorpresa en su rostro por la forma en que se le abrió la boca."

# game/day2 choice.rpy:1007
translate Spanish wizzyroom_day2_30513952:

    # "He clearly hadn't expected this."
    "Claramente no esperaba esto."

# game/day2 choice.rpy:1010
translate Spanish wizzyroom_day2_c7527433:

    # wiz ".... W-Wait..."
    wiz ".... E-espera..."

# game/day2 choice.rpy:1011
translate Spanish wizzyroom_day2_7691ae3e:

    # wiz "You're... our new [title]?"
    wiz "¿Eres... nuestr[letra] nuev[letra] [title!t]?"

# game/day2 choice.rpy:1012
translate Spanish wizzyroom_day2_60bf5586:

    # wiz "Uh-oh..."
    wiz "Uh-oh..."

# game/day2 choice.rpy:1013
translate Spanish wizzyroom_day2_9059fff8:

    # wiz "I wasn't expecting to meet you this soon."
    wiz "No esperaba conocerle tan pronto."

# game/day2 choice.rpy:1014
translate Spanish wizzyroom_day2_d102fe37:

    # wiz "I..."
    wiz "Yo..."

# game/day2 choice.rpy:1017
translate Spanish wizzyroom_day2_01a06ebc:

    # "Wizzy nervously glanced back into his room."
    "Wizzy miró nervioso hacia el interior de su habitación."

# game/day2 choice.rpy:1020
translate Spanish wizzyroom_day2_3dacc154:

    # wiz "M-My room is a little..."
    wiz "M-mi habitación está un poco..."

# game/day2 choice.rpy:1023
translate Spanish wizzyroom_day2_2e027d11:

    # "He looked around frantically, as if searching for an excuse."
    "Miró a su alrededor frenéticamente, como buscando una excusa."

# game/day2 choice.rpy:1024
translate Spanish wizzyroom_day2_c1968a37:

    # "Then he turned back to Jestyn."
    "Luego se volvió hacia Jestyn."

# game/day2 choice.rpy:1031
translate Spanish wizzyroom_day2_cde2d11f:

    # wiz "JESTYN! I'll forgive you if you help me out for a minute!"
    wiz "¡JESTYN! ¡Te perdonaré si me ayudas un minuto!"

# game/day2 choice.rpy:1034
translate Spanish wizzyroom_day2_19100e1e:

    # "Jestyn looked at Wizzy with a mixture of confusion and curiosity."
    "Jestyn miró a Wizzy con una mezcla de confusión y curiosidad."

# game/day2 choice.rpy:1037
translate Spanish wizzyroom_day2_41e79fe4:

    # wiz "A-Ahahaha... My deepest apologies, dear Majesty. Please give us one sec- I mean.....one minute. Hehe... heheh..."
    wiz "A-Ajajaja... Mis más profundas disculpas, querida Majestad. Por favor, denos un seg- quiero decir.....un minuto. Jeje... jejeje..."

# game/day2 choice.rpy:1038
translate Spanish wizzyroom_day2_ed2a2cb5:

    # wiz "WE'LL BE RIGHT BACK!"
    wiz "¡VOLVEMOS ENSEGUIDA!"

# game/day2 choice.rpy:1044
translate Spanish wizzyroom_day2_73bcc82d:

    # "Before I could say anything, Wizzy grabbed Jestyn by the arm, yanked him into his room, and slammed the door shut in front of me."
    "Antes de que pudiera decir nada, Wizzy agarró a Jestyn del brazo, lo metió de un tirón en su habitación y me cerró la puerta en las narices."

# game/day2 choice.rpy:1045
translate Spanish wizzyroom_day2_6acf1146:

    # "Leaving me standing alone in the hallway, utterly confused."
    "Dejándome sol[letra] en el pasillo, completamente confundid[letra]."

# game/day2 choice.rpy:1048
translate Spanish wizzyroom_day2_2355d355:

    # "Even so, I could still hear the two of them talking in hushed voices from inside the room."
    "Aun así, todavía podía oírlos hablar en voz baja desde el interior de la habitación."

# game/day2 choice.rpy:1050
translate Spanish wizzyroom_day2_8e8968e6:

    # wiz "Teleport all of this."
    wiz "Teletransporta todo esto."

# game/day2 choice.rpy:1051
translate Spanish wizzyroom_day2_f7495fe4:

    # jes "What?! That's way too much!"
    jes "¡¿Qué?! ¡Eso es demasiado!"

# game/day2 choice.rpy:1052
translate Spanish wizzyroom_day2_46dc3d05:

    # wiz "Hurry! [poss] Majesty is waiting!"
    wiz "¡Date prisa! ¡Su Majestad está esperando!"

# game/day2 choice.rpy:1053
translate Spanish wizzyroom_day2_b64599d6:

    # wiz "I don't want them to feel uncomfortable!"
    wiz "¡No quiero que se sienta incómod[letra]!"

# game/day2 choice.rpy:1054
translate Spanish wizzyroom_day2_24eb14f1:

    # jes "Now, now, dear Wizard... didn't this magnificent jester tell you to tidy up this dreadful mess this morning?"
    jes "Vamos, vamos, querido Mago... ¿no te dijo este magnífico bufón que ordenaras este espantoso desastre esta mañana?"

# game/day2 choice.rpy:1055
translate Spanish wizzyroom_day2_26ce9788:

    # wiz "I remember! But you never said Your Majesty was coming tonight!"
    wiz "¡Lo recuerdo! ¡Pero nunca dijiste que Su Majestad vendría esta noche!"

# game/day2 choice.rpy:1056
translate Spanish wizzyroom_day2_121f7a5b:

    # jes "Oh? Then when, pray tell, did you imagine [subj]'d come? Next year? I MOST CERTAINLY told you this morning!"
    jes "¿Oh? Entonces, ¿cuándo, dime, imaginaste que [subj!t] vendría? ¿El año que viene? ¡CLARÍSIMO que te lo dije esta mañana!"

# game/day2 choice.rpy:1057
translate Spanish wizzyroom_day2_9e10ec50:

    # wiz "...... When?"
    wiz "...... ¿Cuándo?"

# game/day2 choice.rpy:1058
translate Spanish wizzyroom_day2_d75277ee:

    # jes "While you were burying yourself in your little experiments! I was standing RIGHT beside you."
    jes "¡Mientras te sepultabas en tus jueguitos de experimentos! ¡Estaba JUSTO a tu lado!"

# game/day2 choice.rpy:1059
translate Spanish wizzyroom_day2_221910f1:

    # wiz "...Liar. You always lie."
    wiz "...Mentiroso. Siempre mientes."

# game/day2 choice.rpy:1060
translate Spanish wizzyroom_day2_90d97a67:

    # jes "Not this time! I wanted everything to be absolutely perfect for Your Majesty, so I told you [subj]'d be visiting tonight and that this catastrophe of a room needed to disappear!"
    jes "¡Esta vez no! Quería que todo estuviera absolutamente perfecto para Su Majestad, así que te dije que [subj!t] nos visitaría esta noche y que este desastre de habitación debía desaparecer."

# game/day2 choice.rpy:1061
translate Spanish wizzyroom_day2_22e6c0d6:

    # wiz "........"
    wiz "........"

# game/day2 choice.rpy:1062
translate Spanish wizzyroom_day2_195df276:

    # jes "Forsooth, thou art impossible!"
    jes "¡Por mi fe, sois imposible!"

# game/day2 choice.rpy:1063
translate Spanish wizzyroom_day2_5f2813c8:

    # wiz "Don't start talking with Old English to me! Help me clean this mess up."
    wiz "¡No empieces a hablarme en castellano antiguo! Ayúdame a limpiar este desastre."

# game/day2 choice.rpy:1064
translate Spanish wizzyroom_day2_be67c31c:

    # jes "Hehe~ Come now, Wizzy. Then surely a few little potions are a fair price for the great Jestyn's assistance, hm?"
    jes "Jeje~ Vamos, Wizzy. Entonces seguro que unas cuantas pociones son un precio justo por la ayuda del gran Jestyn, ¿hm?"

# game/day2 choice.rpy:1065
translate Spanish wizzyroom_day2_7861b2e5:

    # wiz "What?! No! I-"
    wiz "¡¿Qué?! ¡No! Yo-"

# game/day2 choice.rpy:1066
translate Spanish wizzyroom_day2_8ac5138a:

    # wiz "....."
    wiz "....."

# game/day2 choice.rpy:1067
translate Spanish wizzyroom_day2_e6ddb071:

    # wiz "...Fine! Fine! But only for a week! Now quit standing around! [poss] Majesty is waiting!"
    wiz "...¡Está bien! ¡Está bien! ¡Pero solo por una semana! ¡Ahora deja de quedarte ahí parado! ¡Su Majestad está esperando!"

# game/day2 choice.rpy:1074
translate Spanish wizzyroom_day2_aab0d5fd:

    # "A few moments later, I heard several finger snaps in quick succession."
    "Unos instantes después, oí varios chasquidos de dedos en rápida sucesión."

# game/day2 choice.rpy:1075
translate Spanish wizzyroom_day2_aff0b290:

    # "Between the sounds of the snapping fingers, I heard some arguing happening from Jestyn and Wizzy."
    "Entre los sonidos de los chasquidos, oí a Jestyn y a Wizzy discutiendo."

# game/day2 choice.rpy:1076
translate Spanish wizzyroom_day2_3176ce4c:

    # "Then silence."
    "Luego, silencio."

# game/day2 choice.rpy:1081
translate Spanish wizzyroom_day2_5794d304:

    # "After a few minutes the door opened and both of them finally came out."
    "Después de unos minutos, la puerta se abrió y por fin salieron los dos."

# game/day2 choice.rpy:1088
translate Spanish wizzyroom_day2_46076395:

    # wiz "Sorry for keeping you waiting, dear Majesty!"
    wiz "¡Perdone la espera, querida Majestad!"

# game/day2 choice.rpy:1089
translate Spanish wizzyroom_day2_480b1989:

    # wiz "All the problems are finally gone! Now please, come in!"
    wiz "¡Todos los problemas han desaparecido por fin! ¡Ahora, por favor, pase!"

# game/day2 choice.rpy:1091
translate Spanish wizzyroom_day2_44e1e29d:

    # "The nervous expression Wizzy had been wearing moments ago had completely vanished, replaced by a bright, welcoming smile."
    "La expresión nerviosa que Wizzy llevaba hacía un momento había desaparecido por completo, reemplazada por una sonrisa radiante y acogedora."

# game/day2 choice.rpy:1092
translate Spanish wizzyroom_day2_1b96b46e:

    # "Meanwhile, Jestyn, who had looked so smug just a minute earlier, now looked as pale as someone who'd lost all the blood in his body."
    "Mientras tanto, Jestyn, que había lucido tan engreído apenas un minuto antes, ahora estaba tan pálido como alguien a quien le hubieran drenado toda la sangre del cuerpo."

# game/day2 choice.rpy:1093
translate Spanish wizzyroom_day2_939b2480:

    # "What happened to him?"
    "¿Qué le habría pasado?"

# game/day2 choice.rpy:1094
translate Spanish wizzyroom_day2_e837bde4:

    # "I decided to not think about it further and just stepped into Wizzy's room."
    "Decidí no pensar más en ello y simplemente entré en la habitación de Wizzy."

# game/day2 choice.rpy:1100
translate Spanish wizzyroom_day2_86b03dea:

    # "The second I stepped inside, the sharp scent of chemicals tickled my nose."
    "En cuanto entré, el penetrante olor a productos químicos me cosquilleó la nariz."

# game/day2 choice.rpy:1101
translate Spanish wizzyroom_day2_fc346103:

    # "Wizzy's room was surprisingly spacious and tidy... at least, from what I could see at first glance."
    "La habitación de Wizzy era sorprendentemente espaciosa y ordenada... al menos, por lo que pude ver a primera vista."

# game/day2 choice.rpy:1102
translate Spanish wizzyroom_day2_ba93191f:

    # "The walls were covered with sheets of paper filled with notes and formulas I could't even begin to understand."
    "Las paredes estaban cubiertas de hojas de papel llenas de notas y fórmulas que ni siquiera empezaba a entender."

# game/day2 choice.rpy:1103
translate Spanish wizzyroom_day2_cc6a8024:

    # "His bed sat on the right side of the room, with long tables beside it."
    "Su cama estaba en el lado derecho de la habitación, con largas mesas a su lado."

# game/day2 choice.rpy:1104
translate Spanish wizzyroom_day2_69ccfd8c:

    # "The table closest to the bed was cluttered with papers, books, pens, and various stationery. I assumed it's where Wizzy did most of his writing."
    "La mesa más cercana a la cama estaba abarrotada de papeles, libros, plumas y artículos de papelería variados. Supuse que era donde Wizzy hacía la mayor parte de su escritura."

# game/day2 choice.rpy:1105
translate Spanish wizzyroom_day2_961070d0:

    # "The other table, on the left side of the room, was packed with all sorts of equipment used for his experiments."
    "La otra mesa, en el lado izquierdo de la habitación, estaba repleta de todo tipo de equipo para sus experimentos."

# game/day2 choice.rpy:1106
translate Spanish wizzyroom_day2_3c8d1fd8:

    # "And in the center of the room stood a large cauldron. Considering his role as the kingdom's wizard puppet, it's not exactly surprising."
    "Y en el centro de la habitación había un gran caldero. Considerando su papel de marioneta mago del reino, no era nada sorprendente."

# game/day2 choice.rpy:1109
translate Spanish wizzyroom_day2_c80db8db:

    # wiz "...Uh... y-yes, I know my room smells a little strange. I was just running a few experiments... My apologies, Your Majesty."
    wiz "...Eh... s-sí, sé que mi habitación huele un poco raro. Estaba haciendo unos experimentos... Mis disculpas, Majestad."

# game/day2 choice.rpy:1111
translate Spanish wizzyroom_day2_d0452505:

    # "It seemed he noticed me looking around his room."
    "Parecía que había notado que miraba su habitación."

# game/day2 choice.rpy:1113
translate Spanish wizzyroom_day2_ca1de515:

    # wiz "A-And... I hope my room is comfortable enough for you, Your Majesty. I also hope it's tidy enough... hehe."
    wiz "Y... espero que mi habitación le resulte lo bastante cómoda, Majestad. También espero que esté lo bastante ordenada... jeje."

# game/day2 choice.rpy:1117
translate Spanish wizzyroom_day2_959df353:

    # jes "Of course it is. This room would be an absolute wreck without me."
    jes "Por supuesto que lo está. Esta habitación sería un completo desastre sin mí."

# game/day2 choice.rpy:1120
translate Spanish wizzyroom_day2_02120ec9:

    # wiz "Shhh!!"
    wiz "¡¡Shhh!!"

# game/day2 choice.rpy:1125
translate Spanish wizzyroom_day2_07519ba8:

    # wiz "Ah! Why don't you have a seat first, Your Majesty? You must be tired from standing."
    wiz "¡Ah! ¿Por qué no toma asiento primero, Majestad? Debe de estar cansad[letra] de estar de pie."

# game/day2 choice.rpy:1128
translate Spanish wizzyroom_day2_e0b9da4c:

    # "Wizzy quickly grabbed a chair and placed it behind me."
    "Wizzy agarró rápidamente una silla y la puso detrás de mí."

# game/day2 choice.rpy:1129
translate Spanish wizzyroom_day2_86eb3580:

    # "Jestyn, however, watched him with obvious disapproval, slowly shaking his head."
    "Jestyn, sin embargo, lo miró con evidente desaprobación, negando lentamente con la cabeza."

# game/day2 choice.rpy:1135
translate Spanish wizzyroom_day2_fa8ce0c4:

    # jes "Wizzy... are you serious? You're going to have [poss] Majesty sit on a hard wooden chair?"
    jes "Wizzy... ¿hablas en serio? ¿Vas a hacer que Su Majestad se siente en una dura silla de madera?"

# game/day2 choice.rpy:1138
translate Spanish wizzyroom_day2_785a0bbe:

    # "Only then did Wizzy realize what he'd done. He immediately turned to me, flustered."
    "Solo entonces Wizzy se dio cuenta de lo que había hecho. Se volvió de inmediato hacia mí, nervioso."

# game/day2 choice.rpy:1140
translate Spanish wizzyroom_day2_305841cd:

    # wiz "W-Wait... you're right! My apologies, Your Majesty! I'll find you a proper cushioned chair right away!"
    wiz "¡E-espere... tiene razón! ¡Mis disculpas, Majestad! ¡Le conseguiré enseguida una silla acolchada adecuada!"

# game/day2 choice.rpy:1141
translate Spanish wizzyroom_day2_93d27483:

    # mc "Y-You really don't have to go that far, Wizzy..."
    mc "N-no hace falta que llegues a tanto, Wizzy..."

# game/day2 choice.rpy:1143
translate Spanish wizzyroom_day2_528af079:

    # "I mean... I'm used to sitting on the old wooden chairs back in my apartment..."
    "Es decir... estoy acostumbrad[letra] a sentarme en las viejas sillas de madera de mi apartamento..."

# game/day2 choice.rpy:1145
translate Spanish wizzyroom_day2_c6232a76:

    # mc "You can just treat me like-"
    mc "Puedes tratarme como-"

# game/day2 choice.rpy:1147
translate Spanish wizzyroom_day2_a1851d70:

    # "Before I could finish my sentence, Jestyn cut me off."
    "Antes de que pudiera terminar la frase, Jestyn me interrumpió."

# game/day2 choice.rpy:1150
translate Spanish wizzyroom_day2_a089f485:

    # jes "Tut, tut, tut~ That simply won't do, Your Majesty. You're our [title]. Nothing less than the finest treatment will do for you."
    jes "Tsk, tsk, tsk~ Eso no puede ser, Majestad. Usted es nuestr[letra] [title!t]. Nada menos que el mejor trato es digno de usted."

# game/day2 choice.rpy:1151
translate Spanish wizzyroom_day2_9c96314f:

    # wiz "Exactly! I actually agree with Jestyn this time!"
    wiz "¡Exacto! ¡Esta vez estoy de acuerdo con Jestyn!"

# game/day2 choice.rpy:1154
translate Spanish wizzyroom_day2_c46b9515:

    # jes "...Excuse me? This time? What's that supposed to mean?"
    jes "...¿Perdón? ¿Esta vez? ¿Qué se supone que significa eso?"

# game/day2 choice.rpy:1155
translate Spanish wizzyroom_day2_123d0c87:

    # wiz "A-Anyway! I'll go find a nice soft chair for Your Majesty-"
    wiz "¡B-bueno! ¡Iré a buscar una silla blandita para Su Majestad-"

# game/day2 choice.rpy:1158
translate Spanish wizzyroom_day2_cbd00da4:

    # jes "No need."
    jes "No hace falta."

# game/day2 choice.rpy:1159
translate Spanish wizzyroom_day2_76ad10e4:

    # jes "Why bother with a cushion... when Your Majesty could simply sit on me?"
    jes "¿Para qué molestarse con un cojín... cuando Su Majestad podría sentarse simplemente sobre mí?"

# game/day2 choice.rpy:1161
translate Spanish wizzyroom_day2_2563484e:

    # mc "...???"
    mc "...???"

# game/day2 choice.rpy:1165
translate Spanish wizzyroom_day2_90494edc:

    # "I stared at Jestyn in utter confusion. He only flashed me a wide, cheeky grin, his cheeks tinged with pink."
    "Miré a Jestyn con total confusión. Él solo me dedicó una amplia sonrisa descarada, con las mejillas teñidas de rosa."

# game/day2 choice.rpy:1166
translate Spanish wizzyroom_day2_63215f01:

    # "There's no way my ears just betrayed me."
    "No era posible que mis oídos me hubieran traicionado."

# game/day2 choice.rpy:1169
translate Spanish wizzyroom_day2_b44f742c:

    # "Wizzy stared at Jestyn for a moment, his face frozen in disbelief."
    "Wizzy miró a Jestyn un momento, con la cara congelada de incredulidad."

# game/day2 choice.rpy:1172
translate Spanish wizzyroom_day2_ebdc2551:

    # "When he turned to look at me, he gave a subtle shake of his head, careful not to let Jestyn notice he disagreed with the idea."
    "Cuando se volvió hacia mí, negó sutilmente con la cabeza, con cuidado de que Jestyn no notara que estaba en desacuerdo con la idea."

# game/day2 choice.rpy:1173
translate Spanish wizzyroom_day2_3a773ee7:

    # "Honestly, I didn't mind sitting on a hard chair. I was more than used to it, anyway."
    "Sinceramente, no me importaba sentarme en una silla dura. De todos modos, estaba más que acostumbrad[letra]."

# game/day2 choice.rpy:1174
translate Spanish wizzyroom_day2_bb70a868:

    # "But... sitting on someone? I mean, on a puppet? That was definitely a first for me."
    "Pero... ¿sentarme sobre alguien? Es decir, ¿sobre una marioneta? Eso sí que era una primera vez para mí."

# game/day2 choice.rpy:1175
translate Spanish wizzyroom_day2_1fa1e504:

    # "I found myself wondering which option would be the better one."
    "Me encontré preguntándome cuál sería la mejor opción."

# game/day2 choice.rpy:1187
translate Spanish sit_on_jestyn_125d71ac:

    # "I couldn't believe I was about to say this."
    "No podía creer que fuera a decir esto."

# game/day2 choice.rpy:1188
translate Spanish sit_on_jestyn_e8c14dde:

    # "But... I was tired of sitting on hard chairs. And sitting on Jestyn... well, I guessed that would be a new experience."
    "Pero... estaba hart[letra] de sentarme en sillas duras. Y sentarme sobre Jestyn... bueno, supuse que sería una experiencia nueva."

# game/day2 choice.rpy:1190
translate Spanish sit_on_jestyn_be7d473a:

    # mc "...Alright, Jestyn. Be my chair."
    mc "...Está bien, Jestyn. Sé mi silla."

# game/day2 choice.rpy:1194
translate Spanish sit_on_jestyn_77ab3090:

    # "The moment the words left my mouth, Wizzy stared at me in utter disbelief. Honestly... I could hardly believe I just said that myself."
    "En cuanto las palabras salieron de mi boca, Wizzy me miró con total incredulidad. La verdad... yo mism[letra] apenas podía creer lo que acababa de decir."

# game/day2 choice.rpy:1195
translate Spanish sit_on_jestyn_2b733ca9:

    # "Jestyn, on the other hand, looked absolutely delighted. His grin stretched even wider, and a rosy blush crept across his cheeks."
    "Jestyn, en cambio, parecía absolutamente encantado. Su sonrisa se estiró aún más y un rubor rosado se extendió por sus mejillas."

# game/day2 choice.rpy:1200
translate Spanish sit_on_jestyn_9015601e:

    # jes "With pleasure, Your Majesty..."
    jes "Con placer, Majestad..."

# game/day2 choice.rpy:1203
translate Spanish sit_on_jestyn_3af66fb7:

    # "Jestyn stepped behind me before lowering himself to the floor. Planting his hands firmly on the ground, he got down on all fours."
    "Jestyn se colocó detrás de mí antes de bajar al suelo. Apoyando firmemente las manos en el piso, se puso a cuatro patas."

# game/day2 choice.rpy:1205
translate Spanish sit_on_jestyn_934a1976:

    # jes "Your seat awaits, Your Majesty~"
    jes "Su asiento le espera, Majestad~"

# game/day2 choice.rpy:1208
translate Spanish sit_on_jestyn_ad3566d8:

    # "I carefully settled myself onto Jestyn's back."
    "Me acomodé con cuidado sobre la espalda de Jestyn."

# game/day2 choice.rpy:1209
translate Spanish sit_on_jestyn_ef396fa9:

    # "The instant I did, I felt his body tremble ever so slightly."
    "En el instante en que lo hice, sentí que su cuerpo temblaba apenas."

# game/day2 choice.rpy:1210
translate Spanish sit_on_jestyn_f3e9b74f:

    # "I could also hear him letting out tiny little noises, doing everything he could to keep them under control."
    "También pude oírlo soltar pequeños ruiditos, haciendo todo lo posible por contenerlos."

# game/day2 choice.rpy:1211
translate Spanish sit_on_jestyn_72fcef48:

    # "...I had a feeling Jestyn was enjoying this."
    "...Tuve la sensación de que Jestyn lo estaba disfrutando."

# game/day2 choice.rpy:1212
translate Spanish sit_on_jestyn_fc75f4e1:

    # "Wizzy glanced between Jestyn and me. He looked like he wanted to say something... but ultimately decided against it."
    "Wizzy miró de Jestyn a mí. Parecía querer decir algo... pero al final decidió no hacerlo."

# game/day2 choice.rpy:1216
translate Spanish sit_on_jestyn_70b96f89:

    # wiz "U-Um... in that case... I hope you're comfortable, Your Majesty..."
    wiz "E-este... en ese caso... espero que esté cómod[letra], Majestad..."

# game/day2 choice.rpy:1221
translate Spanish sit_chair_f3d1d48c:

    # "Okay. I was not about to let a jester puppet act like a complete weirdo around me all the time."
    "Bien. No iba a permitir que un bufón marioneta se comportara como un completo rarito a mi alrededor todo el tiempo."

# game/day2 choice.rpy:1223
translate Spanish sit_chair_75c3b3e9:

    # mc "I'll just sit in the chair, Jestyn."
    mc "Me sentaré en la silla, Jestyn."

# game/day2 choice.rpy:1227
translate Spanish sit_chair_4b8961e3:

    # "Jestyn immediately pouted."
    "Jestyn hizo un puchero de inmediato."

# game/day2 choice.rpy:1228
translate Spanish sit_chair_2684d746:

    # "Meanwhile, beside him, Wizzy let out a sigh of relief and gave me a discreet thumbs up."
    "Mientras tanto, a su lado, Wizzy soltó un suspiro de alivio y me hizo un discreto pulgar arriba."

# game/day2 choice.rpy:1230
translate Spanish sit_chair_1373504e:

    # jes "I promise I'm far more comfortable than that chair. Besides... you are Your Majesty."
    jes "Le prometo que soy mucho más cómodo que esa silla. Además... usted es Su Majestad."

# game/day2 choice.rpy:1231
translate Spanish sit_chair_58ee307e:

    # mc "And that means I get to have what I want. Right now, I want to sit in the chair."
    mc "Y eso significa que puedo tener lo que quiero. Ahora mismo, quiero sentarme en la silla."

# game/day2 choice.rpy:1233
translate Spanish sit_chair_475403ff:

    # "Jestyn's pout deepened."
    "El puchero de Jestyn se acentuó."

# game/day2 choice.rpy:1235
translate Spanish sit_chair_72b5e65f:

    # jes "...As Your Majesty wishes."
    jes "...Como desee Su Majestad."

# game/day2 choice.rpy:1239
translate Spanish sit_chair_354055e4:

    # "I finally took a seat in the chair."
    "Por fin me senté en la silla."

# game/day2 choice.rpy:1246
translate Spanish wizzy_convo_c84f98ae:

    # wiz "Alright... I suppose we can finally have a proper conversation now."
    wiz "Muy bien... supongo que por fin podemos tener una conversación como es debido."

# game/day2 choice.rpy:1250
translate Spanish wizzy_convo_4088efb8:

    # wiz "...."
    wiz "...."

# game/day2 choice.rpy:1254
translate Spanish wizzy_convo_a1274e5f:

    # wiz "Um... haha... I'm actually really nervous. This is all so sudden... and completely outside my usual schedule."
    wiz "Eh... jaja... en realidad estoy muy nervioso. Todo esto es tan repentino... y completamente fuera de mi horario habitual."

# game/day2 choice.rpy:1257
translate Spanish wizzy_convo_87d19c40:

    # wiz "B-But please don't misunderstand, Your Majesty! I really do want to talk with you!"
    wiz "¡P-pero por favor no me malinterprete, Majestad! ¡De verdad quiero hablar con usted!"

# game/day2 choice.rpy:1260
translate Spanish wizzy_convo_a11a49e4:

    # "Wizzy took a deep breath, trying to calm himself."
    "Wizzy respiró hondo, tratando de calmarse."

# game/day2 choice.rpy:1264
translate Spanish wizzy_convo_e70558c8:

    # voice "WIZZY01_DAY2.ogg"
    # wiz "I don't think we've properly introduced ourselves yet, have we, Your Majesty? My name is Wizzy. I'm the puppet who serves the kingdom as a wizard. It's an honor to meet you."
    voice "WIZZY01_DAY2.ogg"
    wiz "Creo que todavía no nos hemos presentado como es debido, ¿verdad, Majestad? Mi nombre es Wizzy. Soy la marioneta que sirve al reino como mago. Es un honor conocerle."

# game/day2 choice.rpy:1268
translate Spanish wizzy_convo_e7390541:

    # "Wizzy bowed respectfully before me."
    "Wizzy hizo una reverencia respetuosa ante mí."

# game/day2 choice.rpy:1270
translate Spanish wizzy_convo_ba857d41:

    # mc "I'm [player_call]. It's nice to meet you too, Wizzy."
    mc "Soy [player_call]. Mucho gusto, Wizzy."

# game/day2 choice.rpy:1273
translate Spanish wizzy_convo_048a6fc7:

    # wiz "M-ME TOO-! I mean... the pleasure is mine as well, Your Majesty."
    wiz "¡Y-YO TAMBIÉN-! Quiero decir... el placer es mío también, Majestad."

# game/day2 choice.rpy:1274
translate Spanish wizzy_convo_cf7011b5:

    # wiz "I'm just excited your majesty. It's... been a very long time since we last had a ruler. How many years has it been now...?"
    wiz "Es que estoy emocionado, Majestad. Hace... muchísimo tiempo que no teníamos gobernante. ¿Cuántos años han pasado ya...?"

# game/day2 choice.rpy:1275
translate Spanish wizzy_convo_d90e6a0c:

    # wiz "Ever since Cro-"
    wiz "Desde que Cro-"

# game/day2 choice.rpy:1278
translate Spanish wizzy_convo_64b6eac1:

    # "Wizzy abruptly cut himself off."
    "Wizzy se interrumpió de golpe."

# game/day2 choice.rpy:1280
translate Spanish wizzy_convo_b8352256:

    # wiz "I-I mean... yes. Ever since the king passed away."
    wiz "Q-quiero decir... sí. Desde que el rey falleció."

# game/day2 choice.rpy:1282
translate Spanish wizzy_convo_0fbb5304:

    # "Silence fell over the room. The atmosphere suddenly grew tense."
    "El silencio cayó sobre la habitación. El ambiente se puso tenso de repente."

# game/day2 choice.rpy:1283
translate Spanish wizzy_convo_25424afb:

    # "But then not for so long, Wizzy clapped his hands to break the silence."
    "Pero poco después, Wizzy aplaudió para romper el silencio."

# game/day2 choice.rpy:1286
translate Spanish wizzy_convo_a38179bf:

    # wiz "Jestyn did mention that he'd be bringing Your Majesty to meet me."
    wiz "Jestyn mencionó que traería a Su Majestad a conocerme."

# game/day2 choice.rpy:1289
translate Spanish wizzy_convo_513775de:

    # wiz "B-But... I got so caught up in my experiments that... well... I completely lost track of time."
    wiz "P-pero... me enfrasqué tanto en mis experimentos que... bueno... perdí por completo la noción del tiempo."

# game/day2 choice.rpy:1292
translate Spanish wizzy_convo_171eb796:

    # wiz "Hehe... Since the whole point is for us to get to know one another, please don't hesitate to ask me anything you'd like, Your Majesty."
    wiz "Jeje... Ya que el objetivo es que nos conozcamos, por favor no dude en preguntarme lo que quiera, Majestad."

# game/day2 choice.rpy:1295
translate Spanish wizzy_convo_d0513824:

    # wiz "Ah, oh! Just a moment! I should've prepared some refreshments for you! I'll be right back, Your Majesty!"
    wiz "¡Ah, oh! ¡Un momento! ¡Debí haber preparado algún refrigerio para usted! ¡Enseguida vuelvo, Majestad!"

# game/day2 choice.rpy:1297
translate Spanish wizzy_convo_6bc62c0c:

    # "Wizzy rushed to a nearby cabinet and started searching for something to offer me."
    "Wizzy corrió hacia un armario cercano y empezó a buscar algo que ofrecerme."

# game/day2 choice.rpy:1298
translate Spanish wizzy_convo_68312c55:

    # "As Wizzy busied himself, my eyes began to wander around the room."
    "Mientras Wizzy se afanaba, mis ojos comenzaron a vagar por la habitación."

# game/day2 choice.rpy:1337
translate Spanish examine_paper_9ce077e5:

    # "My eyes were drawn to the countless sheets of paper pinned across the walls of Wizzy's room."
    "Mis ojos se sintieron atraídos por las incontables hojas de papel clavadas en las paredes de la habitación de Wizzy."

# game/day2 choice.rpy:1338
translate Spanish examine_paper_899deeae:

    # "There were so many of them, each covered in notes I couldn't even begin to understand."
    "Eran tantas, y todas estaban cubiertas de notas que ni siquiera empezaba a entender."

# game/day2 choice.rpy:1339
translate Spanish examine_paper_d8abd225:

    # "Some seemed to be filled with chemical formulas, while others were covered in mathematical equations."
    "Algunas parecían estar llenas de fórmulas químicas, mientras que otras estaban cubiertas de ecuaciones matemáticas."

# game/day2 choice.rpy:1340
translate Spanish examine_paper_3c941fa8:

    # "Judging by these notes alone, Wizzy must have been incredibly intelligent."
    "A juzgar solo por esas notas, Wizzy debía de ser increíblemente inteligente."

# game/day2 choice.rpy:1341
translate Spanish examine_paper_63e19047:

    # "I continued looking through the rest of them."
    "Seguí mirando el resto."

# game/day2 choice.rpy:1342
translate Spanish examine_paper_b5086f92:

    # "One particular sheet caught my attention. Unlike the others, it wasn't filled with just numbers and formulas. There were drawings on it as well."
    "Una hoja en particular llamó mi atención. A diferencia de las demás, no estaba llena solo de números y fórmulas. También tenía dibujos."

# game/day2 choice.rpy:1343
translate Spanish examine_paper_bc8815b3:

    # "I tried my best to make sense of it, but unfortunately, it was completely beyond me."
    "Hice todo lo posible por entenderla, pero por desgracia estaba completamente fuera de mi alcance."

# game/day2 choice.rpy:1348
translate Spanish examine_potion_e1591784:

    # "My eyes drifted toward a shelf lined with bottles of all shapes and sizes."
    "Mis ojos se desviaron hacia un estante lleno de botellas de todas las formas y tamaños."

# game/day2 choice.rpy:1349
translate Spanish examine_potion_ee032e62:

    # "They varied in both shape and size, but what stood out the most was the sheer variety of colors."
    "Variaban en forma y tamaño, pero lo que más destacaba era la enorme variedad de colores."

# game/day2 choice.rpy:1350
translate Spanish examine_potion_b5fbd463:

    # "It was incredibly colorful."
    "Era increíblemente colorido."

# game/day2 choice.rpy:1351
translate Spanish examine_potion_ee9db83d:

    # "Alongside the bottles filled with vibrant liquids were others containing ingredients I didn't even recognize."
    "Junto a las botellas llenas de líquidos vibrantes había otras que contenían ingredientes que ni siquiera reconocía."

# game/day2 choice.rpy:1352
translate Spanish examine_potion_5fef93ce:

    # "In movies, bottles like these were usually filled with ingredients for brewing potions."
    "En las películas, botellas como esas solían estar llenas de ingredientes para preparar pociones."

# game/day2 choice.rpy:1353
translate Spanish examine_potion_180839f7:

    # "Considering Wizzy's role as the kingdom's wizard puppet, I suppose it made perfect sense."
    "Considerando el papel de Wizzy como marioneta mago del reino, supongo que tenía todo el sentido."

# game/day2 choice.rpy:1358
translate Spanish examine_corner1_02be28b2:

    # "My gaze drifted toward the corner of the room."
    "Mi mirada se desvió hacia la esquina de la habitación."

# game/day2 choice.rpy:1359
translate Spanish examine_corner1_d240222e:

    # "Several framed photographs rested quietly in the corner."
    "Varias fotografías enmarcadas descansaban tranquilamente en la esquina."

# game/day2 choice.rpy:1360
translate Spanish examine_corner1_857e02cf:

    # "From where I'm standing, I couldn't make out the details, but they seemed to be rather old."
    "Desde donde estaba, no podía distinguir los detalles, pero parecían bastante antiguas."

# game/day2 choice.rpy:1361
translate Spanish examine_corner1_3f7e3474:

    # "One frame, larger than all the others, immediately caught my attention."
    "Un marco, más grande que todos los demás, captó de inmediato mi atención."

# game/day2 choice.rpy:1362
translate Spanish examine_corner1_a39958f9:

    # "It held a photograph of a large group of people... though sadly, the picture had been torn."
    "Contenía una fotografía de un numeroso grupo de personas... aunque, lamentablemente, la imagen estaba rota."

# game/day2 choice.rpy:1363
translate Spanish examine_corner1_3c02446b:

    # "...I wondered if it was a photo of the puppets."
    "...Me pregunté si sería una foto de las marionetas."

# game/day2 choice.rpy:1368
translate Spanish examine_corner2_000791ce:

    # "My curiosity got the better of me."
    "La curiosidad pudo conmigo."

# game/day2 choice.rpy:1369
translate Spanish examine_corner2_fb8fd763:

    # "I narrowed my eyes, trying to get a better look at the photograph."
    "Entrecerré los ojos, tratando de ver mejor la fotografía."

# game/day2 choice.rpy:1370
translate Spanish examine_corner2_87bf7084:

    # "The upper half had been torn off, so only the lower portion remained."
    "La mitad superior había sido arrancada, así que solo quedaba la parte inferior."

# game/day2 choice.rpy:1371
translate Spanish examine_corner2_cf92f6fa:

    # "Unfortunately, it was still too far away for me to see it clearly."
    "Por desgracia, aún estaba demasiado lejos para verla con claridad."

# game/day2 choice.rpy:1380
translate Spanish examine_corner3_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:1381
translate Spanish examine_corner3_a95ef4db:

    # "...I wanted to know."
    "...Quería saber."

# game/day2 choice.rpy:1382
translate Spanish examine_corner3_be6c645b:

    # "My body felt strangely light as I slowly began to move-"
    "Mi cuerpo se sentía extrañamente ligero mientras empezaba a moverme lentamente-"

# game/day2 choice.rpy:1389
translate Spanish wizzy_convo2_5885e934:

    # wiz "Your Majesty, I'm back! Look, I brought some cookies!"
    wiz "¡Majestad, ya volví! ¡Mire, traje galletas!"

# game/day2 choice.rpy:1393
translate Spanish wizzy_convo2_734d6915:

    # wiz "They're not anything fancy, but... I hope they're better than having nothing at all."
    wiz "No son nada del otro mundo, pero... espero que sean mejor que nada."

# game/day2 choice.rpy:1395
translate Spanish wizzy_convo2_38f50486:

    # "Wizzy handed me a glass jar filled with chocolate cookies."
    "Wizzy me entregó un frasco de vidrio lleno de galletas de chocolate."

# game/day2 choice.rpy:1398
translate Spanish wizzy_convo2_0198e139:

    # wiz "I actually wanted to serve you some tea as well... but I've run out. Maybe I could ask one of the other puppets if they have some..."
    wiz "En realidad quería servirle también un té... pero se me acabó. Quizá podría preguntarle a alguna de las otras marionetas si tienen..."

# game/day2 choice.rpy:1400
translate Spanish wizzy_convo2_c14329cc:

    # "Wizzy started to rise from his seat again."
    "Wizzy empezó a levantarse de nuevo de su asiento."

# game/day2 choice.rpy:1402
translate Spanish wizzy_convo2_2d522a27:

    # mc "What? No, really. There's no need."
    mc "¿Qué? No, de verdad. No hace falta."

# game/day2 choice.rpy:1403
translate Spanish wizzy_convo2_e9db2bb9:

    # wiz "But... I don't feel like cookies alone are enough for Your Majesty."
    wiz "Pero... no creo que las galletas solas sean suficientes para Su Majestad."

# game/day2 choice.rpy:1404
translate Spanish wizzy_convo2_4ad08f28:

    # mc "No, really. This is more than enough."
    mc "No, en serio. Es más que suficiente."

# game/day2 choice.rpy:1405
translate Spanish wizzy_convo2_98cb3f17:

    # mc "The fact that you went through the trouble of serving me cookies is already more than I could ask for."
    mc "El hecho de que te hayas tomado la molestia de servirme galletas ya es más de lo que podría pedir."

# game/day2 choice.rpy:1406
translate Spanish wizzy_convo2_bd03f6fc:

    # mc "You really don't need to do anything more than that."
    mc "De verdad no hace falta que hagas nada más."

# game/day2 choice.rpy:1409
translate Spanish wizzy_convo2_cda93efa:

    # "Wizzy's expression immediately brightened."
    "La expresión de Wizzy se iluminó de inmediato."

# game/day2 choice.rpy:1411
translate Spanish wizzy_convo2_a37e2ee2:

    # wiz "R-Really...? I'm so glad you feel that way, Your Majesty..."
    wiz "¿D-de verdad...? Me alegra mucho que lo sienta así, Majestad..."

# game/day2 choice.rpy:1412
translate Spanish wizzy_convo2_67af2416:

    # wiz "Hehe... You're very kind, Your Majesty."
    wiz "Jeje... Es usted muy amable, Majestad."

# game/day2 choice.rpy:1414
translate Spanish wizzy_convo2_d6f12e08:

    # "With that, Wizzy settled back into his seat."
    "Dicho esto, Wizzy volvió a acomodarse en su asiento."

# game/day2 choice.rpy:1416
translate Spanish wizzy_convo2_17470982:

    # wiz "Go ahead and try one, Your Majesty. They're really good. I always ask Jestyn to pick them up for me whenever he goes outside."
    wiz "Pruebe una, Majestad. Están muy buenas. Siempre le pido a Jestyn que me las traiga cuando sale."

# game/day2 choice.rpy:1417
translate Spanish wizzy_convo2_71964461:

    # wiz "I absolutely love them."
    wiz "Me encantan."

# game/day2 choice.rpy:1420
translate Spanish wizzy_convo2_1364ce2f:

    # "Since Wizzy insisted, I opened the jar and took out a single cookie."
    "Como Wizzy insistía, abrí el frasco y saqué una sola galleta."

# game/day2 choice.rpy:1421
translate Spanish wizzy_convo2_4f22e757:

    # "The moment I bit into it, a rich chocolate flavor filled my mouth. One bite was all it took for me to realize these were high-quality cookies."
    "En cuanto le di un mordisco, un intenso sabor a chocolate me llenó la boca. Un bocado bastó para darme cuenta de que eran galletas de alta calidad."

# game/day2 choice.rpy:1422
translate Spanish wizzy_convo2_d9a61dab:

    # "It was a completely new experience for someone whose diet mostly includes instant foods."
    "Era una experiencia completamente nueva para alguien cuya dieta consistía sobre todo en comida instantánea."

# game/day2 choice.rpy:1424
translate Spanish wizzy_convo2_dee81eef:

    # mc "Mm! These are delicious!"
    mc "¡Mm! ¡Están deliciosas!"

# game/day2 choice.rpy:1425
translate Spanish wizzy_convo2_4a9d2302:

    # wiz "See? I told you. I'm so happy you like them!"
    wiz "¿Ve? Se lo dije. ¡Me alegra mucho que le gusten!"

# game/day2 choice.rpy:1426
translate Spanish wizzy_convo2_27162d96:

    # wiz "Now then, while Your Majesty enjoys the cookies, we can finally have a nice chat."
    wiz "Bien, mientras Su Majestad disfruta de las galletas, por fin podemos charlar un rato."

# game/day2 choice.rpy:1429
translate Spanish wizzy_convo2_7c606535:

    # wiz "Your Majesty only arrived in the kingdom yesterday, isn't that right?"
    wiz "Su Majestad llegó al reino apenas ayer, ¿no es así?"

# game/day2 choice.rpy:1430
translate Spanish wizzy_convo2_cf1adef2:

    # mc "Yeah."
    mc "Sí."

# game/day2 choice.rpy:1431
translate Spanish wizzy_convo2_8000aaf3:

    # wiz "Mmm... Welcome to the Kingdom of Marionettes, Your Majesty."
    wiz "Mmm... Bienvenid[letra] al Reino de las Marionetas, Majestad."

# game/day2 choice.rpy:1432
translate Spanish wizzy_convo2_4b9330d0:

    # wiz "I hope you'll come to feel at home here... and gradually get used to all the puppets who live in the kingdom."
    wiz "Espero que llegue a sentirse como en casa aquí... y que poco a poco se acostumbre a todas las marionetas que viven en el reino."

# game/day2 choice.rpy:1435
translate Spanish wizzy_convo2_f707cc32:

    # wiz "{size= 15}.... Well....not everyone maybe....{/size}"
    wiz "{size= 15}.... Bueno... quizá no a todas....{/size}"

# game/day2 choice.rpy:1438
translate Spanish wizzy_convo2_0ffe93c2:

    # wiz "You've only been here for two days, but... you seem to be settling in rather well."
    wiz "Lleva solo dos días aquí, pero... parece estar adaptándose bastante bien."

# game/day2 choice.rpy:1439
translate Spanish wizzy_convo2_0c957f25:

    # mc "Actually... yes and no. I'm not really sure. Yesterday, Jestyn was... pretty intense. It left such a strong impression that I still can't stop thinking about it."
    mc "En realidad... sí y no. No estoy muy segur[letra]. Ayer, Jestyn fue... bastante intenso. Me dejó una impresión tan fuerte que todavía no puedo dejar de pensar en ello."

# game/day2 choice.rpy:1445
translate Spanish wizzy_convo2_5497cf56:

    # jes "Ooh~ Of course, Your Majesty. After all, this passionate little jester is simply unforgettable."
    jes "Ooh~ Por supuesto, Majestad. Después de todo, este apasionado bufoncito es sencillamente inolvidable."

# game/day2 choice.rpy:1446
translate Spanish wizzy_convo2_41e2753b:

    # jes "Would you care to relive the experience?"
    jes "¿Le gustaría revivir la experiencia?"

# game/day2 choice.rpy:1447
translate Spanish wizzy_convo2_f4b32692:

    # mc "No, thank you."
    mc "No, gracias."

# game/day2 choice.rpy:1450
translate Spanish wizzy_convo2_4b1e3db4:

    # "For now at least..."
    "Por ahora, al menos..."

# game/day2 choice.rpy:1454
translate Spanish wizzy_convo2_aaec70c6:

    # wiz "Hehe... Yes, that's just how Jestyn is."
    wiz "Jeje... Sí, así es Jestyn."

# game/day2 choice.rpy:1455
translate Spanish wizzy_convo2_7fed6a25:

    # wiz "He was actually testing you yesterday. To see whether you were worthy of becoming our [title]."
    wiz "Ayer en realidad le estaba poniendo a prueba. Para ver si era dign[letra] de convertirse en nuestr[letra] [title!t]."

# game/day2 choice.rpy:1456
translate Spanish wizzy_convo2_5bc8ff03:

    # wiz "It's always been done that way. You could say it's... sort of like a ritual."
    wiz "Siempre se ha hecho así. Podría decirse que es... una especie de ritual."

# game/day2 choice.rpy:1459
translate Spanish wizzy_convo2_de0b3bae:

    # wiz "And during the ritual, every puppet stays in their own room..."
    wiz "Y durante el ritual, cada marioneta permanece en su propia habitación..."

# game/day2 choice.rpy:1461
translate Spanish wizzy_convo2_25e1e0a5:

    # "He pauses."
    "Hace una pausa."

# game/day2 choice.rpy:1464
translate Spanish wizzy_convo2_7d588ff9:

    # wiz "...Well, most of them do."
    wiz "...Bueno, la mayoría."

# game/day2 choice.rpy:1469
translate Spanish wizzy_convo2_a2d7059f:

    # jes "But don't worry, Your Majesty. They're all happily spending time in their own rooms. I'm not keeping them locked up like birds in a cage."
    jes "Pero no se preocupe, Majestad. Todos están pasando el rato felizmente en sus propias habitaciones. No los tengo encerrados como pájaros en una jaula."

# game/day2 choice.rpy:1470
translate Spanish wizzy_convo2_0f736b16:

    # jes "Some are reading books... some are SLEEPING."
    jes "Algunos leen libros... algunos están DURMIENDO."

# game/day2 choice.rpy:1473
translate Spanish wizzy_convo2_3ed864cd:

    # "Wizzy frowned the moment Jestyn emphasized that last word."
    "Wizzy frunció el ceño en cuanto Jestyn enfatizó esa última palabra."

# game/day2 choice.rpy:1477
translate Spanish wizzy_convo2_8e5aceeb:

    # jes "Some are sharpening their swords, praying, cooking, swimming, solving puzzles, exercising, dancing, screaming, banging their heads against the wall... la la la la~♪"
    jes "Algunos afilan sus espadas, rezan, cocinan, nadan, resuelven acertijos, hacen ejercicio, bailan, gritan, se golpean la cabeza contra la pared... la la la la~♪"

# game/day2 choice.rpy:1483
translate Spanish wizzy_convo2_5497cf56_1:

    # jes "Ooh~ Of course, Your Majesty. After all, this passionate little jester is simply unforgettable."
    jes "Ooh~ Por supuesto, Majestad. Después de todo, este apasionado bufoncito es sencillamente inolvidable."

# game/day2 choice.rpy:1484
translate Spanish wizzy_convo2_41e2753b_1:

    # jes "Would you care to relive the experience?"
    jes "¿Le gustaría revivir la experiencia?"

# game/day2 choice.rpy:1485
translate Spanish wizzy_convo2_f4b32692_1:

    # mc "No, thank you."
    mc "No, gracias."

# game/day2 choice.rpy:1488
translate Spanish wizzy_convo2_4b1e3db4_1:

    # "For now at least..."
    "Por ahora, al menos..."

# game/day2 choice.rpy:1493
translate Spanish wizzy_convo2_aaec70c6_1:

    # wiz "Hehe... Yes, that's just how Jestyn is."
    wiz "Jeje... Sí, así es Jestyn."

# game/day2 choice.rpy:1494
translate Spanish wizzy_convo2_7fed6a25_1:

    # wiz "He was actually testing you yesterday. To see whether you were worthy of becoming our [title]."
    wiz "Ayer en realidad le estaba poniendo a prueba. Para ver si era dign[letra] de convertirse en nuestr[letra] [title!t]."

# game/day2 choice.rpy:1495
translate Spanish wizzy_convo2_5bc8ff03_1:

    # wiz "It's always been done that way. You could say it's... sort of like a ritual."
    wiz "Siempre se ha hecho así. Podría decirse que es... una especie de ritual."

# game/day2 choice.rpy:1498
translate Spanish wizzy_convo2_de0b3bae_1:

    # wiz "And during the ritual, every puppet stays in their own room..."
    wiz "Y durante el ritual, cada marioneta permanece en su propia habitación..."

# game/day2 choice.rpy:1500
translate Spanish wizzy_convo2_25e1e0a5_1:

    # "He pauses."
    "Hace una pausa."

# game/day2 choice.rpy:1503
translate Spanish wizzy_convo2_7d588ff9_1:

    # wiz "...Well, most of them do."
    wiz "...Bueno, la mayoría."

# game/day2 choice.rpy:1508
translate Spanish wizzy_convo2_a2d7059f_1:

    # jes "But don't worry, Your Majesty. They're all happily spending time in their own rooms. I'm not keeping them locked up like birds in a cage."
    jes "Pero no se preocupe, Majestad. Todos están pasando el rato felizmente en sus propias habitaciones. No los tengo encerrados como pájaros en una jaula."

# game/day2 choice.rpy:1509
translate Spanish wizzy_convo2_0f736b16_1:

    # jes "Some are reading books... some are SLEEPING."
    jes "Algunos leen libros... algunos están DURMIENDO."

# game/day2 choice.rpy:1512
translate Spanish wizzy_convo2_3ed864cd_1:

    # "Wizzy frowned the moment Jestyn emphasized that last word."
    "Wizzy frunció el ceño en cuanto Jestyn enfatizó esa última palabra."

# game/day2 choice.rpy:1516
translate Spanish wizzy_convo2_8e5aceeb_1:

    # jes "Some are sharpening their swords, praying, cooking, swimming, solving puzzles, exercising, dancing, screaming, banging their heads against the wall... la la la la~♪"
    jes "Algunos afilan sus espadas, rezan, cocinan, nadan, resuelven acertijos, hacen ejercicio, bailan, gritan, se golpean la cabeza contra la pared... la la la la~♪"

# game/day2 choice.rpy:1518
translate Spanish wizzy_convo2_2fb50574:

    # "Jestyn continued rambling without so much as taking a breath."
    "Jestyn siguió divagando sin siquiera tomar aire."

# game/day2 choice.rpy:1519
translate Spanish wizzy_convo2_23250c9d:

    # "Honestly... how was I supposed to get to know Wizzy any better if Jestyn kept talking like this?"
    "La verdad... ¿cómo se suponía que iba a conocer mejor a Wizzy si Jestyn seguía hablando así?"

# game/day2 choice.rpy:1520
translate Spanish wizzy_convo2_69c0fe15:

    # "Maybe I should just wait for him to finish..."
    "Quizá debería esperar a que terminara..."

# game/day2 choice.rpy:1521
translate Spanish wizzy_convo2_aa1fec76:

    # "...Or maybe I should stuff something in his mouth."
    "...O quizá debería meterle algo en la boca."

# game/day2 choice.rpy:1522
translate Spanish wizzy_convo2_adf6c978:

    # "At least, that was the thought that crossed my mind."
    "Al menos, ese fue el pensamiento que me cruzó la mente."

# game/day2 choice.rpy:1529
translate Spanish wizzy_convo2_0eb04ba3:

    # "No. If I wanted to get to know Wizzy, Jestyn needed to be quiet."
    "No. Si quería conocer a Wizzy, Jestyn tenía que callarse."

# game/day2 choice.rpy:1530
translate Spanish wizzy_convo2_3cbbc22d:

    # "At the very least, I had to find a way to make him stop talking."
    "Como mínimo, tenía que encontrar la manera de hacer que dejara de hablar."

# game/day2 choice.rpy:1531
translate Spanish wizzy_convo2_ff8993f9:

    # "I glanced around, searching for something that might keep Jestyn quiet. Then I reached into my pocket and found a handkerchief."
    "Miré alrededor, buscando algo que pudiera mantener callado a Jestyn. Entonces metí la mano en el bolsillo y encontré un pañuelo."

# game/day2 choice.rpy:1532
translate Spanish wizzy_convo2_af34974a:

    # "Maybe this would work."
    "Quizá esto serviría."

# game/day2 choice.rpy:1533
translate Spanish wizzy_convo2_b1a7656f:

    # "Without giving it a second thought, I gently stuffed the handkerchief into Jestyn's mouth."
    "Sin pensarlo dos veces, le metí suavemente el pañuelo en la boca a Jestyn."

# game/day2 choice.rpy:1537
translate Spanish wizzy_convo2_abd81e8c:

    # jes "Hmph?!"
    jes "¡¿Hmph?!"

# game/day2 choice.rpy:1538
translate Spanish wizzy_convo2_cb1baada:

    # mc "Jestyn, I'm trying to talk to Wizzy. So please, stay quiet."
    mc "Jestyn, estoy intentando hablar con Wizzy. Así que, por favor, cállate."

# game/day2 choice.rpy:1541
translate Spanish wizzy_convo2_08ae74ca:

    # jes "Mmhh..."
    jes "Mmhh..."

# game/day2 choice.rpy:1543
translate Spanish wizzy_convo2_edbf9b12:

    # "Jestyn nodded. He understood."
    "Jestyn asintió. Lo había entendido."

# game/day2 choice.rpy:1544
translate Spanish wizzy_convo2_299614ab:

    # "Meanwhile, Wizzy was doing his best to hold back his laughter."
    "Mientras tanto, Wizzy hacía todo lo posible por contener la risa."

# game/day2 choice.rpy:1548
translate Spanish wizzy_convo2_5cf989cb:

    # wiz "P-pardon me your majesty... huff... ehem!"
    wiz "P-perdone, Majestad... jeje... ¡ejem!"

# game/day2 choice.rpy:1553
translate Spanish wizzy_convo2_0eb04ba3_1:

    # "No. If I wanted to get to know Wizzy, Jestyn needed to be quiet."
    "No. Si quería conocer a Wizzy, Jestyn tenía que callarse."

# game/day2 choice.rpy:1554
translate Spanish wizzy_convo2_3cbbc22d_1:

    # "At the very least, I had to find a way to make him stop talking."
    "Como mínimo, tenía que encontrar la manera de hacer que dejara de hablar."

# game/day2 choice.rpy:1555
translate Spanish wizzy_convo2_ff8993f9_1:

    # "I glanced around, searching for something that might keep Jestyn quiet. Then I reached into my pocket and found a handkerchief."
    "Miré alrededor, buscando algo que pudiera mantener callado a Jestyn. Entonces metí la mano en el bolsillo y encontré un pañuelo."

# game/day2 choice.rpy:1556
translate Spanish wizzy_convo2_af34974a_1:

    # "Maybe this would work."
    "Quizá esto serviría."

# game/day2 choice.rpy:1557
translate Spanish wizzy_convo2_b1a7656f_1:

    # "Without giving it a second thought, I gently stuffed the handkerchief into Jestyn's mouth."
    "Sin pensarlo dos veces, le metí suavemente el pañuelo en la boca a Jestyn."

# game/day2 choice.rpy:1561
translate Spanish wizzy_convo2_abd81e8c_1:

    # jes "Hmph?!"
    jes "¡¿Hmph?!"

# game/day2 choice.rpy:1562
translate Spanish wizzy_convo2_cb1baada_1:

    # mc "Jestyn, I'm trying to talk to Wizzy. So please, stay quiet."
    mc "Jestyn, estoy intentando hablar con Wizzy. Así que, por favor, cállate."

# game/day2 choice.rpy:1565
translate Spanish wizzy_convo2_08ae74ca_1:

    # jes "Mmhh..."
    jes "Mmhh..."

# game/day2 choice.rpy:1567
translate Spanish wizzy_convo2_edbf9b12_1:

    # "Jestyn nodded. He understood."
    "Jestyn asintió. Lo había entendido."

# game/day2 choice.rpy:1568
translate Spanish wizzy_convo2_299614ab_1:

    # "Meanwhile, Wizzy was doing his best to hold back his laughter."
    "Mientras tanto, Wizzy hacía todo lo posible por contener la risa."

# game/day2 choice.rpy:1573
translate Spanish wizzy_convo2_5cf989cb_1:

    # wiz "P-pardon me your majesty... huff... ehem!"
    wiz "P-perdone, Majestad... jeje... ¡ejem!"

# game/day2 choice.rpy:1580
translate Spanish wizzy_convo2_66676f40:

    # "...On second thought..."
    "...Pensándolo mejor..."

# game/day2 choice.rpy:1581
translate Spanish wizzy_convo2_0a3e230d:

    # "It didn't feel right to force him to stay quiet. It felt like I was silencing him."
    "No me pareció correcto obligarlo a guardar silencio. Sentía que lo estaba silenciando."

# game/day2 choice.rpy:1582
translate Spanish wizzy_convo2_f0731abd:

    # "I should just let him talk until he's satisfied."
    "Debería dejarlo hablar hasta que quede satisfecho."

# game/day2 choice.rpy:1584
translate Spanish wizzy_convo2_e0ac0be2:

    # jes "Your Majesty must be wondering why I kept everyone in their rooms while I was... entertaining you."
    jes "Su Majestad debe de estar preguntándose por qué mantuve a todos en sus habitaciones mientras yo... le entretenía."

# game/day2 choice.rpy:1585
translate Spanish wizzy_convo2_4185ac2b:

    # jes "Well, surely Your Majesty would be nervous with so many puppets. Living puppets no less, watching your every move."
    jes "Bueno, seguramente Su Majestad se pondría nervios[letra] con tantas marionetas. Marionetas vivas, nada menos, observando cada uno de sus movimientos."

# game/day2 choice.rpy:1588
translate Spanish wizzy_convo2_7a1f6fa4:

    # jes "I know that feeling all too well. Hundreds of eyes fixed on a single person. Every gaze in the room upon you. You become the center of everyone's attention, wrapped in a blanket of overwhelm and anxiety as thick as a fairy godmother's quilt."
    jes "Conozco esa sensación demasiado bien. Cientos de ojos fijos en una sola persona. Todas las miradas de la sala puestas en uno. Uno se convierte en el centro de atención de todos, envuelto en una manta de agobio y ansiedad tan gruesa como el edredón de un hada madrina."

# game/day2 choice.rpy:1589
translate Spanish wizzy_convo2_f1bdeb05:

    # jes "And because this jester is so wonderfully considerate... I came up with the perfect solution! I made sure every puppet stayed in their room, leaving the stage completely empty."
    jes "Y como este bufón es tan maravillosamente considerado... ¡se me ocurrió la solución perfecta! Me aseguré de que cada marioneta permaneciera en su habitación, dejando el escenario completamente vacío."

# game/day2 choice.rpy:1592
translate Spanish wizzy_convo2_811c3e3e:

    # jes "So it would be just the two of us... dancing beneath the brilliant stage lights... while the other puppets simply moved along like the tides of the sea."
    jes "Así seríamos solo los dos... bailando bajo las brillantes luces del escenario... mientras las demás marionetas simplemente se movían como las mareas del mar."

# game/day2 choice.rpy:1593
translate Spanish wizzy_convo2_a7bcf340:

    # mc "I see..."
    mc "Ya veo..."

# game/day2 choice.rpy:1594
translate Spanish wizzy_convo2_862d43a0:

    # mc "Are you finished now?"
    mc "¿Ya terminaste?"

# game/day2 choice.rpy:1597
translate Spanish wizzy_convo2_d86597d9:

    # jes "Aaaand because it was my chance to have Your Majesty all to myself, like a pair of graceful swans~"
    jes "Yyyy porque era mi oportunidad de tener a Su Majestad solo para mí, como un par de elegantes cisnes~"

# game/day2 choice.rpy:1598
translate Spanish wizzy_convo2_57d8befa:

    # jes "Yes. I'm finished now."
    jes "Sí. Ya terminé."

# game/day2 choice.rpy:1602
translate Spanish wizzy_convo2_d1019c0c:

    # wiz "...That's just how Jestyn is, Your Majesty."
    wiz "...Así es Jestyn, Majestad."

# game/day2 choice.rpy:1603
translate Spanish wizzy_convo2_30c75e1b:

    # wiz "He really does love to talk... so I hope you'll forgive him."
    wiz "Le encanta hablar... así que espero que lo perdone."

# game/day2 choice.rpy:1606
translate Spanish wizzy_convo2_66676f40_1:

    # "...On second thought..."
    "...Pensándolo mejor..."

# game/day2 choice.rpy:1607
translate Spanish wizzy_convo2_0a3e230d_1:

    # "It didn't feel right to force him to stay quiet. It felt like I was silencing him."
    "No me pareció correcto obligarlo a guardar silencio. Sentía que lo estaba silenciando."

# game/day2 choice.rpy:1608
translate Spanish wizzy_convo2_f0731abd_1:

    # "I should just let him talk until he's satisfied."
    "Debería dejarlo hablar hasta que quede satisfecho."

# game/day2 choice.rpy:1611
translate Spanish wizzy_convo2_e0ac0be2_1:

    # jes "Your Majesty must be wondering why I kept everyone in their rooms while I was... entertaining you."
    jes "Su Majestad debe de estar preguntándose por qué mantuve a todos en sus habitaciones mientras yo... le entretenía."

# game/day2 choice.rpy:1612
translate Spanish wizzy_convo2_4185ac2b_1:

    # jes "Well, surely Your Majesty would be nervous with so many puppets. Living puppets no less, watching your every move."
    jes "Bueno, seguramente Su Majestad se pondría nervios[letra] con tantas marionetas. Marionetas vivas, nada menos, observando cada uno de sus movimientos."

# game/day2 choice.rpy:1615
translate Spanish wizzy_convo2_7a1f6fa4_1:

    # jes "I know that feeling all too well. Hundreds of eyes fixed on a single person. Every gaze in the room upon you. You become the center of everyone's attention, wrapped in a blanket of overwhelm and anxiety as thick as a fairy godmother's quilt."
    jes "Conozco esa sensación demasiado bien. Cientos de ojos fijos en una sola persona. Todas las miradas de la sala puestas en uno. Uno se convierte en el centro de atención de todos, envuelto en una manta de agobio y ansiedad tan gruesa como el edredón de un hada madrina."

# game/day2 choice.rpy:1616
translate Spanish wizzy_convo2_f1bdeb05_1:

    # jes "And because this jester is so wonderfully considerate... I came up with the perfect solution! I made sure every puppet stayed in their room, leaving the stage completely empty."
    jes "Y como este bufón es tan maravillosamente considerado... ¡se me ocurrió la solución perfecta! Me aseguré de que cada marioneta permaneciera en su habitación, dejando el escenario completamente vacío."

# game/day2 choice.rpy:1619
translate Spanish wizzy_convo2_811c3e3e_1:

    # jes "So it would be just the two of us... dancing beneath the brilliant stage lights... while the other puppets simply moved along like the tides of the sea."
    jes "Así seríamos solo los dos... bailando bajo las brillantes luces del escenario... mientras las demás marionetas simplemente se movían como las mareas del mar."

# game/day2 choice.rpy:1620
translate Spanish wizzy_convo2_a7bcf340_1:

    # mc "I see..."
    mc "Ya veo..."

# game/day2 choice.rpy:1621
translate Spanish wizzy_convo2_862d43a0_1:

    # mc "Are you finished now?"
    mc "¿Ya terminaste?"

# game/day2 choice.rpy:1624
translate Spanish wizzy_convo2_d86597d9_1:

    # jes "Aaaand because it was my chance to have Your Majesty all to myself, like a pair of graceful swans~"
    jes "Yyyy porque era mi oportunidad de tener a Su Majestad solo para mí, como un par de elegantes cisnes~"

# game/day2 choice.rpy:1625
translate Spanish wizzy_convo2_57d8befa_1:

    # jes "Yes. I'm finished now."
    jes "Sí. Ya terminé."

# game/day2 choice.rpy:1629
translate Spanish wizzy_convo2_d1019c0c_1:

    # wiz "...That's just how Jestyn is, Your Majesty."
    wiz "...Así es Jestyn, Majestad."

# game/day2 choice.rpy:1630
translate Spanish wizzy_convo2_30c75e1b_1:

    # wiz "He really does love to talk... so I hope you'll forgive him."
    wiz "Le encanta hablar... así que espero que lo perdone."

# game/day2 choice.rpy:1633
translate Spanish wizzy_convo2_cc9809d6:

    # wiz "As for me... Yes, Jestyn is not wrong. I slept through the entire thing yesterday."
    wiz "En cuanto a mí... Sí, Jestyn no se equivoca. Ayer me dormí durante todo el asunto."

# game/day2 choice.rpy:1635
translate Spanish wizzy_convo2_b95e65a9:

    # voice "WIZZY02_DAY2.ogg"
    # wiz "That's not usually the case, though. I'd been up all night running experiments, so I was completely exhausted."
    voice "WIZZY02_DAY2.ogg"
    wiz "Aunque normalmente no es así. Había pasado toda la noche haciendo experimentos, así que estaba completamente agotado."

# game/day2 choice.rpy:1638
translate Spanish wizzy_convo2_95e0e6ec:

    # mc "...Has anyone else ever come here... and gone through that ritual to become the next ruler?"
    mc "...¿Alguien más ha venido aquí... y ha pasado por ese ritual para convertirse en el próximo gobernante?"

# game/day2 choice.rpy:1641
translate Spanish wizzy_convo2_147fa308:

    # "Wizzy fell silent for a moment. His fingers intertwined as he fidgeted nervously."
    "Wizzy guardó silencio un momento. Entrelazó los dedos mientras se inquietaba nervioso."

# game/day2 choice.rpy:1643
translate Spanish wizzy_convo2_05f75f14:

    # wiz "...Yes."
    wiz "...Sí."

# game/day2 choice.rpy:1644
translate Spanish wizzy_convo2_8b482f52:

    # wiz "There have been... a few."
    wiz "Ha habido... algunos."

# game/day2 choice.rpy:1645
translate Spanish wizzy_convo2_3b21f354:

    # mc "......"
    mc "......"

# game/day2 choice.rpy:1646
translate Spanish wizzy_convo2_e5c802c0:

    # mc "Then... since I'm here..."
    mc "Entonces... ya que estoy aquí..."

# game/day2 choice.rpy:1647
translate Spanish wizzy_convo2_754017b8:

    # mc "...Am I right to assume the ritual didn't choose them?"
    mc "...¿Debo suponer que el ritual no los eligió a ellos?"

# game/day2 choice.rpy:1648
translate Spanish wizzy_convo2_a34af93a:

    # wiz "...You could say that, Your Majesty."
    wiz "...Se podría decir que sí, Majestad."

# game/day2 choice.rpy:1650
translate Spanish wizzy_convo2_939eafd8:

    # "My mind began to race with countless possibilities, and a wave of anxiety washed over me."
    "Mi mente empezó a acelerarse con incontables posibilidades, y una ola de ansiedad me invadió."

# game/day2 choice.rpy:1651
translate Spanish wizzy_convo2_f806cf72:

    # "Only one question lingered in my mind."
    "Solo una pregunta persistía en mi mente."

# game/day2 choice.rpy:1652
translate Spanish wizzy_convo2_b156b3b1:

    # "If the ritual failed... then what happened to the person who worked here before me?"
    "Si el ritual fracasó... ¿qué le pasó a la persona que estuvo aquí antes que yo?"

# game/day2 choice.rpy:1653
translate Spanish wizzy_convo2_d0b1445f:

    # "...Was that even a safe question to ask?"
    "...¿Era siquiera seguro hacer esa pregunta?"

# game/day2 choice.rpy:1655
translate Spanish wizzy_convo2_2b9484d4:

    # mc "If... the ritual failed... then what..."
    mc "Si... el ritual fracasó... entonces qué..."

# game/day2 choice.rpy:1656
translate Spanish wizzy_convo2_547cd005:

    # wiz "...It means that person had to leave the kingdom. At least... that's what the rules say..."
    wiz "...Significa que esa persona tuvo que abandonar el reino. Al menos... eso dicen las reglas..."

# game/day2 choice.rpy:1659
translate Spanish wizzy_convo2_f8877e41:

    # wiz " Jestyn's rules... More precisely."
    wiz " Las reglas de Jestyn... Para ser más precisos."

# game/day2 choice.rpy:1661
translate Spanish wizzy_convo2_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:1663
translate Spanish wizzy_convo2_65843a43:

    # wiz "Please don't worry so much, Your Majesty. There's no need to be so anxious."
    wiz "Por favor, no se preocupe tanto, Majestad. No hay necesidad de estar tan ansios[letra]."

# game/day2 choice.rpy:1666
translate Spanish wizzy_convo2_76d4bdd6:

    # wiz "How about asking me something instead? The whole point of this conversation is for Your Majesty to get to know your retainers better, isn't it?"
    wiz "¿Qué tal si me pregunta algo mejor? El objetivo de esta conversación es que Su Majestad conozca mejor a sus vasallos, ¿no es así?"

# game/day2 choice.rpy:1667
translate Spanish wizzy_convo2_d2035661:

    # wiz "You can ask me anything you'd like, Your Majesty."
    wiz "Puede preguntarme lo que quiera, Majestad."

# game/day2 choice.rpy:1669
translate Spanish wizzy_convo2_ffba5969:

    # "Wizzy took off his cloak and laid it neatly on the bed before returning to his seat to continue our conversation."
    "Wizzy se quitó la capa y la dejó cuidadosamente sobre la cama antes de volver a su asiento para continuar nuestra conversación."

# game/day2 choice.rpy:1694
translate Spanish freetime_wizzy_5c360b2a:

    # mc "I'm curious... what do you usually do in your free time?"
    mc "Tengo curiosidad... ¿qué sueles hacer en tu tiempo libre?"

# game/day2 choice.rpy:1697
translate Spanish freetime_wizzy_cda93efa:

    # "Wizzy's expression immediately brightened."
    "La expresión de Wizzy se iluminó de inmediato."

# game/day2 choice.rpy:1699
translate Spanish freetime_wizzy_4df09a68:

    # wiz "Oh! Quite a lot, actually."
    wiz "¡Oh! Bastante, en realidad."

# game/day2 choice.rpy:1700
translate Spanish freetime_wizzy_2e3e7de1:

    # wiz "I have plenty of free time every day because... well... there's not much work that actually requires my attention."
    wiz "Tengo mucho tiempo libre todos los días porque... bueno... no hay mucho trabajo que realmente requiera mi atención."

# game/day2 choice.rpy:1703
translate Spanish freetime_wizzy_808a8101:

    # wiz "So I usually spend my time writing, reading... and my favorite of all, conducting experiments."
    wiz "Así que normalmente paso el tiempo escribiendo, leyendo... y lo que más me gusta de todo, haciendo experimentos."

# game/day2 choice.rpy:1704
translate Spanish freetime_wizzy_2861c5d4:

    # wiz "I probably spend the most time experimenting."
    wiz "Probablemente es en lo que más tiempo invierto."

# game/day2 choice.rpy:1706
translate Spanish freetime_wizzy_8188c980:

    # "Yep. This puppet is definitely the smart one."
    "Sí. Esta marioneta es definitivamente la inteligente."

# game/day2 choice.rpy:1708
translate Spanish freetime_wizzy_fbca39a3:

    # mc "What do you write about?"
    mc "¿Sobre qué escribes?"

# game/day2 choice.rpy:1711
translate Spanish freetime_wizzy_88e8fa76:

    # wiz "All sorts of things... Hmm, let's see..."
    wiz "De todo un poco... Mmm, a ver..."

# game/day2 choice.rpy:1714
translate Spanish freetime_wizzy_66732432:

    # "Wizzy stands up and walked over to his desk."
    "Wizzy se levantó y caminó hacia su escritorio."

# game/day2 choice.rpy:1715
translate Spanish freetime_wizzy_7ca76f00:

    # "He opened one of the drawers and pulled out a thick, worn brown notebook."
    "Abrió uno de los cajones y sacó un cuaderno marrón grueso y desgastado."

# game/day2 choice.rpy:1718
translate Spanish freetime_wizzy_1c9d89d9:

    # wiz "Here it is! Pretty thick, isn't it? Well... I write in it almost every day."
    wiz "¡Aquí está! Bastante grueso, ¿verdad? Bueno... escribo en él casi todos los días."

# game/day2 choice.rpy:1719
translate Spanish freetime_wizzy_602f3305:

    # wiz "It's also filled with notes from all of my experiments, so... you could say it's mostly an experiment journal."
    wiz "También está lleno de notas de todos mis experimentos, así que... podría decirse que es sobre todo un diario de experimentos."

# game/day2 choice.rpy:1722
translate Spanish freetime_wizzy_368ef8a5:

    # "Wizzy opened his journal and began flipping through the pages."
    "Wizzy abrió su diario y empezó a hojear las páginas."

# game/day2 choice.rpy:1724
translate Spanish freetime_wizzy_8732abbc:

    # wiz "Besides my experiments, I also write down anything I find interesting."
    wiz "Además de mis experimentos, también anoto cualquier cosa que me parezca interesante."

# game/day2 choice.rpy:1727
translate Spanish freetime_wizzy_f1bb5105:

    # wiz "For example... I once dedicated a few pages to roses, since they're my favorite flowers."
    wiz "Por ejemplo... una vez dediqué unas cuantas páginas a las rosas, ya que son mis flores favoritas."

# game/day2 choice.rpy:1728
translate Spanish freetime_wizzy_c3b7542b:

    # wiz "Roses come in all sorts of colors. Pink, white, black..."
    wiz "Las rosas vienen en todo tipo de colores. Rosa, blanco, negro..."

# game/day2 choice.rpy:1729
translate Spanish freetime_wizzy_fefb8b4e:

    # wiz "I've always been fascinated by that, so I decided to write about them here."
    wiz "Siempre me ha fascinado eso, así que decidí escribir sobre ellas aquí."

# game/day2 choice.rpy:1733
translate Spanish freetime_wizzy_d41d8cd9:

    # voice "WIZZY03_DAY2.ogg"
    voice "WIZZY03_DAY2.ogg"

# game/day2 choice.rpy:1735
translate Spanish freetime_wizzy_55e29c83:

    # wiz "After reading several books on botany, I learned that the color of a rose can actually be influenced by the environment it grows in. Isn't that fascinating?"
    wiz "Después de leer varios libros de botánica, aprendí que el color de una rosa en realidad puede verse influido por el entorno en el que crece. ¿No es fascinante?"

# game/day2 choice.rpy:1736
translate Spanish freetime_wizzy_c959ada3:

    # wiz "For example, the soil's acidity, the amount of sunlight, the temperature... even the age of the rose itself can all affect its color."
    wiz "Por ejemplo, la acidez del suelo, la cantidad de luz solar, la temperatura... incluso la edad de la propia rosa pueden afectar su color."

# game/day2 choice.rpy:1739
translate Spanish freetime_wizzy_6cd79dba:

    # wiz "Oh! And I also wrote down the meaning behind each rose color!"
    wiz "¡Oh! ¡Y también anoté el significado de cada color de rosa!"

# game/day2 choice.rpy:1740
translate Spanish freetime_wizzy_d98732f7:

    # wiz "White roses symbolize purity, innocence, sincere love... and new beginnings."
    wiz "Las rosas blancas simbolizan pureza, inocencia, amor sincero... y nuevos comienzos."

# game/day2 choice.rpy:1741
translate Spanish freetime_wizzy_418f0db7:

    # wiz "Black roses, on the other hand, are often associated with mystery, farewells, and grief. Though... some people also see them as symbols of inner strength, courage, and new beginnings."
    wiz "Las rosas negras, por otro lado, suelen asociarse con el misterio, las despedidas y el duelo. Aunque... algunas personas también las ven como símbolos de fortaleza interior, valentía y nuevos comienzos."

# game/day2 choice.rpy:1744
translate Spanish freetime_wizzy_381e1a63:

    # wiz "Oh! Here's a fun fact about black roses. If I remember correctly... pure black roses don't actually exist in nature. They're usually just very dark shades of red or purple."
    wiz "¡Oh! Aquí tienes un dato curioso sobre las rosas negras. Si mal no recuerdo... las rosas totalmente negras no existen en la naturaleza. Normalmente son solo tonos muy oscuros de rojo o morado."

# game/day2 choice.rpy:1747
translate Spanish freetime_wizzy_be27354f:

    # wiz "Isn't it amazing? Even though they're the same flower, something as simple as color can completely change what they represent."
    wiz "¿No es increíble? Aunque sean la misma flor, algo tan simple como el color puede cambiar por completo lo que representan."

# game/day2 choice.rpy:1748
translate Spanish freetime_wizzy_4e0bde45:

    # mc "Then which rose is your favourite?"
    mc "Entonces, ¿cuál es tu rosa favorita?"

# game/day2 choice.rpy:1751
translate Spanish freetime_wizzy_3f404e33:

    # wiz "Red roses."
    wiz "Las rosas rojas."

# game/day2 choice.rpy:1752
translate Spanish freetime_wizzy_46337c44:

    # wiz "I think they're lovely... especially because they symbolize true love and deep romance. I think that's rather cute."
    wiz "Me parecen encantadoras... sobre todo porque simbolizan el amor verdadero y el romance profundo. Creo que es bastante tierno."

# game/day2 choice.rpy:1753
translate Spanish freetime_wizzy_9c4b5479:

    # wiz "How about you, Your Majesty? If you could choose, which color of rose would be your favorite?"
    wiz "¿Y usted, Majestad? Si pudiera elegir, ¿qué color de rosa sería su favorito?"

# game/day2 choice.rpy:1757
translate Spanish freetime_wizzy_ed1099af:

    # wiz "Oh?! That means we have the same taste! Hahaha!"
    wiz "¡¿Oh?! ¡Eso significa que tenemos el mismo gusto! ¡Jajaja!"

# game/day2 choice.rpy:1760
translate Spanish freetime_wizzy_1bb97bad:

    # wiz "Purity, innocence, sincere love and new beginnings. Good choice, Your Majesty."
    wiz "Pureza, inocencia, amor sincero y nuevos comienzos. Buena elección, Majestad."

# game/day2 choice.rpy:1763
translate Spanish freetime_wizzy_db341a54:

    # wiz "Mystery, farewells, and grief. Wow, you're so mysterious, Your Majesty!"
    wiz "Misterio, despedidas y duelo. ¡Vaya, qué misterios[letra] es usted, Majestad!"

# game/day2 choice.rpy:1766
translate Spanish freetime_wizzy_8ab7eebd:

    # wiz "Gentleness, grace, gratitude, and admiration. Good choice, Your Majesty."
    wiz "Ternura, gracia, gratitud y admiración. Buena elección, Majestad."

# game/day2 choice.rpy:1769
translate Spanish freetime_wizzy_f88eedd3:

    # wiz "Close friendship, cheerfulness, happiness, and positive energy. Aww, good choice, Your Majesty."
    wiz "Amistad cercana, alegría, felicidad y energía positiva. Aww, buena elección, Majestad."

# game/day2 choice.rpy:1772
translate Spanish freetime_wizzy_27f686b6:

    # wiz "Enthusiasm, energy, and admiration. Good choice, Your Majesty."
    wiz "Entusiasmo, energía y admiración. Buena elección, Majestad."

# game/day2 choice.rpy:1775
translate Spanish freetime_wizzy_f70b3605:

    # wiz "Charm, love at first sight, and elegance. Wow, that is a good choice, Your Majesty!"
    wiz "Encanto, amor a primera vista y elegancia. ¡Vaya, esa sí que es una buena elección, Majestad!"

# game/day2 choice.rpy:1778
translate Spanish freetime_wizzy_3ea7a2d2:

    # "Wiizy went on to tell me about all sorts of things he'd written in his journal."
    "Wizzy siguió contándome todo tipo de cosas que había anotado en su diario."

# game/day2 choice.rpy:1779
translate Spanish freetime_wizzy_33867e07:

    # "Plants. Food. Carbon compounds. Chemistry... and countless other topics."
    "Plantas. Comida. Compuestos de carbono. Química... y un sinfín de otros temas."

# game/day2 choice.rpy:1780
translate Spanish freetime_wizzy_6df920fe:

    # "Just from listening to him, it was obvious that Wizzy had an incredibly curious mind."
    "Solo con escucharlo, era evidente que Wizzy tenía una mente increíblemente curiosa."

# game/day2 choice.rpy:1781
translate Spanish freetime_wizzy_a9c77b95:

    # "My gaze eventually drifted back to the shelf lined with bottles filled with colorful liquids and strange ingredients I can't recognize."
    "Mi mirada acabó volviendo al estante lleno de botellas con líquidos coloridos e ingredientes extraños que no podía reconocer."

# game/day2 choice.rpy:1783
translate Spanish freetime_wizzy_a8866cff:

    # mc "Wizzy, you said you enjoy experimenting. Are all the things on that shelf your creations?"
    mc "Wizzy, dijiste que disfrutas experimentando. ¿Todas las cosas de ese estante son creaciones tuyas?"

# game/day2 choice.rpy:1786
translate Spanish freetime_wizzy_9ae24955:

    # "I pointed toward the shelf."
    "Señalé el estante."

# game/day2 choice.rpy:1788
translate Spanish freetime_wizzy_e7651e6c:

    # wiz "Oh! Yes! Every single one of them is the result of my experiments!"
    wiz "¡Oh! ¡Sí! ¡Cada una de ellas es el resultado de mis experimentos!"

# game/day2 choice.rpy:1791
translate Spanish freetime_wizzy_8ff93d47:

    # wiz "Come, dear Majesty. Let me show you."
    wiz "Venga, querida Majestad. Déjeme mostrárselo."

# game/day2 choice.rpy:1794
translate Spanish freetime_wizzy_7807b5e5:

    # "Wizzy gestured for me to walk ahead before following behind me."
    "Wizzy me indicó con un gesto que caminara adelante antes de seguirme por detrás."

# game/day2 choice.rpy:1795
translate Spanish freetime_wizzy_f2d312df:

    # "As I stepped closer, I began to notice just how many different bottles were on the shelves."
    "Al acercarme, empecé a notar cuántas botellas distintas había en los estantes."

# game/day2 choice.rpy:1796
translate Spanish freetime_wizzy_811e651a:

    # "Some contained bright blue liquid. Others were pink, black, yellow... and countless more colors besides."
    "Algunas contenían un líquido azul brillante. Otras eran rosas, negras, amarillas... y muchísimos colores más."

# game/day2 choice.rpy:1797
translate Spanish freetime_wizzy_20c96dd1:

    # "On the lower shelves were jars filled with strange ingredients: twigs, powders I couldn't identify, and all sorts of other odd materials."
    "En los estantes inferiores había frascos llenos de ingredientes extraños: ramitas, polvos que no podía identificar y todo tipo de materiales raros."

# game/day2 choice.rpy:1799
translate Spanish freetime_wizzy_df405117:

    # mc "Hmm... What are all these liquids?"
    mc "Mmm... ¿Qué son todos estos líquidos?"

# game/day2 choice.rpy:1802
translate Spanish freetime_wizzy_d261db50:

    # wiz "Ah... they're not dangerous. Well... some of them are poisonous, but this one..."
    wiz "Ah... no son peligrosos. Bueno... algunos son venenosos, pero este..."

# game/day2 choice.rpy:1804
translate Spanish freetime_wizzy_94d2688e:

    # "Wizzy picked up a bottle filled with a black liquid."
    "Wizzy tomó una botella llena de un líquido negro."

# game/day2 choice.rpy:1808
translate Spanish freetime_wizzy_56a80783:

    # wiz "This one's medicine."
    wiz "Esta es una medicina."

# game/day2 choice.rpy:1809
translate Spanish freetime_wizzy_d82b92e0:

    # wiz "You can drink this whenever you have a fever or a cold. It tastes like ginger and mint."
    wiz "Puede beberlo cuando tenga fiebre o un resfriado. Sabe a jengibre y menta."

# game/day2 choice.rpy:1810
translate Spanish freetime_wizzy_475bec88:

    # wiz "It's a little spicy at first, so it can be a bit unpleasant. But once you get used to it, it's actually quite nice. The mint helps clear your airways whenever your nose is congested."
    wiz "Al principio es un poco picante, así que puede ser algo desagradable. Pero cuando uno se acostumbra, en realidad es bastante agradable. La menta ayuda a despejar las vías respiratorias cuando se tiene la nariz congestionada."

# game/day2 choice.rpy:1811
translate Spanish freetime_wizzy_68d346c6:

    # wiz "If you're curious, Your Majesty, you can give it a sniff. It's perfectly safe."
    wiz "Si siente curiosidad, Majestad, puede olerlo. Es completamente seguro."

# game/day2 choice.rpy:1813
translate Spanish freetime_wizzy_dce7331e:

    # "I brought the black potion closer to my face and took a cautious sniff."
    "Acerqué la poción negra a mi cara y olí con cautela."

# game/day2 choice.rpy:1814
translate Spanish freetime_wizzy_630542d7:

    # "The moment I did, a sharp minty scent stung my nose."
    "En cuanto lo hice, un penetrante aroma a menta me picó la nariz."

# game/day2 choice.rpy:1816
translate Spanish freetime_wizzy_5ed054e9:

    # mc "Ugh... that's a really strong mint smell..."
    mc "Ugh... eso es un olor a menta muy fuerte..."

# game/day2 choice.rpy:1817
translate Spanish freetime_wizzy_9eda8605:

    # wiz "Haha, it is."
    wiz "Jaja, sí que lo es."

# game/day2 choice.rpy:1821
translate Spanish freetime_wizzy_4a91705b:

    # "Wizzy placed the black bottle back on the shelf before picking up another one filled with a yellow liquid."
    "Wizzy devolvió la botella negra al estante antes de tomar otra llena de un líquido amarillo."

# game/day2 choice.rpy:1824
translate Spanish freetime_wizzy_b907c4bf:

    # wiz "This one's a sleeping potion. If you're ever having trouble falling asleep, you can drink this."
    wiz "Esta es una poción para dormir. Si alguna vez tiene problemas para conciliar el sueño, puede beberla."

# game/day2 choice.rpy:1825
translate Spanish freetime_wizzy_30424c30:

    # wiz "It tastes like oranges... though it might make you cough a little since it's rather harsh on the throat."
    wiz "Sabe a naranja... aunque podría hacerle toser un poco, ya que es bastante áspera para la garganta."

# game/day2 choice.rpy:1827
translate Spanish freetime_wizzy_35b5d77d:

    # "Wizzy suddenly fell silent."
    "Wizzy se quedó de pronto en silencio."

# game/day2 choice.rpy:1830
translate Spanish freetime_wizzy_b51cbebc:

    # wiz "...This potion is powerful. Maybe... a little too powerful..."
    wiz "...Esta poción es potente. Quizá... un poco demasiado potente..."

# game/day2 choice.rpy:1832
translate Spanish freetime_wizzy_d26d2352:

    # "I tilted my head, puzzled."
    "Incliné la cabeza, desconcertad[letra]."

# game/day2 choice.rpy:1834
translate Spanish freetime_wizzy_b2b9e19d:

    # mc "What do you mean?"
    mc "¿A qué te refieres?"

# game/day2 choice.rpy:1835
translate Spanish freetime_wizzy_e420cc32:

    # wiz "One time... Jestyn drank it without my permission."
    wiz "Una vez... Jestyn la bebió sin mi permiso."

# game/day2 choice.rpy:1838
translate Spanish freetime_wizzy_91050978:

    # wiz "Well... it certainly worked. It put him to sleep..."
    wiz "Bueno... sin duda funcionó. Lo hizo dormir..."

# game/day2 choice.rpy:1839
translate Spanish freetime_wizzy_aa8ab9b3:

    # wiz "...For an entire month."
    wiz "...Durante un mes entero."

# game/day2 choice.rpy:1841
translate Spanish freetime_wizzy_0cff8f7c:

    # "My eyes went wide."
    "Mis ojos se abrieron como platos."

# game/day2 choice.rpy:1842
translate Spanish freetime_wizzy_cf4f841b:

    # "...A whole month? That's less 'sleeping' and more 'hibernating."
    "...¿Un mes entero? Eso es menos 'dormir' y más 'hibernar'."

# game/day2 choice.rpy:1843
translate Spanish freetime_wizzy_983ba16e:

    # "Yep. Definitely not safe for humans."
    "Sí. Definitivamente no es segura para los humanos."

# game/day2 choice.rpy:1845
translate Spanish freetime_wizzy_e4bd4d8d:

    # mc "What about those jars with the twigs, powders, and everything else?"
    mc "¿Y esos frascos con las ramitas, los polvos y todo lo demás?"

# game/day2 choice.rpy:1848
translate Spanish freetime_wizzy_11fe6898:

    # wiz "Oh, those are just ingredients for my experiments. Sometimes I add them on a whim to see what happens."
    wiz "Ah, esos son solo ingredientes para mis experimentos. A veces los agrego por capricho para ver qué pasa."

# game/day2 choice.rpy:1849
translate Spanish freetime_wizzy_0680764b:

    # wiz "Jestyn always gathers them for me whenever he goes outside the kingdom. I'm... a little too lazy to leave on my own."
    wiz "Jestyn siempre me los recoge cuando sale del reino. Yo soy... un poco demasiado perezoso para salir por mi cuenta."

# game/day2 choice.rpy:1850
translate Spanish freetime_wizzy_55f5dee0:

    # mc "Hmm... Where did you learn so much about medicine and potions?"
    mc "Mmm... ¿Dónde aprendiste tanto sobre medicina y pociones?"

# game/day2 choice.rpy:1853
translate Spanish freetime_wizzy_9ba36d8d:

    # wiz "I learned from medical books written by humans. I have quite a collection, actually. If you'd ever like to borrow one, Your Majesty, I'd be happy to lend them to you."
    wiz "Aprendí de libros de medicina escritos por humanos. De hecho, tengo bastante colección. Si alguna vez quisiera tomar prestado alguno, Majestad, estaré encantado de prestárselos."

# game/day2 choice.rpy:1854
translate Spanish freetime_wizzy_eb60d3df:

    # mc "That's really impressive."
    mc "Eso es realmente impresionante."

# game/day2 choice.rpy:1855
translate Spanish freetime_wizzy_75163eea:

    # mc "Is there anything you've found especially difficult to learn? Or maybe an experiment that gave you the most trouble?"
    mc "¿Hay algo que te haya resultado especialmente difícil de aprender? ¿O algún experimento que te haya dado más problemas?"

# game/day2 choice.rpy:1860
translate Spanish freetime_wizzy_bad9c2df:

    # "The smile on Wizzy's face faded almost instantly."
    "La sonrisa en el rostro de Wizzy se desvaneció casi al instante."

# game/day2 choice.rpy:1861
translate Spanish freetime_wizzy_f606b65c:

    # "An awkward silence settled over the room."
    "Un silencio incómodo se instaló en la habitación."

# game/day2 choice.rpy:1862
translate Spanish freetime_wizzy_9459ec39:

    # "...Did I say something wrong?"
    "...¿Dije algo malo?"

# game/day2 choice.rpy:1864
translate Spanish freetime_wizzy_05f75f14:

    # wiz "...Yes."
    wiz "...Sí."

# game/day2 choice.rpy:1866
translate Spanish freetime_wizzy_69f90e99:

    # wiz "Humans."
    wiz "Los humanos."

# game/day2 choice.rpy:1868
translate Spanish freetime_wizzy_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:1869
translate Spanish freetime_wizzy_1bfff580:

    # "Humans...? What did he mean by that?"
    "¿Los humanos...? ¿Qué quiso decir con eso?"

# game/day2 choice.rpy:1871
translate Spanish freetime_wizzy_1d6c865c:

    # wiz "I once tried to learn everything I could about the human body."
    wiz "Una vez intenté aprender todo lo que pude sobre el cuerpo humano."

# game/day2 choice.rpy:1872
translate Spanish freetime_wizzy_21a97e2f:

    # wiz "Bones. Flesh. Organs. Skin."
    wiz "Huesos. Carne. Órganos. Piel."

# game/day2 choice.rpy:1873
translate Spanish freetime_wizzy_018a2b87:

    # wiz "I studied every part that humans have... and we do not."
    wiz "Estudié cada parte que tienen los humanos... y nosotros no."

# game/day2 choice.rpy:1874
translate Spanish freetime_wizzy_e08662a3:

    # mc "T-Then... what made it so difficult?"
    mc "E-entonces... ¿qué lo hizo tan difícil?"

# game/day2 choice.rpy:1875
translate Spanish freetime_wizzy_f0702c5b:

    # wiz "I studied every part of the human body... because I wanted to try creating one."
    wiz "Estudié cada parte del cuerpo humano... porque quería intentar crear uno."

# game/day2 choice.rpy:1876
translate Spanish freetime_wizzy_3f1f6e57:

    # mc "What?! Why?"
    mc "¡¿Qué?! ¿Por qué?"

# game/day2 choice.rpy:1877
translate Spanish freetime_wizzy_649cac9c:

    # wiz "...It's a long and complicated story."
    wiz "...Es una historia larga y complicada."

# game/day2 choice.rpy:1878
translate Spanish freetime_wizzy_be118f65:

    # wiz "But I thought... if I could succeed... it might become a new path forward for all of us."
    wiz "Pero pensé que... si lograba hacerlo... podría convertirse en un nuevo camino a seguir para todos nosotros."

# game/day2 choice.rpy:1879
translate Spanish freetime_wizzy_fa16d5d9:

    # wiz "And perhaps... the kingdom wouldn't have ended up like this..."
    wiz "Y quizá... el reino no habría acabado así..."

# game/day2 choice.rpy:1881
translate Spanish freetime_wizzy_ee400b0d:

    # "My mind struggled to make sense of what Wizzy was trying to tell me."
    "Mi mente se esforzaba por entender lo que Wizzy intentaba decirme."

# game/day2 choice.rpy:1882
translate Spanish freetime_wizzy_05f0556e:

    # "I wanted to ask more... but somehow, the atmosphere made me too afraid to press any further."
    "Quería preguntar más... pero, de algún modo, el ambiente me dio demasiado miedo para insistir."

# game/day2 choice.rpy:1884
translate Spanish freetime_wizzy_0d7ec889:

    # "Noticing the look on my face, Wizzy finally seemed to snap out of his thoughts."
    "Al notar la expresión de mi rostro, Wizzy pareció por fin salir de sus pensamientos."

# game/day2 choice.rpy:1887
translate Spanish freetime_wizzy_d5dc9f02:

    # wiz "Ah! M-My apologies, Your Majesty. It's... it's nothing, really."
    wiz "¡Ah! P-perdone, Majestad. Es... no es nada, de verdad."

# game/day2 choice.rpy:1889
translate Spanish freetime_wizzy_ce7b92c5:

    # wiz "Let's talk about something else instead... hehe."
    wiz "Hablemos mejor de otra cosa... jeje."

# game/day2 choice.rpy:1895
translate Spanish hat_wizzy_ac870d09:

    # "My eyes drifted toward Wizzy's hat."
    "Mis ojos se desviaron hacia el sombrero de Wizzy."

# game/day2 choice.rpy:1896
translate Spanish hat_wizzy_80808559:

    # "It's a really cool wizard's hat. Honestly... I kind of wanted to try it on."
    "Es un sombrero de mago realmente genial. Sinceramente... tenía ganas de probármelo."

# game/day2 choice.rpy:1898
translate Spanish hat_wizzy_44b0622d:

    # mc "Wizzy... can I be honest with you?"
    mc "Wizzy... ¿puedo ser sincer[letra] contigo?"

# game/day2 choice.rpy:1901
translate Spanish hat_wizzy_1f302ffe:

    # wiz "H-Huh? Of course..."
    wiz "¿E-eh? Claro..."

# game/day2 choice.rpy:1904
translate Spanish hat_wizzy_8c580084:

    # wiz "W-What's wrong? Was I boring? Did I talk too much? Was I not interesting enough?"
    wiz "¿Q-qué pasa? ¿Fui aburrido? ¿Hablé demasiado? ¿No fui lo bastante interesante?"

# game/day2 choice.rpy:1905
translate Spanish hat_wizzy_8767000d:

    # mc "What?! No, not at all!"
    mc "¡¿Qué?! ¡No, para nada!"

# game/day2 choice.rpy:1906
translate Spanish hat_wizzy_d8df0855:

    # mc "I just think your hat looks really cool."
    mc "Es que creo que tu sombrero se ve genial."

# game/day2 choice.rpy:1909
translate Spanish hat_wizzy_f68fc8d8:

    # "Wizzy's expression turned into surprise. A faint blush slowly spread across his cheeks."
    "La expresión de Wizzy se transformó en sorpresa. Un leve rubor se extendió lentamente por sus mejillas."

# game/day2 choice.rpy:1911
translate Spanish hat_wizzy_309d5675:

    # wiz "O-Oh... You really think so?"
    wiz "O-Oh... ¿De verdad lo cree?"

# game/day2 choice.rpy:1914
translate Spanish hat_wizzy_0e167655:

    # "He gently took hold of his hat, absentmindedly brushing a hand over it."
    "Tomó suavemente su sombrero, pasándose la mano por él distraídamente."

# game/day2 choice.rpy:1916
translate Spanish hat_wizzy_25695947:

    # wiz "Thank you, Your Majesty... I'm really happy you like it."
    wiz "Gracias, Majestad... Me alegra mucho que le guste."

# game/day2 choice.rpy:1917
translate Spanish hat_wizzy_0fa3367a:

    # wiz "You could say this hat is very precious to me. Our creator... the one who created all of us... made it himself."
    wiz "Podría decirse que este sombrero es muy preciado para mí. Nuestro creador... el que nos creó a todos... lo hizo él mismo."

# game/day2 choice.rpy:1918
translate Spanish hat_wizzy_86630d00:

    # mc "Your creator?"
    mc "¿Tu creador?"

# game/day2 choice.rpy:1920
translate Spanish hat_wizzy_afc0e4fa:

    # "...That's new."
    "...Eso es nuevo."

# game/day2 choice.rpy:1922
translate Spanish hat_wizzy_b736825f:

    # wiz "Yes. The one who created us... and the entire Kingdom of Marionettes."
    wiz "Sí. Quien nos creó a nosotros... y a todo el Reino de las Marionetas."

# game/day2 choice.rpy:1923
translate Spanish hat_wizzy_0dc7e2ff:

    # wiz "He told me this hat would become my strong identity and something people would always recognize me by. And... well... I think he was right."
    wiz "Me dijo que este sombrero se convertiría en mi fuerte seña de identidad y en algo por lo que la gente siempre me reconocería. Y... bueno... creo que tenía razón."

# game/day2 choice.rpy:1924
translate Spanish hat_wizzy_56d26eb1:

    # wiz "It's one of the few keepsakes I still have from my creator. I've treasured it ever since."
    wiz "Es uno de los pocos recuerdos que aún conservo de mi creador. Lo he atesorado desde entonces."

# game/day2 choice.rpy:1926
translate Spanish hat_wizzy_32d114eb:

    # "Wizzy looks down at his hat, quietly reminiscing about the memories attached to it."
    "Wizzy mira su sombrero, recordando en silencio las memorias ligadas a él."

# game/day2 choice.rpy:1928
translate Spanish hat_wizzy_8abd8328:

    # mc "...Would it be alright if I tried it on?"
    mc "...¿Estaría bien si me lo probara?"

# game/day2 choice.rpy:1932
translate Spanish hat_wizzy_8e4b7b7c:

    # wiz "H-Huh? You want to wear my hat, Your Majesty?"
    wiz "¿E-eh? ¿Quiere ponerse mi sombrero, Majestad?"

# game/day2 choice.rpy:1933
translate Spanish hat_wizzy_d5a34e23:

    # mc "Yeah. But if you're not comfortable with it, that's completely okay."
    mc "Sí. Pero si no te sientes cómodo con eso, no pasa nada."

# game/day2 choice.rpy:1936
translate Spanish hat_wizzy_2638584e:

    # wiz "......"
    wiz "......"

# game/day2 choice.rpy:1939
translate Spanish hat_wizzy_f5c03673:

    # wiz "Hehe... Of course. I trust you, Your Majesty."
    wiz "Jeje... Por supuesto. Confío en usted, Majestad."

# game/day2 choice.rpy:1943
translate Spanish hat_wizzy_fbb890e8:

    # wiz "Unlike... someone who wears red, yellow, black, and white."
    wiz "A diferencia de... cierta persona que viste de rojo, amarillo, negro y blanco."

# game/day2 choice.rpy:1945
translate Spanish hat_wizzy_45e8ce9e:

    # "Wizzy carefully took off his hat, and I my crown, before he gently placed it on my head."
    "Wizzy se quitó con cuidado el sombrero, y yo mi corona, antes de que él me lo colocara suavemente en la cabeza."

# game/day2 choice.rpy:1949
translate Spanish hat_wizzy_9fd9f420:

    # "Unfortunately, it was far too big. The brim immediately slipped down and blocked my entire view."
    "Por desgracia, me quedaba demasiado grande. El ala se deslizó de inmediato y me tapó toda la vista."

# game/day2 choice.rpy:1951
translate Spanish hat_wizzy_c93303f0:

    # mc "W-Whoa-! It's huge! I can't see anything!"
    mc "¡U-Uf! ¡Es enorme! ¡No veo nada!"

# game/day2 choice.rpy:1952
translate Spanish hat_wizzy_89a723cb:

    # wiz "Haha! I know. It's much too big for you."
    wiz "¡Jaja! Lo sé. Es demasiado grande para usted."

# game/day2 choice.rpy:1955
translate Spanish hat_wizzy_a80ee32e:

    # "Chuckling softly, Wizzy lifted the brim just enough for me to see again."
    "Riendo suavemente, Wizzy levantó el ala lo justo para que pudiera ver de nuevo."

# game/day2 choice.rpy:1958
translate Spanish hat_wizzy_61bfecaf:

    # wiz "There. Much better."
    wiz "Listo. Mucho mejor."

# game/day2 choice.rpy:1960
translate Spanish hat_wizzy_e3c1c1a5:

    # "He took a moment to look at me."
    "Se tomó un momento para mirarme."

# game/day2 choice.rpy:1963
translate Spanish hat_wizzy_63d3a522:

    # wiz "...Hmm. It actually looks rather cute on you, Your Majesty."
    wiz "...Mmm. En realidad le queda bastante lindo, Majestad."

# game/day2 choice.rpy:1969
translate Spanish hat_wizzy_c4d328ed:

    # jes "HMPHH!!"
    jes "¡¡HMPHH!!"

# game/day2 choice.rpy:1970
translate Spanish hat_wizzy_6cb5d120:

    # jes "Mmrrghhh!"
    jes "¡Mmrrghhh!"

# game/day2 choice.rpy:1975
translate Spanish hat_wizzy_df3b1733:

    # wiz "Do you like the hat?"
    wiz "¿Le gusta el sombrero?"

# game/day2 choice.rpy:1976
translate Spanish hat_wizzy_3041dddb:

    # mc "Yeah. It's a really nice hat."
    mc "Sí. Es un sombrero muy bonito."

# game/day2 choice.rpy:1977
translate Spanish hat_wizzy_35ed321a:

    # wiz "Hehe... I liked seeing Your Majesty wear it, too. Perhaps I could ask someone to make another one just like it."
    wiz "Jeje... A mí también me gustó ver a Su Majestad con él. Quizá podría pedirle a alguien que haga otro igual."

# game/day2 choice.rpy:1980
translate Spanish hat_wizzy_aad2bbf7:

    # wiz "Then we'd look even closer, wouldn't we?"
    wiz "Entonces nos veríamos aún más parecidos, ¿no?"

# game/day2 choice.rpy:1981
translate Spanish hat_wizzy_6e61140a:

    # mc "I agree. Haha."
    mc "Estoy de acuerdo. Jaja."

# game/day2 choice.rpy:1982
translate Spanish hat_wizzy_6b3f2bfa:

    # jes "Mmmrrghh!!"
    jes "¡¡Mmmrrghh!!"

# game/day2 choice.rpy:1987
translate Spanish hat_wizzy_e31bc0d5:

    # jes "Ahem!!"
    jes "¡¡Ejem!!"

# game/day2 choice.rpy:1989
translate Spanish hat_wizzy_29eace35:

    # "Jestyn clears his throat, making both of us jump."
    "Jestyn se aclara la garganta, haciendo que los dos nos sobresaltemos."

# game/day2 choice.rpy:1991
translate Spanish hat_wizzy_ba9666d1:

    # wiz "H-Huh? What's wrong?"
    wiz "¿E-eh? ¿Qué pasa?"

# game/day2 choice.rpy:1992
translate Spanish hat_wizzy_c7feb860:

    # jes "Nothing at all~ Just making sure the two of you don't get up to anything... too strange."
    jes "Nada en absoluto~ Solo me aseguro de que ustedes dos no hagan nada... demasiado raro."

# game/day2 choice.rpy:1993
translate Spanish hat_wizzy_a15d79df:

    # wiz "I wasn't doing anything!"
    wiz "¡No estaba haciendo nada!"

# game/day2 choice.rpy:2001
translate Spanish hat_wizzy_c4d328ed_1:

    # jes "HMPHH!!"
    jes "¡¡HMPHH!!"

# game/day2 choice.rpy:2002
translate Spanish hat_wizzy_6cb5d120_1:

    # jes "Mmrrghhh!"
    jes "¡Mmrrghhh!"

# game/day2 choice.rpy:2007
translate Spanish hat_wizzy_df3b1733_1:

    # wiz "Do you like the hat?"
    wiz "¿Le gusta el sombrero?"

# game/day2 choice.rpy:2008
translate Spanish hat_wizzy_3041dddb_1:

    # mc "Yeah. It's a really nice hat."
    mc "Sí. Es un sombrero muy bonito."

# game/day2 choice.rpy:2009
translate Spanish hat_wizzy_35ed321a_1:

    # wiz "Hehe... I liked seeing Your Majesty wear it, too. Perhaps I could ask someone to make another one just like it."
    wiz "Jeje... A mí también me gustó ver a Su Majestad con él. Quizá podría pedirle a alguien que haga otro igual."

# game/day2 choice.rpy:2012
translate Spanish hat_wizzy_aad2bbf7_1:

    # wiz "Then we'd look even closer, wouldn't we?"
    wiz "Entonces nos veríamos aún más parecidos, ¿no?"

# game/day2 choice.rpy:2013
translate Spanish hat_wizzy_6e61140a_1:

    # mc "I agree. Haha."
    mc "Estoy de acuerdo. Jaja."

# game/day2 choice.rpy:2014
translate Spanish hat_wizzy_6b3f2bfa_1:

    # jes "Mmmrrghh!!"
    jes "¡¡Mmmrrghh!!"

# game/day2 choice.rpy:2020
translate Spanish hat_wizzy_e31bc0d5_1:

    # jes "Ahem!!"
    jes "¡¡Ejem!!"

# game/day2 choice.rpy:2022
translate Spanish hat_wizzy_29eace35_1:

    # "Jestyn clears his throat, making both of us jump."
    "Jestyn se aclara la garganta, haciendo que los dos nos sobresaltemos."

# game/day2 choice.rpy:2026
translate Spanish hat_wizzy_ba9666d1_1:

    # wiz "H-Huh? What's wrong?"
    wiz "¿E-eh? ¿Qué pasa?"

# game/day2 choice.rpy:2027
translate Spanish hat_wizzy_c7feb860_1:

    # jes "Nothing at all~ Just making sure the two of you don't get up to anything... too strange."
    jes "Nada en absoluto~ Solo me aseguro de que ustedes dos no hagan nada... demasiado raro."

# game/day2 choice.rpy:2028
translate Spanish hat_wizzy_a15d79df_1:

    # wiz "I wasn't doing anything!"
    wiz "¡No estaba haciendo nada!"

# game/day2 choice.rpy:2035
translate Spanish hat_wizzy_f5692ab9:

    # "Wizzy took his hat back, then talked in a whisper to me."
    "Wizzy recuperó su sombrero y luego me habló en un susurro."

# game/day2 choice.rpy:2037
translate Spanish hat_wizzy_dd53bb5a:

    # wiz "Maybe next time... you could wear my hat longer, Your Majesty..."
    wiz "Quizá la próxima vez... pueda usar mi sombrero por más tiempo, Majestad..."

# game/day2 choice.rpy:2039
translate Spanish hat_wizzy_8bb96301:

    # "I smiled, then nodded in agreement."
    "Sonreí y luego asentí en señal de acuerdo."

# game/day2 choice.rpy:2048
translate Spanish relationship_wizzy_414cbe18:

    # mc "I'm curious. What's your relationship with the other puppets like?"
    mc "Tengo curiosidad. ¿Cómo es tu relación con las otras marionetas?"

# game/day2 choice.rpy:2051
translate Spanish relationship_wizzy_6a89dbb3:

    # wiz "Oh? My relationship with everyone else? Hmm..."
    wiz "¿Oh? ¿Mi relación con todos los demás? Mmm..."

# game/day2 choice.rpy:2052
translate Spanish relationship_wizzy_182eca42:

    # wiz "Let's see... I suppose I'll start with the one closest to us..."
    wiz "A ver... supongo que empezaré por el más cercano a nosotros..."

# game/day2 choice.rpy:2055
translate Spanish relationship_wizzy_6dcb4c62:

    # wiz "...Jestyn."
    wiz "...Jestyn."

# game/day2 choice.rpy:2057
translate Spanish relationship_wizzy_c4f97be0:

    # "The moment Wizzy says his name, he puffed out his cheeks in annoyance."
    "En cuanto Wizzy dijo su nombre, este infló las mejillas con fastidio."

# game/day2 choice.rpy:2059
translate Spanish relationship_wizzy_bf024463:

    # wiz "He's a pain."
    wiz "Es un fastidio."

# game/day2 choice.rpy:2061
translate Spanish relationship_wizzy_38071406:

    # "I glanced over at Jestyn. Rather than looking offended, he was wearing an incredibly smug grin."
    "Miré a Jestyn. En lugar de verse ofendido, lucía una sonrisa increíblemente engreída."

# game/day2 choice.rpy:2062
translate Spanish relationship_wizzy_b3ef1de6:

    # "...Of course he is."
    "...Por supuesto que sí."

# game/day2 choice.rpy:2065
translate Spanish relationship_wizzy_211b00f8:

    # wiz "He's always pulling pranks on me! He steals my potion bottles... and he even hides my hat!"
    wiz "¡Siempre me está haciendo bromas pesadas! Me roba los frascos de pociones... ¡y hasta me esconde el sombrero!"

# game/day2 choice.rpy:2066
translate Spanish relationship_wizzy_f1710f39:

    # wiz "He plays tricks on the other puppets too, but I'm one of his favorite targets! Ugh..."
    wiz "¡También les hace jugarretas a las otras marionetas, pero yo soy uno de sus blancos favoritos! Ugh..."

# game/day2 choice.rpy:2067
translate Spanish relationship_wizzy_2638584e:

    # wiz "......"
    wiz "......"

# game/day2 choice.rpy:2070
translate Spanish relationship_wizzy_6c940969:

    # wiz "...But even so... he's actually... a good person."
    wiz "...Pero aun así... en realidad es... una buena persona."

# game/day2 choice.rpy:2073
translate Spanish relationship_wizzy_cf76e948:

    # jes "Hhhhmmmmmm~...."
    jes "Hhhhmmmmmm~...."

# game/day2 choice.rpy:2076
translate Spanish relationship_wizzy_a4acdd01:

    # jes "Oho~? A good person, am I~? Go on, then. Tell [poss] Majesty all about it."
    jes "¡Oho~! ¿Que soy una buena persona, eh~? Adelante, entonces. Cuéntele a Su Majestad todo al respecto."

# game/day2 choice.rpy:2078
translate Spanish relationship_wizzy_cb7cf67f:

    # "Being forced to compliment Jestyn right in front of him, Wizzy suddenly looked deeply troubled."
    "Obligado a elogiar a Jestyn justo delante de él, Wizzy de pronto parecía profundamente apurado."

# game/day2 choice.rpy:2080
translate Spanish relationship_wizzy_cb9264a3:

    # wiz "H-He... well..."
    wiz "É-él... bueno..."

# game/day2 choice.rpy:2081
translate Spanish relationship_wizzy_fe65f138:

    # wiz "...Sigh... As annoying as he is... he's like a little brother to me."
    wiz "...Suspiro... Por molesto que sea... es como un hermano menor para mí."

# game/day2 choice.rpy:2084
translate Spanish relationship_wizzy_d35c864f:

    # wiz "He helps me... and the other puppets... more often than he'd ever admit. So..."
    wiz "Me ayuda... a mí y a las otras marionetas... más a menudo de lo que jamás admitiría. Así que..."

# game/day2 choice.rpy:2085
translate Spanish relationship_wizzy_254d0d7c:

    # wiz "I... understand what he's been through. At least... a little."
    wiz "Yo... entiendo por lo que ha pasado. Al menos... un poco."

# game/day2 choice.rpy:2086
translate Spanish relationship_wizzy_297bd8c2:

    # wiz "I suppose that's enough for me to forgive... some of his more infuriating habits."
    wiz "Supongo que eso basta para perdonarle... algunos de sus hábitos más exasperantes."

# game/day2 choice.rpy:2087
translate Spanish relationship_wizzy_8ac5138a:

    # wiz "....."
    wiz "....."

# game/day2 choice.rpy:2090
translate Spanish relationship_wizzy_809d88bb:

    # wiz "But he is still annoying. End of discussion!"
    wiz "¡Pero sigue siendo molesto. Fin de la discusión!"

# game/day2 choice.rpy:2092
translate Spanish relationship_wizzy_dd0e06f8:

    # "Jestyn simply laughs at Wizzy's frustration. With a sigh, Wizzy decides to ignore him and moves on to the next puppet."
    "Jestyn simplemente se ríe de la frustración de Wizzy. Con un suspiro, Wizzy decide ignorarlo y pasa a la siguiente marioneta."

# game/day2 choice.rpy:2095
translate Spanish relationship_wizzy_6efb976c:

    # wiz "Now, who else...? Ah, Knighter. He's the kingdom's knight puppet."
    wiz "Ahora, ¿quién más...? Ah, Knighter. Es la marioneta caballero del reino."

# game/day2 choice.rpy:2096
translate Spanish relationship_wizzy_2600f7a3:

    # wiz "He's... hmm... not very talkative, and he can seem a little short-tempered."
    wiz "Es... mmm... poco hablador, y puede parecer un poco de mal genio."

# game/day2 choice.rpy:2097
translate Spanish relationship_wizzy_da347d42:

    # wiz "Though, to be fair, he's not really an angry person. It's just... Jestyn keeps pestering him, so... well... that's usually how it ends."
    wiz "Aunque, para ser justos, no es realmente una persona enojona. Es solo que... Jestyn no deja de fastidiarlo, así que... bueno... normalmente termina así."

# game/day2 choice.rpy:2100
translate Spanish relationship_wizzy_b2681e11:

    # wiz "He's a good puppet, though. He gets a little awkward around new people, but he genuinely tries to get along with them. It's actually kind of adorable."
    wiz "Aun así es una buena marioneta. Se pone algo torpe con la gente nueva, pero de verdad se esfuerza por llevarse bien con ellos. Es bastante adorable, en realidad."

# game/day2 choice.rpy:2101
translate Spanish relationship_wizzy_ae714885:

    # wiz "He also comes to me whenever he needs someone to talk to. I always do my best to give him advice. He's... not the type who's good at expressing his feelings."
    wiz "También viene a verme cuando necesita alguien con quien hablar. Siempre hago lo posible por aconsejarlo. No es de los que saben expresar sus sentimientos."

# game/day2 choice.rpy:2104
translate Spanish relationship_wizzy_baab99ce:

    # wiz "Oh! And he loves novels! He often comes to me to talk about whatever he's been reading."
    wiz "¡Oh! ¡Y le encantan las novelas! A menudo viene a hablarme de lo que ha estado leyendo."

# game/day2 choice.rpy:2107
translate Spanish relationship_wizzy_12823d0f:

    # "Wizzy suddenly fell silent, staring at me for a long moment."
    "Wizzy se quedó de pronto en silencio, mirándome fijamente durante un largo momento."

# game/day2 choice.rpy:2109
translate Spanish relationship_wizzy_7c1118df:

    # mc "...Wizzy?"
    mc "...¿Wizzy?"

# game/day2 choice.rpy:2110
translate Spanish relationship_wizzy_cddc27fd:

    # wiz "...I just remembered something."
    wiz "...Acabo de acordarme de algo."

# game/day2 choice.rpy:2111
translate Spanish relationship_wizzy_f4d1a7ec:

    # wiz "Now that you're our [title], Your Majesty... I think you should be careful around Knighter."
    wiz "Ahora que usted es nuestr[letra] [title!t], Majestad... creo que debería tener cuidado con Knighter."

# game/day2 choice.rpy:2112
translate Spanish relationship_wizzy_69fb21f6:

    # mc "Huh? Why?"
    mc "¿Eh? ¿Por qué?"

# game/day2 choice.rpy:2113
translate Spanish relationship_wizzy_9bdea3cb:

    # wiz "He's truly a kind person, but... Cro-"
    wiz "Es de verdad una buena persona, pero... Cro-"

# game/day2 choice.rpy:2116
translate Spanish relationship_wizzy_c9587771:

    # "He caught himself."
    "Se contuvo."

# game/day2 choice.rpy:2118
translate Spanish relationship_wizzy_ff0672f0:

    # wiz "I-I mean... he hasn't fully accepted someone taking our former king's place. He's still deeply loyal to him... It's... a complicated situation."
    wiz "Q-quiero decir... no ha aceptado del todo que alguien ocupe el lugar de nuestro antiguo rey. Sigue siendo profundamente leal a él... Es una situación complicada."

# game/day2 choice.rpy:2121
translate Spanish relationship_wizzy_5298d7b0:

    # wiz "There's a chance he might try to harm you, Your Majesty. So... I'd advise you to be careful around him."
    wiz "Existe la posibilidad de que intente hacerle daño, Majestad. Así que... le aconsejo tener cuidado con él."

# game/day2 choice.rpy:2123
translate Spanish relationship_wizzy_1f25db60:

    # "Wizzy glanced toward Jestyn for a moment."
    "Wizzy miró un momento hacia Jestyn."

# game/day2 choice.rpy:2126
translate Spanish relationship_wizzy_d3a1aac0:

    # wiz "...Though, with Jestyn always by your side, I don't think I have much to worry about."
    wiz "...Aunque, con Jestyn siempre a su lado, no creo que tenga mucho de qué preocuparme."

# game/day2 choice.rpy:2128
translate Spanish relationship_wizzy_8f132a88:

    # "I looked over at Jestyn. As always, he was wearing that same carefree smile."
    "Miré a Jestyn. Como siempre, lucía esa misma sonrisa despreocupada."

# game/day2 choice.rpy:2130
translate Spanish relationship_wizzy_a2c33402:

    # wiz "Knighter may get annoyed with Jestyn, yes... but he does tend to listen to him. I don't know why it works."
    wiz "Knighter puede fastidiarse con Jestyn, sí... pero suele hacerle caso. No sé por qué funciona."

# game/day2 choice.rpy:2133
translate Spanish relationship_wizzy_8015d3d2:

    # wiz "So as long as Jestyn is with you, Your Majesty... you'll be safe."
    wiz "Así que mientras Jestyn esté con usted, Majestad... estará a salvo."

# game/day2 choice.rpy:2136
translate Spanish relationship_wizzy_6c858f86:

    # wiz "Now then... hmm... who else...?"
    wiz "Bien... mmm... ¿quién más...?"

# game/day2 choice.rpy:2138
translate Spanish relationship_wizzy_080a9820:

    # wiz "Ah, Prieston. He's the kingdom's priest puppet."
    wiz "Ah, Prieston. Es la marioneta sacerdote del reino."

# game/day2 choice.rpy:2139
translate Spanish relationship_wizzy_d3af1ff2:

    # wiz "He's..."
    wiz "Es..."

# game/day2 choice.rpy:2141
translate Spanish relationship_wizzy_2638584e_1:

    # wiz "......"
    wiz "......"

# game/day2 choice.rpy:2143
translate Spanish relationship_wizzy_c4ed861b:

    # "Wizzy fell silent, struggling to find the right words."
    "Wizzy guardó silencio, esforzándose por encontrar las palabras adecuadas."

# game/day2 choice.rpy:2145
translate Spanish relationship_wizzy_f3b3d28f:

    # mc "What's wrong?"
    mc "¿Qué pasa?"

# game/day2 choice.rpy:2148
translate Spanish relationship_wizzy_b684f827:

    # wiz "...To be honest, I'm not really sure how to describe Prieston to you, Your Majesty."
    wiz "...La verdad, no estoy muy seguro de cómo describirle a Prieston, Majestad."

# game/day2 choice.rpy:2149
translate Spanish relationship_wizzy_11ea6c28:

    # wiz "The two of us talk quite often, and I'd say we're fairly close."
    wiz "Hablamos con bastante frecuencia, y diría que somos bastante cercanos."

# game/day2 choice.rpy:2152
translate Spanish relationship_wizzy_d99f6537:

    # wiz "It's just... I never really know what's going on inside his head. He's... rather difficult to predict."
    wiz "Es solo que... nunca sé realmente qué pasa por su cabeza. Es... bastante difícil de predecir."

# game/day2 choice.rpy:2155
translate Spanish relationship_wizzy_b3e8b25a:

    # wiz "Still, he's calm, thoughtful, and surprisingly mature... even though he's younger than I am. I really admire him."
    wiz "Aun así, es tranquilo, reflexivo y sorprendentemente maduro... aunque es menor que yo. Lo admiro mucho."

# game/day2 choice.rpy:2158
translate Spanish relationship_wizzy_0dd71ec7:

    # wiz "I also feel like there's always something hidden about him. He's quite mysterious. Honestly, if someone manages to see Prieston even once in a week, I'd call that lucky."
    wiz "También siento que siempre hay algo oculto en él. Es bastante misterioso. Sinceramente, si alguien logra ver a Prieston aunque sea una vez a la semana, yo diría que tiene suerte."

# game/day2 choice.rpy:2159
translate Spanish relationship_wizzy_c6e04887:

    # mc "Is he shy or something?"
    mc "¿Es tímido o algo así?"

# game/day2 choice.rpy:2162
translate Spanish relationship_wizzy_12c7da1b:

    # wiz "Oh, no. Quite the opposite."
    wiz "Oh, no. Todo lo contrario."

# game/day2 choice.rpy:2163
translate Spanish relationship_wizzy_182b3570:

    # wiz "He simply isn't fond of idle conversation. He usually only leaves his room when there's a reason to."
    wiz "Simplemente no es amigo de la charla ociosa. Normalmente solo sale de su habitación cuando hay un motivo."

# game/day2 choice.rpy:2166
translate Spanish relationship_wizzy_5766303c:

    # wiz "...Though perhaps you'll get to meet him soon, Your Majesty."
    wiz "...Aunque quizá pueda conocerlo pronto, Majestad."

# game/day2 choice.rpy:2173
translate Spanish crownusask_wizzy_f7bf24ed:

    # mc "I'm curious... What was the King Puppet like? What do you think of him?"
    mc "Tengo curiosidad... ¿Cómo era la Marioneta Rey? ¿Qué piensas de él?"

# game/day2 choice.rpy:2177
translate Spanish crownusask_wizzy_a6e2dd21:

    # "The instant Wizzy heard the question, he froze in place. His expression became unreadable."
    "En cuanto Wizzy oyó la pregunta, se quedó paralizado. Su expresión se volvió indescifrable."

# game/day2 choice.rpy:2178
translate Spanish crownusask_wizzy_663eb3d9:

    # "Then... he slowly turned his face away from me."
    "Luego... giró lentamente la cara para no mirarme."

# game/day2 choice.rpy:2180
translate Spanish crownusask_wizzy_2638584e:

    # wiz "......"
    wiz "......"

# game/day2 choice.rpy:2183
translate Spanish crownusask_wizzy_4cb8fcfb:

    # wiz "...Why do you want to know about him, Your Majesty?"
    wiz "...¿Por qué quiere saber de él, Majestad?"

# game/day2 choice.rpy:2185
translate Spanish crownusask_wizzy_e83b4a47:

    # "From his voice alone, I could tell the subject made him deeply uncomfortable."
    "Solo por su voz, pude notar que el tema lo incomodaba profundamente."

# game/day2 choice.rpy:2186
translate Spanish crownusask_wizzy_f85bf85a:

    # "...Oh no. I shouldn't have asked."
    "...Oh, no. No debí preguntar."

# game/day2 choice.rpy:2188
translate Spanish crownusask_wizzy_79ec4bd3:

    # mc "U-Um... I'm sorry, Wizzy. I was just curious."
    mc "E-eh... lo siento, Wizzy. Solo tenía curiosidad."

# game/day2 choice.rpy:2189
translate Spanish crownusask_wizzy_562d3cc4:

    # mc "If you don't want to talk about it, that's okay."
    mc "Si no quieres hablar de eso, no pasa nada."

# game/day2 choice.rpy:2190
translate Spanish crownusask_wizzy_2638584e_1:

    # wiz "......"
    wiz "......"

# game/day2 choice.rpy:2193
translate Spanish crownusask_wizzy_528b98d8:

    # wiz "No..."
    wiz "No..."

# game/day2 choice.rpy:2194
translate Spanish crownusask_wizzy_e0bebf22:

    # wiz "I think you deserve to know."
    wiz "Creo que merece saberlo."

# game/day2 choice.rpy:2195
translate Spanish crownusask_wizzy_81b86c9c:

    # wiz "The King Puppet... was not a good king."
    wiz "La Marioneta Rey... no era un buen rey."

# game/day2 choice.rpy:2198
translate Spanish crownusask_wizzy_b97bdbb3:

    # voice "WIZZY04_DAY2.ogg"
    # wiz "He was a liar."
    voice "WIZZY04_DAY2.ogg"
    wiz "Era un mentiroso."

# game/day2 choice.rpy:2200
translate Spanish crownusask_wizzy_806024a9:

    # voice "WIZZY05_DAY2.ogg"
    # wiz "A big liar."
    voice "WIZZY05_DAY2.ogg"
    wiz "Un gran mentiroso."

# game/day2 choice.rpy:2202
translate Spanish crownusask_wizzy_1b242679:

    # voice "WIZZY06_DAY2.ogg"
    # wiz "With nothing but sweet words, he bewitched the puppets... blinded them... made them believe every lie he told."
    voice "WIZZY06_DAY2.ogg"
    wiz "Con nada más que dulces palabras, hechizó a las marionetas... las cegó... les hizo creer cada mentira que decía."

# game/day2 choice.rpy:2206
translate Spanish crownusask_wizzy_0199f4b9:

    # wiz "I MEAN... HOW COULD HE MAKE ALL THOSE PROMISES....AND LEAVE US LIKE THIS?!"
    wiz "¡QUIERO DECIR... ¿CÓMO PUDO HACER TODAS ESAS PROMESAS... Y DEJARNOS ASÍ?!"

# game/day2 choice.rpy:2208
translate Spanish crownusask_wizzy_bd4d315a:

    # "Slowly, a thick black liquid began to seep from the cracks beneath Wizzy's blindfold and from the corners of his mouth."
    "Lentamente, un espeso líquido negro comenzó a filtrarse por las grietas bajo la venda de Wizzy y por las comisuras de su boca."

# game/day2 choice.rpy:2211
translate Spanish crownusask_wizzy_0d95b790:

    # wiz "HE DIDN'T CARE!"
    wiz "¡NO LE IMPORTÓ!"

# game/day2 choice.rpy:2213
translate Spanish crownusask_wizzy_7cc1458f:

    # wiz "HE NEVER CARED ABOUT ANY OF US!"
    wiz "¡NUNCA LE IMPORTÓ NINGUNO DE NOSOTROS!"

# game/day2 choice.rpy:2214
translate Spanish crownusask_wizzy_8237ddaf:

    # wiz "IT WAS ALL..."
    wiz "TODO FUE..."

# game/day2 choice.rpy:2218
translate Spanish crownusask_wizzy_f1c68bc1:

    # wiz "FOR HIMSELF!"
    wiz "¡POR SÍ MISMO!"

# game/day2 choice.rpy:2220
translate Spanish crownusask_wizzy_54ce8483:

    # mc "Wizzy, calm down!"
    mc "¡Wizzy, cálmate!"

# game/day2 choice.rpy:2222
translate Spanish crownusask_wizzy_efe25393:

    # "I quickly grabbed Wizzy's arm, hoping to snap him out of it."
    "Agarré rápidamente el brazo de Wizzy, con la esperanza de hacerlo reaccionar."

# game/day2 choice.rpy:2225
translate Spanish crownusask_wizzy_245aae01:

    # "Thankfully, he came back to his senses. Realizing what just happened, he hurriedly wiped away the black liquid seeping from beneath his blindfold and the corners of his mouth."
    "Por suerte, recuperó la razón. Al darse cuenta de lo que acababa de pasar, se apresuró a limpiar el líquido negro que goteaba bajo su venda y por las comisuras de su boca."

# game/day2 choice.rpy:2227
translate Spanish crownusask_wizzy_a9dbcd1f:

    # wiz "I-I'm so sorry, Your Majesty... I let my emotions get the better of me."
    wiz "L-lo siento mucho, Majestad... dejé que mis emociones me dominaran."

# game/day2 choice.rpy:2228
translate Spanish crownusask_wizzy_820e0fe6:

    # mc "What happened to you? That black liquid... it was coming from your eyes and your mouth."
    mc "¿Qué te pasó? Ese líquido negro... salía de tus ojos y de tu boca."

# game/day2 choice.rpy:2229
translate Spanish crownusask_wizzy_44d43bda:

    # wiz "It's alright... It only happens when my emotions spiral out of control."
    wiz "No pasa nada... Solo ocurre cuando mis emociones se descontrolan."

# game/day2 choice.rpy:2232
translate Spanish crownusask_wizzy_86cdb358:

    # wiz "I'll be fine... as long as it doesn't happen too often."
    wiz "Estaré bien... mientras no pase muy a menudo."

# game/day2 choice.rpy:2236
translate Spanish crownusask_wizzy_8efcca2d:

    # "Wizzy excused himself for a moment to wipe his face with a cloth."
    "Wizzy se excusó un momento para limpiarse la cara con un paño."

# game/day2 choice.rpy:2237
translate Spanish crownusask_wizzy_d9608f5c:

    # "If his emotions could affect him this deeply... then whatever had happened to him must have left him with a profound trauma."
    "Si sus emociones podían afectarle tan profundamente... entonces lo que fuera que le hubiera pasado debía de haberle dejado un trauma profundo."

# game/day2 choice.rpy:2238
translate Spanish crownusask_wizzy_792b4477:

    # "As he came back, he hesitated for a moment."
    "Al volver, dudó un momento."

# game/day2 choice.rpy:2241
translate Spanish crownusask_wizzy_2ad643c3:

    # wiz "...You're not afraid of me, are you, Your Majesty?"
    wiz "...No me tiene miedo, ¿verdad, Majestad?"

# game/day2 choice.rpy:2245
translate Spanish crownusask_wizzy_dfcee85e:

    # wiz "Y-you are? I'm so sorry, Your Majesty. I'll make sure that won't happen again."
    wiz "¿L-le doy miedo? Lo lamento muchísimo, Majestad. Me aseguraré de que no vuelva a ocurrir."

# game/day2 choice.rpy:2249
translate Spanish crownusask_wizzy_b5cfe6ac:

    # wiz "...Thank goodness."
    wiz "...Menos mal."

# game/day2 choice.rpy:2250
translate Spanish crownusask_wizzy_6d30cd2a:

    # wiz "I'm truly sorry, Your Majesty..."
    wiz "De verdad lo lamento, Majestad..."

# game/day2 choice.rpy:2253
translate Spanish crownusask_wizzy_cf1e50a0:

    # wiz "But... like I said before... the King Puppet was not a good king. He only ever cared about himself."
    wiz "Pero... como dije antes... la Marioneta Rey no era un buen rey. Solo se preocupaba por sí mismo."

# game/day2 choice.rpy:2254
translate Spanish crownusask_wizzy_9e9d7e8d:

    # wiz "...I'm afraid that's all I can say. I'm not comfortable talking about him."
    wiz "...Me temo que eso es todo lo que puedo decir. No me siento cómodo hablando de él."

# game/day2 choice.rpy:2255
translate Spanish crownusask_wizzy_4f3ce38f:

    # mc "That's okay. I understand."
    mc "Está bien. Lo entiendo."

# game/day2 choice.rpy:2261
translate Spanish afterconvo_wizzy_45246df7:

    # wiz "Oh? Is that all?"
    wiz "¿Oh? ¿Eso es todo?"

# game/day2 choice.rpy:2264
translate Spanish afterconvo_wizzy_b52db37b:

    # wiz "In that case... I hope you enjoyed our conversation, Your Majesty."
    wiz "En ese caso... espero que haya disfrutado nuestra conversación, Majestad."

# game/day2 choice.rpy:2265
translate Spanish afterconvo_wizzy_a46c3104:

    # wiz "Because... I certainly did."
    wiz "Porque... yo sin duda sí."

# game/day2 choice.rpy:2266
translate Spanish afterconvo_wizzy_ebf0dfa1:

    # mc "I did too, Wizzy. I really enjoyed talking with you. You're very easy to talk to."
    mc "Yo también, Wizzy. Disfruté mucho hablar contigo. Es muy fácil hablar contigo."

# game/day2 choice.rpy:2269
translate Spanish afterconvo_wizzy_323aa9df:

    # wiz "Ehehe... You're making me blush."
    wiz "Ejeje... Me hace sonrojar."

# game/day2 choice.rpy:2270
translate Spanish afterconvo_wizzy_4e531286:

    # wiz "I wish we could talk a little longer... but I imagine Your Majesty has a rather busy schedule."
    wiz "Ojalá pudiéramos hablar un poco más... pero imagino que Su Majestad tiene una agenda bastante ocupada."

# game/day2 choice.rpy:2271
translate Spanish afterconvo_wizzy_fb8f2b20:

    # wiz "Perhaps we can chat again another time."
    wiz "Quizá podamos charlar de nuevo en otra ocasión."

# game/day2 choice.rpy:2274
translate Spanish afterconvo_wizzy_9cae04c5:

    # "I nodded in agreement before getting to my feet."
    "Asentí en señal de acuerdo antes de ponerme de pie."

# game/day2 choice.rpy:2276
translate Spanish afterconvo_wizzy_02b9571c:

    # mc "I'm glad I got to know you, Wizzy. We'll definitely talk again."
    mc "Me alegra haberte conocido, Wizzy. Sin duda volveremos a hablar."

# game/day2 choice.rpy:2279
translate Spanish afterconvo_wizzy_db50ade3:

    # wiz "Yes! Yes! You can always knock on my door, Your Majesty. I'd be happy to talk with you anytime."
    wiz "¡Sí! ¡Sí! Siempre puede llamar a mi puerta, Majestad. Estaré encantado de hablar con usted en cualquier momento."

# game/day2 choice.rpy:2280
translate Spanish afterconvo_wizzy_9771cce7:

    # wiz "Next time, I'll make sure to prepare tea and some cake for us while we chat."
    wiz "La próxima vez me aseguraré de preparar té y algo de pastel para nosotros mientras charlamos."

# game/day2 choice.rpy:2283
translate Spanish afterconvo_wizzy_ac4d97c5:

    # wiz "Until then... please take care of yourself!"
    wiz "Hasta entonces... ¡cuídese mucho!"

# game/day2 choice.rpy:2286
translate Spanish afterconvo_wizzy_0d977abd:

    # wiz "And Jestyn! Don't give [poss] Majesty too much trouble!"
    wiz "¡Y Jestyn! ¡No le des demasiados problemas a Su Majestad!"

# game/day2 choice.rpy:2290
translate Spanish afterconvo_wizzy_c4ffba63:

    # jes "Hmm~ Sure, sure... no promises."
    jes "Mmm~ Claro, claro... no prometo nada."

# game/day2 choice.rpy:2293
translate Spanish afterconvo_wizzy_63aa7ecf:

    # wiz "Geeezz..."
    wiz "Uf..."

# game/day2 choice.rpy:2297
translate Spanish afterconvo_wizzy_e692cc36:

    # "Wizzy waved goodbye as Jestyn led me out of his room."
    "Wizzy se despidió con la mano mientras Jestyn me sacaba de su habitación."

# game/day2 choice.rpy:2300
translate Spanish afterconvo_wizzy_c31b4b11:

    # wiz "Your Majesty...."
    wiz "Majestad...."

# game/day2 choice.rpy:2302
translate Spanish afterconvo_wizzy_7464db8d:

    # "My steps suddenly came to a halt."
    "Mis pasos se detuvieron de repente."

# game/day2 choice.rpy:2303
translate Spanish afterconvo_wizzy_abbb754b:

    # "Wizzy's voice was right beside my ear, whispered as if he didn't want Jestyn to hear him."
    "La voz de Wizzy estaba justo junto a mi oído, susurrada como si no quisiera que Jestyn lo oyera."

# game/day2 choice.rpy:2305
translate Spanish afterconvo_wizzy_45b315e0:

    # wiz "Be careful..."
    wiz "Tenga cuidado..."

# game/day2 choice.rpy:2307
translate Spanish afterconvo_wizzy_c7d659a4:

    # "What...?"
    "¿Qué...?"

# game/day2 choice.rpy:2308
translate Spanish afterconvo_wizzy_e7a06437:

    # "I watched as Jestyn walked away, completely unaware of what was happening behind him."
    "Vi cómo Jestyn se alejaba, completamente ajeno a lo que ocurría a sus espaldas."

# game/day2 choice.rpy:2309
translate Spanish afterconvo_wizzy_da747723:

    # "What would happen if he found out?"
    "¿Qué pasaría si se enterara?"

# game/day2 choice.rpy:2310
translate Spanish afterconvo_wizzy_563ee6d7:

    # "I didn't even dare turn my head toward Wizzy."
    "Ni siquiera me atreví a girar la cabeza hacia Wizzy."

# game/day2 choice.rpy:2314
translate Spanish afterconvo_wizzy_aa40b38c:

    # wiz "..... Until we meet again, Your Majesty."
    wiz "..... Hasta que nos volvamos a ver, Majestad."

# game/day2 choice.rpy:2317
translate Spanish afterconvo_wizzy_1889381c:

    # ".... I don't understand..."
    ".... No entiendo..."

# game/day2 choice.rpy:2319
translate Spanish afterconvo_wizzy_ef79209c:

    # "But overall, Wizzy is kind, thoughtful, and incredibly intelligent."
    "Pero, en general, Wizzy es amable, atento e increíblemente inteligente."

# game/day2 choice.rpy:2320
translate Spanish afterconvo_wizzy_b76917cf:

    # "He's... genuinely wonderful to talk to."
    "Es... realmente maravilloso para conversar."

# game/day2 choice.rpy:2330
translate Spanish knighterroom_day2_9f366740:

    # "My eyes settled on the door bearing the nameplate Knight."
    "Mis ojos se posaron en la puerta con la placa Caballero."

# game/day2 choice.rpy:2331
translate Spanish knighterroom_day2_d6be4d02:

    # "The knight puppet."
    "La marioneta caballero."

# game/day2 choice.rpy:2332
translate Spanish knighterroom_day2_25cfd770:

    # "Yesterday's encounter in the corridor was still vivid in my mind. The knight puppet had loomed over me like an unmovable wall."
    "El encuentro de ayer en el pasillo seguía vívido en mi mente. La marioneta caballero se había erguido sobre mí como un muro inamovible."

# game/day2 choice.rpy:2333
translate Spanish knighterroom_day2_835a6a9f:

    # "The lingering shiver still crawled across my skin whenever I recalled it."
    "Aún me recorría un escalofrío por la piel cada vez que lo recordaba."

# game/day2 choice.rpy:2334
translate Spanish knighterroom_day2_038fb87f:

    # "Especially the moment I realized... that puppet had every intention of killing me."
    "Sobre todo el momento en que me di cuenta... de que esa marioneta tenía toda la intención de matarme."

# game/day2 choice.rpy:2335
translate Spanish knighterroom_day2_a3bb82c3:

    # "And yet... something deep inside urged me to at least try introducing myself to the knight puppet."
    "Y aun así... algo en lo más profundo me instaba a, al menos, intentar presentarme a la marioneta caballero."

# game/day2 choice.rpy:2338
translate Spanish knighterroom_day2_9f366740_1:

    # "My eyes settled on the door bearing the nameplate Knight."
    "Mis ojos se posaron en la puerta con la placa Caballero."

# game/day2 choice.rpy:2339
translate Spanish knighterroom_day2_d6be4d02_1:

    # "The knight puppet."
    "La marioneta caballero."

# game/day2 choice.rpy:2341
translate Spanish knighterroom_day2_91f2ade1:

    # mc "I'd like to meet the Knight Puppet."
    mc "Me gustaría conocer a la Marioneta Caballero."

# game/day2 choice.rpy:2343
translate Spanish knighterroom_day2_9a0b0218:

    # jes "Of course, Your Majesty. This way~"
    jes "Por supuesto, Majestad. Por aquí~"

# game/day2 choice.rpy:2346
translate Spanish knighterroom_day2_ec12948f:

    # "Jestyn leads me over to the Knight Puppet's door."
    "Jestyn me guía hasta la puerta de la Marioneta Caballero."

# game/day2 choice.rpy:2348
translate Spanish knighterroom_day2_ecf8ffc1:

    # "And before long, we were standing right in front of it."
    "Y poco después, estábamos justo frente a ella."

# game/day2 choice.rpy:2350
translate Spanish knighterroom_day2_ed9c2ad5:

    # jes "Before we go in, Your Majesty, there's something you should know about our dear knight."
    jes "Antes de entrar, Majestad, hay algo que debe saber sobre nuestro querido caballero."

# game/day2 choice.rpy:2351
translate Spanish knighterroom_day2_2d69b0f4:

    # jes "He's not the easiest puppet to get along with. He's rather hot-headed... especially around strangers."
    jes "No es la marioneta más fácil de tratar. Es bastante impulsivo... sobre todo con los extraños."

# game/day2 choice.rpy:2353
translate Spanish knighterroom_day2_e5dcb7b4:

    # jes "And he hasn't exactly accepted Your Majesty as the new [title] of the Kingdom of Marionettes."
    jes "Y no ha aceptado exactamente a Su Majestad como nuev[letra] [title!t] del Reino de las Marionetas."

# game/day2 choice.rpy:2355
translate Spanish knighterroom_day2_afd67cfc:

    # "I swallowed hard.... This was going to be difficult."
    "Tragué saliva.... Esto iba a ser difícil."

# game/day2 choice.rpy:2357
translate Spanish knighterroom_day2_4a0f5b5c:

    # jes "So my advice is simple. Keep teasing him."
    jes "Así que mi consejo es simple. Siga molestándolo."

# game/day2 choice.rpy:2358
translate Spanish knighterroom_day2_dc16ebcd:

    # mc "Got it."
    mc "Entendido."

# game/day2 choice.rpy:2361
translate Spanish knighterroom_day2_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:2363
translate Spanish knighterroom_day2_c4207569:

    # mc "...Wait, what?"
    mc "...Espera, ¿qué?"

# game/day2 choice.rpy:2366
translate Spanish knighterroom_day2_95f22a6b:

    # "As I tried to question what I just heard, Jestyn simply looked back at me as though he'd said nothing unusual."
    "Mientras intentaba cuestionar lo que acababa de oír, Jestyn solo me miró como si no hubiera dicho nada extraño."

# game/day2 choice.rpy:2368
translate Spanish knighterroom_day2_d17b6d7d:

    # mc "W-What do you mean? Shouldn't I be doing the exact opposite?"
    mc "¿Q-qué quieres decir? ¿No debería hacer justo lo contrario?"

# game/day2 choice.rpy:2370
translate Spanish knighterroom_day2_394cf220:

    # jes "Hm? Why? Teasing him is fun~"
    jes "¿Hm? ¿Por qué? Molestarlo es divertido~"

# game/day2 choice.rpy:2371
translate Spanish knighterroom_day2_8568886a:

    # jes "Besides, don't worry, Your Majesty. He won't lay a finger on you. Not while I'm by your side."
    jes "Además, no se preocupe, Majestad. No le pondrá un dedo encima. No mientras yo esté a su lado."

# game/day2 choice.rpy:2372
translate Spanish knighterroom_day2_39e78004:

    # mc "Are you sure...? It feels wrong to tease someone I've never even met before."
    mc "¿Seguro...? Se siente mal molestar a alguien a quien ni siquiera conozco."

# game/day2 choice.rpy:2374
translate Spanish knighterroom_day2_2b3825bb:

    # jes "Trust me, Your Majesty. I know Knighter better than anyone. If you really want to get closer to him, then the best thing to do is-"
    jes "Confíe en mí, Majestad. Conozco a Knighter mejor que nadie. Si de verdad quiere acercarse a él, lo mejor es-"

# game/day2 choice.rpy:2375
translate Spanish knighterroom_day2_9e836d2a:

    # kni "Do you honestly think I can't hear everything you're saying out there?"
    kni "¿De verdad crees que no puedo oír todo lo que dices ahí fuera?"

# game/day2 choice.rpy:2377
translate Spanish knighterroom_day2_1cce6ca7:

    # "The voice from behind the door startled me."
    "La voz que venía desde detrás de la puerta me sobresaltó."

# game/day2 choice.rpy:2379
translate Spanish knighterroom_day2_d9c34d8f:

    # "Jestyn, on the other hand, simply laughed."
    "Jestyn, en cambio, simplemente rio."

# game/day2 choice.rpy:2381
translate Spanish knighterroom_day2_e8a71bb7:

    # jes "I know~ That's why I said it loud enough for you to hear."
    jes "Lo sé~ Por eso lo dije lo bastante alto para que me oyeras."

# game/day2 choice.rpy:2383
translate Spanish knighterroom_day2_c865ad92:

    # "Jestyn gave me a playful wink, silently showing me exactly how he dealt with Knighter."
    "Jestyn me guiñó un ojo con picardía, mostrándome en silencio cómo trataba a Knighter."

# game/day2 choice.rpy:2385
translate Spanish knighterroom_day2_4f0e261f:

    # kni "What do you want?"
    kni "¿Qué quieres?"

# game/day2 choice.rpy:2387
translate Spanish knighterroom_day2_fd18723f:

    # jes "Knighter, my beloved knight. Today I've brought you the most important guest in the entire kingdom."
    jes "Knighter, mi amado caballero. Hoy te he traído al invitado más importante de todo el reino."

# game/day2 choice.rpy:2388
translate Spanish knighterroom_day2_bb896c0c:

    # jes "[poss] Majesty wishes to have a conversation with you."
    jes "Su Majestad desea conversar contigo."

# game/day2 choice.rpy:2390
translate Spanish knighterroom_day2_97996077:

    # "Silence fills the hallway for a few moments."
    "El silencio llena el pasillo por unos instantes."

# game/day2 choice.rpy:2392
translate Spanish knighterroom_day2_bd3d2b50:

    # kni "I don't know anyone by that title."
    kni "No conozco a nadie con ese título."

# game/day2 choice.rpy:2394
translate Spanish knighterroom_day2_67b1550f:

    # "...Wow. That was cold."
    "...Vaya. Qué frío."

# game/day2 choice.rpy:2397
translate Spanish knighterroom_day2_5380ef95:

    # jes "Gasp! How could you say something so rude in front of [poss] Majesty? Where are your manners?"
    jes "¡Ay! ¿Cómo puedes decir algo tan grosero frente a Su Majestad? ¿Dónde están tus modales?"

# game/day2 choice.rpy:2398
translate Spanish knighterroom_day2_d7b822e7:

    # kni "There is no ruler in this kingdom anymore. End of discussion. Leave."
    kni "Ya no hay ningún gobernante en este reino. Fin de la discusión. Largo."

# game/day2 choice.rpy:2400
translate Spanish knighterroom_day2_3ff3db03:

    # "Jestyn patted me on the shoulder before leaning in to whisper."
    "Jestyn me dio una palmadita en el hombro antes de inclinarse para susurrarme."

# game/day2 choice.rpy:2402
translate Spanish knighterroom_day2_93b15e15:

    # jes "Try ordering him~ Say something like... Knighter, as your ruler, I command you to open this door."
    jes "Pruebe a darle una orden~ Diga algo como... Knighter, como tu gobernante, te ordeno que abras esta puerta."

# game/day2 choice.rpy:2404
translate Spanish knighterroom_day2_f89a861a:

    # "I glanced at Jestyn nervously."
    "Miré nervios[letra] a Jestyn."

# game/day2 choice.rpy:2405
translate Spanish knighterroom_day2_30f71181:

    # "...I had no idea if that's a good idea. But... I had to try."
    "...No tenía idea de si era buena idea. Pero... tenía que intentarlo."

# game/day2 choice.rpy:2407
translate Spanish knighterroom_day2_e79a852c:

    # mc "K-Knighter! As your [title]... I command you to open the door!"
    mc "¡K-Knighter! ¡Como tu [title!t]... te ordeno que abras la puerta!"

# game/day2 choice.rpy:2408
translate Spanish knighterroom_day2_d1e82c1f:

    # kni "Say something like that to me again... and I'll drive my sword straight through your heart."
    kni "Vuelve a decirme algo así... y te atravesaré el corazón con mi espada."

# game/day2 choice.rpy:2409
translate Spanish knighterroom_day2_d55335de:

    # kni "I'm serious."
    kni "Hablo en serio."

# game/day2 choice.rpy:2411
translate Spanish knighterroom_day2_ab948894:

    # "I froze on the spot."
    "Me quedé helad[letra] en el sitio."

# game/day2 choice.rpy:2413
translate Spanish knighterroom_day2_e8a0f7cb:

    # "Meanwhile, beside me, Jestyn was struggling to hold back his laughter. That jerk."
    "Mientras tanto, a mi lado, Jestyn se esforzaba por contener la risa. Ese canalla."

# game/day2 choice.rpy:2414
translate Spanish knighterroom_day2_bdb77b57:

    # "So this was what I got for trying to be brave?"
    "¿Así que esto era lo que obtenía por intentar ser valiente?"

# game/day2 choice.rpy:2416
translate Spanish knighterroom_day2_58520de2:

    # kni "Leave. Both of you. I'm not opening this door."
    kni "Largo. Los dos. No pienso abrir esta puerta."

# game/day2 choice.rpy:2418
translate Spanish knighterroom_day2_7f32f4cc:

    # jes "Very well~ We'll leave."
    jes "Muy bien~ Nos iremos."

# game/day2 choice.rpy:2419
translate Spanish knighterroom_day2_02c23e5f:

    # jes "Your Majesty... if you'll excuse us."
    jes "Majestad... si nos disculpa."

# game/day2 choice.rpy:2421
translate Spanish knighterroom_day2_18f2d1c1:

    # "Jestyn placed a hand on my shoulder and snapped his fingers."
    "Jestyn me puso una mano en el hombro y chasqueó los dedos."

# game/day2 choice.rpy:2425
translate Spanish knighterroom_day2_8c9305e9:

    # "In an instant, the two of us were teleported into what I could only assume was Knighter's room."
    "En un instante, ambos fuimos teletransportados a lo que solo podía suponer que era la habitación de Knighter."

# game/day2 choice.rpy:2430
translate Spanish knighterroom_day2_121b9fc4:

    # kni "WHAT-?!"
    kni "¡¿QUÉ-?!"

# game/day2 choice.rpy:2432
translate Spanish knighterroom_day2_c3b10872:

    # kni "I SAID GET OUT!!"
    kni "¡DIJE QUE SE FUERAN!"

# game/day2 choice.rpy:2436
translate Spanish knighterroom_day2_97d390d8:

    # jes "I heard you~ That's exactly why we left from the front door...and came into your room instead."
    jes "Te oí~ Precisamente por eso nos fuimos por la puerta principal... y entramos en tu habitación."

# game/day2 choice.rpy:2437
translate Spanish knighterroom_day2_ce6cea8b:

    # kni "What- YOU-!"
    kni "¡Qué- TÚ-!"

# game/day2 choice.rpy:2440
translate Spanish knighterroom_day2_27b35c99:

    # "Knighter ran a hand through his hair in frustration."
    "Knighter se pasó una mano por el cabello, frustrado."

# game/day2 choice.rpy:2443
translate Spanish knighterroom_day2_079b0631:

    # kni "...... Hhhhhhhhhhaaaaaaaaaaaaaaaaaaaaahhhhhhhhhhhhhhhhh......"
    kni "...... Hhhhhhhhhhaaaaaaaaaaaaaaaaaaaaahhhhhhhhhhhhhhhhh......"

# game/day2 choice.rpy:2444
translate Spanish knighterroom_day2_98d12e55:

    # kni "... I forgot you could do that..."
    kni "... Olvidé que podías hacer eso..."

# game/day2 choice.rpy:2446
translate Spanish knighterroom_day2_60dfebc5:

    # jes "Happy to remind you."
    jes "Encantado de recordártelo."

# game/day2 choice.rpy:2448
translate Spanish knighterroom_day2_b7a7f707:

    # jes "Nowwww, let this humble jester introduce both of you to each other."
    jes "Aaahora, permitan que este humilde bufón los presente el uno al otro."

# game/day2 choice.rpy:2450
translate Spanish knighterroom_day2_a37c1401:

    # jes "Your Majesty, this is our brave, strong knight, Sir Knighter."
    jes "Majestad, este es nuestro valiente y fuerte caballero, Sir Knighter."

# game/day2 choice.rpy:2451
translate Spanish knighterroom_day2_1eb6c0b1:

    # jes "Knighter darling, this is our beloved, amazing, cute, adorable, gorgeous, kind, gentle [title] [player_call]"
    jes "Knighter querido, te presento a nuestr[letra] amad[letra], asombros[letra], lind[letra], adorable, hermos[letra], amable y gentil [title!t] [player_call]"

# game/day2 choice.rpy:2452
translate Spanish knighterroom_day2_5749a0b6:

    # jes "Now then... let's have a nice chat. [poss] Majesty came all this way to speak with you."
    jes "Ahora bien... tengamos una agradable charla. Su Majestad vino hasta aquí para hablar contigo."

# game/day2 choice.rpy:2453
translate Spanish knighterroom_day2_9e3d73ef:

    # kni "....."
    kni "....."

# game/day2 choice.rpy:2454
translate Spanish knighterroom_day2_801eb837:

    # kni "About what?"
    kni "¿Sobre qué?"

# game/day2 choice.rpy:2455
translate Spanish knighterroom_day2_9812f768:

    # mc "Actually, just a little chat to get to know you better."
    mc "En realidad, solo una pequeña charla para conocerte mejor."

# game/day2 choice.rpy:2457
translate Spanish knighterroom_day2_159ce7b5:

    # kni "I'm not interested in that."
    kni "Eso no me interesa."

# game/day2 choice.rpy:2459
translate Spanish knighterroom_day2_231291fe:

    # "Knighter looked me up and down with undisguised irritation."
    "Knighter me miró de arriba abajo con descarada irritación."

# game/day2 choice.rpy:2463
translate Spanish knighterroom_day2_f7597ca9:

    # voice "KNIGHTER01_DAY2.ogg"
    # kni "Intruder. Stop pretending you're the ruler of this kingdom."
    voice "KNIGHTER01_DAY2.ogg"
    kni "Intrus[letra]. Deja de fingir que eres [arti] gobernante de este reino."

# game/day2 choice.rpy:2465
translate Spanish knighterroom_day2_be6edcab:

    # voice "KNIGHTER02_DAY2.ogg"
    # kni "You don't belong here."
    voice "KNIGHTER02_DAY2.ogg"
    kni "No perteneces aquí."

# game/day2 choice.rpy:2467
translate Spanish knighterroom_day2_8e3fb306:

    # voice "KNIGHTER03_DAY2.ogg"
    # kni "You're lucky that clown is standing beside you. Otherwise, I would've already-"
    voice "KNIGHTER03_DAY2.ogg"
    kni "Tienes suerte de que ese payaso esté a tu lado. De lo contrario, ya habría-"

# game/day2 choice.rpy:2470
translate Spanish knighterroom_day2_0881a0e6:

    # jes "Knighter."
    jes "Knighter."

# game/day2 choice.rpy:2472
translate Spanish knighterroom_day2_54f3f52f:

    # "Jestyn spoke his name."
    "Jestyn pronunció su nombre."

# game/day2 choice.rpy:2473
translate Spanish knighterroom_day2_a650d55f:

    # "His voice was lower than usual... and all traces of his playful tone were gone."
    "Su voz era más grave de lo habitual... y no quedaba ni rastro de su tono juguetón."

# game/day2 choice.rpy:2475
translate Spanish knighterroom_day2_cc594e6b:

    # jes "What did I tell you about speaking to [poss] Majesty like that?"
    jes "¿Qué te dije sobre hablarle así a Su Majestad?"

# game/day2 choice.rpy:2477
translate Spanish knighterroom_day2_9797707e:

    # kni "......"
    kni "......"

# game/day2 choice.rpy:2479
translate Spanish knighterroom_day2_773a99bf:

    # "Knighter's expression didn't change."
    "La expresión de Knighter no cambió."

# game/day2 choice.rpy:2480
translate Spanish knighterroom_day2_5b887ab3:

    # "But judging by his body language... he suddenly seemed tense."
    "Pero a juzgar por su lenguaje corporal... de pronto parecía tenso."

# game/day2 choice.rpy:2481
translate Spanish knighterroom_day2_b1639d30:

    # "...Why? Was it because of Jestyn? Was he... afraid of him?"
    "...¿Por qué? ¿Fue por Jestyn? ¿Le tenía... miedo?"

# game/day2 choice.rpy:2483
translate Spanish knighterroom_day2_df9f4b3b:

    # jes "If you speak to [poss] Majesty like that one more time-"
    jes "Si le hablas así a Su Majestad una vez más-"

# game/day2 choice.rpy:2484
translate Spanish knighterroom_day2_f121e1cd:

    # kni "...Enough."
    kni "...Basta."

# game/day2 choice.rpy:2486
translate Spanish knighterroom_day2_6ec0ae0c:

    # kni "...I understand."
    kni "...Entiendo."

# game/day2 choice.rpy:2488
translate Spanish knighterroom_day2_83d11e2d:

    # jes "Good! Now... speak to [poss] Majesty properly. I've introduced you to [obj], now try it by yourself."
    jes "¡Bien! Ahora... háblale a Su Majestad como corresponde. Ya te he presentado a [subj!t], ahora inténtalo tú solo."

# game/day2 choice.rpy:2492
translate Spanish knighterroom_day2_4ff60f70:

    # "Jestyn stepped back, giving Knighter and me some space."
    "Jestyn dio un paso atrás, dándonos a Knighter y a mí algo de espacio."

# game/day2 choice.rpy:2495
translate Spanish knighterroom_day2_9797707e_1:

    # kni "......"
    kni "......"

# game/day2 choice.rpy:2496
translate Spanish knighterroom_day2_3b21f354:

    # mc "......"
    mc "......"

# game/day2 choice.rpy:2498
translate Spanish knighterroom_day2_e20d07d9:

    # "...This was painfully awkward."
    "...Esto era dolorosamente incómodo."

# game/day2 choice.rpy:2499
translate Spanish knighterroom_day2_cdb7b1b8:

    # "I had absolutely no idea how to start a conversation with him."
    "No tenía ni idea de cómo empezar una conversación con él."

# game/day2 choice.rpy:2501
translate Spanish knighterroom_day2_e73249a6:

    # mc "...U-Um... hi."
    mc "...E-eh... hola."

# game/day2 choice.rpy:2504
translate Spanish knighterroom_day2_ef30588b:

    # "The moment the word left my mouth, Knighter's expression hardened even further."
    "En cuanto la palabra salió de mi boca, la expresión de Knighter se endureció aún más."

# game/day2 choice.rpy:2505
translate Spanish knighterroom_day2_d068cd11:

    # "...How was I supposed to have a conversation with this puppet if even saying 'hi' seemed to annoy him?"
    "...¿Cómo se suponía que iba a conversar con esta marioneta si incluso decir 'hola' parecía fastidiarlo?"

# game/day2 choice.rpy:2509
translate Spanish knighterroom_day2_3d7fca41:

    # jes "Sigh... Alright. Looks like I'll have to help after all."
    jes "Suspiro... Está bien. Parece que tendré que ayudar después de todo."

# game/day2 choice.rpy:2510
translate Spanish knighterroom_day2_4bc1b98b:

    # jes "Excuse me for a moment, Your Majesty."
    jes "Disculpe un momento, Majestad."

# game/day2 choice.rpy:2517
translate Spanish knighterroom_day2_1198d7f2:

    # "Standing behind Knighter, Jestyn grabbed his arm and extended it toward me."
    "Parado detrás de Knighter, Jestyn le agarró el brazo y lo extendió hacia mí."

# game/day2 choice.rpy:2519
translate Spanish knighterroom_day2_b31ebc06:

    # "...What was he doing?"
    "...¿Qué estaba haciendo?"

# game/day2 choice.rpy:2520
translate Spanish knighterroom_day2_f8cadbd2:

    # "Clearly irritated, Knighter immediately tried to pull his arm back."
    "Claramente irritado, Knighter intentó retirar el brazo de inmediato."

# game/day2 choice.rpy:2522
translate Spanish knighterroom_day2_ff29c4a5:

    # jes "Hello, Your Majesty. I'm Knighterrr~"
    jes "Hola, Majestad. Soy Knighterrr~"

# game/day2 choice.rpy:2523
translate Spanish knighterroom_day2_6b6f5214:

    # kni "Let go-! What do you think you're doing?!"
    kni "¡Suéltame-! ¿¡Qué crees que haces?!"

# game/day2 choice.rpy:2524
translate Spanish knighterroom_day2_6141c531:

    # jes "Helping you introduce yourself to [poss] Majesty, of course. Now be a good knight and cooperate~"
    jes "Ayudarte a presentarte ante Su Majestad, por supuesto. Ahora sé un buen caballero y coopera~"

# game/day2 choice.rpy:2529
translate Spanish knighterroom_day2_5484b795:

    # "Knighter looked ready to fight back before finally letting out a defeated sigh."
    "Knighter parecía a punto de resistirse antes de soltar finalmente un suspiro de derrota."

# game/day2 choice.rpy:2534
translate Spanish knighterroom_day2_6251cc35:

    # jes "Your Majesty, Knighter would like to shake your hand~"
    jes "Majestad, Knighter quiere estrecharle la mano~"

# game/day2 choice.rpy:2535
translate Spanish knighterroom_day2_548cf697:

    # mc "O-Oh... alright."
    mc "O-Oh... de acuerdo."

# game/day2 choice.rpy:2537
translate Spanish knighterroom_day2_990635b5:

    # "As awkward as it was, I took Knighter's hand and shook it politely."
    "Aunque fue incómodo, tomé la mano de Knighter y la estreché con cortesía."

# game/day2 choice.rpy:2542
translate Spanish knighterroom_day2_26366a17:

    # jes "Alright, alright~ That's enough hand-holding."
    jes "Bien, bien~ Ya basta de tomarse de las manos."

# game/day2 choice.rpy:2543
translate Spanish knighterroom_day2_a7468ab5:

    # mc "...Okay?"
    mc "...¿Ok?"

# game/day2 choice.rpy:2545
translate Spanish knighterroom_day2_fa8d50d4:

    # "After a few moments, I let go of Knighter's hand."
    "Tras unos momentos, solté la mano de Knighter."

# game/day2 choice.rpy:2550
translate Spanish knighterroom_day2_88056451:

    # jes "......"
    jes "......"

# game/day2 choice.rpy:2551
translate Spanish knighterroom_day2_167aac6b:

    # jes "Well? Why are you so quiet, Knighter? Introduce yourself. What's your name?"
    jes "¿Y bien? ¿Por qué estás tan callado, Knighter? Preséntate. ¿Cómo te llamas?"

# game/day2 choice.rpy:2555
translate Spanish knighterroom_day2_ac995697:

    # kni "...Ugh... Knighter."
    kni "...Ugh... Knighter."

# game/day2 choice.rpy:2559
translate Spanish knighterroom_day2_a612670b:

    # jes "Knighter who~?"
    jes "¿Knighter qué~?"

# game/day2 choice.rpy:2563
translate Spanish knighterroom_day2_b1aa97df:

    # kni "...Knighter. The Knight Puppet."
    kni "...Knighter. La Marioneta Caballero."

# game/day2 choice.rpy:2565
translate Spanish knighterroom_day2_ebf20b17:

    # "...For some reason, the whole situation was so ridiculous that I had to fight back a laugh."
    "...Por alguna razón, toda la situación era tan ridícula que tuve que contener una risa."

# game/day2 choice.rpy:2567
translate Spanish knighterroom_day2_ba58734e:

    # mc "Ehe- I mean... it's nice to meet you, Knighter. I'm [player_call]..."
    mc "Ehe- Quiero decir... un gusto conocerte, Knighter. Soy [player_call]..."

# game/day2 choice.rpy:2568
translate Spanish knighterroom_day2_a68feebe:

    # jes "[player_call] who, Your Majesty~?"
    jes "¿[player_call] qué, Majestad~?"

# game/day2 choice.rpy:2569
translate Spanish knighterroom_day2_061b90e0:

    # mc "...[player_call], the new [title] of the Kingdom of Marionettes..."
    mc "...[player_call], nuev[letra] [title!t] del Reino de las Marionetas..."

# game/day2 choice.rpy:2572
translate Spanish knighterroom_day2_b15fb18a:

    # "Jestyn nodded in satisfaction before finally letting go of Knighter's arm."
    "Jestyn asintió satisfecho antes de soltar por fin el brazo de Knighter."

# game/day2 choice.rpy:2574
translate Spanish knighterroom_day2_ee218239:

    # jes "There we go~ Now you've both been properly introduced."
    jes "Listo~ Ahora ya se han presentado como es debido."

# game/day2 choice.rpy:2577
translate Spanish knighterroom_day2_23bbe727:

    # "Jestyn brought over two chairs and placed them side by side."
    "Jestyn trajo dos sillas y las colocó una al lado de la otra."

# game/day2 choice.rpy:2580
translate Spanish knighterroom_day2_93ae96c7:

    # jes "You two, have a seat right here~"
    jes "Ustedes dos, siéntense aquí~"

# game/day2 choice.rpy:2582
translate Spanish knighterroom_day2_03f176e9:

    # "To my surprise, Knighter actually obeyed, though not without grumbling under his breath."
    "Para mi sorpresa, Knighter obedeció, aunque no sin rezongar entre dientes."

# game/day2 choice.rpy:2583
translate Spanish knighterroom_day2_26e0e0e0:

    # "I hesitantly walked over and took the seat right beside Knighter."
    "Me acerqué con duda y tomé el asiento justo al lado de Knighter."

# game/day2 choice.rpy:2586
translate Spanish knighterroom_day2_9113d194:

    # jes ".........."
    jes ".........."

# game/day2 choice.rpy:2589
translate Spanish knighterroom_day2_b8935dac:

    # "Jestyn suddenly slid my chair a little farther away from Knighter."
    "Jestyn alejó de pronto mi silla un poco de Knighter."

# game/day2 choice.rpy:2591
translate Spanish knighterroom_day2_2d6c5484:

    # jes "There we go~ Please, have a seat, Your Grace~"
    jes "Listo~ Por favor, tome asiento, Su Gracia~"

# game/day2 choice.rpy:2594
translate Spanish knighterroom_day2_56489ab3:

    # "What's gotten into him...?"
    "¿Qué le pasa...?"

# game/day2 choice.rpy:2595
translate Spanish knighterroom_day2_1005e160:

    # "I sat down and tried to make myself comfortable."
    "Me senté e intenté ponerme cómod[letra]."

# game/day2 choice.rpy:2596
translate Spanish knighterroom_day2_d0e6c395:

    # "Knighter also took the seat beside me."
    "Knighter también tomó asiento a mi lado."

# game/day2 choice.rpy:2597
translate Spanish knighterroom_day2_fe11f44a:

    # "As soon as he sat down, he opened his book and started reading."
    "En cuanto se sentó, abrió su libro y empezó a leer."

# game/day2 choice.rpy:2601
translate Spanish knighterroom_day2_0fd4d656_1:

    # "......"
    "......"

# game/day2 choice.rpy:2602
translate Spanish knighterroom_day2_0dbafab4:

    # "Even after all that, the atmosphere was still painfully awkward. Knighter didn't even try to start a conversation."
    "Incluso después de todo eso, el ambiente seguía siendo dolorosamente incómodo. Knighter ni siquiera intentó iniciar una conversación."

# game/day2 choice.rpy:2603
translate Spanish knighterroom_day2_67457082:

    # "I couldn't really blame him. He didn't like me one bit."
    "No podía culparlo. No le caía bien en absoluto."

# game/day2 choice.rpy:2604
translate Spanish knighterroom_day2_248dfeb9:

    # "In the end, I decided to take a look around Knighter's room."
    "Al final, decidí echar un vistazo a la habitación de Knighter."

# game/day2 choice.rpy:2605
translate Spanish knighterroom_day2_53a90d93:

    # "Knighter's room was pretty simple with not so much objects."
    "La habitación de Knighter era bastante sencilla, sin demasiados objetos."

# game/day2 choice.rpy:2646
translate Spanish examine_decoration_45062126:

    # "My eyes wandered to the walls of the room."
    "Mis ojos recorrieron las paredes de la habitación."

# game/day2 choice.rpy:2647
translate Spanish examine_decoration_bad17770:

    # "Several decorations were displayed there, though most of them were shields."
    "Había varias decoraciones expuestas, aunque la mayoría eran escudos."

# game/day2 choice.rpy:2648
translate Spanish examine_decoration_c97233eb:

    # "There were several shields mounted on the walls, each with a different shape and design."
    "Había varios escudos montados en las paredes, cada uno con una forma y un diseño distintos."

# game/day2 choice.rpy:2649
translate Spanish examine_decoration_0da080f1:

    # "I couldn't help but wonder if they were real shields or just decorative pieces."
    "No pude evitar preguntarme si eran escudos de verdad o simples piezas decorativas."

# game/day2 choice.rpy:2650
translate Spanish examine_decoration_53b80113:

    # "But then again... would a puppet even need real shields? Even if they were used for a theater performance."
    "Pero, pensándolo bien... ¿necesitaría una marioneta escudos de verdad? Aunque se usaran para una función de teatro."

# game/day2 choice.rpy:2654
translate Spanish examine_book_63f09cad:

    # "My eyes drifted toward the bookshelf beside the desk."
    "Mis ojos se desviaron hacia la estantería junto al escritorio."

# game/day2 choice.rpy:2655
translate Spanish examine_book_636848fc:

    # "It wasn't very large, but it was packed with books."
    "No era muy grande, pero estaba repleta de libros."

# game/day2 choice.rpy:2656
translate Spanish examine_book_3954a9aa:

    # "Just from looking at it, I could already tell Knighter was quite the bookworm."
    "Solo con mirarla, ya pude notar que Knighter era todo un ratón de biblioteca."

# game/day2 choice.rpy:2657
translate Spanish examine_book_bbd70bf5:

    # "I leaned in a little, trying to get a better look at the kinds of books he liked to read."
    "Me incliné un poco, intentando ver mejor qué tipo de libros le gustaba leer."

# game/day2 choice.rpy:2658
translate Spanish examine_book_bf7daecf:

    # "Even from where I stood, I recognized a few novels I had read or at least seen before."
    "Incluso desde donde estaba, reconocí algunas novelas que había leído o al menos visto antes."

# game/day2 choice.rpy:2659
translate Spanish examine_book_07e8f98b:

    # "I also noticed plenty of other novels lining the shelves... and most of them were romance."
    "También noté muchas otras novelas alineadas en los estantes... y la mayoría eran románticas."

# game/day2 choice.rpy:2660
translate Spanish examine_book_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:2661
translate Spanish examine_book_e2f59dc8:

    # "So... Knighter likes reading romance novels...?"
    "Así que... ¿a Knighter le gusta leer novelas románticas...?"

# game/day2 choice.rpy:2662
translate Spanish examine_book_e25ebe3f:

    # "I definitely wasn't expecting that."
    "Definitivamente no esperaba eso."

# game/day2 choice.rpy:2663
translate Spanish examine_book_4fa2275b:

    # "But I had seen this kind of character before in manga and other fictional stories."
    "Pero ya había visto este tipo de personaje en mangas y otras historias de ficción."

# game/day2 choice.rpy:2664
translate Spanish examine_book_1ed36a42:

    # "The type who looks tough on the outside but secretly has a soft spot for sweet, romantic things."
    "El tipo que parece duro por fuera pero en secreto tiene debilidad por las cosas dulces y románticas."

# game/day2 choice.rpy:2668
translate Spanish examine_table1_d052cd2b:

    # "My eyes settled on the desk tucked away in the corner of the room."
    "Mis ojos se posaron en el escritorio ubicado en un rincón de la habitación."

# game/day2 choice.rpy:2669
translate Spanish examine_table1_c36bf71b:

    # "It was covered with stacks of books, which I assumed were novels he had recently been reading."
    "Estaba cubierto de pilas de libros, que supuse que eran novelas que había estado leyendo recientemente."

# game/day2 choice.rpy:2670
translate Spanish examine_table1_f1b80178:

    # "There were also a few sheets of paper, a pen, and various other writing supplies scattered across the desk."
    "También había unas cuantas hojas de papel, una pluma y varios otros útiles de escritura esparcidos por el escritorio."

# game/day2 choice.rpy:2674
translate Spanish examine_table2_b656c4b1:

    # "My gaze returned to the desk."
    "Mi mirada volvió al escritorio."

# game/day2 choice.rpy:2675
translate Spanish examine_table2_545b3a9d:

    # "I took another look at the things scattered across its surface."
    "Volví a mirar las cosas esparcidas sobre su superficie."

# game/day2 choice.rpy:2676
translate Spanish examine_table2_034a099b:

    # "That's when I noticed a photograph sitting on it."
    "Fue entonces cuando noté una fotografía sobre él."

# game/day2 choice.rpy:2677
translate Spanish examine_table2_59055fec:

    # "It was a group photo, filled with people."
    "Era una foto grupal, llena de gente."

# game/day2 choice.rpy:2686
translate Spanish examine_table3_d64d0fe7:

    # "My curiosity got the better of me, and my eyes drifted back to the photograph on the desk."
    "La curiosidad pudo conmigo y mis ojos volvieron a la fotografía del escritorio."

# game/day2 choice.rpy:2687
translate Spanish examine_table3_66970987:

    # "This time, I took a closer look."
    "Esta vez, la miré más de cerca."

# game/day2 choice.rpy:2688
translate Spanish examine_table3_f47ab522:

    # "In the photo, all of the puppets were gathered together for a group picture."
    "En la foto, todas las marionetas estaban reunidas para una fotografía grupal."

# game/day2 choice.rpy:2689
translate Spanish examine_table3_a3eeba86:

    # "Judging by its black-and-white colors alone, the photograph seemed quite old."
    "A juzgar solo por sus colores en blanco y negro, la fotografía parecía bastante antigua."

# game/day2 choice.rpy:2690
translate Spanish examine_table3_fe4d8954:

    # "The one standing in the center..."
    "El que estaba de pie en el centro..."

# game/day2 choice.rpy:2691
translate Spanish examine_table3_8c4b6c26:

    # "Is that Cro-"
    "¿Es ese Cro-"

# game/day2 choice.rpy:2700
translate Spanish knighter_convo2_d3a4bd5f:

    # jes "Are you two seriously just going to sit here in awkward silence?"
    jes "¿De verdad van a quedarse sentados aquí en un incómodo silencio los dos?"

# game/day2 choice.rpy:2703
translate Spanish knighter_convo2_acd6819e:

    # "Jestyn's voice finally broke the silence."
    "La voz de Jestyn por fin rompió el silencio."

# game/day2 choice.rpy:2707
translate Spanish knighter_convo2_9df524b3:

    # kni "I already told you I don't have time for this."
    kni "Ya te dije que no tengo tiempo para esto."

# game/day2 choice.rpy:2709
translate Spanish knighter_convo2_fcdf1b72:

    # jes "Oh? When exactly did you say that?"
    jes "¿Oh? ¿Cuándo exactamente dijiste eso?"

# game/day2 choice.rpy:2710
translate Spanish knighter_convo2_7b06149e:

    # kni "Before you two barged in and ruined everything."
    kni "Antes de que ustedes dos irrumpieran y lo arruinaran todo."

# game/day2 choice.rpy:2711
translate Spanish knighter_convo2_e40eb66b:

    # jes "All you said was, 'Leave.'"
    jes "Todo lo que dijiste fue: 'Largo'."

# game/day2 choice.rpy:2712
translate Spanish knighter_convo2_416efdc6:

    # kni "Yeah. Because I was busy."
    kni "Sí. Porque estaba ocupado."

# game/day2 choice.rpy:2714
translate Spanish knighter_convo2_50f51804:

    # jes "Busy reading those roma-"
    jes "Ocupado leyendo esas roma-"

# game/day2 choice.rpy:2718
translate Spanish knighter_convo2_1b79d81b:

    # kni "S-SHUT UP!!"
    kni "¡¡C-CÁLLATE!!"

# game/day2 choice.rpy:2720
translate Spanish knighter_convo2_f78ea502:

    # "Knighter's face instantly turned bright red as Jestyn was about to bring up about something."
    "El rostro de Knighter se puso rojo brillante al instante cuando Jestyn estaba a punto de sacar algo a relucir."

# game/day2 choice.rpy:2723
translate Spanish knighter_convo2_90196bb1:

    # jes "Well?"
    jes "¿Y bien?"

# game/day2 choice.rpy:2724
translate Spanish knighter_convo2_13e56374:

    # kni "......."
    kni "......."

# game/day2 choice.rpy:2726
translate Spanish knighter_convo2_78e69c64:

    # kni "Tsk... Fine. I'll talk to this human."
    kni "Tsk... Está bien. Hablaré con esta persona."

# game/day2 choice.rpy:2729
translate Spanish knighter_convo2_462d8dfb:

    # kni "So... what did you want to talk about?"
    kni "Entonces... ¿de qué querías hablar?"

# game/day2 choice.rpy:2733
translate Spanish knighter_convo2_0ff8b9ed:

    # "Knighter finally spoke to me, though his focus never left the book in his hands."
    "Knighter por fin me habló, aunque su atención nunca se apartó del libro que tenía en las manos."

# game/day2 choice.rpy:2761
translate Spanish freetime_knighter_158eace9:

    # "Maybe it wouldn't hurt to ask what he usually does in his free time..."
    "Quizá no estaría de más preguntarle qué suele hacer en su tiempo libre..."

# game/day2 choice.rpy:2763
translate Spanish freetime_knighter_ae50c239:

    # mc "So... if you don't mind me asking, what do you usually do in your free time?"
    mc "Entonces... si no te molesta que pregunte, ¿qué sueles hacer en tu tiempo libre?"

# game/day2 choice.rpy:2765
translate Spanish freetime_knighter_6a3ad66d:

    # kni "Read."
    kni "Leer."

# game/day2 choice.rpy:2767
translate Spanish freetime_knighter_665deb70:

    # mc "Oh... Reading."
    mc "Oh... Leer."

# game/day2 choice.rpy:2768
translate Spanish freetime_knighter_182848b6:

    # mc "That's... nice."
    mc "Qué... bien."

# game/day2 choice.rpy:2769
translate Spanish freetime_knighter_dddb6f7e:

    # mc "........."
    mc "........."

# game/day2 choice.rpy:2770
translate Spanish freetime_knighter_13e56374:

    # kni "......."
    kni "......."

# game/day2 choice.rpy:2772
translate Spanish freetime_knighter_4f151258:

    # "And... that's it?!"
    "¡¿Y... eso es todo?!"

# game/day2 choice.rpy:2773
translate Spanish freetime_knighter_706d8ec8:

    # "Knighter wasn't even trying to keep the conversation going."
    "Knighter ni siquiera intentaba mantener viva la conversación."

# game/day2 choice.rpy:2775
translate Spanish freetime_knighter_92f03fab:

    # jes "Sir Knighter, the honorable knight~ A proper conversation usually involves AT LEAST making an effort to keep it going."
    jes "Sir Knighter, el honorable caballero~ Una conversación como es debido suele implicar AL MENOS un esfuerzo por mantenerla."

# game/day2 choice.rpy:2776
translate Spanish freetime_knighter_7c44d4c0:

    # jes "What kind of conversation was that? It was so short; almost as short as your manners~"
    jes "¿Qué clase de conversación fue esa? Fue tan corta; casi tan corta como tus modales~"

# game/day2 choice.rpy:2779
translate Spanish freetime_knighter_be5bd0ce:

    # "Knighter's irritated expression deepened for a moment before he let out a quiet sigh and decided not to argue with Jestyn any further."
    "La expresión irritada de Knighter se acentuó un momento antes de que soltara un suspiro silencioso y decidiera no discutir más con Jestyn."

# game/day2 choice.rpy:2780
translate Spanish freetime_knighter_6a5acd9a:

    # "He knew better than anyone that arguing with the royal jester was nothing but a waste of time."
    "Sabía mejor que nadie que discutir con el bufón real no era más que una pérdida de tiempo."

# game/day2 choice.rpy:2783
translate Spanish freetime_knighter_093e0668:

    # kni "...I don't do much in my free time."
    kni "...No hago mucho en mi tiempo libre."

# game/day2 choice.rpy:2784
translate Spanish freetime_knighter_b508fb2c:

    # kni "I read, clean my sword, and tidy my room."
    kni "Leo, limpio mi espada y ordeno mi habitación."

# game/day2 choice.rpy:2787
translate Spanish freetime_knighter_be054849:

    # "I found myself growing curious about his daily routine."
    "Me encontré sintiendo curiosidad por su rutina diaria."

# game/day2 choice.rpy:2788
translate Spanish freetime_knighter_44a1b71f:

    # "Clean his sword. Tidy his room..."
    "Limpiar su espada. Ordenar su habitación..."

# game/day2 choice.rpy:2789
translate Spanish freetime_knighter_cdbb4bdf:

    # "Knighter really was a disciplined person. Even his room was spotless and neatly organized. It suited him perfectly."
    "Knighter de verdad era una persona disciplinada. Incluso su habitación estaba impecable y bien organizada. Le quedaba perfecto."

# game/day2 choice.rpy:2790
translate Spanish freetime_knighter_1e25770d:

    # "Seeing how clean and orderly his room was reminded me of my own apartment."
    "Ver lo limpia y ordenada que estaba su habitación me recordó a mi propio apartamento."

# game/day2 choice.rpy:2791
translate Spanish freetime_knighter_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:2792
translate Spanish freetime_knighter_ca19e688:

    # "Unlike Knighter's room, my apartment was... pretty messy."
    "A diferencia de la habitación de Knighter, mi apartamento era... bastante desordenado."

# game/day2 choice.rpy:2793
translate Spanish freetime_knighter_95a95f00:

    # "Actually, 'pretty messy' might be an understatement. When was the last time I cleaned it...? Now I was kind of embarrassed."
    "En realidad, 'bastante desordenado' quizá se quedaba corto. ¿Cuándo fue la última vez que lo limpié...? Ahora me daba algo de vergüenza."

# game/day2 choice.rpy:2795
translate Spanish freetime_knighter_f1b2fc80:

    # mc "Mmm... You like keeping things clean. That's amazing."
    mc "Mmm... Te gusta mantener todo limpio. Es increíble."

# game/day2 choice.rpy:2796
translate Spanish freetime_knighter_b2b4f26a:

    # mc "I mean, cleanliness is important."
    mc "Es decir, la limpieza es importante."

# game/day2 choice.rpy:2798
translate Spanish freetime_knighter_c14ef53f:

    # "Knighter didn't respond. He simply kept reading his book."
    "Knighter no respondió. Simplemente siguió leyendo su libro."

# game/day2 choice.rpy:2799
translate Spanish freetime_knighter_f5c8c7bb:

    # "Dear God... what was I supposed to talk to him about?"
    "Dios mío... ¿de qué se suponía que iba a hablarle?"

# game/day2 choice.rpy:2800
translate Spanish freetime_knighter_c18517d6:

    # "My eyes wandered around the room, searching for something, anything, that could become a conversation topic."
    "Mis ojos vagaron por la habitación, buscando algo, lo que fuera, que pudiera convertirse en tema de conversación."

# game/day2 choice.rpy:2801
translate Spanish freetime_knighter_3c6f41a4:

    # "Or at least something interesting enough to bring up."
    "O al menos algo lo bastante interesante como para sacarlo."

# game/day2 choice.rpy:2802
translate Spanish freetime_knighter_28cb245e:

    # "Then my gaze landed on the book he was reading."
    "Entonces mi mirada cayó sobre el libro que estaba leyendo."

# game/day2 choice.rpy:2803
translate Spanish freetime_knighter_9ef4a17d:

    # "Tyrant of Love*... Oh, I thought I'd heard of that one."
    "Tirano del amor*... Oh, me sonaba haberlo oído."

# game/day2 choice.rpy:2804
translate Spanish freetime_knighter_5af9081f:

    # "It's a novel about a CEO who'll stop at nothing to win the protagonist's heart."
    "Es una novela sobre un director ejecutivo que haría cualquier cosa por ganarse el corazón de la protagonista."

# game/day2 choice.rpy:2805
translate Spanish freetime_knighter_fe43fbd2:

    # "Honestly... if I was being truthful, the story was a little cheesy."
    "Sinceramente... si era sincer[letra], la historia era un poco cursi."

# game/day2 choice.rpy:2806
translate Spanish freetime_knighter_cb5d63c7:

    # "But Knighter seemed to be enjoying it. He looked completely absorbed in it."
    "Pero Knighter parecía estar disfrutándola. Se veía completamente absorto."

# game/day2 choice.rpy:2807
translate Spanish freetime_knighter_e28b5973:

    # "He really does enjoy cheesy romance stories... Maybe I could use that to keep the conversation going."
    "De verdad disfruta las historias románticas cursis... Quizá podría aprovecharlo para mantener la conversación."

# game/day2 choice.rpy:2809
translate Spanish freetime_knighter_53a212e4:

    # mc "...Looks like you enjoy reading novels."
    mc "...Parece que disfrutas leyendo novelas."

# game/day2 choice.rpy:2812
translate Spanish freetime_knighter_4bd86376:

    # "The moment I mentioned novels, his eyes immediately flicked toward me."
    "En cuanto mencioné las novelas, sus ojos se dirigieron de inmediato hacia mí."

# game/day2 choice.rpy:2813
translate Spanish freetime_knighter_16edec0d:

    # "After all this time, it was the first time he'd actually looked at me."
    "Después de todo este tiempo, era la primera vez que realmente me miraba."

# game/day2 choice.rpy:2814
translate Spanish freetime_knighter_73dc262d:

    # "Jackpot."
    "Premio gordo."

# game/day2 choice.rpy:2816
translate Spanish freetime_knighter_13e56374_1:

    # kni "......."
    kni "......."

# game/day2 choice.rpy:2818
translate Spanish freetime_knighter_12a9bc94:

    # kni "...What makes you think that? You can't just assume I like novels because I'm reading one right now."
    kni "...¿Qué te hace pensar eso? No puedes suponer que me gustan las novelas solo porque ahora mismo estoy leyendo una."

# game/day2 choice.rpy:2819
translate Spanish freetime_knighter_5a0e84e2:

    # mc "Because I noticed all the novels on your bookshelf."
    mc "Porque noté todas las novelas de tu estantería."

# game/day2 choice.rpy:2822
translate Spanish freetime_knighter_d650590c:

    # "Knighter froze, his gaze slowly shifting toward the shelves lined with his collection."
    "Knighter se quedó helado, y su mirada se desvió lentamente hacia los estantes repletos de su colección."

# game/day2 choice.rpy:2824
translate Spanish freetime_knighter_b50a43e7:

    # kni "...You can tell they're all novels...?"
    kni "...¿Puedes saber que todas son novelas...?"

# game/day2 choice.rpy:2825
translate Spanish freetime_knighter_3a0c3ef6:

    # mc "Most of them, yeah. I've read a few of them myself."
    mc "La mayoría, sí. Yo mism[letra] he leído algunas."

# game/day2 choice.rpy:2826
translate Spanish freetime_knighter_ecc09d04:

    # mc "And I know they're all romance novels... including the one you're reading right now."
    mc "Y sé que todas son novelas románticas... incluida la que estás leyendo ahora."

# game/day2 choice.rpy:2831
translate Spanish freetime_knighter_2f88d8e3:

    # "Knighter immediately snapped his book shut and hid it behind his back."
    "Knighter cerró de golpe su libro y lo escondió detrás de la espalda."

# game/day2 choice.rpy:2833
translate Spanish freetime_knighter_ab24314b:

    # "His face turned bright red in an instant."
    "Su rostro se puso rojo brillante en un instante."

# game/day2 choice.rpy:2834
translate Spanish freetime_knighter_1fbbe91c:

    # "Wait... Don't tell me he's actually embarrassed because he reads romance novels...?"
    "Espera... ¿No me digas que en realidad le da vergüenza leer novelas románticas...?"

# game/day2 choice.rpy:2836
translate Spanish freetime_knighter_f0832d8d:

    # mc "H-Hey, it's not a bad thi-"
    mc "E-Eh, no es nada mal-"

# game/day2 choice.rpy:2837
translate Spanish freetime_knighter_1d62fbd0:

    # kni "Quiet."
    kni "Silencio."

# game/day2 choice.rpy:2838
translate Spanish freetime_knighter_30015f89:

    # kni "Don't bother trying to make me feel better..."
    kni "No te molestes en intentar hacerme sentir mejor..."

# game/day2 choice.rpy:2839
translate Spanish freetime_knighter_f252a802:

    # mc "...Okay..."
    mc "...Está bien..."

# game/day2 choice.rpy:2842
translate Spanish freetime_knighter_d499cf7a:

    # mc "............"
    mc "............"

# game/day2 choice.rpy:2843
translate Spanish freetime_knighter_9a151148:

    # mc "Soooo... who are you rooting for in the novel you're reading?"
    mc "Entooonces... ¿por quién vas en la novela que estás leyendo?"

# game/day2 choice.rpy:2845
translate Spanish freetime_knighter_3d93d6da:

    # "Since I've read the novel, I decided to steer the conversation toward the story itself, hoping he'd feel a little more comfortable talking about it."
    "Como había leído la novela, decidí orientar la conversación hacia la historia misma, con la esperanza de que se sintiera un poco más cómodo hablando de ella."

# game/day2 choice.rpy:2847
translate Spanish freetime_knighter_175346e0:

    # kni ".........."
    kni ".........."

# game/day2 choice.rpy:2848
translate Spanish freetime_knighter_22381e3d:

    # kni "...Edward. The second love interest."
    kni "...Edward. El segundo interés amoroso."

# game/day2 choice.rpy:2850
translate Spanish freetime_knighter_95a6dcf0:

    # "He answered my question, which I took as a green light to keep the conversation going."
    "Respondió a mi pregunta, lo cual tomé como luz verde para seguir con la conversación."

# game/day2 choice.rpy:2851
translate Spanish freetime_knighter_83162900:

    # "In the novel, the protagonist was caught between two men: Jacob, the wealthy CEO and the story's main love interest, and Edward, the protagonist's childhood friend and the second love interest."
    "En la novela, la protagonista estaba atrapada entre dos hombres: Jacob, el rico director ejecutivo e interés amoroso principal de la historia, y Edward, el amigo de la infancia de la protagonista y segundo interés amoroso."

# game/day2 choice.rpy:2852
translate Spanish freetime_knighter_d96e8464:

    # "Jacob was obsessively in love with the protagonist and will stop at nothing to get rid of Edward. He constantly convinced the protagonist that Edward wasn't a good man..."
    "Jacob estaba obsesivamente enamorado de la protagonista y haría cualquier cosa por deshacerse de Edward. Convencía constantemente a la protagonista de que Edward no era un buen hombre..."

# game/day2 choice.rpy:2853
translate Spanish freetime_knighter_11729f23:

    # "...claiming that driving a wedge between them was for the protagonist's own good."
    "...alegando que interponerse entre ellos era por el propio bien de la protagonista."

# game/day2 choice.rpy:2854
translate Spanish freetime_knighter_da019c9a:

    # "He did all of it in the name of winning the protagonist's heart."
    "Todo lo hacía en nombre de ganarse el corazón de la protagonista."

# game/day2 choice.rpy:2855
translate Spanish freetime_knighter_c2f906c7:

    # "Of course, anyone in their right mind could tell that Jacob was completely the wrong one."
    "Por supuesto, cualquiera en su sano juicio podía darse cuenta de que Jacob era completamente el equivocado."

# game/day2 choice.rpy:2857
translate Spanish freetime_knighter_75174d1f:

    # mc "Right? I thought so too. I mean... Jacob is insane."
    mc "¿Verdad? Yo también lo pensé. Es decir... Jacob está loco."

# game/day2 choice.rpy:2858
translate Spanish freetime_knighter_8e932ae4:

    # mc "He keeps painting Edward as the villain and drives a wedge between him and the protagonist."
    mc "Sigue pintando a Edward como el villano y se interpone entre él y la protagonista."

# game/day2 choice.rpy:2861
translate Spanish freetime_knighter_7d7616db:

    # "Knighter nodded in agreement."
    "Knighter asintió, de acuerdo."

# game/day2 choice.rpy:2863
translate Spanish freetime_knighter_5eb93f6e:

    # kni "Exactly... anyone with half a brain can see how despicable that is."
    kni "Exacto... cualquiera con medio cerebro ve lo despreciable que es eso."

# game/day2 choice.rpy:2864
translate Spanish freetime_knighter_4d755885:

    # kni "What irritates me the most is how Jacob abuses his position as the company's CEO to frame Edward for embezzling company funds."
    kni "Lo que más me irrita es cómo Jacob abusa de su puesto de director ejecutivo de la empresa para incriminar a Edward por malversar fondos de la compañía."

# game/day2 choice.rpy:2866
translate Spanish freetime_knighter_039dfe02:

    # kni "He doesn't just try to convince the protagonist. He manipulates everyone around them as well, making sure the majority is on his side."
    kni "No solo intenta convencer a la protagonista. También manipula a todos los que los rodean, asegurándose de que la mayoría esté de su lado."

# game/day2 choice.rpy:2867
translate Spanish freetime_knighter_bc367ba1:

    # kni "Absolute scum."
    kni "Escoria absoluta."

# game/day2 choice.rpy:2869
translate Spanish freetime_knighter_0bc6d51d:

    # "I was taken aback by the anger in Knighter's voice. He was far more invested in the story than I had expected."
    "Me sorprendió la ira en la voz de Knighter. Estaba mucho más metido en la historia de lo que esperaba."

# game/day2 choice.rpy:2871
translate Spanish freetime_knighter_fce10b64:

    # mc "Yeah... and the saddest part is that everyone believes him. Even the protagonist falls for his lies, and Edward ends up completely isolated."
    mc "Sí... y lo más triste es que todos le creen. Incluso la protagonista cae en sus mentiras, y Edward termina completamente aislado."

# game/day2 choice.rpy:2872
translate Spanish freetime_knighter_1c922810:

    # mc "Poor guy..."
    mc "Pobre tipo..."

# game/day2 choice.rpy:2873
translate Spanish freetime_knighter_4f2ccbe0:

    # mc "But I'm kind of curious... Do you think Jacob is really in the wrong? There are actually people who like his obsessive personality and say he's incredibly loyal and sweet to the protagonist."
    mc "Pero tengo curiosidad... ¿Crees que Jacob está realmente equivocado? Hay gente a la que le gusta su personalidad obsesiva y dice que es increíblemente leal y dulce con la protagonista."

# game/day2 choice.rpy:2877
translate Spanish freetime_knighter_89b7d1e0:

    # "Knighter let out a heavy sigh."
    "Knighter soltó un pesado suspiro."

# game/day2 choice.rpy:2879
translate Spanish freetime_knighter_280db018:

    # kni "Whether it's fiction or reality, that kind of behavior is dangerous."
    kni "Ya sea en la ficción o en la realidad, ese tipo de comportamiento es peligroso."

# game/day2 choice.rpy:2881
translate Spanish freetime_knighter_49058b4a:

    # kni "He manipulates people, abuses the authority he has over Edward, and he's obsessively possessive. There's nothing admirable about him."
    kni "Manipula a la gente, abusa de la autoridad que tiene sobre Edward y es obsesivamente posesivo. No hay nada admirable en él."

# game/day2 choice.rpy:2882
translate Spanish freetime_knighter_3c1e058b:

    # kni "Even if he's loyal and acts sweet toward the protagonist, that doesn't erase all the terrible things he's done to get what he wants."
    kni "Incluso si es leal y se muestra dulce con la protagonista, eso no borra todas las cosas terribles que ha hecho para conseguir lo que quiere."

# game/day2 choice.rpy:2883
translate Spanish freetime_knighter_5dab6b9b:

    # kni "So yes... I think Jacob is wrong."
    kni "Así que sí... creo que Jacob está equivocado."

# game/day2 choice.rpy:2887
translate Spanish freetime_knighter_06ef6322:

    # "Knighter seemed to regain his composure and went back to reading his novel."
    "Knighter pareció recuperar la compostura y volvió a su novela."

# game/day2 choice.rpy:2888
translate Spanish freetime_knighter_f6eb4270:

    # "So he can actually be pretty talkative under the right circumstances... Talking to Knighter isn't so bad after all."
    "Así que en realidad puede ser bastante conversador en las circunstancias adecuadas... Hablar con Knighter no es tan malo después de todo."

# game/day2 choice.rpy:2890
translate Spanish freetime_knighter_68c96643:

    # mc "Haha. You're actually pretty fun to talk to."
    mc "Jaja. En realidad eres bastante divertido para hablar."

# game/day2 choice.rpy:2895
translate Spanish freetime_knighter_53d5dc74:

    # "His eyes widened for a split second before he quickly looked away."
    "Sus ojos se abrieron un instante antes de que apartara rápidamente la mirada."

# game/day2 choice.rpy:2896
translate Spanish freetime_knighter_925ab8df:

    # "Even so, I could still see a faint blush creeping across his cheeks."
    "Aun así, todavía podía ver un leve rubor asomando en sus mejillas."

# game/day2 choice.rpy:2898
translate Spanish freetime_knighter_eced440c:

    # kni ".... I don't need your compliments."
    kni ".... No necesito tus halagos."

# game/day2 choice.rpy:2903
translate Spanish compliment_knighter_d5c03483:

    # "I'd been looking at Knighter's face for a while now. He really did look like a prince straight out of a fairy tale."
    "Llevaba un rato mirando el rostro de Knighter. De verdad parecía un príncipe sacado de un cuento de hadas."

# game/day2 choice.rpy:2904
translate Spanish compliment_knighter_9b5b42cc:

    # "Most people are happy when someone compliments them... I think."
    "La mayoría de la gente se alegra cuando alguien la halaga... creo."

# game/day2 choice.rpy:2905
translate Spanish compliment_knighter_c7a0b29c:

    # "But what about Knighter?"
    "¿Pero y Knighter?"

# game/day2 choice.rpy:2906
translate Spanish compliment_knighter_f008e350:

    # "Judging by how he's been acting, he seems like the type who couldn't care less."
    "A juzgar por cómo se había estado comportando, parecía de los que no podrían importarle menos."

# game/day2 choice.rpy:2907
translate Spanish compliment_knighter_bc9b1083:

    # "There's a good chance he won't react even if I compliment him."
    "Hay muchas probabilidades de que no reaccione ni aunque lo halague."

# game/day2 choice.rpy:2908
translate Spanish compliment_knighter_bc6d9603:

    # "Still... it wouldn't hurt to try. I'll never know unless I do, right...?"
    "Aun así... no estaría de más intentarlo. No lo sabré a menos que lo haga, ¿verdad...?"

# game/day2 choice.rpy:2909
translate Spanish compliment_knighter_4dcb2c37:

    # "I took a deep breath, trying to steady my nerves. I was actually pretty anxious."
    "Respiré hondo, tratando de calmar los nervios. En realidad estaba bastante ansios[letra]."

# game/day2 choice.rpy:2911
translate Spanish compliment_knighter_93bf6250:

    # mc "You know... I think you're really handsome."
    mc "Sabes... creo que eres muy guapo."

# game/day2 choice.rpy:2914
translate Spanish compliment_knighter_3928a113:

    # "......."
    "......."

# game/day2 choice.rpy:2916
translate Spanish compliment_knighter_1bec4244:

    # "As expected, he looked at me... but instead of seeming indifferent, his face twisted into one of pure disgust."
    "Como era de esperar, me miró... pero en lugar de parecer indiferente, su rostro se torció en una expresión de puro asco."

# game/day2 choice.rpy:2917
translate Spanish compliment_knighter_645c0e06:

    # "Wow... I definitely wasn't expecting that. Now that was a plot twist."
    "Vaya... definitivamente no esperaba eso. Eso sí que fue un giro de trama."

# game/day2 choice.rpy:2918
translate Spanish compliment_knighter_3c02fe68:

    # "Suddenly, I felt a hand rest gently on my shoulder from behind."
    "De repente, sentí una mano posarse suavemente en mi hombro desde atrás."

# game/day2 choice.rpy:2920
translate Spanish compliment_knighter_f7627934:

    # jes "Your Majesty."
    jes "Majestad."

# game/day2 choice.rpy:2922
translate Spanish compliment_knighter_4bd655a1:

    # "Jestyn's voice was so close that his whisper brushed against my ear."
    "La voz de Jestyn estaba tan cerca que su susurro me rozó la oreja."

# game/day2 choice.rpy:2924
translate Spanish compliment_knighter_4c1075a3:

    # jes "Now then... what exactly did you just say to Knighter, hm~?"
    jes "Ahora bien... ¿qué le acaba de decir exactamente a Knighter, hm~?"

# game/day2 choice.rpy:2928
translate Spanish compliment_knighter_2b506eed:

    # "I glanced back at Jestyn standing behind me."
    "Miré hacia atrás, a Jestyn, que estaba de pie detrás de mí."

# game/day2 choice.rpy:2930
translate Spanish compliment_knighter_e13c2a3d:

    # "His expression looked... irritated...?"
    "Su expresión parecía... ¿irritada...?"

# game/day2 choice.rpy:2932
translate Spanish compliment_knighter_3884aab5:

    # mc "W-What? Did I do something wrong?"
    mc "¿Q-qué? ¿Hice algo mal?"

# game/day2 choice.rpy:2934
translate Spanish compliment_knighter_4671f10e:

    # "Jestyn didn't answer. He simply stared at me with a sharp, unreadable gaze."
    "Jestyn no respondió. Simplemente me miró con una mirada afilada e indescifrable."

# game/day2 choice.rpy:2935
translate Spanish compliment_knighter_b5f9205d:

    # "I was only trying to compliment Knighter... Is he upset because of that?"
    "Solo intentaba halagar a Knighter... ¿Está molesto por eso?"

# game/day2 choice.rpy:2936
translate Spanish compliment_knighter_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:2937
translate Spanish compliment_knighter_001db0d9:

    # "Wait... don't tell me..."
    "Espera... no me digas que..."

# game/day2 choice.rpy:2938
translate Spanish compliment_knighter_1f7af9d7:

    # "Knighter and Jestyn..."
    "Knighter y Jestyn..."

# game/day2 choice.rpy:2941
translate Spanish compliment_knighter_b55c208b:

    # "My gaze shifted back to Knighter. He was still wearing that same look of disgust."
    "Mi mirada volvió a Knighter. Seguía con esa misma cara de asco."

# game/day2 choice.rpy:2943
translate Spanish compliment_knighter_d44e7d4f:

    # "His irritated expression instantly shifted into confusion and shock."
    "Su expresión irritada pasó al instante a confusión y conmoción."

# game/day2 choice.rpy:2945
translate Spanish compliment_knighter_0ce78278:

    # kni "What the hell did you just say?"
    kni "¿Qué demonios acabas de decir?"

# game/day2 choice.rpy:2946
translate Spanish compliment_knighter_a54ff068:

    # mc "I was only telling the truth."
    mc "Solo estaba diciendo la verdad."

# game/day2 choice.rpy:2948
translate Spanish compliment_knighter_0696255a:

    # "Honestly, I wasn't sure if saying that was a good idea."
    "Sinceramente, no estaba segur[letra] de que decir eso fuera buena idea."

# game/day2 choice.rpy:2951
translate Spanish compliment_knighter_9daf98fc:

    # kni "There must be something wrong with your head."
    kni "Algo debe de andar mal con tu cabeza."

# game/day2 choice.rpy:2953
translate Spanish compliment_knighter_4cccafe7:

    # "M-maybe if I kept going, I could manage to soften him a little?"
    "¿Q-quizá si seguía, lograría ablandarlo un poco?"

# game/day2 choice.rpy:2955
translate Spanish compliment_knighter_866bc44b:

    # mc "Of course~ Who could possibly resist such a handsome face?"
    mc "Por supuesto~ ¿Quién podría resistirse a un rostro tan apuesto?"

# game/day2 choice.rpy:2956
translate Spanish compliment_knighter_187bdf2d:

    # mc "I'm certain that anyone who lays eyes on you for the first time would be driven completely crazy over you one hundred percent."
    mc "Estoy segur[letra] de que cualquiera que te vea por primera vez perdería la cabeza por ti, al cien por cien."

# game/day2 choice.rpy:2959
translate Spanish compliment_knighter_3928a113_1:

    # "......."
    "......."

# game/day2 choice.rpy:2961
translate Spanish compliment_knighter_2740387a:

    # "His lips slowly curled into a grin."
    "Sus labios se curvaron lentamente en una sonrisa."

# game/day2 choice.rpy:2964
translate Spanish compliment_knighter_d08b20d0:

    # kni "I see... So that's what you're trying to do."
    kni "Ya veo... Así que eso es lo que intentas hacer."

# game/day2 choice.rpy:2965
translate Spanish compliment_knighter_9dc17c6e:

    # kni "Because I'm not someone who trusts easily, you've decided to flirt with me instead."
    kni "Como no soy alguien que confíe fácilmente, has decidido coquetear conmigo."

# game/day2 choice.rpy:2966
translate Spanish compliment_knighter_e17f5205:

    # voice "KNIGHTER04_DAY2.ogg"
    # kni "You compliment my appearance... tell me I'm handsome..."
    voice "KNIGHTER04_DAY2.ogg"
    kni "Elogias mi aspecto... me dices que soy guapo..."

# game/day2 choice.rpy:2969
translate Spanish compliment_knighter_c6ef9da4:

    # voice "KNIGHTER05_DAY2.ogg"
    # kni "All so I'll let my guard down. And once you get close enough, you'll take advantage of me... and manipulate me."
    voice "KNIGHTER05_DAY2.ogg"
    kni "Todo para que baje la guardia. Y cuando te acerques lo suficiente, te aprovecharás de mí... y me manipularás."

# game/day2 choice.rpy:2972
translate Spanish compliment_knighter_4b1d1cb0:

    # "Knighter laid out every one of his suspicions without hesitation."
    "Knighter expuso cada una de sus sospechas sin vacilar."

# game/day2 choice.rpy:2973
translate Spanish compliment_knighter_f64f0ad0:

    # "I never imagined he'd be this distrustful... to the point of thinking I was flirting with him."
    "Jamás imaginé que fuera tan desconfiado... hasta el punto de pensar que yo coqueteaba con él."

# game/day2 choice.rpy:2974
translate Spanish compliment_knighter_79660b28:

    # "This is not how I expected this conversation to go."
    "No era así como esperaba que fuera esta conversación."

# game/day2 choice.rpy:2976
translate Spanish compliment_knighter_0b5ed428:

    # mc "That's not it at all! I genuinely meant that as a compliment!"
    mc "¡Nada de eso! ¡De verdad lo dije como un cumplido!"

# game/day2 choice.rpy:2978
translate Spanish compliment_knighter_56e38707:

    # kni "Heh. In that case you deserve to die."
    kni "Je. En ese caso, mereces morir."

# game/day2 choice.rpy:2980
translate Spanish compliment_knighter_9d469299:

    # "Fuck."
    "Mierda."

# game/day2 choice.rpy:2983
translate Spanish compliment_knighter_70bf53b8:

    # "Jestyn suddenly stepped in front of me and grabbed Knighter's arm, stopping him."
    "Jestyn se interpuso de repente delante de mí y agarró el brazo de Knighter, deteniéndolo."

# game/day2 choice.rpy:2988
translate Spanish compliment_knighter_5e6e9890:

    # kni "Ugh-"
    kni "Ugh-"

# game/day2 choice.rpy:2992
translate Spanish compliment_knighter_64bed749:

    # jes "Knighter... if I hear those words come out of your mouth one more time-"
    jes "Knighter... si vuelvo a oír esas palabras salir de tu boca una sola vez más-"

# game/day2 choice.rpy:2993
translate Spanish compliment_knighter_26a687f6:

    # kni "Why? You can't keep ordering me around."
    kni "¿Por qué? No puedes seguir dándome órdenes."

# game/day2 choice.rpy:2994
translate Spanish compliment_knighter_ed98562a:

    # kni "I'm not a child."
    kni "No soy un niño."

# game/day2 choice.rpy:2995
translate Spanish compliment_knighter_c046640c:

    # jes "Yes, yes, yes~ My honorable Sir Knighter. I don't recall these lovely lips of mine ever saying I thought you were a baby learning how to walk~"
    jes "Sí, sí, sí~ Mi honorable Sir Knighter. No recuerdo que estos encantadores labios míos hayan dicho jamás que te creía un bebé aprendiendo a caminar~"

# game/day2 choice.rpy:2996
translate Spanish compliment_knighter_ac041092:

    # jes "In fact! Even a baby is easier to deal with. Right now, you're nothing more than a stray dog abandoned by its owner. How tragic~"
    jes "¡De hecho! Hasta un bebé es más fácil de tratar. Ahora mismo no eres más que un perro callejero abandonado por su dueño. Qué trágico~"

# game/day2 choice.rpy:3003
translate Spanish compliment_knighter_6f2a7f89:

    # "His anger finally boiling over, Knighter grabbed Jestyn by the collar."
    "Con su ira por fin desbordada, Knighter agarró a Jestyn del cuello de la ropa."

# game/day2 choice.rpy:3006
translate Spanish compliment_knighter_a13700f3:

    # "The two locked eyes, glaring at each other."
    "Los dos se miraron a los ojos, fulminándose."

# game/day2 choice.rpy:3008
translate Spanish compliment_knighter_4597b41d:

    # kni "Say that to my face one more time."
    kni "Dímelo a la cara una vez más."

# game/day2 choice.rpy:3010
translate Spanish compliment_knighter_bf798866:

    # jes "Hahahaha~! I'm the Jester Puppet, darling. These lips speak only the sweet taste of truth. Not the bitter, sour flavor of lies and deceit."
    jes "¡Jajajaja~! Soy la Marioneta Bufón, querido. Estos labios solo pronuncian el dulce sabor de la verdad. No el amargo y agrio sabor de la mentira y el engaño."

# game/day2 choice.rpy:3011
translate Spanish compliment_knighter_bffd084e:

    # jes "And if I were to offer you another taste of that sweetness... what then? Do you want to relive those WOOOOONDERFUL old days, hm~?"
    jes "Y si te ofreciera otro bocado de esa dulzura... ¿entonces qué? ¿Quieres revivir aquellos MAAARAVILLOSOS viejos tiempos, hm~?"

# game/day2 choice.rpy:3013
translate Spanish compliment_knighter_a5f25af0:

    # jes "I wouldn't mind at all. Let me fetch my axe... and we can begin."
    jes "No me importaría en absoluto. Déjame ir por mi hacha... y podemos empezar."

# game/day2 choice.rpy:3015
translate Spanish compliment_knighter_0008d5bd:

    # "My poor brain, incapable of processing things quickly, worked overtime trying to make sense of the situation that had suddenly become so tense."
    "Mi pobre cerebro, incapaz de procesar las cosas rápido, trabajó horas extra tratando de entender la situación que de pronto se había vuelto tan tensa."

# game/day2 choice.rpy:3016
translate Spanish compliment_knighter_5bce4d49:

    # "W-What the heck...?? Are they seriously about to fight?"
    "¿Q-qué demonios...?? ¿De verdad están a punto de pelear?"

# game/day2 choice.rpy:3017
translate Spanish compliment_knighter_bb6571d0:

    # "All I did was compliment Knighter, and somehow it turned into this?!"
    "¡Lo único que hice fue halagar a Knighter, y de algún modo terminó así!"

# game/day2 choice.rpy:3018
translate Spanish compliment_knighter_30c02f98:

    # "No... This can't be happening."
    "No... Esto no puede estar pasando."

# game/day2 choice.rpy:3020
translate Spanish compliment_knighter_983a2f8c:

    # mc "Okay, that's enough, both of you!"
    mc "¡Bien, ya basta, los dos!"

# game/day2 choice.rpy:3021
translate Spanish compliment_knighter_b20f5c6c:

    # mc "We're here to talk, not fight. Remember?"
    mc "Estamos aquí para hablar, no para pelear. ¿Recuerdan?"

# game/day2 choice.rpy:3023
translate Spanish compliment_knighter_65a19326:

    # "They didn't move an inch, even after I said that."
    "No se movieron ni un centímetro, incluso después de que dije eso."

# game/day2 choice.rpy:3024
translate Spanish compliment_knighter_991ab5cd:

    # "I couldn't read Jestyn's expression at all. Was he genuinely angry... or was he just fooling around like he usually did?"
    "No podía descifrar para nada la expresión de Jestyn. ¿Estaba genuinamente enojado... o solo estaba bromeando como solía hacerlo?"

# game/day2 choice.rpy:3025
translate Spanish compliment_knighter_b42481bd:

    # "Whatever the case, the atmosphere around Jestyn felt... unsettling."
    "Fuera como fuese, el ambiente alrededor de Jestyn resultaba... inquietante."

# game/day2 choice.rpy:3027
translate Spanish compliment_knighter_07de3d24:

    # mc "Jestyn. Stop. That's enough."
    mc "Jestyn. Para. Ya basta."

# game/day2 choice.rpy:3028
translate Spanish compliment_knighter_fc74024a:

    # jes "........"
    jes "........"

# game/day2 choice.rpy:3030
translate Spanish compliment_knighter_e333e0f6:

    # "Even Jestyn didn't move."
    "Ni siquiera Jestyn se movió."

# game/day2 choice.rpy:3031
translate Spanish compliment_knighter_269c8f38:

    # "I desperately racked my brain, trying to figure out how to lighten the mood."
    "Me devané los sesos desesperadamente, tratando de pensar cómo aligerar el ambiente."

# game/day2 choice.rpy:3032
translate Spanish compliment_knighter_cf0ce931:

    # "Maybe something fun...? Something funny...? Ugh, I'm terrible at coming up with conversation topics."
    "¿Quizá algo divertido...? ¿Algo gracioso...? Ugh, soy pésim[letra] para inventar temas de conversación."

# game/day2 choice.rpy:3033
translate Spanish compliment_knighter_3928a113_2:

    # "......."
    "......."

# game/day2 choice.rpy:3034
translate Spanish compliment_knighter_955f95e4:

    # "......Oh... Maybe I could ask about that."
    "......Oh... Quizá podría preguntar sobre eso."

# game/day2 choice.rpy:3036
translate Spanish compliment_knighter_a6584b72:

    # mc "Uh... I've actually been wondering about something..."
    mc "Eh... en realidad me estaba preguntando algo..."

# game/day2 choice.rpy:3037
translate Spanish compliment_knighter_b9c65460:

    # mc "Are you two, like... dating?"
    mc "¿Ustedes dos están, como... saliendo?"

# game/day2 choice.rpy:3040
translate Spanish compliment_knighter_701135a7:

    # jeskni "Huh?"
    jeskni "¿Eh?"

# game/day2 choice.rpy:3042
translate Spanish compliment_knighter_30202ce3:

    # "......Maybe I was completely wrong, judging by their reactions."
    "......Quizá estaba completamente equivocad[letra], a juzgar por sus reacciones."

# game/day2 choice.rpy:3043
translate Spanish compliment_knighter_65e220fc:

    # "Without a second thought, Knighter shoved Jestyn away."
    "Sin pensarlo dos veces, Knighter apartó a Jestyn de un empujón."

# game/day2 choice.rpy:3048
translate Spanish compliment_knighter_a1b6f6ac:

    # "Well... at least I managed to stop them from fighting."
    "Bueno... al menos logré que dejaran de pelear."

# game/day2 choice.rpy:3051
translate Spanish compliment_knighter_1b28ce77:

    # kni "Does everything that comes out of your mouth have to be complete nonsense?!"
    kni "¡¿Tiene que ser puro disparate todo lo que sale de tu boca?!"

# game/day2 choice.rpy:3052
translate Spanish compliment_knighter_4167c361:

    # mc "...I was just asking."
    mc "...Solo preguntaba."

# game/day2 choice.rpy:3053
translate Spanish compliment_knighter_44908929:

    # kni "No. Not today. Not ever. I'd sooner drive my own sword through my heart than end up with this idiotic jester."
    kni "No. Hoy no. Nunca. Prefiero atravesarme el corazón con mi propia espada antes que terminar con este bufón idiota."

# game/day2 choice.rpy:3055
translate Spanish compliment_knighter_866fd087:

    # "...Wow. He really means that, huh?"
    "...Vaya. Lo dice en serio, ¿eh?"

# game/day2 choice.rpy:3060
translate Spanish compliment_knighter_2e108cdb:

    # jes "Your Majesty... how could you possibly think I'd be with this Mr. Grumpy in armor? What have I ever done to deserve such an accusation~?"
    jes "Majestad... ¿cómo puede pensar siquiera que estaría con este Señor Gruñón con armadura? ¿Qué he hecho yo para merecer semejante acusación~?"

# game/day2 choice.rpy:3061
translate Spanish compliment_knighter_e3bf4ff0:

    # mc "Nothing... I was just guessing..."
    mc "Nada... solo estaba suponiendo..."

# game/day2 choice.rpy:3062
translate Spanish compliment_knighter_d98551c0:

    # mc "...Well, maybe because you keep teasing me all the time."
    mc "...Bueno, quizá porque me molestas todo el tiempo."

# game/day2 choice.rpy:3064
translate Spanish compliment_knighter_361716a4:

    # jes "But that's simply my duty as the royal jester~"
    jes "Pero ese es simplemente mi deber como bufón real~"

# game/day2 choice.rpy:3066
translate Spanish compliment_knighter_342e5999:

    # "Jestyn looked at me with wide, pleading puppy-dog eyes."
    "Jestyn me miró con enormes ojos suplicantes de cachorrito."

# game/day2 choice.rpy:3067
translate Spanish compliment_knighter_be696720:

    # "Since when could he make a face like that?! That's not fair!"
    "¡¿Desde cuándo podía poner esa cara?! ¡No es justo!"

# game/day2 choice.rpy:3069
translate Spanish compliment_knighter_9edd10ec:

    # jes "......So the time we spent together yesterday meant nothing at all to Your Majesty..."
    jes "......Así que el tiempo que pasamos juntos ayer no significó nada para Su Majestad..."

# game/day2 choice.rpy:3070
translate Spanish compliment_knighter_0dfabce7:

    # mc "N-no, that's not what I meant! L-look... let's just get back to our conversation, okay?"
    mc "¡N-no, no era eso lo que quería decir! M-mira... volvamos a nuestra conversación, ¿ok?"

# game/day2 choice.rpy:3071
translate Spanish compliment_knighter_7a91dbd0:

    # mc "Whatever issues you two have with each other, leave them out of this conversation. Got it?"
    mc "Sean cuales sean los problemas que tengan entre ustedes, déjenlos fuera de esta conversación. ¿Entendido?"

# game/day2 choice.rpy:3073
translate Spanish compliment_knighter_9750bdfc:

    # "Jestyn gave a small nod."
    "Jestyn asintió levemente."

# game/day2 choice.rpy:3076
translate Spanish compliment_knighter_363df763:

    # jes "...Your Majesty truly is too kind... but my poor heart is still wounded..."
    jes "...Su Majestad es de verdad demasiado amable... pero mi pobre corazón sigue herido..."

# game/day2 choice.rpy:3077
translate Spanish compliment_knighter_23b5186e:

    # mc "Now, how about you two make up? You know... shake hands."
    mc "Ahora, ¿qué tal si hacen las paces? Ya saben... estrechen las manos."

# game/day2 choice.rpy:3081
translate Spanish compliment_knighter_94cda263:

    # "Jestyn and Knighter simply stared at each other."
    "Jestyn y Knighter simplemente se miraron."

# game/day2 choice.rpy:3084
translate Spanish compliment_knighter_d5c0fff7:

    # "Before eventually looking away, both wearing annoyed expressions."
    "Antes de apartar finalmente la vista, ambos con expresión fastidiada."

# game/day2 choice.rpy:3086
translate Spanish compliment_knighter_a098cc9a:

    # mc "Hahh... Do I really have to guide you two through an apology like a couple of children?"
    mc "Hahh... ¿De verdad tengo que guiarlos en una disculpa como si fueran un par de niños?"

# game/day2 choice.rpy:3087
translate Spanish compliment_knighter_5b3cf8b9:

    # mc "I said, shake hands. That's an order."
    mc "Dije que se den la mano. Es una orden."

# game/day2 choice.rpy:3088
translate Spanish compliment_knighter_a14668b4:

    # mc "Jestyn, hold out your hand to Knighter."
    mc "Jestyn, extiende la mano a Knighter."

# game/day2 choice.rpy:3089
translate Spanish compliment_knighter_fc74024a_1:

    # jes "........"
    jes "........"

# game/day2 choice.rpy:3091
translate Spanish compliment_knighter_76268b6f:

    # "Jestyn obeyed as usual and held out his hand to Knighter."
    "Jestyn obedeció como siempre y extendió la mano a Knighter."

# game/day2 choice.rpy:3093
translate Spanish compliment_knighter_1efd549e:

    # mc "Knighter, your turn. Hold out your hand and shake Jestyn's."
    mc "Knighter, tu turno. Extiende la mano y estrecha la de Jestyn."

# game/day2 choice.rpy:3094
translate Spanish compliment_knighter_6ad8008b:

    # kni "........"
    kni "........"

# game/day2 choice.rpy:3096
translate Spanish compliment_knighter_9048fa66:

    # "Surprisingly, Knighter obeyed too and held out his hand. The two of them finally shook hands."
    "Sorprendentemente, Knighter también obedeció y extendió la mano. Los dos por fin se dieron la mano."

# game/day2 choice.rpy:3098
translate Spanish compliment_knighter_e9c57359:

    # mc "And then? What are you supposed to say when you've done something wrong?"
    mc "¿Y luego? ¿Qué se supone que se dice cuando se ha hecho algo malo?"

# game/day2 choice.rpy:3099
translate Spanish compliment_knighter_2b470952:

    # jeskni "........."
    jeskni "........."

# game/day2 choice.rpy:3100
translate Spanish compliment_knighter_3e55638c:

    # jeskni "...I'm sorry."
    jeskni "...Lo siento."

# game/day2 choice.rpy:3102
translate Spanish compliment_knighter_e58f40b4:

    # mc "See? That wasn't so hard, was it...?"
    mc "¿Ves? No fue tan difícil, ¿verdad...?"

# game/day2 choice.rpy:3104
translate Spanish compliment_knighter_678a8dc5:

    # "After a few moments, they finally let go of each other's hands."
    "Tras unos instantes, por fin se soltaron las manos."

# game/day2 choice.rpy:3105
translate Spanish compliment_knighter_b0373fd8:

    # "With an exaggeratedly dejected sigh, Jestyn slowly shuffled back to his usual spot behind me."
    "Con un suspiro exageradamente abatido, Jestyn volvió arrastrando los pies hasta su sitio habitual detrás de mí."

# game/day2 choice.rpy:3106
translate Spanish compliment_knighter_6b550c89:

    # "All I wanted was to compliment Knighter's appearance... Maybe complimenting him was a mistake from the very beginning..."
    "Solo quería halagar el aspecto de Knighter... Quizá halagarlo fue un error desde el principio..."

# game/day2 choice.rpy:3115
translate Spanish relationship_knighter_8182e0ab:

    # "Knighter seemed like the type of puppet who had a hard time getting along with others. I couldn't help but wonder what his relationships with the rest of the puppets were like."
    "Knighter parecía el tipo de marioneta a la que le costaba llevarse bien con los demás. No pude evitar preguntarme cómo serían sus relaciones con el resto de las marionetas."

# game/day2 choice.rpy:3117
translate Spanish relationship_knighter_1df93467:

    # mc "Can I ask what your relationship is like with the other puppets?"
    mc "¿Puedo preguntarte cómo es tu relación con las otras marionetas?"

# game/day2 choice.rpy:3120
translate Spanish relationship_knighter_f36785dd:

    # "Knighter glanced at me for a brief moment."
    "Knighter me miró un breve instante."

# game/day2 choice.rpy:3123
translate Spanish relationship_knighter_100f9b4a:

    # kni "Fine."
    kni "Bien."

# game/day2 choice.rpy:3126
translate Spanish relationship_knighter_f708f9d4:

    # "Then he immediately went back to his book. Seriously?"
    "Luego volvió de inmediato a su libro. ¿En serio?"

# game/day2 choice.rpy:3128
translate Spanish relationship_knighter_bf555b11:

    # mc "...How fine?"
    mc "...¿Qué tan bien?"

# game/day2 choice.rpy:3130
translate Spanish relationship_knighter_de139007:

    # kni "Just fine."
    kni "Solo bien."

# game/day2 choice.rpy:3132
translate Spanish relationship_knighter_901e8055:

    # mc "You know that's not what I meant."
    mc "Sabes que no es eso lo que quise decir."

# game/day2 choice.rpy:3135
translate Spanish relationship_knighter_b4342379:

    # "He let out a long sigh."
    "Soltó un largo suspiro."

# game/day2 choice.rpy:3138
translate Spanish relationship_knighter_221fdad4:

    # kni "I don't know what exactly you want me to explain."
    kni "No sé qué exactamente quieres que te explique."

# game/day2 choice.rpy:3141
translate Spanish relationship_knighter_91201326:

    # "Do I seriously have to spell everything out for this puppet?"
    "¿De verdad tengo que explicarle todo con pelos y señales a esta marioneta?"

# game/day2 choice.rpy:3143
translate Spanish relationship_knighter_bd01ead8:

    # mc "Okay, fiiine."
    mc "Okay, bieeen."

# game/day2 choice.rpy:3144
translate Spanish relationship_knighter_e57cc1a5:

    # mc "I want you to tell me what your relationship with the other puppets is like. How well do you get along with each of them?"
    mc "Quiero que me digas cómo es tu relación con las otras marionetas. ¿Qué tan bien te llevas con cada una de ellas?"

# game/day2 choice.rpy:3145
translate Spanish relationship_knighter_2531c9fd:

    # mc "Let's start with Jestyn."
    mc "Empecemos por Jestyn."

# game/day2 choice.rpy:3147
translate Spanish relationship_knighter_c7cdcaf1:

    # "Jestyn puffed out his chest proudly, looking smugger than ever."
    "Jestyn sacó pecho con orgullo, luciendo más engreído que nunca."

# game/day2 choice.rpy:3150
translate Spanish relationship_knighter_d644782a:

    # "Knighter, on the other hand, looked like he had just bitten into something bitter."
    "Knighter, en cambio, parecía haber mordido algo amargo."

# game/day2 choice.rpy:3152
translate Spanish relationship_knighter_5114e747:

    # kni "I want to punch him."
    kni "Quiero golpearlo."

# game/day2 choice.rpy:3153
translate Spanish relationship_knighter_45c17f11:

    # jes "Such high praise from my noble knight~ My poor heart is so touched it's practically cracked."
    jes "Qué grandes elogios de mi noble caballero~ Mi pobre corazón está tan conmovido que prácticamente se ha resquebrajado."

# game/day2 choice.rpy:3155
translate Spanish relationship_knighter_93a7d983:

    # "Knighter responded to Jestyn's sarcasm with nothing more than an eye roll."
    "Knighter respondió al sarcasmo de Jestyn con nada más que un giro de ojos."

# game/day2 choice.rpy:3158
translate Spanish relationship_knighter_52f419af:

    # kni "He's nothing but a nuisance. A walking headache."
    kni "No es más que una molestia. Un dolor de cabeza con patas."

# game/day2 choice.rpy:3160
translate Spanish relationship_knighter_0f4de918:

    # mc "What exactly has he done to make you dislike him this much?"
    mc "¿Qué ha hecho exactamente para que te caiga tan mal?"

# game/day2 choice.rpy:3162
translate Spanish relationship_knighter_05565aab:

    # kni "A lot of things."
    kni "Muchas cosas."

# game/day2 choice.rpy:3164
translate Spanish relationship_knighter_b2aba0e3:

    # mc "Like what?"
    mc "¿Como qué?"

# game/day2 choice.rpy:3166
translate Spanish relationship_knighter_cf24e28f:

    # kni "Pranks. He loves pulling pranks on people. Me especially."
    kni "Bromas. Le encanta hacerle bromas pesadas a la gente. A mí sobre todo."

# game/day2 choice.rpy:3167
translate Spanish relationship_knighter_04279fd3:

    # mc "Are Jestyn's pranks on you really that bad?"
    mc "¿De verdad son tan malas las bromas de Jestyn?"

# game/day2 choice.rpy:3169
translate Spanish relationship_knighter_725b8a6b:

    # kni "Judge it by yourself."
    kni "Júzgalo tú."

# game/day2 choice.rpy:3171
translate Spanish relationship_knighter_d0a50443:

    # "Yeah... I think I'll take his word for it."
    "Sí... creo que mejor le creo."

# game/day2 choice.rpy:3173
translate Spanish relationship_knighter_8a413bd3:

    # mc "Mmm... What's the tamest prank he's ever pulled on you?"
    mc "Mmm... ¿Cuál es la broma más inofensiva que te ha hecho?"

# game/day2 choice.rpy:3177
translate Spanish relationship_knighter_c7db7634:

    # "Knighter paused to think for a moment."
    "Knighter se detuvo a pensar un momento."

# game/day2 choice.rpy:3180
translate Spanish relationship_knighter_92f94936:

    # kni "He dumped a bucket of mud over my head."
    kni "Me echó un cubo de barro por la cabeza."

# game/day2 choice.rpy:3182
translate Spanish relationship_knighter_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:3183
translate Spanish relationship_knighter_ec2cde8c:

    # "That's the tamest one...?"
    "¿Esa es la más inofensiva...?"

# game/day2 choice.rpy:3185
translate Spanish relationship_knighter_c7e3714c:

    # mc "U-Uh... okay... Then what was the worst one?"
    mc "E-eh... vale... Entonces, ¿cuál fue la peor?"

# game/day2 choice.rpy:3188
translate Spanish relationship_knighter_b1a27d58:

    # "Knighter's brow furrowed even deeper. His jaw clenched as irritation flashed across his face."
    "El ceño de Knighter se frunció aún más. Apretó la mandíbula mientras la irritación cruzaba su rostro."

# game/day2 choice.rpy:3189
translate Spanish relationship_knighter_357b5e8c:

    # "Whatever happened... it was clearly burned into his memory."
    "Fuera lo que fuera lo que pasó... claramente estaba grabado en su memoria."

# game/day2 choice.rpy:3191
translate Spanish relationship_knighter_9c786184:

    # kni "...I'd rather not remember."
    kni "...Prefiero no recordarlo."

# game/day2 choice.rpy:3196
translate Spanish relationship_knighter_5c50f61b:

    # jes "My apologies for interrupting, Your Majesty~ But since my dear knightly friend seems to be struggling, allow this humble jester to recount the tale on his behalf."
    jes "Mis disculpas por interrumpir, Majestad~ Pero como mi querido amigo caballero parece tener dificultades, permita a este humilde bufón relatar la historia en su nombre."

# game/day2 choice.rpy:3201
translate Spanish relationship_knighter_6fd15d41:

    # "Knighter shot Jestyn a murderous glare. His whole body went rigid."
    "Knighter le lanzó a Jestyn una mirada asesina. Todo su cuerpo se puso rígido."

# game/day2 choice.rpy:3205
translate Spanish relationship_knighter_e7952b72:

    # jes "On one bright and beautiful afternoon~ Sir Knighter was peacefully enjoying a refreshing cup of iced coffee while reading a romance novel he hadn't yet finished."
    jes "Una tarde brillante y hermosa~ Sir Knighter disfrutaba tranquilamente de una refrescante taza de café helado mientras leía una novela romántica que aún no había terminado."

# game/day2 choice.rpy:3207
translate Spanish relationship_knighter_98d15836:

    # jes "Then he sighed and said... 'Hahh... It's so hot...'"
    jes "Entonces suspiró y dijo... 'Hahh... Qué calor hace...'"

# game/day2 choice.rpy:3211
translate Spanish relationship_knighter_d36109c0:

    # kni "Jestyn, you-"
    kni "Jestyn, tú-"

# game/day2 choice.rpy:3213
translate Spanish relationship_knighter_fc0e5dcd:

    # jes "So naturally, this lowly jester, with a heart overflowing with kindness and an irresistible urge to help, decided to come to the honorable knight's rescue~"
    jes "Así que, naturalmente, este humilde bufón, con un corazón rebosante de bondad y un impulso irresistible de ayudar, decidió acudir al rescate del honorable caballero~"

# game/day2 choice.rpy:3215
translate Spanish relationship_knighter_9ddf8c6c:

    # jes "Without his knowledge, of course. True kindness asks for no recognition. I acted out of the pure goodness of my heart."
    jes "Sin que él lo supiera, por supuesto. La verdadera bondad no pide reconocimiento. Actué por la pura bondad de mi corazón."

# game/day2 choice.rpy:3217
translate Spanish relationship_knighter_db3a2a7d:

    # jes "A single grateful smile would have been more than enough for me. SO..."
    jes "Una sola sonrisa de agradecimiento habría sido más que suficiente para mí. ASÍ QUE..."

# game/day2 choice.rpy:3218
translate Spanish relationship_knighter_8df4fb84:

    # jes "This humble jester transformed his heavy, rigid, shining, shimmering, splendid suit of armor into something soft, light, and guaranteed to keep its wearer nice and cool..."
    jes "Este humilde bufón transformó su pesada, rígida, reluciente, centelleante y espléndida armadura en algo suave, ligero y garantizado para mantener a quien la use bien fresco..."

# game/day2 choice.rpy:3220
translate Spanish relationship_knighter_8f67c922:

    # kni "JESTYN!!"
    kni "¡¡JESTYN!!"

# game/day2 choice.rpy:3223
translate Spanish relationship_knighter_be4d64da:

    # "Before Knighter could finish, Jestyn instantly teleported behind him and clamped a hand over his mouth."
    "Antes de que Knighter pudiera terminar, Jestyn se teletransportó al instante detrás de él y le tapó la boca con una mano."

# game/day2 choice.rpy:3224
translate Spanish relationship_knighter_d8ebf138:

    # "Knighter struggled furiously, trying to pry Jestyn's hand away."
    "Knighter forcejeó furiosamente, intentando apartar la mano de Jestyn."

# game/day2 choice.rpy:3227
translate Spanish relationship_knighter_c38e37d7:

    # jes "...A bikini!"
    jes "...¡Un bikini!"

# game/day2 choice.rpy:3228
translate Spanish relationship_knighter_dddb6f7e:

    # mc "........."
    mc "........."

# game/day2 choice.rpy:3229
translate Spanish relationship_knighter_ba32daf6:

    # mc "You turned Knighter's armor... into a bikini?"
    mc "¿Convertiste la armadura de Knighter... en un bikini?"

# game/day2 choice.rpy:3231
translate Spanish relationship_knighter_10038d52:

    # jes "BINGO~!"
    jes "¡BINGO~!"

# game/day2 choice.rpy:3235
translate Spanish relationship_knighter_7c092ab0:

    # "Jestyn then teleported back behind me."
    "Jestyn volvió entonces a teletransportarse detrás de mí."

# game/day2 choice.rpy:3237
translate Spanish relationship_knighter_83fde6ee:

    # "Knighter, his face still bright red, glared at him with obvious irritation."
    "Knighter, con la cara todavía roja brillante, lo fulminó con evidente irritación."

# game/day2 choice.rpy:3238
translate Spanish relationship_knighter_567acee6:

    # "But the moment he realized his secret was out, he quickly turned his face away from me."
    "Pero en cuanto se dio cuenta de que su secreto había salido a la luz, apartó rápidamente la cara de mí."

# game/day2 choice.rpy:3239
translate Spanish relationship_knighter_e2b0d9c2:

    # "So Jestyn wasn't making it up after all... That story was actually true."
    "Así que Jestyn no lo estaba inventando después de todo... Esa historia era cierta."

# game/day2 choice.rpy:3241
translate Spanish relationship_knighter_743b8b11:

    # kni "......Now you know. Don't ask for the details."
    kni "......Ahora ya lo sabes. No pidas los detalles."

# game/day2 choice.rpy:3243
translate Spanish relationship_knighter_b4be8bfd:

    # "I decided not to push it any further and moved on to asking about his relationship with the other puppets."
    "Decidí no insistir más y pasé a preguntarle por su relación con las otras marionetas."

# game/day2 choice.rpy:3245
translate Spanish relationship_knighter_a64b9917:

    # mc "In that case... what about the other puppets besides Jestyn?"
    mc "En ese caso... ¿y las otras marionetas además de Jestyn?"

# game/day2 choice.rpy:3249
translate Spanish relationship_knighter_9e3d73ef:

    # kni "....."
    kni "....."

# game/day2 choice.rpy:3251
translate Spanish relationship_knighter_ed870936:

    # kni "...Wizzy, I suppose."
    kni "...Wizzy, supongo."

# game/day2 choice.rpy:3252
translate Spanish relationship_knighter_5b6fa755:

    # kni "I get along well with him. We don't have any problems."
    kni "Me llevo bien con él. No tenemos ningún problema."

# game/day2 choice.rpy:3254
translate Spanish relationship_knighter_f97c93aa:

    # mc "Do you two talk often?"
    mc "¿Hablan seguido?"

# game/day2 choice.rpy:3256
translate Spanish relationship_knighter_d92ab47d:

    # kni "Fairly often."
    kni "Bastante."

# game/day2 choice.rpy:3258
translate Spanish relationship_knighter_609dab5f:

    # kni "Usually we just discuss random things... or I listen while Wizzy goes on about his experiments."
    kni "Normalmente solo hablamos de cosas al azar... o yo escucho mientras Wizzy habla de sus experimentos."

# game/day2 choice.rpy:3259
translate Spanish relationship_knighter_b64cec05:

    # kni "I don't talk much. I mostly just listen."
    kni "Yo no hablo mucho. Sobre todo escucho."

# game/day2 choice.rpy:3263
translate Spanish relationship_knighter_f504d473:

    # "I nodded in understanding."
    "Asentí con comprensión."

# game/day2 choice.rpy:3264
translate Spanish relationship_knighter_d2f74698:

    # "It sounded like Knighter and Wizzy were actually pretty close. At the very least, he had someone he could genuinely get along with."
    "Parecía que Knighter y Wizzy eran bastante cercanos. Al menos, tenía a alguien con quien llevarse de verdad bien."

# game/day2 choice.rpy:3266
translate Spanish relationship_knighter_60e6c864:

    # mc "Alright then."
    mc "Muy bien."

# game/day2 choice.rpy:3267
translate Spanish relationship_knighter_b9706746:

    # mc "What about the other puppets?"
    mc "¿Y las otras marionetas?"

# game/day2 choice.rpy:3269
translate Spanish relationship_knighter_3faefb5d:

    # "Knighter fell into deep thought."
    "Knighter se sumió en profundos pensamientos."

# game/day2 choice.rpy:3271
translate Spanish relationship_knighter_175346e0:

    # kni ".........."
    kni ".........."

# game/day2 choice.rpy:3273
translate Spanish relationship_knighter_d84cc87d:

    # kni "Most of them are just acquaintances."
    kni "La mayoría son solo conocidos."

# game/day2 choice.rpy:3274
translate Spanish relationship_knighter_4c649836:

    # kni "Farmin, Butley... they're all just ordinary companions. We greet each other politely whenever we cross paths."
    kni "Farmin, Butley... son todos simples compañeros. Nos saludamos con cortesía cuando nos cruzamos."

# game/day2 choice.rpy:3279
translate Spanish relationship_knighter_a7bcf340:

    # mc "I see..."
    mc "Ya veo..."

# game/day2 choice.rpy:3280
translate Spanish relationship_knighter_de755ea3:

    # mc "Mmm... Earlier, I was talking to Wizzy, and he mentioned a priest puppet named Prieston. What's your relationship with him like?"
    mc "Mmm... Hace un rato hablaba con Wizzy y mencionó una marioneta sacerdote llamada Prieston. ¿Cómo es tu relación con él?"

# game/day2 choice.rpy:3283
translate Spanish relationship_knighter_27e19d95:

    # "Knighter's brow furrowed almost immediately."
    "El ceño de Knighter se frunció casi de inmediato."

# game/day2 choice.rpy:3285
translate Spanish relationship_knighter_a8b889c5:

    # kni ".....Him..."
    kni ".....Él..."

# game/day2 choice.rpy:3286
translate Spanish relationship_knighter_86a9d3ae:

    # kni "............."
    kni "............."

# game/day2 choice.rpy:3288
translate Spanish relationship_knighter_10f18cb8:

    # "He paused for a moment, seemingly struggling to find the right words."
    "Hizo una pausa, aparentemente esforzándose por encontrar las palabras adecuadas."

# game/day2 choice.rpy:3291
translate Spanish relationship_knighter_d40b71a3:

    # kni "He's... confusing."
    kni "Es... confuso."

# game/day2 choice.rpy:3292
translate Spanish relationship_knighter_b2b9e19d:

    # mc "What do you mean?"
    mc "¿A qué te refieres?"

# game/day2 choice.rpy:3293
translate Spanish relationship_knighter_7b7594c0:

    # kni "I don't know much about him. We greet each other when we happen to meet... but even that doesn't happen very often."
    kni "No sé mucho de él. Nos saludamos cuando coincidimos... pero ni eso ocurre muy a menudo."

# game/day2 choice.rpy:3294
translate Spanish relationship_knighter_1d7e2ada:

    # kni "He rarely leaves his room."
    kni "Rara vez sale de su habitación."

# game/day2 choice.rpy:3295
translate Spanish relationship_knighter_54e13113:

    # kni "...And..."
    kni "...Y..."

# game/day2 choice.rpy:3296
translate Spanish relationship_knighter_4a7d19e1:

    # kni "I honestly have no idea what's going on inside his head."
    kni "Sinceramente, no tengo idea de qué pasa por su cabeza."

# game/day2 choice.rpy:3297
translate Spanish relationship_knighter_b59cfda9:

    # kni "I don't really trust him."
    kni "No confío mucho en él."

# game/day2 choice.rpy:3299
translate Spanish relationship_knighter_aeb69552:

    # mc "...Alright, then..."
    mc "...Entiendo, entonces..."

# game/day2 choice.rpy:3300
translate Spanish relationship_knighter_8d466776:

    # mc "Maybe-"
    mc "Quizá-"

# game/day2 choice.rpy:3301
translate Spanish relationship_knighter_78c7206e:

    # kni "I think that's enough for now. There's nothing particularly interesting about this topic."
    kni "Creo que ya es suficiente por ahora. No hay nada especialmente interesante en este tema."

# game/day2 choice.rpy:3308
translate Spanish crownusask_knighter_b33e76c3:

    # "I wanted to know what he thought of the King Puppet. I wanted to know what kind of person he had been."
    "Quería saber qué pensaba de la Marioneta Rey. Quería saber qué clase de persona había sido."

# game/day2 choice.rpy:3310
translate Spanish crownusask_knighter_61e85baf:

    # mc "You know... I'm actually pretty curious about the King Puppet."
    mc "Sabes... en realidad tengo bastante curiosidad por la Marioneta Rey."

# game/day2 choice.rpy:3311
translate Spanish crownusask_knighter_5f799c44:

    # mc "So... I'd like to hear what you think of him."
    mc "Así que... me gustaría oír qué piensas de él."

# game/day2 choice.rpy:3315
translate Spanish crownusask_knighter_90837585:

    # "Knighter froze."
    "Knighter se quedó helado."

# game/day2 choice.rpy:3316
translate Spanish crownusask_knighter_4f468ba2:

    # "Then he slowly looked at me. But with a completely different expression."
    "Luego me miró lentamente. Pero con una expresión completamente distinta."

# game/day2 choice.rpy:3318
translate Spanish crownusask_knighter_8699f5f3:

    # "He looked... surprised. And... sad?"
    "Parecía... sorprendido. ¿Y... triste?"

# game/day2 choice.rpy:3319
translate Spanish crownusask_knighter_94871ed8:

    # "Why?"
    "¿Por qué?"

# game/day2 choice.rpy:3321
translate Spanish crownusask_knighter_91f0f666:

    # mc "Knighter...?"
    mc "¿Knighter...?"

# game/day2 choice.rpy:3322
translate Spanish crownusask_knighter_a18cf782:

    # kni ".......He..."
    kni ".......Él..."

# game/day2 choice.rpy:3324
translate Spanish crownusask_knighter_60a8958d:

    # "Knighter fell silent for a moment."
    "Knighter guardó silencio un momento."

# game/day2 choice.rpy:3326
translate Spanish crownusask_knighter_01150b2c:

    # voice "KNIGHTER06_DAY2.ogg"
    # kni "... Crownus was.... our future.... He-"
    voice "KNIGHTER06_DAY2.ogg"
    kni "... Crownus era.... nuestro futuro.... Él-"

# game/day2 choice.rpy:3328
translate Spanish crownusask_knighter_25dbfcfa:

    # jes "I think we'll end this conversation here."
    jes "Creo que terminaremos esta conversación aquí."

# game/day2 choice.rpy:3330
translate Spanish crownusask_knighter_ace7c7c2:

    # "Jestyn abruptly cut Knighter off. His voice sounded as playful as ever, yet somehow... the atmosphere around him suddenly felt unsettling."
    "Jestyn interrumpió abruptamente a Knighter. Su voz sonaba tan juguetona como siempre, pero de algún modo... el ambiente a su alrededor se volvió de pronto inquietante."

# game/day2 choice.rpy:3332
translate Spanish crownusask_knighter_9dc60fed:

    # mc "Huh? But I was only-"
    mc "¿Eh? Pero yo solo-"

# game/day2 choice.rpy:3333
translate Spanish crownusask_knighter_136787e5:

    # jes "Don't you think it's rather disrespectful to speak of someone who's already passed on? His soul deserves to rest in peace."
    jes "¿No le parece bastante irrespetuoso hablar de alguien que ya falleció? Su alma merece descansar en paz."

# game/day2 choice.rpy:3335
translate Spanish crownusask_knighter_49a6f3fa:

    # jes "So let us leave him to his eternal rest forever. Alright~?"
    jes "Así que dejémoslo en su eterno descanso para siempre. ¿Les parece~?"

# game/day2 choice.rpy:3341
translate Spanish Poke_knighter_0fd4d656:

    # "......"
    "......"

# game/day2 choice.rpy:3342
translate Spanish Poke_knighter_f86b84c5:

    # "For some reason, I suddenly had this overwhelming urge to mess with him."
    "Por alguna razón, de pronto me invadieron unas ganas irresistibles de molestarlo."

# game/day2 choice.rpy:3343
translate Spanish Poke_knighter_244825f7:

    # "Before I could think twice, I reached out and poked his cheek."
    "Antes de pensarlo dos veces, extendí la mano y le piqué la mejilla."

# game/day2 choice.rpy:3347
translate Spanish Poke_knighter_4d7cab40:

    # kni "!!"
    kni "¡¡!!"

# game/day2 choice.rpy:3349
translate Spanish Poke_knighter_593224d3:

    # "I could actually feel his skin beneath my finger. It felt just like human skin... How strange."
    "De verdad podía sentir su piel bajo mi dedo. Se sentía igual que la piel humana... Qué extraño."

# game/day2 choice.rpy:3351
translate Spanish Poke_knighter_7eb2a802:

    # kni "What exactly do you think you're doing?"
    kni "¿Qué demonios crees que haces?"

# game/day2 choice.rpy:3353
translate Spanish Poke_knighter_6d2ee277:

    # "Knighter shot me a murderous glare, yet all he did was stare."
    "Knighter me lanzó una mirada asesina, pero lo único que hizo fue mirarme."

# game/day2 choice.rpy:3356
translate Spanish Poke_knighter_07755c67:

    # kni "Don't you dare touch me again, or I'll-"
    kni "No te atrevas a tocarme otra vez, o te-"

# game/day2 choice.rpy:3357
translate Spanish Poke_knighter_70cae27a:

    # jes "Ahem!"
    jes "¡Ejem!"

# game/day2 choice.rpy:3360
translate Spanish Poke_knighter_8c8270b1:

    # "Jestyn cleared his throat loudly, cutting Knighter off before he could finish."
    "Jestyn se aclaró la garganta con fuerza, cortando a Knighter antes de que terminara."

# game/day2 choice.rpy:3361
translate Spanish Poke_knighter_e301ee1f:

    # "Knighter could only let out a defeated sigh."
    "Knighter solo pudo soltar un suspiro de derrota."

# game/day2 choice.rpy:3364
translate Spanish Poke_knighter_399fe227:

    # kni "Stop that."
    kni "Deja de hacer eso."

# game/day2 choice.rpy:3367
translate Spanish Poke_knighter_d4acf1ea:

    # "He went right back to reading his book."
    "Volvió enseguida a su libro."

# game/day2 choice.rpy:3371
translate Spanish Poke_knighter_0430456b:

    # "I ignored his warning and poked his cheek again."
    "Ignoré su advertencia y volví a picarle la mejilla."

# game/day2 choice.rpy:3374
translate Spanish Poke_knighter_175346e0:

    # kni ".........."
    kni ".........."

# game/day2 choice.rpy:3375
translate Spanish Poke_knighter_78a2c776:

    # kni "Are you deaf?"
    kni "¿Estás sord[letra]?"

# game/day2 choice.rpy:3376
translate Spanish Poke_knighter_ee0472f8:

    # jes "My dear friend Knighter~?"
    jes "¿Mi querido amigo Knighter~?"

# game/day2 choice.rpy:3378
translate Spanish Poke_knighter_175346e0_1:

    # kni ".........."
    kni ".........."

# game/day2 choice.rpy:3380
translate Spanish Poke_knighter_fe0b5957:

    # kni "Could you please stop poking my cheek~?"
    kni "¿Podrías dejar de picarme la mejilla, por favor~?"

# game/day2 choice.rpy:3381
translate Spanish Poke_knighter_d9b3e9ad:

    # kni "...Or I'll kill you."
    kni "...O te mato."

# game/day2 choice.rpy:3390
translate Spanish Poke_knighter_3da7e44d:

    # "poke"
    "*toc*"

# game/day2 choice.rpy:3396
translate Spanish Poke_knighter_58b860f3:

    # kni "YOU!!"
    kni "¡¡TÚ!!"

# game/day2 choice.rpy:3398
translate Spanish Poke_knighter_647a447d:

    # kni "I'M GONNA-"
    kni "¡VOY A-"

# game/day2 choice.rpy:3399
translate Spanish Poke_knighter_0787283b:

    # jes "Do I really have to repeat myself?"
    jes "¿De verdad tengo que repetirme?"

# game/day2 choice.rpy:3402
translate Spanish Poke_knighter_70461824:

    # "Knighter struggled to keep his temper in check."
    "Knighter se esforzó por mantener su temperamento bajo control."

# game/day2 choice.rpy:3403
translate Spanish Poke_knighter_f64ee9d8:

    # "Then..."
    "Entonces..."

# game/day2 choice.rpy:3407
translate Spanish Poke_knighter_560098ec:

    # mc "OW, OW, OW, OW!!"
    mc "¡¡AY, AY, AY, AY!!"

# game/day2 choice.rpy:3409
translate Spanish Poke_knighter_7b71f05d:

    # "Knighter pinched my arm hard in retaliation."
    "Knighter me pellizcó el brazo con fuerza como represalia."

# game/day2 choice.rpy:3411
translate Spanish Poke_knighter_c9d1d091:

    # "I immediately yanked my hand back."
    "Retiré la mano de inmediato."

# game/day2 choice.rpy:3413
translate Spanish Poke_knighter_17c90512:

    # kni "Do that again, and I can't promise the next pinch won't hurt even more."
    kni "Vuelve a hacerlo y no puedo prometer que el próximo pellizco no duela aún más."

# game/day2 choice.rpy:3414
translate Spanish Poke_knighter_ac9c8d90:

    # jes "How dare you hurt [poss] majesty?!"
    jes "¡¿Cómo te atreves a lastimar a Su Majestad?!"

# game/day2 choice.rpy:3417
translate Spanish Poke_knighter_c183bbe1:

    # kni "It was just a pinch. Don't be so dramatic. You should be grateful I wasn't reckless enough to draw my sword."
    kni "Fue solo un pellizco. No seas tan dramático. Deberías agradecer que no fui lo bastante imprudente como para desenvainar mi espada."

# game/day2 choice.rpy:3429
translate Spanish afterconvo_knighter_7419f5a6:

    # kni "Are we done?"
    kni "¿Hemos terminado?"

# game/day2 choice.rpy:3431
translate Spanish afterconvo_knighter_31afd5a1:

    # "I couldn't think of another topic to bring up, so I nodded, bringing the conversation to an end."
    "No se me ocurría otro tema, así que asentí, dando por terminada la conversación."

# game/day2 choice.rpy:3432
translate Spanish afterconvo_knighter_3b7ce67e:

    # "I'd learned enough for one day."
    "Había aprendido suficiente por un día."

# game/day2 choice.rpy:3433
translate Spanish afterconvo_knighter_231e1cf8:

    # "And honestly... Knighter looked exhausted. Emotionally, more than anything."
    "Y, sinceramente... Knighter parecía agotado. Emocionalmente, más que nada."

# game/day2 choice.rpy:3436
translate Spanish afterconvo_knighter_1efa56d5:

    # kni "Finally. I've completely run out of social energy dealing with you two."
    kni "Por fin. Me he quedado sin energía social tratando con ustedes dos."

# game/day2 choice.rpy:3437
translate Spanish afterconvo_knighter_c4f774ac:

    # kni "So, now that I've satisfied your curiosity, I'd kindly ask both of you to leave my room."
    kni "Así que, ahora que he satisfecho su curiosidad, les pediría amablemente a ambos que salgan de mi habitación."

# game/day2 choice.rpy:3438
translate Spanish afterconvo_knighter_ee0933e6:

    # kni "Now."
    kni "Ahora."

# game/day2 choice.rpy:3441
translate Spanish afterconvo_knighter_1c2a3680:

    # "I stood up from my chair."
    "Me levanté de la silla."

# game/day2 choice.rpy:3442
translate Spanish afterconvo_knighter_312efaf9:

    # "Knighter rose as well, watching us as we made our way toward the door."
    "Knighter también se levantó, observándonos mientras nos dirigíamos a la puerta."

# game/day2 choice.rpy:3448
translate Spanish afterconvo_knighter_41c604f9:

    # jes "Thank you for taking the time to speak with [poss] Majesty, my honorable knight~"
    jes "Gracias por tomarte el tiempo de hablar con Su Majestad, mi honorable caballero~"

# game/day2 choice.rpy:3450
translate Spanish afterconvo_knighter_804c702e:

    # jes "Deep down... you truly do have a noble heart."
    jes "En el fondo... de verdad tienes un corazón noble."

# game/day2 choice.rpy:3452
translate Spanish afterconvo_knighter_8b88ab3e:

    # kni "I can't tell whether you're mocking me or complimenting me. I'll choose to take it as a compliment, considering I just wasted time I never wanted to waste in the first place."
    kni "No sé si te burlas de mí o me halagas. Elegiré tomarlo como un halago, considerando que acabo de perder un tiempo que nunca quise perder."

# game/day2 choice.rpy:3454
translate Spanish afterconvo_knighter_c3243046:

    # kni "And remember this, I never wanted to talk to that human. You forced me to."
    kni "Y recuerda esto: nunca quise hablar con esa persona. Me obligaste."

# game/day2 choice.rpy:3457
translate Spanish afterconvo_knighter_19f8c8fb:

    # "Jestyn answered with nothing but laughter."
    "Jestyn respondió con nada más que risas."

# game/day2 choice.rpy:3460
translate Spanish afterconvo_knighter_4fca4ccb:

    # jes "Well, at least some things about you never change~"
    jes "Bueno, al menos algunas cosas de ti nunca cambian~"

# game/day2 choice.rpy:3464
translate Spanish afterconvo_knighter_1ebe8f66:

    # kni "...................."
    kni "...................."

# game/day2 choice.rpy:3465
translate Spanish afterconvo_knighter_f69eb9c2:

    # jes "In that case, until next time... my moooost honorable Sir Knighter~!"
    jes "En ese caso, hasta la próxima... ¡mi muuuuy honorable Sir Knighter~!"

# game/day2 choice.rpy:3469
translate Spanish afterconvo_knighter_7a836130:

    # "Knighter merely rolled his eyes in response."
    "Knighter simplemente puso los ojos en blanco como respuesta."

# game/day2 choice.rpy:3470
translate Spanish afterconvo_knighter_eb7abaa8:

    # "Jestyn then followed me out of Knighter's room."
    "Jestyn me siguió entonces fuera de la habitación de Knighter."

# game/day2 choice.rpy:3472
translate Spanish afterconvo_knighter_3b44cd37:

    # "Overall, talking to Knighter had been pretty difficult. He was a very reserved puppet."
    "En general, hablar con Knighter había sido bastante difícil. Era una marioneta muy reservada."

# game/day2 choice.rpy:3473
translate Spanish afterconvo_knighter_5bd14d6b:

    # "If Jestyn hadn't been there, it probably would've been even harder. Surprisingly, though, Knighter actually listened to him. Jestyn could even pressure him into answering my questions."
    "Si Jestyn no hubiera estado allí, probablemente habría sido aún más difícil. Sorprendentemente, sin embargo, Knighter de verdad le hacía caso. Jestyn incluso podía presionarlo para que respondiera mis preguntas."

# game/day2 choice.rpy:3474
translate Spanish afterconvo_knighter_5a8a3ac0:

    # "Still... I think I need to get closer to Knighter."
    "Aun así... creo que necesito acercarme más a Knighter."

# game/day2 choice.rpy:3475
translate Spanish afterconvo_knighter_cc264967:

    # "He hasn't learned to trust me yet."
    "Todavía no ha aprendido a confiar en mí."

translate Spanish strings:

    # game/day2 choice.rpy:237
    old "Jealous"
    new "Celos"

    # game/day2 choice.rpy:240
    old "Nothing"
    new "Nada"

    # game/day2 choice.rpy:1178
    old "Sit on Jestyn"
    new "Sentarme sobre Jestyn"

    # game/day2 choice.rpy:1182
    old "Sit on the chair"
    new "Sentarme en la silla"

    # game/day2 choice.rpy:1315
    old "Examine the papers."
    new "Examinar los papeles."

    # game/day2 choice.rpy:1318
    old "[wizzyroom_text]"
    new "[wizzyroom_text]"

    # game/day2 choice.rpy:1330
    old "Examine Wizzy's potion shelf"
    new "Examinar el estante de pociones de Wizzy"

    # game/day2 choice.rpy:1333
    old "That's enough"
    new "Ya basta"

    # game/day2 choice.rpy:1525
    old "Stuff a cloth into Jestyn's mouth"
    new "Meterle un trapo en la boca a Jestyn"

    # game/day2 choice.rpy:1576
    old "Leave him be"
    new "Dejarlo en paz"

    # game/day2 choice.rpy:1677
    old "What do you do in your free time?"
    new "¿Qué haces en tu tiempo libre?"

    # game/day2 choice.rpy:1680
    old "I love your hat."
    new "Me encanta tu sombrero."

    # game/day2 choice.rpy:1683
    old "I want to know about your relationship with everyone."
    new "Quiero saber cómo es tu relación con todos."

    # game/day2 choice.rpy:1686
    old "What do you think about the king puppet?"
    new "¿Qué piensas de la Marioneta Rey?"

    # game/day2 choice.rpy:1690
    old "That's all"
    new "Eso es todo"

    # game/day2 choice.rpy:1756
    old "Red rose"
    new "Rosa roja"

    # game/day2 choice.rpy:1759
    old "White rose"
    new "Rosa blanca"

    # game/day2 choice.rpy:1762
    old "Black rose"
    new "Rosa negra"

    # game/day2 choice.rpy:1765
    old "Pink rose"
    new "Rosa rosada"

    # game/day2 choice.rpy:1768
    old "Yellow rose"
    new "Rosa amarilla"

    # game/day2 choice.rpy:1771
    old "Orange rose"
    new "Rosa naranja"

    # game/day2 choice.rpy:1774
    old "Purple rose"
    new "Rosa morada"

    # game/day2 choice.rpy:2244
    old "I'm scared"
    new "Tengo miedo"

    # game/day2 choice.rpy:2247
    old "No, I'm not"
    new "No, no tengo miedo"

    # game/day2 choice.rpy:2624
    old "Examine the wall decorations"
    new "Examinar las decoraciones de la pared"

    # game/day2 choice.rpy:2627
    old "[knighterroom_text]"
    new "[knighterroom_text]"

    # game/day2 choice.rpy:2639
    old "Examine Knighter's book shelf"
    new "Examinar la estantería de Knighter"

    # game/day2 choice.rpy:2744
    old "You're handsome."
    new "Eres guapo."

    # game/day2 choice.rpy:2750
    old "Poke his cheek"
    new "Picarle la mejilla"

    # game/day2 choice.rpy:3370
    old "Poke him again"
    new "Picarlo otra vez"

    # game/day2 choice.rpy:3384
    old "Better stop"
    new "Mejor detenerme"

    # game/day2 choice.rpy:3388
    old "Poke him again."
    new "Picarlo otra vez."

