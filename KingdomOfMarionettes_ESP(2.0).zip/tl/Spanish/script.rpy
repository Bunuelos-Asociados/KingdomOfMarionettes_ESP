# TODO: Translation updated at 2026-11-09 22:40

# game/script.rpy:40
translate Spanish start_629f6a67:

    # "Who would've thought I'd end up trapped in a situation this strange?"
    "¿Quién habría pensado que acabaría en una situación tan extraña?"

# game/script.rpy:41
translate Spanish start_9ece5d1e:

    # "It all started because I was desperately looking for a job."
    "Todo comenzó porque necesitaba desesperadamente encontrar trabajo."

# game/script.rpy:42
translate Spanish start_866fca32:

    # "Of course I was desperate. My savings were running low, and I still had countless living expenses plus debt to pay."
    "Claro que la situación me tenía al límite. Mis ahorros se estaban acabando, y todavía tenía innumerables gastos de vida además de deudas por pagar."

# game/script.rpy:43
translate Spanish start_aaed3db5:

    # "I applied to all kinds of places, but it felt like luck absolutely hated me"
    "Postulé a todo tipo de lugares, pero sentía que la suerte me odiaba por completo."

# game/script.rpy:44
translate Spanish start_b5bd5641:

    # "In a situation like this, I no longer cared what kind of job it was, as long as it paid. Cleaning toilets, catching bears...I'd do anything."
    "En una situación así, ya no me importaba qué tipo de trabajo fuera, mientras pagara. Limpiar baños, atrapar osos… haría lo que fuera."

# game/script.rpy:48
translate Spanish start_eaebbdc6:

    # "That's when I found this job online..."
    "Fue entonces cuando encontré este trabajo en línea…"

# game/script.rpy:49
translate Spanish start_62e8aaa8:

    # "A security position at an abandoned theater. Seriously, why would a place that no longer operates even need a security guard?"
    "Un puesto de seguridad en un teatro abandonado. En serio, ¿por qué un lugar que ya no funciona necesitaría siquiera un guardia de seguridad?"

# game/script.rpy:50
translate Spanish start_b9aa92f5:

    # "Kingdom of Marionettes. I'd heard this place used to be famous for its puppet performances long ago."
    "Kingdom of Marionettes. Había escuchado que este lugar solía ser famoso por sus espectáculos de marionetas hace mucho tiempo."

# game/script.rpy:51
translate Spanish start_d79b2a65:

    # "Oh. Only three duties. Duty number one: keep the theater safe from vandals. Hmm.... I could probably manage that."
    "Oh. Solo tres deberes. Deber número uno: mantener el teatro a salvo de vándalos. Hmm… probablemente pueda encargarme de eso."

# game/script.rpy:52
translate Spanish start_b34bd404:

    # "Duty number two: clean the theater. That's technically outside a security guard's job, but whatever as long as it pays."
    "Deber número dos: limpiar el teatro. Técnicamente eso está fuera del trabajo de un guardia de seguridad, pero da igual mientras paguen."

# game/script.rpy:53
translate Spanish start_7d1d2bbf:

    # "Duty number three: make sure none of the puppets are missing and walking around."
    "Deber número tres: asegurarse de que ninguno de los títeres desaparezca ni ande deambulando."

# game/script.rpy:54
translate Spanish start_5f9b772e:

    # "...."
    "…."

# game/script.rpy:55
translate Spanish start_0ca99485:

    # "Hmm. Maybe I'm so sleep-deprived that I misread it."
    "Hmm. Tal vez llevo tanto tiempo sin dormir que lo leí mal."

# game/script.rpy:60
translate Spanish start_51aac7de:

    # "Make sure none of the puppets are missing...and walking around."
    "Asegurarse de que ninguno de los títeres desaparezca... ni ande deambulando."

# game/script.rpy:61
translate Spanish start_695a6715:

    # "W-wait. Walking around?? Make sure there are no puppets walking around?? What does that even mean?!"
    "E–espera. ¿Caminando?? ¿Asegurarme de que no haya marionetas caminando?? ¿¡Qué significa eso!?"

# game/script.rpy:62
translate Spanish start_f403a2a7:

    # "Hahaha... maybe they meant making sure no one steals the puppets. Yeah. That has to be it. Whoever wrote this must be joking."
    "Jajaja… tal vez querían decir asegurarse de que nadie robe las marionetas. Sí. Tiene que ser eso. Quien haya escrito esto debe estar bromeando."

# game/script.rpy:67
translate Spanish start_0c6f7dd9:

    # "Alright then. Let's do this."
    "Muy bien entonces. Hagámoslo."

# game/script.rpy:74
translate Spanish start_da402c72:

    # "Here it is.... After all this time, I finally got a job."
    "Aquí está… después de tanto tiempo, por fin conseguí un trabajo."

# game/script.rpy:75
translate Spanish start_d72070f1:

    # "Strangely enough, this job didn't require an interview."
    "Curiosamente, este trabajo no requirió una entrevista."

# game/script.rpy:76
translate Spanish start_5879a4bf:

    # "When I contacted them yesterday, everything was settled almost immediately."
    "Cuando los contacté ayer, todo se resolvió casi de inmediato."

# game/script.rpy:77
translate Spanish start_cbab8c3b:

    # "I almost thought this was a scam but thankfully, it wasn't."
    "Casi pensé que era una estafa, pero por suerte no lo era."

# game/script.rpy:78
translate Spanish start_b6586210:

    # "Alright. I have three tasks. First, keep the place safe from vandals. Fortunately, there hasn't been any sign of trouble so far."
    "Bien. Tengo tres tareas. Primero, mantener el lugar a salvo de vándalos. Afortunadamente, no ha habido señales de problemas hasta ahora."

# game/script.rpy:79
translate Spanish start_bdaa902b:

    # "That only leaves cleaning the theater and making sure all the puppets are accounted for."
    "Eso solo deja limpiar el teatro y asegurarme de que todas las marionetas estén presentes."

# game/script.rpy:109
translate Spanish rest_56ca1470:

    # "I head straight back to my room and report to the boss."
    "Regreso directamente a mi habitación y le informo al jefe."

# game/script.rpy:110
translate Spanish rest_0719947f:

    # "All of my tasks are finished. Now all that's left is to stand guard."
    "Todas mis tareas están terminadas. Ahora lo único que queda es hacer guardia."

# game/script.rpy:111
translate Spanish rest_ffa43a97:

    # "Being a security guard doesn't seem so bad. I get paid just for keeping watch."
    "Ser guardia de seguridad no parece tan malo. Me pagan solo por vigilar."

# game/script.rpy:112
translate Spanish rest_7e54efa2:

    # "The pay isn't great, but better than nothing."
    "El pago no es excelente, pero es mejor que nada."

# game/script.rpy:114
translate Spanish rest_a3892342:

    # u "What should I do while I'm on watch...?"
    u "¿Qué debería hacer mientras estoy de guardia…?"

# game/script.rpy:115
translate Spanish rest_c14f26dc:

    # u "I'm so tired... but I can't afford to fall asleep."
    u "Estoy que no doy más… pero no puedo permitirme dormir."

# game/script.rpy:117
translate Spanish rest_945d4661:

    # "I take out my phone and start browsing the internet."
    "Saco mi teléfono y empiezo a navegar por internet."

# game/script.rpy:118
translate Spanish rest_b8f03606:

    # "My knowledge about this theater is still pretty limited and my curiosity gets the better of me, so I decide to look up some information online."
    "Mi conocimiento sobre este teatro sigue siendo bastante limitado y mi curiosidad puede más que yo, así que decido buscar información en línea."

# game/script.rpy:119
translate Spanish rest_991d8857:

    # "Kingdom of Marionettes. A puppet theater that tells the story of the everyday lives of puppets in a kingdom."
    "Kingdom of Marionettes. Un teatro de marionetas que cuenta la historia de la vida cotidiana de las marionetas de un reino."

# game/script.rpy:120
translate Spanish rest_4a83d812:

    # "No wonder the puppets I saw earlier were dressed in outfits from a royal era"
    "Con razón las marionetas que vi antes llevaban vestimentas de la época de la realeza."

# game/script.rpy:121
translate Spanish rest_e0d175a8:

    # "Kingdom of Marionettes was known for its amusing and mesmerizing performances, enhanced by the puppet's charming designs."
    "Kingdom of Marionettes era conocido por sus presentaciones divertidas y fascinantes, realzadas por los encantadores diseños de las marionetas."

# game/script.rpy:123
translate Spanish rest_c77259cb:

    # "Was this place really that famous back then? They even sold merchandise and all kinds of stuff."
    "¿De verdad este lugar era tan famoso en ese entonces? Incluso vendían mercancía y todo tipo de cosas."

# game/script.rpy:124
translate Spanish rest_986f51d2:

    # "There was even a poll for favorite characters. That's kind of cute."
    "Incluso había una encuesta de personajes favoritos. Eso es bastante tierno."

# game/script.rpy:125
translate Spanish rest_14ea2202:

    # "First place went to the jester. People really do like odd characters, huh."
    "El bufón quedó en primer lugar. A la gente sí que le gustan los personajes peculiares, ¿eh?"

# game/script.rpy:126
translate Spanish rest_e0d2acba:

    # "Second place was the knight, and third was the wizard."
    "El segundo lugar fue el caballero, y el tercero el mago."

# game/script.rpy:127
translate Spanish rest_f6468fa0:

    # "I end up getting completely absorbed in all this information about the theater, and before I realize it, I've been scrolling for half an hour."
    "Toda esta información sobre el teatro me atrapa por completo y, antes de darme cuenta, llevo media hora desplazándome."

# game/script.rpy:129
translate Spanish rest_6da0153b:

    # u "Oh crap. I need to check the CCTV."
    u "Oh, rayos. Necesito revisar el CCTV."

# game/script.rpy:166
translate Spanish performance_2e984f22:

    # jespuppet "Mmmm..."
    jespuppet "Mmmm…"

# game/script.rpy:172
translate Spanish performance_52c6096a:

    # "The puppet then snaps his fingers, and in an instant, he disappears from in front of me."
    "Entonces la marioneta chasquea los dedos y, en un instante, desaparece de delante de mí."

# game/script.rpy:173
translate Spanish performance_3e44c6c5:

    # "W-what...? Where did he go now??"
    "E–¿qué…? ¿Adónde se fue ahora?"

# game/script.rpy:182
translate Spanish performance_597ed58b:

    # jespuppet "A hand so small and soft. like cotton... liiiike a kitten's paw."
    jespuppet "Una mano tan pequeña y suave… como algodón… coooomo la patita de un gatito."

# game/script.rpy:187
translate Spanish performance_b5b08ef6:

    # "He is caressing my arm gently with his puppet hand."
    "Acaricia mi brazo suavemente con su mano de marioneta."

# game/script.rpy:189
translate Spanish performance_14d553fd:

    # jespuppet "A form so small... so easily broken... yet somehow brimming with warmth and movement...."
    jespuppet "Una forma tan pequeña… tan frágil… y aun así rebosante de calidez y movimiento…"

# game/script.rpy:190
translate Spanish performance_854a6ec0:

    # jespuppet "A vessel that reacts, trembles, and changes so beautifully....."
    jespuppet "Un recipiente que reacciona, tiembla y cambia de una forma tan hermosa…"

# game/script.rpy:194
translate Spanish performance_49562cdd:

    # jespuppet "And that face.... always shifting, always telling stories without meaning to....."
    jespuppet "Y ese rostro… siempre cambiando, siempre contando historias sin siquiera proponérselo…"

# game/script.rpy:198
translate Spanish performance_0fd4d656:

    # "......"
    "……"

# game/script.rpy:199
translate Spanish performance_2fa81cee:

    # "Is he... examining me???"
    "¿¿¿Me está… examinando???"

# game/script.rpy:201
translate Spanish performance_a86c54f1:

    # jespuppet "You're really are huuuuman."
    jespuppet "Realmente eres un ser huuuumano…"

# game/script.rpy:202
translate Spanish performance_a21fad1a:

    # u "Y-yes...I'm human...."
    u "S–sí… soy un ser humano…"

# game/script.rpy:204
translate Spanish performance_8f13a297:

    # "I reply in a nervous voice, laced with fear."
    "Respondo con una voz nerviosa, cargada de miedo."

# game/script.rpy:208
translate Spanish performance_269b7f47:

    # jespuppet "Seconds passed... then hours... days... weeks... months... years..."
    jespuppet "Pasaron segundos… luego horas… después días… semanas… meses… años…"

# game/script.rpy:209
translate Spanish performance_b886c43e:

    # jespuppet "It has been so very long since all of that faded away."
    jespuppet "Ha pasado tanto tiempo desde que todo aquello se desvaneció."

# game/script.rpy:213
translate Spanish performance_e9ca8105:

    # jespuppet "A kingdom that was once so lively, so magnificent, so full of joy... has now been reduced to silence."
    jespuppet "Un reino que alguna vez fue tan animado, tan magnífico, tan lleno de alegría… ahora ha sido reducido al silencio."

# game/script.rpy:217
translate Spanish performance_815c1411:

    # jespuppet "A kingdom that was once led by a ruler, one who guided us all toward our purpose, toward our lives, has now vanished."
    jespuppet "Un reino que alguna vez fue liderado por un gobernante, alguien que nos guiaba a todos hacia nuestro propósito, hacia nuestras vidas, ahora ha desaparecido."

# game/script.rpy:218
translate Spanish performance_71afbde2:

    # jespuppet "Like fledgling birds abandoned by their parent before they were ever ready to fly, we were left to be guided by confusion... by despair..."
    jespuppet "Como polluelos abandonados por sus padres antes de estar siquiera preparados para volar, quedamos a merced de la confusión… de la desesperación…"

# game/script.rpy:223
translate Spanish performance_be92aa84:

    # jespuppet "We move without direction or destination, not knowing where we are meant to go..."
    jespuppet "Avanzamos sin rumbo ni destino, sin saber hacia dónde debemos ir…"

# game/script.rpy:224
translate Spanish performance_20a833f9:

    # jespuppet "And yet...we believe. That someday... a new light will appear to guide us."
    jespuppet "Y aun así… seguimos creyendo que algún día… aparecerá una nueva luz que nos guíe."

# game/script.rpy:229
translate Spanish performance_8e276719:

    # jespuppet "A leader who will give us life once more and lead us toward the lives we were always meant to live..."
    jespuppet "Un líder que nos devolverá la vida y nos guiará hacia la existencia que siempre debimos tener…"

# game/script.rpy:234
translate Spanish performance_906a604e:

    # jespuppet "We waited... and we hoped. Hoped... and waited. Round and round, over and over until the two became indistinguishable, as though they were never meant to be apart."
    jespuppet "Esperamos… y albergamos esperanza. Albergamos esperanza… y esperamos. Una y otra vez, hasta que ambas cosas se volvieron indistinguibles, como si nunca hubieran debido separarse."

# game/script.rpy:235
translate Spanish performance_7db42dc6:

    # jespuppet "And so, that circle endured. It lingered through the passage of time... until now. Uuuuntil this very day, which quietly dares to call itself a turning point."
    jespuppet "Y así, ese círculo perduró. Se mantuvo a través del paso del tiempo… hasta ahora. Haaasta este mismo día, que silenciosamente se atreve a llamarse a sí mismo un punto de inflexión."

# game/script.rpy:240
translate Spanish performance_347fdeee:

    # jespuppet "Will this circle continue its gentle, merciless dance, unbroken, unchanged?"
    jespuppet "¿Continuará este círculo su suave y despiadada danza, inquebrantable, inmutable?"

# game/script.rpy:241
translate Spanish performance_fcf1079e:

    # jespuppet "Or will it, at last, begin to crack... to fracture... and finally shatter, granting us release from the loop we call life?"
    jespuppet "¿O finalmente comenzará a agrietarse… a fracturarse… y por fin romperse, otorgándonos liberación del ciclo al que llamamos vida?"

# game/script.rpy:243
translate Spanish performance_0fd4d656_1:

    # "......"
    "……"

# game/script.rpy:244
translate Spanish performance_1084310d:

    # "err...What is he talking about so sudden? I don't understand. Is he telling me a fairy tale?"
    "Eh… ¿de qué está hablando tan de repente? No entiendo. ¿Me está contando un cuento de hadas?"

# game/script.rpy:250
translate Spanish performance_461954a5:

    # jespuppet "A kingdom... a place never far removed from politics, a realm steeped in tension, where seriousness lurks beneath its lavish, glittering surface."
    jespuppet "Un reino… un lugar siempre ligado a la política, un territorio cargado de tensiones, donde la solemnidad se esconde bajo una superficie lujosa y deslumbrante."

# game/script.rpy:251
translate Spanish performance_2c4d81b0:

    # jespuppet "Like ice, bitterly cold, it requires at least a touch of warmth. no... perhaps half of that warmth to keep its balance."
    jespuppet "Como el hielo, amargamente frío, requiere al menos un poco de calidez. No… quizás la mitad de esa calidez para mantener su equilibrio."

# game/script.rpy:256
translate Spanish performance_1e2492ef:

    # jespuppet "And that is precisely why I am here. To soften the air, to deliver laughter, to carry joy wherever it dares to fade."
    jespuppet "Y es precisamente por eso que estoy aquí. Para suavizar el ambiente, para brindar risas, para llevar alegría dondequiera que esta se desvanezca."

# game/script.rpy:257
translate Spanish performance_cad34bcc:

    # jespuppet "Now... can you guess who I am?"
    jespuppet "Ahora… ¿puedes adivinar quién soy?"

# game/script.rpy:259
translate Spanish performance_092283e8:

    # "Th-This person... no, this puppet... seems to really enjoy talking..."
    "E–Esta persona… no, esta marioneta… parece disfrutar mucho hablando…"

# game/script.rpy:261
translate Spanish performance_f470b4c3:

    # u "Uh... you're a...jester?"
    u "Eh… ¿eres un… bufón?"

# game/script.rpy:265
translate Spanish performance_3310f055:

    # jespuppet "Ding, ding, ding! Correct!"
    jespuppet "¡Ding, ding, ding! ¡Correcto!"

# game/script.rpy:269
translate Spanish performance_ca2dea47:

    # jes "Though to be precise, jester is merely my role. Allow me to properly introduce myself to you sweet human. My name is Jestyn. You may call me Jestyn."
    jes "Aunque, para ser precisos, bufón es simplemente el papel que interpreto. Permíteme presentarme como es debido, dulc[letra] human[letra]. Mi nombre es Jestyn. Puedes llamarme Jestyn."

# game/script.rpy:270
translate Spanish performance_687eb39c:

    # jes "Though some prefer Jes, Jesy, Tyn-Tyn and quite a few other variations, I'm afraid."
    jes "Aunque algunos prefieren llamarme Jes, Jesy, Tyn-Tyn y de muchas otras formas, me temo."

# game/script.rpy:271
translate Spanish performance_ad2cd72e:

    # jes "Now that I have offered you my name, allow me, just this once to ask for yours in return."
    jes "Ahora que te he ofrecido mi nombre, permíteme, solo esta vez, pedir el tuyo a cambio."

# game/script.rpy:275
translate Spanish performance_9051201a:

    # jes "[player_call]....what a lovely name for such a lovely soul."
    jes "[player_call]… qué nombre tan encantador para un alma tan encantadora."

# game/script.rpy:276
translate Spanish performance_5b8aa077:

    # jes "And your pronoun is?"
    jes "¿Y cuál es tu pronombre?"

# game/script.rpy:279
translate Spanish performance_0b19927d:

    # jes "Understood."
    jes "Entendido."

# game/script.rpy:286
translate Spanish performance_fa21c7df:

    # jes "But tell me... what brings you to this kingdom, I wonder? Are you perhaps carrying out a duty for the crown?"
    jes "Pero dime… me pregunto qué te trae a este reino. ¿Acaso estás cumpliendo algún deber para la corona?"

# game/script.rpy:288
translate Spanish performance_b93672a0:

    # "He keeps referring to this theater as a kingdom. It's starting to confuse me."
    "Sigue refiriéndose a este teatro como un reino. Está empezando a confundirme."

# game/script.rpy:289
translate Spanish performance_b973f6c7:

    # "Also, the way he speaks is really strange."
    "Además, la forma en que habla es realmente extraña."

# game/script.rpy:290
translate Spanish performance_65101f6d:

    # "But... whatever. I'll play along for now. I just want to get out of here as soon as possible."
    "Pero… da igual. Seguiré el juego por ahora. Solo quiero salir de aquí lo antes posible."

# game/script.rpy:292
translate Spanish performance_e96dfe31:

    # mc "I-I'm just a security guard. My job is to watch over this theater... and do a bit of cleaning on the side."
    mc "Y–yo solo soy [arti_2] guardia de seguridad. Mi trabajo es vigilar este teatro… y encargarme también de un poco de limpieza."

# game/script.rpy:294
translate Spanish performance_a175816a:

    # "I hope my answer satisfies him."
    "Espero que mi respuesta lo satisfaga."

# game/script.rpy:298
translate Spanish performance_33c8f8bd:

    # "But suddenly, he starts laughing, and I have no idea why. Is my answer really that amusing to him?"
    "Pero de repente, empieza a reír, y no tengo idea de por qué. ¿De verdad mi respuesta le resulta tan graciosa?"

# game/script.rpy:302
translate Spanish performance_20da2bb0:

    # jes "Ah... a guardian, is it? Such a nooooble calling. A protector of the kingdom, one who stands firm, fighting on until the very last drop of blood."
    jes "Ah… ¿un guardián, dices? Qué nooooble vocación. Un protector del reino, alguien que se mantiene firme, luchando hasta la última gota de sangre."

# game/script.rpy:303
translate Spanish performance_d8bc5de1:

    # jes "And yet... regrettably, you cannot become a guardian here."
    jes "Y sin embargo… lamentablemente, no puedes convertirte en un guardián aquí."

# game/script.rpy:304
translate Spanish performance_519eacf2:

    # mc "W-What do you mean?"
    mc "¿Q–qué quieres decir?"

# game/script.rpy:308
translate Spanish performance_2f9a3173:

    # jes "You see, we already have a knight who serves as this kingdom's shield. His name is Knighter. And we have no intention of welcoming another."
    jes "Verás, ya tenemos a un caballero que sirve como el escudo de este reino. Su nombre es Knighter. Y no tenemos intención de aceptar a otro."

# game/script.rpy:309
translate Spanish performance_34356624:

    # jes "One knight is more than sufficient."
    jes "Un caballero es más que suficiente."

# game/script.rpy:311
translate Spanish performance_d8a0138b:

    # "Is he... talking about roles in this theater?"
    "¿Está… hablando de los roles en este teatro?"

# game/script.rpy:313
translate Spanish performance_c99df6a2:

    # mc "Oh... then I'll just be a cleaner, I guess..."
    mc "Oh… entonces supongo que solo me encargaré de la limpieza…"

# game/script.rpy:317
translate Spanish performance_c71f0f62:

    # jes "We already have plenty of maids here, and I don't think it would be possible for us to add another."
    jes "Ya tenemos suficientes doncellas aquí, y no creo que sea posible añadir otra."

# game/script.rpy:318
translate Spanish performance_5b3dea91:

    # mc "Alright then. I suppose I'll just be no one."
    mc "Muy bien entonces. Supongo que simplemente no seré nadie."

# game/script.rpy:322
translate Spanish performance_4d4e6485:

    # jes "Oh no, no... everyone who comes here must have a role of their own."
    jes "Oh no, no… todo aquel que llega aquí debe tener su propio rol."

# game/script.rpy:323
translate Spanish performance_609b7438:

    # jes "And the role that currently stands vacant... Is the king, the queen, the ruler of the kingdom."
    jes "Y el rol que actualmente está vacante… es el del rey, la reina, el gobernante del reino."

# game/script.rpy:324
translate Spanish performance_f9ed36da:

    # mc "A-Alright... uh... but why is only the position of king empty?? What happened to the previous king?"
    mc "E–está bien… eh… pero ¿¿por qué solo está vacío el puesto de rey?? ¿Qué pasó con el rey anterior?"

# game/script.rpy:326
translate Spanish performance_dc20a6b6:

    # "When I checked the puppets earlier, there was a room labeled 'The King'. So the king puppet must have existed."
    "Cuando revisé las marionetas antes, había una habitación etiquetada como 'El Rey'. Así que la marioneta rey debió haber existido."

# game/script.rpy:330
translate Spanish performance_b2b283fa:

    # jes "Sadly, he passed away."
    jes "Lamentablemente, falleció."

# game/script.rpy:331
translate Spanish performance_f5f15b25:

    # mc "Oh... I'm sorry. My condolences."
    mc "Oh… lo siento. Mis condolencias."

# game/script.rpy:334
translate Spanish performance_17f42cd9:

    # jes "It's alright, my dear. That is simply how life is. people coooome and go. It is part of a cycle you cannot escape. I believe humans understand that very much"
    jes "Está bien, mi querid[letra]. Así es simplemente la vida. La gente va y viiiiene. Es parte de un ciclo del que no puedes escapar. Creo que los humanos entienden muy bien eso."

# game/script.rpy:336
translate Spanish performance_5bf47951:

    # "He then clapped his hands."
    "Luego aplaudió."

# game/script.rpy:340
translate Spanish performance_d94e3c51:

    # jes "It has been a very long time since the king passed. This kingdom has grown terribly dark... filled with silence, without direction or joy."
    jes "Ha pasado mucho tiempo desde que el rey falleció. Este reino se ha vuelto terriblemente oscuro… lleno de silencio, sin dirección ni alegría."

# game/script.rpy:341
translate Spanish performance_1f957725:

    # jes "And I must admit... it has grown rather boring in here."
    jes "Y debo admitir… se ha vuelto bastante aburrido aquí."

# game/script.rpy:342
translate Spanish performance_2e3fca28:

    # jes "But now that I have met such a sweet human before me, why don't you indulge me in a little game, Your majesty?"
    jes "Pero ahora que he conocido a [arti_2] human[letra] tan dulce frente a mí, ¿por qué no me concedes un pequeño juego, Su Majestad?"

# game/script.rpy:343
translate Spanish performance_6c977b5a:

    # mc "..... Your majesty? me?"
    mc "….. ¿Su Majestad? ¿yo?"

# game/script.rpy:347
translate Spanish performance_e6d429b2:

    # "His smile widened."
    "Su sonrisa se ensanchó."

# game/script.rpy:351
translate Spanish performance_9bc84d96:

    # jes "Yes. Let us play a bit of acting. You shall pretend to be the [title], and I.. will be your jester."
    jes "Sí. Juguemos un poco a actuar. Tú fingirás ser [arti] [title!t], y yo… seré tu bufón."

# game/script.rpy:355
translate Spanish performance_fc5d52a4:

    # jes "Oh, do forgive me. I have been a jester from the very beginning. How foolish of me."
    jes "Oh, perdóname. He sido un bufón desde el principio. Qué torpe de mi parte."

# game/script.rpy:358
translate Spanish performance_2eb4cb07:

    # "Jestyn then snapped his fingers, and before i knew it, He had moved into the stage."
    "Jestyn chasqueó los dedos y, antes de darme cuenta, se había movido al escenario."

# game/script.rpy:369
translate Spanish performance_1a9aa838:

    # jes "Now then... shall we allow the performance to begin?"
    jes "Ahora bien… ¿permitimos que la función comience?"

# game/script.rpy:370
translate Spanish performance_bfbd0f10:

    # mc "W-wait, wait! I've never acted before! I don't even know how-"
    mc "E–espera, ¡espera! ¡Nunca he actuado antes! ¡Ni siquiera sé cómo—"

# game/script.rpy:371
translate Spanish performance_a65eb2d5:

    # jes "Oh no, my dear... Simply live, as though you have always been the [title] of this kingdom."
    jes "Oh no, mi querid[letra]… Simplemente vive, como si siempre hubieras sido [arti] [title!t] de este reino."

# game/script.rpy:376
translate Spanish performance_63b4ff1c:

    # "Jestyn snapped his fingers again."
    "Jestyn volvió a chasquear los dedos."

# game/script.rpy:383
translate Spanish performance_9f46e3f4:

    # "And in an instant, I found myself already on the stage. Seated upon a plush throne, a crown resting atop my head."
    "Y en un instante, me encontré ya en el escenario, sentad[letra] en un lujoso trono, con una corona descansando sobre mi cabeza."

# game/script.rpy:389
translate Spanish performance_a4cb69fc:

    # mc "Wha- what?!"
    mc "¿¡Qu–qué!?"

# game/script.rpy:390
translate Spanish performance_88a957a0:

    # nara "{color=#E0AE4B}One day, beneath the scorching summer sun, the kingdom was struck by trouble once more. The farmers were filled with sorrow as the relentless heat of summer scorched the land.{/color}"
    nara "{color=#E0AE4B}Un día, bajo el abrasador sol del verano, una nueva desgracia azotó el reino. Los agricultores estaban desolados mientras el implacable calor veraniego abrasaba la tierra.{/color}"

# game/script.rpy:391
translate Spanish performance_51554ab9:

    # nara "{color=#E0AE4B}Crops withered and failed under the drought, leaving the fields barren. As a result, the farmers suffered great losses, with no harvest left to sell.{/color}"
    nara "{color=#E0AE4B}Los cultivos se marchitaron y se perdieron a causa de la sequía, dejando los campos desolados. Como resultado, los agricultores sufrieron grandes pérdidas, pues ya no tenían cosecha que vender.{/color}"

# game/script.rpy:392
translate Spanish performance_8364a461:

    # nara "{color=#E0AE4B}In the end, the farmers brought their plight before [poss] Majesty, hoping [subj] might receive aid and relief.{/color}"
    nara "{color=#E0AE4B}Al final, los granjeros llevaron su situación ante Su Majestad, con la esperanza de que [subj!t] les brindara ayuda y alivio.{/color}"

# game/script.rpy:394
translate Spanish performance_c231e200:

    # "I looked around, trying to find the source of the voice that sounded like a narrator."
    "Miré a mi alrededor, intentando encontrar la fuente de la voz que sonaba como un narrador."

# game/script.rpy:396
translate Spanish performance_4386de70:

    # nara "{color=#E0AE4B}Within the kingdom, [poss] Majesty sat upon [poss] throne, [poss] expression clouded with confusion, when Jestyn, the royal jester appeared before [poss] to relay the troubles faced by the farmers.{/color}"
    nara "{color=#E0AE4B}Dentro del reino, Su Majestad se encontraba sentad[letra] en su trono, con su expresión nublada por la confusión, cuando Jestyn, el bufón real, apareció ante Su Majestad para transmitirle los problemas que enfrentaban los granjeros.{/color}"

# game/script.rpy:401
translate Spanish performance_01422283:

    # jes "Good evening, Your majesty."
    jes "Buenas noches, Su Majestad."

# game/script.rpy:403
translate Spanish performance_a64afe78:

    # "Jestyn appear and bowed before me with utmost reverence."
    "Jestyn apareció y se inclinó ante mí con la mayor reverencia."

# game/script.rpy:408
translate Spanish performance_e9042124:

    # jes "What a truuuuly beautiful day today is."
    jes "Qué día taaaan verdaderamente hermoso es hoy."

# game/script.rpy:409
translate Spanish performance_abdeb370:

    # jes "A day just as fitting to tend to the little troubles stirring within the kingdom... Wouldn't you agree, Your Majesty?"
    jes "Un día igualmente adecuado para atender los pequeños problemas que surgen dentro del reino… ¿no está de acuerdo, Su Majestad?"

# game/script.rpy:410
translate Spanish performance_f95a4fa4:

    # mc "Troubles... in the kingdom?"
    mc "¿Problemas… en el reino?"

# game/script.rpy:411
translate Spanish performance_4874d63f:

    # jes "Indeed, Your Majesty."
    jes "En efecto, Su Majestad."

# game/script.rpy:415
translate Spanish performance_f9c09460:

    # jes "As of late, the townsfolk have begun to voice their worries. The harvests have failed, brought low by the relentless drought of the dry season."
    jes "Últimamente, los habitantes del pueblo han comenzado a expresar sus preocupaciones. Las cosechas han fracasado, abatidas por la implacable sequía de la estación seca."

# game/script.rpy:416
translate Spanish performance_05d74c2d:

    # jes "And as one might expect, such misfortune has left them... quite lacking in means."
    jes "Y como era de esperarse, tal infortunio los ha dejado… bastante faltos de recursos."

# game/script.rpy:422
translate Spanish performance_b428ab79:

    # jes "Please come in dear, guest."
    jes "Por favor, pase, querido invitado."

# game/script.rpy:423
translate Spanish performance_d534aa3a:

    # nara "{color=#E0AE4B}A man who worked as a farmer then entered, after Jestyn granted the man permission to enter.{/color}"
    nara "{color=#E0AE4B}Un hombre que trabajaba como granjero entró entonces, después de que Jestyn le concediera permiso para pasar.{/color}"

# game/script.rpy:425
translate Spanish performance_e943668d:

    # "Suddenly, a puppet dressed as a farmer stepped forward and knelt before me."
    "De repente, una marioneta vestida como granjero dio un paso al frente y se arrodilló ante mí."

# game/script.rpy:429
translate Spanish performance_b64f7501:

    # farm "Greetings, Your Majesty. Please forgive my boldness, but we come before you to humbly seek your aid."
    farm "Saludos, Su Majestad. Por favor, perdone mi atrevimiento, pero venimos ante usted para solicitar humildemente su ayuda."

# game/script.rpy:430
translate Spanish performance_8578e918:

    # farm "Due to the failed harvests, we no longer have the means to replace the crops that withered, nor do we have the funds to meet our daily needs..."
    farm "Debido al fracaso de las cosechas, ya no tenemos los medios para reemplazar los cultivos que se marchitaron, ni contamos con fondos para cubrir nuestras necesidades diarias…"

# game/script.rpy:431
translate Spanish performance_9d72adad:

    # farm "Thus, we beg you... to grant us your guidance."
    farm "Por lo tanto, le suplicamos… que nos brinde su guía."

# game/script.rpy:433
translate Spanish performance_972b6338:

    # "Having been dragged into the role of a [title] without warning, confusion washed over me."
    "Después de verme arrastrad[letra] sin previo aviso al papel de [title!t], la confusión se apoderó de mí."

# game/script.rpy:434
translate Spanish performance_595efd78:

    # "My own troubles were far from resolved, and now I was expected to find a way to save the farmers as well?!"
    "Mis propios problemas estaban lejos de resolverse, ¿¡y ahora se esperaba que encontrara una manera de salvar también a los granjeros!?"

# game/script.rpy:436
translate Spanish performance_ec04fee4:

    # mc "U-um..."
    mc "E–eh…"

# game/script.rpy:438
translate Spanish performance_15a64d5d:

    # "What am I supposed to do...?"
    "¿Qué se supone que debo hacer…?"

# game/script.rpy:493
translate Spanish problem2_e3bea3c4:

    # mc "..... Is it finished?"
    mc "….. ¿Ya terminó?"

# game/script.rpy:496
translate Spanish problem2_70f8e564:

    # jes "Finished?"
    jes "¿Terminó?"

# game/script.rpy:498
translate Spanish problem2_fb4c14c0:

    # jes "If governing a kingdom were that simple, Your Majesty, I fear we would have far fewer queens."
    jes "Si gobernar un reino fuera tan sencillo, Su Majestad, me temo que tendríamos muchas menos reinas."

# game/script.rpy:500
translate Spanish problem2_eef100ec:

    # "There's still more..."
    "Aún hay más…"

# game/script.rpy:505
translate Spanish problem2_a7674f73:

    # nara "{color=#E0AE4B}The day passed slowly within the kingdom. And without [poss] Majesty realizing it, the time that had once shown nine in the morning had already advanced to one in the afternoon.{/color}"
    nara "{color=#E0AE4B}El día transcurrió lentamente dentro del reino. Y sin que Su Majestad lo notara, el tiempo que una vez marcaba las nueve de la mañana ya había avanzado hasta la una de la tarde.{/color}"

# game/script.rpy:506
translate Spanish problem2_a95fab49:

    # nara "{color=#E0AE4B}At that very moment, a formal letter from another kingdom suddenly arrived.{/color}"
    nara "{color=#E0AE4B}En ese preciso momento, una carta formal de otro reino llegó repentinamente.{/color}"

# game/script.rpy:507
translate Spanish problem2_a5e90a9f:

    # nara "{color=#E0AE4B}Upon learning of this, the butler promptly took the letter and set out to deliver it to [poss] Majesty.{/color}"
    nara "{color=#E0AE4B}Al enterarse de esto, el mayordomo tomó rápidamente la carta y se dispuso a entregársela a Su Majestad.{/color}"

# game/script.rpy:514
translate Spanish problem2_007b68af:

    # "Suddenly, a butler-dressed puppet approached Jestyn and handed him a parchment scroll."
    "De repente, una marioneta vestida de mayordomo se acercó a Jestyn y le entregó un pergamino."

# game/script.rpy:518
translate Spanish problem2_9ad1e23c:

    # "Jestyn read it for a moment. His expression turned focused, before his eyes shifted toward me and that wide smile returned to his face."
    "Jestyn lo leyó durante unos instantes. Su expresión se tornó seria y concentrada; luego volvió la mirada hacia mí y recuperó aquella amplia sonrisa."

# game/script.rpy:522
translate Spanish problem2_65c94ba0:

    # jes "Your Majesty, we have received a most astonishing and rather intriguing request from a neighboring kingdom."
    jes "Su Majestad, hemos recibido una solicitud sumamente asombrosa y bastante intrigante de un reino vecino."

# game/script.rpy:526
translate Spanish problem2_33b6191e:

    # "It is all written here, in ink, upon this scroll."
    "Todo está escrito aquí, en tinta, sobre este pergamino."

# game/script.rpy:530
translate Spanish problem2_ebec001e:

    # jes "In short, they wish to purchase a small piece of land along our border, under the pretense of facilitating trade."
    jes "En resumen, desean comprar una pequeña porción de tierra a lo largo de nuestra frontera, bajo el pretexto de facilitar el comercio."

# game/script.rpy:533
translate Spanish problem2_e32448da:

    # jes "Should Your Majesty agree to this arrangement, they are prepared to offer compensation in gold coins. an amount I am quite certain would give Your Majesty a heart attack on the spot~"
    jes "Si Su Majestad acepta este acuerdo, están dispuestos a ofrecer una compensación en monedas de oro. Una suma que, estoy bastante segur[letra], le provocaría un infarto en el acto~"

# game/script.rpy:534
translate Spanish problem2_f70a91f0:

    # jes "So then.... what will you do, Your Majesty?"
    jes "Entonces… ¿qué hará, Su Majestad?"

# game/script.rpy:536
translate Spanish problem2_445e6ea5:

    # "Oh no... this is starting to sound complicated. What should I do?"
    "Oh no… esto está empezando a sonar complicado. ¿Qué debería hacer?"

# game/script.rpy:578
translate Spanish after_acting_20edf98e:

    # jes "Very well then. I shall inform our neighbors of Your Majesty's will."
    jes "Muy bien entonces. Informaré a nuestros vecinos de la voluntad de Su Majestad."

# game/script.rpy:579
translate Spanish after_acting_8942a864:

    # jes "And I believe that, for now, the matters Your Majesty was required to resolve have reached the end of today's program."
    jes "Y creo que, por ahora, los asuntos que Su Majestad debía resolver concluyen aquí por hoy."

# game/script.rpy:580
translate Spanish after_acting_917307e9:

    # jes "You may rest your head now your majesty~"
    jes "Puede descansar ahora, Su Majestad~"

# game/script.rpy:582
translate Spanish after_acting_65db4673:

    # "Finally..... it ends. I don't know if my brain can handle these kingdom things anymore."
    "Por fin… terminó. No sé si mi cerebro puede soportar más asuntos del reino."

# game/script.rpy:585
translate Spanish after_acting_e6132cd8:

    # "Before i finally able to let myself relax, my phone rang."
    "Justo cuando por fin iba a poder relajarme, sonó mi teléfono."

# game/script.rpy:586
translate Spanish after_acting_7578997d:

    # "Oh no... it has to be my debt collector."
    "Oh no… tiene que ser el cobrador de deudas."

# game/script.rpy:588
translate Spanish after_acting_827af99b:

    # "I really don't want to deal with this right now. I don't have the money to pay."
    "De verdad no quiero lidiar con esto ahora mismo. No tengo el dinero para pagar."

# game/script.rpy:589
translate Spanish after_acting_89f3d788:

    # "But I don't really have a choice..."
    "Pero realmente no tengo elección…"

# game/script.rpy:592
translate Spanish after_acting_4e85cb4d:

    # mc "Hello?"
    mc "¿Hola?"

# game/script.rpy:593
translate Spanish after_acting_85276275:

    # debt "[player_call]! You know why I'm calling, don't you?"
    debt "¡[player_call]! ¿Sabes por qué te estoy llamando, verdad?"

# game/script.rpy:594
translate Spanish after_acting_5a64fdcd:

    # mc "Of course...."
    mc "Claro…"

# game/script.rpy:595
translate Spanish after_acting_d0d55219:

    # debt "So?"
    debt "¿Entonces?"

# game/script.rpy:596
translate Spanish after_acting_aaa27f92:

    # mc "I'm sorry... I can't pay it right now."
    mc "Lo siento… no puedo pagarlo ahora mismo."

# game/script.rpy:597
translate Spanish after_acting_18aa1915:

    # mc "But I just got a job again. You just need to wait until payday."
    mc "Pero acabo de conseguir un trabajo otra vez. Solo necesitas esperar hasta el día de pago."

# game/script.rpy:599
translate Spanish after_acting_6f0dcc7c:

    # debt "Haaah... fine. But remember, you've already delayed this for five months."
    debt "Haaah… está bien. Pero recuerda, ya has retrasado esto por cinco meses."

# game/script.rpy:600
translate Spanish after_acting_cc837eb4:

    # mc "I know... I know... thank you for your understanding..."
    mc "Lo sé… lo sé… gracias por tu comprensión…"

# game/script.rpy:603
translate Spanish after_acting_17c0a825:

    # "Moments after ending the call, I leaned my body against my seat, needing a brief rest."
    "Unos instantes después de terminar la llamada, me recosté en el asiento, necesitaba descansar un momento."

# game/script.rpy:604
translate Spanish after_acting_3345f35d:

    # "I have to pay it within a month..."
    "Tengo que pagarlo en un mes…"

# game/script.rpy:606
translate Spanish after_acting_a63b6d6b:

    # "I ran my fingers through my hair in frustration, before remembering that Jestyn was still standing in front of me."
    "Pasé mis dedos por mi cabello con frustración, antes de recordar que Jestyn aún estaba frente a mí."

# game/script.rpy:608
translate Spanish after_acting_557c49c4:

    # mc "Oh- sorry, Jestyn. That was just a personal matter-"
    mc "Oh— lo siento, Jestyn. Eso era solo un asunto personal—"

# game/script.rpy:614
translate Spanish after_acting_bc5e5db2:

    # "Suddenly, Jestyn's hand gently closed around my shoulder. He looked at me with that wide smile of his."
    "De repente, la mano de Jestyn se cerró suavemente sobre mi hombro. Me miró con esa amplia sonrisa suya."

# game/script.rpy:616
translate Spanish after_acting_4ae5b7c3:

    # jes "Your Majesty, your personal matters are the kingdom's matters."
    jes "Su Majestad, sus asuntos personales son asuntos del reino."

# game/script.rpy:617
translate Spanish after_acting_4eb2beb1:

    # jes "And that makes them my concern as well, as the kingdom's jester."
    jes "Y eso los convierte en mi preocupación también, como bufón del reino."

# game/script.rpy:620
translate Spanish after_acting_be56e838:

    # jes "From what I observed in your conversation through that technology just now, it seems Your Majesty is in debt... to another kingdom, am I correct?"
    jes "Por lo que observé en su conversación a través de esa tecnología hace un momento, parece que Su Majestad está en deuda… con otro reino, ¿estoy en lo correcto?"

# game/script.rpy:621
translate Spanish after_acting_2b35b6fe:

    # mc "..."
    mc "…"

# game/script.rpy:622
translate Spanish after_acting_07f99d29:

    # mc "Yeah...."
    mc "Sí…"

# game/script.rpy:624
translate Spanish after_acting_fbbe8638:

    # "His hand on my shoulder gently kneaded the tension away. Instantly, I felt myself relax."
    "Me masajeó suavemente el hombro, aliviando la tensión que llevaba encima. Al instante, sentí cómo me relajaba."

# game/script.rpy:627
translate Spanish after_acting_3a4a6a82:

    # jes "You may tell me your troubles, Your Majesty."
    jes "Puede contarme sus problemas, Su Majestad."

# game/script.rpy:628
translate Spanish after_acting_ddf56c7b:

    # jes "After all, I am your most loyal and only jester..."
    jes "Después de todo, soy su bufón más leal… y el único…"

# game/script.rpy:631
translate Spanish after_acting_0fd4d656:

    # "......"
    "……"

# game/script.rpy:634
translate Spanish after_acting_ae6e7c9e:

    # mc "... I've been thinking about the kingdom's finances for a long time now. They've been dwindling more and more."
    mc "… He estado pensando en las finanzas del reino durante mucho tiempo. Han estado disminuyendo cada vez más."

# game/script.rpy:637
translate Spanish after_acting_164f9f77:

    # jes "Oh my~"
    jes "Oh, vaya~"

# game/script.rpy:638
translate Spanish after_acting_e0fe2d11:

    # mc "Yeah... back then I..... you could say I formed a sort of friendship with the ruler of another kingdom."
    mc "Sí… en aquel entonces yo… podría decirse que entablé cierta amistad con el gobernante de otro reino."

# game/script.rpy:639
translate Spanish after_acting_2ea7ab35:

    # mc "That kingdom needed help because they were facing a similar problem."
    mc "Ese reino necesitaba ayuda porque enfrentaba un problema similar."

# game/script.rpy:640
translate Spanish after_acting_f6c68c16:

    # mc "But In the end, that kingdom was only exploiting me, and then they betrayed me."
    mc "Pero al final, ese reino solo me estaba utilizando y luego me traicionó."

# game/script.rpy:641
translate Spanish after_acting_45f2d9f0:

    # mc "So... I had to borrow funds from other kingdoms. And now... our kingdom is burdened with considerable debt."
    mc "Así que… tuve que pedir dinero prestado a otros reinos. Y ahora… nuestro reino arrastra una deuda considerable."

# game/script.rpy:642
translate Spanish after_acting_fff70632:

    # mc "I've been trying to find other sources of income just to keep things stable."
    mc "He estado tratando de encontrar otras fuentes de ingresos solo para mantener la estabilidad."

# game/script.rpy:645
translate Spanish after_acting_f35ef482:

    # "After I explained all my troubles through full of metaphors, Jestyn said nothing for a while."
    "Después de explicarle todos mis problemas, llenos de metáforas, Jestyn permaneció en silencio durante un rato."

# game/script.rpy:646
translate Spanish after_acting_3d1a6ef7:

    # "Silence wrapped itself around the air between us."
    "El silencio envolvió el aire entre nosotros."

# game/script.rpy:649
translate Spanish after_acting_ed5ba8b5:

    # jes "Do you know why the lion is honored as the king of the forest, Your Majesty?"
    jes "¿Sabe por qué se considera al león el rey del bosque, Su Majestad?"

# game/script.rpy:652
translate Spanish after_acting_d1dd8d04:

    # "For a second, i feel confused by his sudden question about lion"
    "Por un instante, me desconcertó su repentina pregunta sobre los leones."

# game/script.rpy:655
translate Spanish after_acting_f9a03031:

    # mc "Um... because they're majestic?"
    mc "Eh… ¿porque son majestuosos?"

# game/script.rpy:656
translate Spanish after_acting_ff7db947:

    # jes "Indeed. They are majestic. They are fearsome. They are resilient, apex predators, standing at the very top."
    jes "En efecto. Son majestuosos. Son temibles. Son resilientes, depredadores alfa, situados en la cima."

# game/script.rpy:657
translate Spanish after_acting_8a60221d:

    # jes "Now, imagine a rabbit. Why is the rabbit never called the king of the forest?"
    jes "Ahora imagine un conejo. ¿Por qué nunca se considera al conejo el rey del bosque?"

# game/script.rpy:658
translate Spanish after_acting_732e8b36:

    # mc "Because... rabbits are too gentle? Small? Not frightening enough?"
    mc "Porque… ¿los conejos son demasiado dóciles? ¿Pequeños? ¿No lo suficientemente intimidantes?"

# game/script.rpy:659
translate Spanish after_acting_7f9f0b7b:

    # jes "Gentle."
    jes "Dóciles."

# game/script.rpy:661
translate Spanish after_acting_d44128d2:

    # jes "Far too hesitant.. and, ah, tragically human."
    jes "Demasiado dubitativos… y, ah, trágicamente humanos."

# game/script.rpy:662
translate Spanish after_acting_0c515d6e:

    # jes "And most importantly... trusting others a little too easily."
    jes "Y lo más importante… confían en los demás con demasiada facilidad."

# game/script.rpy:663
translate Spanish after_acting_edfe729e:

    # jes "Very noble qualities... for a suffering soul. Less so for a [title]."
    jes "Cualidades muy nobles… para un alma sufriente. No tanto para [arti] [title!t]."

# game/script.rpy:665
translate Spanish after_acting_2669f073:

    # jes "You thought that by helping others, they would like you. That they would smile at you, stand beside you, and call you a friend."
    jes "Pensaste que, al ayudar a los demás, te querrían. Que te sonreirían, estarían a tu lado y te llamarían amig[letra]."

# game/script.rpy:666
translate Spanish after_acting_12293362:

    # jes "And then BOOM! What a delightful surprise! You have been fooled! Tricked! Played like a lovely little tune! Hahahahahaha!"
    jes "¡Y entonces, BOOM! ¡Qué sorpresa tan encantadora! ¡Te engañaron! ¡Te tomaron el pelo! ¡Te hicieron bailar a su ritmo como si fueras una dulce melodía! ¡Jajajajajajaja!"

# game/script.rpy:669
translate Spanish after_acting_b3646884:

    # "He laugh maniacly"
    "Se rió de forma maniaca."

# game/script.rpy:672
translate Spanish after_acting_0ed5166b:

    # jes "Isn't that just perfectly ironic?"
    jes "¿No es perfectamente irónico?"

# game/script.rpy:675
translate Spanish after_acting_0fc512df:

    # "Jestyn spoke with a smile, each laugh delicate and polite... yet every word felt like a sharp blade pressed against my chest."
    "Jestyn habló con una sonrisa, cada risa delicada y educada… pero cada palabra se sentía como una afilada hoja presionada contra mi pecho."

# game/script.rpy:676
translate Spanish after_acting_c0fc5d9d:

    # "I once read that a jester's task in a kingdom... is to entertain. And part of that... is revealing truth through jest."
    "Una vez leí que la tarea de un bufón en un reino… es entretener. Y parte de eso… es revelar la verdad a través de la burla."

# game/script.rpy:689
translate Spanish funny_ff9d3655:

    # "I see it now. yes, i must follow the game."
    "Ya lo veo. Sí… debo seguir el juego."

# game/script.rpy:692
translate Spanish funny_e04a833a:

    # mc "Hahahaha! you're... not wrong Jestyn."
    mc "¡Jajajaja! No estás… equivocad[letra], Jestyn."

# game/script.rpy:699
translate Spanish annoying_444727e3:

    # "But the way he said that..."
    "Pero la forma en que dijo eso…"

# game/script.rpy:700
translate Spanish annoying_8ea1f22a:

    # "His words piercing deadly throught my heart"
    "Sus palabras me atravesaban el corazón como cuchillas."

# game/script.rpy:701
translate Spanish annoying_b7842494:

    # "I won't lie, that's so annoying"
    "No voy a mentir, eso es muy molesto."

# game/script.rpy:709
translate Spanish advice_8369cbcc:

    # jes "You see, Your Majesty, the rules of this world are not some sweet little fable where kindness is always repaid in kind. I believe you already know it."
    jes "Verá, Su Majestad, las reglas de este mundo no son un cuento de hadas donde la bondad siempre se devuelve con la misma moneda. Creo que ya lo sabe."

# game/script.rpy:710
translate Spanish advice_aceede3e:

    # jes "Sometimes the game is far simpler than that. Sometimes, the rule is merely eat... or be eaten."
    jes "A veces el juego es mucho más simple que eso. A veces, la regla es simplemente devorar… o ser devorado."

# game/script.rpy:711
translate Spanish advice_5a4a31da:

    # mc "Do you mean I should become a lion?"
    mc "¿Quieres decir que debería convertirme en un león?"

# game/script.rpy:713
translate Spanish advice_45864e6b:

    # jes "Oh no, no, Your Majesty. That won't be necessary. Why, the look on your face alone, so deprived of sleep is already quite terrifying."
    jes "Oh, no, no, Su Majestad. No será necesario. ¡Vaya! Con esa cara de no haber dormido nada, ya resulta bastante aterrador."

# game/script.rpy:715
translate Spanish advice_520b089f:

    # "He laughs mockingly as he watches me frowned"
    "Se ríe burlonamente al verme fruncir el ceño."

# game/script.rpy:717
translate Spanish advice_1b24106c:

    # jes "Hehe, forgive me, Your Majesty. I was only joking. I am not telling you to become a lion."
    jes "Jeje, perdóneme, Su Majestad. Solo estaba bromeando. No le estoy diciendo que se convierta en un león."

# game/script.rpy:719
translate Spanish advice_f2e1bab4:

    # jes "Have you ever considered... combining a rabbit and a lion?"
    jes "¿Alguna vez ha considerado… combinar un conejo y un león?"

# game/script.rpy:720
translate Spanish advice_d3a14d1c:

    # mc "Uh...wouldn't that look like some kind of mutant?"
    mc "Eh… ¿no se vería como una especie de mutante?"

# game/script.rpy:722
translate Spanish advice_b39d6b88:

    # jes "Not that sort of combination, Your Majesty..."
    jes "No ese tipo de combinación, Su Majestad…"

# game/script.rpy:724
translate Spanish advice_f34bf4fe:

    # "He waves a finger lightly."
    "Hace un ligero gesto con el dedo."

# game/script.rpy:727
translate Spanish advice_35e34081:

    # jes "The appearance of a rabbit, yet the heart of a lion. Like a wolf beneath sheep's clothing if you ask me."
    jes "La apariencia de un conejo, pero el corazón de un león. Como un lobo con piel de oveja, si me pregunta."

# game/script.rpy:729
translate Spanish advice_21d73933:

    # "He pause."
    "Hace una pausa."

# game/script.rpy:731
translate Spanish advice_54063081:

    # jes "And also... trust only those around you whom you truly know."
    jes "Y además… confíe únicamente en quienes realmente conoce y tiene cerca."

# game/script.rpy:732
translate Spanish advice_df231ede:

    # jes "Those who will remain loyal to you, no matter what. Difficult? Yes. But that is simply the truth."
    jes "Aquellos que permanecerán leales a usted, pase lo que pase. ¿Difícil? Sí. Pero esa es simplemente la verdad."

# game/script.rpy:735
translate Spanish advice_50a39fa6:

    # jes "And after that... perhaps, those loyal to you may even help you destroy the ones who have hurt you."
    jes "Y después de eso… quizá aquellos leales a usted incluso le ayuden a destruir a quienes le han hecho daño."

# game/script.rpy:736
translate Spanish advice_e2419ffb:

    # jes "{color=#FF2727}Just for you.{/color}"
    jes "{color=#FF2727}Solo por usted.{/color}"

# game/script.rpy:739
translate Spanish advice_47adc674:

    # jes "You do understand what I mean, do you not, Your Majesty?"
    jes "Entiende lo que quiero decir, ¿no es así, Su Majestad?"

# game/script.rpy:741
translate Spanish advice_2f85c766:

    # "His words leave me lost in thought."
    "Sus palabras me dejan perdid[letra] en mis pensamientos."

# game/script.rpy:742
translate Spanish advice_d8581df8:

    # "Now that I think about it... I really am a people pleaser."
    "Ahora que lo pienso… realmente soy alguien que busca complacer a los demás."

# game/script.rpy:744
translate Spanish advice_325689fc:

    # mc "I understand... but changing that isn't easy."
    mc "Lo entiendo… pero cambiar eso no es fácil."

# game/script.rpy:746
translate Spanish advice_e13b0076:

    # "Jestyn lets out a soft chuckle. His eyes narrow as his smile slowly widens."
    "Jestyn deja escapar una suave risa. Sus ojos se entrecierran mientras su sonrisa se ensancha lentamente."

# game/script.rpy:748
translate Spanish advice_bab18eb3:

    # jes "Quite right, Your Majesty... and that is precisely why."
    jes "Muy cierto, Su Majestad… y es precisamente por eso."

# game/script.rpy:750
translate Spanish advice_64883bc1:

    # jes "Perhaps instead of asking what more you can give... you should ask yourself what you are still refusing to take."
    jes "Tal vez, en lugar de preguntarse qué más puede dar… debería preguntarse qué es lo que aún se niega a tomar."

# game/script.rpy:755
translate Spanish advice_891258a4:

    # "Jestyn steps away from me, giving me space to ponder the meaning of his words."
    "Jestyn se aleja de mí, dándome espacio para reflexionar sobre el significado de sus palabras."

# game/script.rpy:756
translate Spanish advice_4c28949b:

    # "His words are always hard to understand..."
    "Sus palabras siempre son difíciles de entender…"

# game/script.rpy:758
translate Spanish advice_9e9daed2:

    # "He clapped his hands, snapping me out of my thoughts."
    "Aplaude, sacándome de mis pensamientos."

# game/script.rpy:760
translate Spanish advice_40b7afeb:

    # jes "Now... allow me to present you with entertaintment. You must be tired working all day yes, your majesty?"
    jes "Ahora… permítame ofrecerle un espectáculo. Debe de estar cansad[letra] después de trabajar todo el día, ¿verdad, Su Majestad?"

# game/script.rpy:761
translate Spanish advice_62999dc6:

    # jes "Much as I adore that expression of yours, like a bat awakened in broad daylight. I would still rather not seeing you forever wearing a face so utterly devoid of joy..."
    jes "Por mucho que me encante esa expresión suya, como la de un murciélago despertado a plena luz del día, preferiría no verle siempre con un rostro tan falto de alegría…"

# game/script.rpy:763
translate Spanish advice_3bdcf7c5:

    # "He chuckles softly. It leaves me with far too little to laugh at."
    "Él suelta una risita. A mí, en cambio, no me causa tanta gracia."

# game/script.rpy:765
translate Spanish advice_1d738662:

    # jes "I shall make you smile once more. Melting the chill of your life with the fire of delight I bring."
    jes "Haré que vuelva a sonreír. Derretiré el frío de su vida con el fuego de la alegría que traigo."

# game/script.rpy:767
translate Spanish advice_767cd509:

    # jes "Allow me~"
    jes "Permítame~"

# game/script.rpy:769
translate Spanish advice_13e168ae:

    # "Jestyn snapped his fingers. In an instant something appears on his hands."
    "Jestyn chasquea los dedos. En un instante, algo aparece en sus manos."

# game/script.rpy:770
translate Spanish advice_0a0d80da:

    # "It was a small rectangular object, wrapped in a layer of gold and tied neatly with a red ribbon."
    "Era un pequeño objeto rectangular, envuelto en una capa dorada y atado cuidadosamente con una cinta roja."

# game/script.rpy:773
translate Spanish advice_def0ad19:

    # mc "What is it?"
    mc "¿Qué es?"

# game/script.rpy:777
translate Spanish advice_31a87d5e:

    # "Jestyn then handed it to me, allowing me to open it myself."
    "Jestyn me lo entregó para que pudiera abrirlo por mi cuenta."

# game/script.rpy:779
translate Spanish advice_eabac4e2:

    # mc "Chocolate?"
    mc "¿Chocolate?"

# game/script.rpy:781
translate Spanish advice_565b9561:

    # jes "Indeed, Your Majesty. Everyone loves chocolate. Who doesn't? So I do hope you'll like it."
    jes "En efecto, Su Majestad. A todo el mundo le gusta el chocolate. ¿A quién no? Así que espero que le guste."

# game/script.rpy:782
translate Spanish advice_05fb4f9e:

    # jes "And it's not just any ordinary chocolate."
    jes "Y no es un chocolate cualquiera."

# game/script.rpy:784
translate Spanish advice_e1d95d7c:

    # jes "I crafted every step of it with all my heart. Carefully, gently, and with the utmost devotion."
    jes "Lo preparé poniendo todo mi corazón en ello. Con cuidado, delicadeza y la mayor devoción."

# game/script.rpy:786
translate Spanish advice_48c40352:

    # jes "So I hope you'll savor my handmade chocolate and not forget the color of its wrapping, Your Majesty~"
    jes "Así que espero que disfrute de mi chocolate artesanal y recuerde el color de su envoltorio, Su Majestad~"

# game/script.rpy:799
translate Spanish eatchocolate_4f8bc19e:

    # "Well... since it was already given to me, I couldn't refuse. I didn't have the heart to."
    "Bueno… como ya me lo había regalado, no podía rechazarlo. No me sentía capaz de hacerlo."

# game/script.rpy:800
translate Spanish eatchocolate_ba8cabbe:

    # "I broke off a piece of the chocolate and put it into my mouth."
    "Partí un trozo del chocolate y lo llevé a mi boca."

# game/script.rpy:801
translate Spanish eatchocolate_f185d9cc:

    # "The moment it touched my tongue, I could feel it melting."
    "En el momento en que tocó mi lengua, pude sentir cómo se derretía."

# game/script.rpy:802
translate Spanish eatchocolate_9da8740d:

    # "But at the same time, I saw Jestyn's smile sharpen and that was when I felt it."
    "Pero al mismo tiempo, vi cómo la sonrisa de Jestyn se afilaba y fue entonces cuando lo sentí."

# game/script.rpy:804
translate Spanish eatchocolate_2564fd93:

    # mc "Uph-?!"
    mc "¿¡Ugh—!?"

# game/script.rpy:806
translate Spanish eatchocolate_a8c586c7:

    # "A burning sensation spread across my tongue."
    "Una sensación ardiente se extendió por mi lengua."

# game/script.rpy:808
translate Spanish eatchocolate_69ebc829:

    # jes "Oh dear, it seems someone forgot the color of the wrapping~"
    jes "Oh, cielos… parece que alguien olvidó el color de la envoltura~"

# game/script.rpy:810
translate Spanish eatchocolate_8f5595d0:

    # "Jestyn chuckled softly at my face turning red from the heat."
    "Jestyn soltó una risa suave al ver mi rostro enrojecer por el picante."

# game/script.rpy:812
translate Spanish eatchocolate_2e3650a0:

    # mc "W-what kind of chocolate is this?!"
    mc "¿¡Q–qué clase de chocolate es este!?"

# game/script.rpy:813
translate Spanish eatchocolate_5e274c38:

    # jes "Hehe. It's chocolate, of course. But I find the usual ingredients rather dull. Nothing new. How boring."
    jes "Jeje. Es chocolate, por supuesto. Pero encuentro los ingredientes habituales bastante aburridos. Nada nuevo. Qué tedioso."

# game/script.rpy:816
translate Spanish eatchocolate_70eaca9d:

    # jes "And then! A brilliant idea struck me. Why not add something new to the recipe?"
    jes "¡Y entonces! Se me ocurrió una idea brillante. ¿Por qué no añadir algo nuevo a la receta?"

# game/script.rpy:817
translate Spanish eatchocolate_2f9e35fe:

    # jes "So I added chili powder."
    jes "Así que le añadí chile en polvo."

# game/script.rpy:819
translate Spanish eatchocolate_9bbcefec:

    # "I stared at him, completely speechless. What kind of thinking is that?!"
    "Lo miré, completamente sin palabras. ¿¡Qué clase de lógica es esa!?"

# game/script.rpy:822
translate Spanish eatchocolate_e9a00209:

    # jes "Poor you, Your Majesty. But that flustered, reddened expression of yours is simply adorable."
    jes "Pobrecit[letra], Su Majestad. Pero esa expresión suya, tan alterada y enrojecida, es simplemente adorable."

# game/script.rpy:824
translate Spanish eatchocolate_0e55d190:

    # "Jestyn then handed me a glass of water to drink."
    "Jestyn me entregó entonces un vaso de agua para beber."

# game/script.rpy:825
translate Spanish eatchocolate_0534be04:

    # "How did I fall for his prank so easily?"
    "¿Cómo caí en su broma tan fácilmente?"

# game/script.rpy:830
translate Spanish donteat_5d8ce5a8:

    # "I stared at the chocolate for a moment."
    "Miré el chocolate por un momento."

# game/script.rpy:831
translate Spanish donteat_a2d2d152:

    # "I didn't want to refuse someone's gift... but my instincts told me something was off."
    "No quería rechazar el regalo de alguien… pero mis instintos me decían que algo no estaba bien."

# game/script.rpy:832
translate Spanish donteat_278c7e29:

    # "........."
    "………"

# game/script.rpy:834
translate Spanish donteat_17f2ebd7:

    # mc "Jestyn?"
    mc "¿Jestyn?"

# game/script.rpy:835
translate Spanish donteat_32797f5c:

    # jes "Yes, Your Majesty?"
    jes "¿Sí, Su Majestad?"

# game/script.rpy:836
translate Spanish donteat_e5404d24:

    # mc "This isn't ordinary chocolate, is it?"
    mc "Esto no es un chocolate normal, ¿verdad?"

# game/script.rpy:838
translate Spanish donteat_de02ce2c:

    # "His smile didn't fade in the slightest as he looked back at me."
    "Su sonrisa no se desvaneció en lo más mínimo mientras me miraba."

# game/script.rpy:840
translate Spanish donteat_77c8fcdd:

    # jes "Oh? And what makes you say that, Your Majesty?"
    jes "¿Oh? ¿Y qué le hace decir eso, Su Majestad?"

# game/script.rpy:842
translate Spanish donteat_c9725607:

    # jes "Ah... to be honest, it pains my heart that you would accuse me so. I gave you that chocolate sincerely."
    jes "Ah… para ser honesto, me duele que me acuse así. Le di ese chocolate con sinceridad."

# game/script.rpy:844
translate Spanish donteat_90b3aaad:

    # "His smile slowly faded, replaced by the expression of someone deeply wounded."
    "Su sonrisa se desvaneció lentamente, reemplazada por la expresión de alguien profundamente herido."

# game/script.rpy:854
translate Spanish donteat2_5c9ae649:

    # mc "Don't lie to me."
    mc "No me mientas."

# game/script.rpy:855
translate Spanish donteat2_8a43ad9a:

    # mc "There's something in this chocolate, isn't there? I won't be fooled."
    mc "Hay algo en este chocolate, ¿no es así? No voy a caer."

# game/script.rpy:857
translate Spanish donteat2_3f2af826:

    # jes "....."
    jes "….."

# game/script.rpy:859
translate Spanish donteat2_68fc2657:

    # jes "Pfft... khuhu..."
    jes "Pfft… khuhu…"

# game/script.rpy:861
translate Spanish donteat2_7a0c2c91:

    # "Jestyn let out a soft laugh. And with that alone, everything was proven."
    "Jestyn dejó escapar una suave risa. Y con eso, todo quedó demostrado."

# game/script.rpy:863
translate Spanish donteat2_f6bbaa0f:

    # jes "Heheheheh... ahahahahaha!"
    jes "Jejeje… ¡ahahahahaha!"

# game/script.rpy:865
translate Spanish donteat2_7803fe46:

    # jes "Ahh... so someone didn't forget the color of the wrapping after all."
    jes "Ahh… así que alguien no olvidó el color de la envoltura después de todo."

# game/script.rpy:866
translate Spanish donteat2_cc6d53fe:

    # jes "You're sharper than you look, Your Majesty..."
    jes "Es más perspicaz de lo que parece, Su Majestad…"

# game/script.rpy:868
translate Spanish donteat2_79b789ab:

    # jes "Yes. I added something to the chocolate."
    jes "Sí. Le añadí algo al chocolate."

# game/script.rpy:870
translate Spanish donteat2_1df16ba6:

    # "I dropped the chocolate onto the floor."
    "Dejé caer el chocolate al suelo."

# game/script.rpy:872
translate Spanish donteat2_f037cc0e:

    # mc "T-then what did you put in it?! Don't tell me it's poison. Are you trying to kill me?!"
    mc "¿¡E–entonces qué le pusiste!? ¡No me digas que es veneno! ¿¡Estás tratando de matarme!?"

# game/script.rpy:874
translate Spanish donteat2_e05a60ec:

    # jes "Poison?! AHAHAHAHAHAHA!"
    jes "¿¡Veneno!? ¡AHAHAHAHAHAHA!"

# game/script.rpy:876
translate Spanish donteat2_bc7b7377:

    # jes "Oh, Your Majesty, I'm not that cruel. It was merely a prank. And I would never do something so merciless for the sake of a joke."
    jes "Oh, Su Majestad, no soy tan cruel. Solo era una broma. Jamás haría algo tan despiadado por una simple broma."

# game/script.rpy:880
translate Spanish donteat2_0ec1e5ff:

    # jes "It's chocolate, of course. But I find the usual ingredients rather dull. Nothing new. How boring."
    jes "Es chocolate, por supuesto. Pero encuentro los ingredientes habituales bastante aburridos. Nada nuevo. Qué tedioso."

# game/script.rpy:881
translate Spanish donteat2_70eaca9d:

    # jes "And then! A brilliant idea struck me. Why not add something new to the recipe?"
    jes "¡Y entonces! Se me ocurrió una idea brillante. ¿Por qué no añadir algo nuevo a la receta?"

# game/script.rpy:882
translate Spanish donteat2_2f9e35fe:

    # jes "So I added chili powder."
    jes "Así que le añadí chile en polvo."

# game/script.rpy:885
translate Spanish donteat2_9bbcefec:

    # "I stared at him, completely speechless. What kind of thinking is that?!"
    "Lo miré, completamente sin palabras. ¿¡Qué clase de lógica es esa!?"

# game/script.rpy:893
translate Spanish freakymomen_84622e1b:

    # jes "Hehehe. Please forgive me, Your Majesty. I'll give you a proper entertainment this time. I promise this isn't another prank."
    jes "Jejeje. Por favor, perdóneme, Su Majestad. Esta vez le daré un entretenimiento adecuado. Prometo que no es otra broma."

# game/script.rpy:895
translate Spanish freakymomen_9524c3a6:

    # "Jestyn snapped his fingers."
    "Jestyn chasqueó los dedos."

# game/script.rpy:911
translate Spanish balls_ef621327:

    # mc "... balls?"
    mc "… ¿pelotas?"

# game/script.rpy:912
translate Spanish balls_95449cd9:

    # jes "Correct"
    jes "Correcto."

# game/script.rpy:918
translate Spanish balls_8524ccab:

    # "Without waiting any longer, He began to juggling with remarkable skill."
    "Sin esperar más, comenzó a hacer malabares con una habilidad impresionante."

# game/script.rpy:919
translate Spanish balls_d78cf6b9:

    # "The balls flew from one hand to another, mixed with a few flashy tricks. It was obvious he had done this countless times before."
    "Las pelotas volaban de una mano a otra, mezcladas con algunos trucos llamativos. Era evidente que lo había hecho innumerables veces antes."

# game/script.rpy:920
translate Spanish balls_1a48c3f4:

    # "Then, his gaze shifted toward me."
    "Entonces, su mirada se dirigió hacia mí."

# game/script.rpy:922
translate Spanish balls_9f05f094:

    # jes "You must continue my juggling your majesty!"
    jes "¡Ahora le toca continuar con los malabares, Su Majestad!"

# game/script.rpy:923
translate Spanish balls_3fb0e546:

    # mc "Wait what-"
    mc "Espera, ¿qué—?"

# game/script.rpy:925
translate Spanish balls_3f766e70:

    # "Before I could finish my sentence, Jestyn tossed all the balls toward me."
    "Antes de que pudiera terminar la frase, Jestyn lanzó todas las pelotas hacia mí."

# game/script.rpy:926
translate Spanish balls_d8cf2bd5:

    # "No matter how hard I tried, it was hopeless. The balls slipped from my hands and hit the floor before I could even keep them in the air."
    "Por más que lo intenté, fue inútil. Las pelotas se escapaban de mis manos y golpeaban el suelo antes de que pudiera siquiera mantenerlas en el aire."

# game/script.rpy:927
translate Spanish balls_b69104d7:

    # "Seeing my pathetic attempt, Jestyn burst into laughter."
    "Al ver mi patético intento, Jestyn estalló en carcajadas."

# game/script.rpy:929
translate Spanish balls_3ce7a169:

    # jes "Truly your majesty? You cannot even catch them, let alone juggle."
    jes "¿En serio, Su Majestad? Ni siquiera puede atraparlas, mucho menos hacer malabares."

# game/script.rpy:930
translate Spanish balls_b8c333fb:

    # mc "Of course not! I've never done this before!"
    mc "¡Claro que no! ¡Nunca he hecho esto antes!"

# game/script.rpy:932
translate Spanish balls_32a85459:

    # "The balls rolled across the stage, scattering at my feet."
    "Las pelotas rodaron por el escenario, dispersándose a mis pies."

# game/script.rpy:935
translate Spanish balls_4faa5ed5:

    # jes "Ah ah ah! Do not look so defeated already, your majesty"
    jes "¡Ah, ah, ah! No se vea tan derrotad[letra] ya, Su Majestad."

# game/script.rpy:936
translate Spanish balls_da52edfd:

    # jes "here I thought humans were quite good at catching things. Opportunities, promises, responsibilities."
    jes "Y yo que creía que los humanos eran bastante buenos atrapando cosas. Oportunidades, promesas, responsabilidades."

# game/script.rpy:938
translate Spanish balls_ddc21682:

    # "He chuckles softly, as if he had just told a harmless joke."
    "Se ríe suavemente, como si acabara de decir una broma inocente."

# game/script.rpy:940
translate Spanish balls_81f3ccdb:

    # mc "You threw them at me without warning..."
    mc "Me las lanzaste sin aviso…"

# game/script.rpy:942
translate Spanish balls_1da73b32:

    # jes "Did I?"
    jes "¿Lo hice?"

# game/script.rpy:944
translate Spanish balls_42d168c2:

    # "He tilts his head, the bells on his hood chiming faintly."
    "Inclina la cabeza, las campanillas de su gorro tintineando débilmente."

# game/script.rpy:946
translate Spanish balls_97bfd332:

    # jes "My apologies then. Sometimes, I forget that not everyone enjoys surprises as much as I do."
    jes "Mis disculpas entonces. A veces olvido que no todos disfrutan de las sorpresas tanto como yo."

# game/script.rpy:949
translate Spanish balls_d7fbe90a:

    # "He bent down and picked up one of the fallen balls, spinning it lightly on his palm."
    "Se agachó y recogió una de las pelotas caídas, haciéndola girar ligeramente sobre su palma."

# game/script.rpy:952
translate Spanish balls_7c2ed117:

    # jes "Tell me, what do you think juggling is your majesty?"
    jes "Dígame, ¿qué cree que son los malabares, Su Majestad?"

# game/script.rpy:953
translate Spanish balls_d44ced45:

    # mc "Uh... throwing things? Trying not to drop them?"
    mc "Eh… ¿lanzar cosas? ¿Tratar de no dejarlas caer?"

# game/script.rpy:955
translate Spanish balls_7bf63dbf:

    # jes "Hoho... an honest answer. I like that."
    jes "Hoho… una respuesta honesta. Me gusta."

# game/script.rpy:957
translate Spanish balls_78579f7a:

    # jes "Juggling is balance. Timing. Knowing which ball to catch first and which one you must allow to fall."
    jes "Los malabares son equilibrio. Ritmo. Saber qué pelota atrapar primero y cuál debe permitir que caiga."

# game/script.rpy:958
translate Spanish balls_f11d3722:

    # "He casually tosses the ball into the air, catching it with ease."
    "Lanza la pelota al aire con naturalidad, atrapándola con facilidad."

# game/script.rpy:960
translate Spanish balls_18837d02:

    # "Then he lets the ball slips from his fingers and hits the stage with a dull sound. then he stares back at me"
    "Luego deja que la pelota se le escape de entre los dedos y caiga sobre el escenario con un golpe sordo. Después vuelve a mirarme."

# game/script.rpy:967
translate Spanish home_b2dbb149:

    # jes "I believe your time in this kingdom has now come to an end."
    jes "Creo que su tiempo en este reino ha llegado a su fin."

# game/script.rpy:969
translate Spanish home_28fa5188:

    # "I am confused by what he means, but when I glance at my watch, it reads 5:30 a.m."
    "Me confunde lo que quiere decir, pero cuando miro mi reloj, marca las 5:30 a. m."

# game/script.rpy:971
translate Spanish home_ab05c1c8:

    # mc "Oh... my shift is over."
    mc "Oh… mi turno ha terminado."

# game/script.rpy:973
translate Spanish home_3f1bdbf6:

    # "He takes my hand and presses a kiss to the back of it."
    "Toma mi mano y besa el dorso."

# game/script.rpy:974
translate Spanish home_8079daff:

    # "His lips feel cold, yet the sensation sends heat racing through my body and straight to my heart."
    "Sus labios se sienten fríos, pero la sensación envía calor recorriendo mi cuerpo hasta el corazón."

# game/script.rpy:976
translate Spanish home_42a2cc2b:

    # jes "Then, until we meet again,"
    jes "Entonces, hasta que nos volvamos a encontrar,"

# game/script.rpy:978
translate Spanish home_1632ba7e:

    # jes "sweet human..."
    jes "dulce human[letra]…"

# game/script.rpy:980
translate Spanish home_3cdae3c3:

    # "After saying that, Jestyn walks toward the dark side of the stage and disappears."
    "Después de decir eso, Jestyn camina hacia la parte oscura del escenario y desaparece."

# game/script.rpy:983
translate Spanish home_9342fca3:

    # "I finally return to my small, miserable apartment."
    "Finalmente regreso a mi pequeño y miserable apartamento."

# game/script.rpy:984
translate Spanish home_f52f2dbb:

    # "And what happened today was truly something...."
    "Y lo que pasó hoy fue realmente algo…"

# game/script.rpy:985
translate Spanish home_0e4b939f:

    # "Living puppets... and being treated like some kind of [title]."
    "Marionetas vivientes… y siendo tratad[letra] como algún tipo de [title!t]."

# game/script.rpy:986
translate Spanish home_4e207e4e:

    # "What a strange day. I feels like i'm going crazy"
    "Qué día tan extraño. Siento que me estoy volviendo loc[letra]."

# game/script.rpy:987
translate Spanish home_5ef7297b:

    # "Should I go back again tomorrow? These whole situation feels so creepy..."
    "¿Debería volver mañana? Toda esta situación es bastante inquietante…"

# game/script.rpy:988
translate Spanish home_07bdde05:

    # "....."
    "….."

# game/script.rpy:989
translate Spanish home_aeb9b1ae:

    # "... Of course I have to go. My debt won't be paid by itself. I need the money. Looking for another job would be far too difficult for me right now."
    "… Claro que tengo que ir. Mi deuda no se va a pagar sola. Necesito el dinero. Buscar otro trabajo sería demasiado difícil para mí ahora mismo."

# game/script.rpy:990
translate Spanish home_c24b1462:

    # "I don't know what will happen to me later."
    "No sé qué pasará conmigo después."

# game/script.rpy:991
translate Spanish home_31b50e90:

    # "For now, I'd better get some sleep. I'm utterly exhausted."
    "Por ahora, será mejor que duerma un poco. Estoy completamente agotad[letra]."

# game/script.rpy:992
translate Spanish home_a20cefa7:

    # "..."
    "…"

# game/script.rpy:993
translate Spanish home_5f9b772e:

    # "...."
    "…."

# game/script.rpy:994
translate Spanish home_0fd4d656:

    # "......"
    "……"

# game/script.rpy:1003
translate Spanish home_bbd50ba8:

    # jes "Seconds passed... then hours... days... weeks... months... years..."
    jes "Pasaron segundos… luego horas… después días… semanas… meses… años…"

# game/script.rpy:1004
translate Spanish home_cfeb39ac:

    # jes "It has been so very long since all of that faded away."
    jes "Ha pasado tanto tiempo desde que todo aquello se desvaneció."

# game/script.rpy:1005
translate Spanish home_c959d32a:

    # jes "And after so long.... I've finally found you..."
    jes "Y después de tanto tiempo… por fin le he encontrado…"

# game/script.rpy:1007
translate Spanish home_5ac78ce0:

    # jes "My [title]."
    jes "Mi [title!t]."

# game/script.rpy:1008
translate Spanish home_df575e84:

    # jes "Your Majesty... I truly thank you for today. You've made me so unbearably happy..."
    jes "Su Majestad… realmente le agradezco por hoy. Me ha hecho tan insoportablemente feliz…"

# game/script.rpy:1010
translate Spanish home_60f0af1e:

    # jes "Ah... but... you will come again tonight, won't you...?"
    jes "Ah… pero… volverá esta noche, ¿verdad…?"

# game/script.rpy:1011
translate Spanish home_8dc0e5f7:

    # jes "Of course... of course you will. There are still so many things we can do together. I simply couldn't bear it if you didn't."
    jes "Claro… claro que volverá. Aún hay tantas cosas que podemos hacer juntos. Simplemente no podría soportar que no lo hiciera."

# game/script.rpy:1014
translate Spanish home_71d3930a:

    # jes "I'll teach you juggling. You said you wanted me to, didn't you? Then I'll teach you everything. every trick, every motion, until your hands move exactly the way mine do."
    jes "Le enseñaré malabares. Dijo que quería que lo hiciera, ¿verdad? Entonces le enseñaré todo. Cada truco, cada movimiento, hasta que sus manos se muevan exactamente como las mías."

# game/script.rpy:1015
translate Spanish home_df56af4f:

    # jes "Then I'll show you magic tricks... ones I promise will steal your breath away. Oh, and there are so many puppets waiting for you to meet... to arrange...to belong where you want them. And then...and then..."
    jes "Luego le mostraré trucos de magia… unos que le dejarán sin aliento, se lo prometo. Oh, y hay tantas marionetas esperando a que las conozca… a que las organice… y a que las coloque donde usted quiera. Y luego… y luego…"

# game/script.rpy:1018
translate Spanish home_53ae36ac:

    # jes "We can play again like we did earlier, Your Majesty. I am your loyal jester, kneeling before my master like a devoted hound."
    jes "Podemos jugar otra vez como antes, Su Majestad. Soy su leal bufón, arrodillado ante mi am[letra] como un sabueso devoto."

# game/script.rpy:1019
translate Spanish home_48673b0f:

    # jes "Oh, you have no idea how that feeling made my heart race.. how it made me feel as though I belonged to you.. yes.. I belong to you, [title] [player_call]."
    jes "Oh, no tiene idea de cómo esa sensación hizo latir mi corazón… cómo me hizo sentir que le pertenecía… sí… le pertenezco a usted, [title!t] [player_call]."

# game/script.rpy:1022
translate Spanish home_3b7654bf:

    # jes "We can dine together, sleep together, sing together, dance together... always together.. and then... and then... "
    jes "Podemos cenar juntos, dormir juntos, cantar juntos, bailar juntos… siempre juntos… y luego… y luego…"

# game/script.rpy:1024
translate Spanish home_a1abeaae:

    # jes "Oh, sweet tart and cream, there are simply too many things we could do that I hardly know where to begin... as long as you never leave my side."
    jes "¡Ay, tarta dulce y crema! Hay tantas cosas que podríamos hacer que ni siquiera sé por dónde empezar… siempre y cuando nunca se aparte de mi lado."

# game/script.rpy:1025
translate Spanish home_149abbe3:

    # jes "Truly... what have you done to me, Your Majesty... I'm beginning to believe you're a sorcerer of terrifying power. Even Wizzy, the royal mage, couldn't twist a heart like this..."
    jes "De verdad… ¿qué me ha hecho, Su Majestad…? Estoy empezando a creer que es [arti_2] hechicer[letra] de poder aterrador. Ni siquiera Wizzy, el mago real, podría torcer un corazón de esta forma…"

# game/script.rpy:1028
translate Spanish home_99f3b0e7:

    # jes "I feel as though I've been caught in your web... wrapped tightly, unable to escape... simply waiting to be devoured by you.. and yet..I don't think I want to struggle at all."
    jes "Siento como si hubiera caído en su telaraña… atrapado entre sus hilos, incapaz de escapar… simplemente esperando a que usted me devore… y, aun así… creo que ni siquiera quiero resistirme."

# game/script.rpy:1030
translate Spanish home_eca5a21c:

    # jes "I scarcely recognize myself anymore, Your Majesty... but somehow, I don't wish to go back."
    jes "Apenas me reconozco ya, Su Majestad… pero de alguna manera, no deseo volver atrás."

# game/script.rpy:1031
translate Spanish home_9afef110:

    # jes "The kingdom needs you... I need you."
    jes "El reino le necesita… yo le necesito."

# game/script.rpy:1034
translate Spanish home_45e4e473:

    # jes "No. I want you... I crave you... My [title], [player_call]... "
    jes "No. Le quiero… le anhelo… Mi [title!t], [player_call]…"

# game/script.rpy:1035
translate Spanish home_34f37ed7:

    # jes "I've never felt anything this overwhelming before... I want to stay by your side, watch you breathe, carve your image into my mind, touch you.. and perhaps.. sink even deeper into you, until there's nothing left but us..."
    jes "Nunca antes había sentido algo tan abrumador… quiero quedarme a su lado, observar cómo respira, grabar su imagen en mi mente, tocarle… y quizá… hundirme aún más en usted, hasta que no quede nada más que nosotros…"

# game/script.rpy:1036
translate Spanish home_0370a43e:

    # jes "Ah- no, no, no. How improper of me. A mere jester touching his [title] so boldly... but if you were to grant me permission, I would cherish every inch of you with the utmost devotion."
    jes "Ah— no, no, no. Qué inapropiado de mi parte. Un simple bufón tocando a su [title!t] con tanta osadía… pero si usted me diera permiso, atesoraría cada centímetro de usted con la mayor devoción."

# game/script.rpy:1037
translate Spanish home_a1e6d275:

    # jes "Oh, My [title], I can hardly endure the wait to see you again... I wish time would rush forward... and yet freeze completely when I am with you. If only I could bend time itself. Just for you."
    jes "Oh, mi [title!t], apenas puedo soportar la espera para verle de nuevo… desearía que el tiempo avanzara rápido… y al mismo tiempo se congelara por completo cuando estoy con usted. Si tan solo pudiera doblar el tiempo mismo. Solo para usted."

# game/script.rpy:1038
translate Spanish home_5546ae5e:

    # jes "I'll take my leave now, My [title]... may your dreams be filled with me... "
    jes "Me retiro ahora, mi [title!t]… que sus sueños estén llenos de mí…"

# game/script.rpy:1041
translate Spanish home_77b7ec11:

    # jes "[player_call]."
    jes "[player_call]."

translate Spanish strings:

    # game/script.rpy:88
    old "Cleaning up"
    new "Limpiar"

    # game/script.rpy:94
    old "Checking puppets"
    new "Revisar marionetas"

    # game/script.rpy:100
    old "All done"
    new "Todo listo"

    # game/script.rpy:140
    old "Check outer gate"
    new "Revisar puerta exterior"

    # game/script.rpy:143
    old "Check corridor 1"
    new "Revisar pasillo 1"

    # game/script.rpy:146
    old "Check theater hall"
    new "Revisar sala del teatro"

    # game/script.rpy:149
    old "Check storage"
    new "Revisar almacén"

    # game/script.rpy:154
    old "Check stage"
    new "Revisar escenario"

    # game/script.rpy:443
    old "Give them money"
    new "Darles dinero"

    # game/script.rpy:453
    old "Build water channels"
    new "Construir canales de agua"

    # game/script.rpy:463
    old "Give them new seeds"
    new "Darles nuevas semillas"

    # game/script.rpy:473
    old "I need time to think"
    new "Necesito tiempo para pensar"

    # game/script.rpy:483
    old "You should find a solution yourselves"
    new "Deberían encontrar una solución ustedes mismos"

    # game/script.rpy:541
    old "Agree"
    new "Aceptar"

    # game/script.rpy:550
    old "Refuse"
    new "Rechazar"

    # game/script.rpy:559
    old "Delay"
    new "Retrasar"

    # game/script.rpy:679
    old "Laugh with it"
    new "Reírse con ello"

    # game/script.rpy:684
    old "That's annoying"
    new "Eso es molesto"

    # game/script.rpy:789
    old "Eat"
    new "Comer"

    # game/script.rpy:793
    old "Don't eat"
    new "No comer"

    # game/script.rpy:846
    old "Trust him"
    new "Confiar en él"

    # game/script.rpy:850
    old "Don't trust him"
    new "No confiar en él"

    # game/script.rpy:898
    old "Balls"
    new "Pelotas"

    # game/script.rpy:902
    old "Collar"
    new "Collar"

    old "{size=70}{b}{color=#ff0000}WARNING{/color}{/b}{/size}\n\nThis game contains Mild swearing, Screen shaking effects, Manipulative behavior, \nToxic relationship dynamics, Jumpscare, Obsessive behavior, Light BDSM, Suggestive content.\n\nPlayer discretion is advised."
    new "{size=70}{b}{color=#ff0000}ADVERTENCIA{/color}{/b}{/size}\n\nEste juego contiene lenguaje ligeramente vulgar, efectos de temblor de pantalla, comportamiento manipulador, dinámicas de relaciones tóxicas, sustos repentinos, comportamiento obsesivo, BDSM ligero y contenido sugerente.\n\nSe recomienda discreción al jugador."
