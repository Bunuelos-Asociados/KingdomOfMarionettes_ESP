﻿# TODO: Translation updated at 2026-11-09 22:40

translate Spanish strings:

    # game/options.rpy:15
    old "Kingdom Of Marionettes"
    new "Kingdom Of Marionettes"

