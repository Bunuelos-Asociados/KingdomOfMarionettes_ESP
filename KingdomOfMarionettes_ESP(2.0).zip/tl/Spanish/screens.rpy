# TODO: Translation updated at 2026-11-09 22:40

translate Spanish strings:

    # game/screens.rpy:251
    old "Back"
    new "Volver"

    # game/screens.rpy:252
    old "History"
    new "Historial"

    # game/screens.rpy:253
    old "Skip"
    new "Saltar"

    # game/screens.rpy:254
    old "Auto"
    new "Auto"

    # game/screens.rpy:255
    old "Save"
    new "Guardar"

    # game/screens.rpy:256
    old "Q.Save"
    new "G.Ráp."

    # game/screens.rpy:257
    old "Q.Load"
    new "C.Ráp."

    # game/screens.rpy:258
    old "Prefs"
    new "Opciones"

    # game/screens.rpy:299
    old "Start"
    new "Comenzar"

    # game/screens.rpy:307
    old "Load"
    new "Cargar"

    # game/screens.rpy:309
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:313
    old "End Replay"
    new "Terminar repetición"

    # game/screens.rpy:317
    old "Main Menu"
    new "Menú principal"

    # game/screens.rpy:319
    old "About"
    new "Acerca de"

    # game/screens.rpy:324
    old "Help"
    new "Ayuda"

    # game/screens.rpy:330
    old "Quit"
    new "Salir"

    # game/screens.rpy:511
    old "Return"
    new "Volver"

    # game/screens.rpy:595
    old "Version [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:601
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:637
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:637
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:637
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:679
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %d de %B de %Y, %H:%M"

    # game/screens.rpy:679
    old "empty slot"
    new "Ranura vacía"

    # game/screens.rpy:699
    old "<"
    new "<"

    # game/screens.rpy:703
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:706
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # game/screens.rpy:712
    old ">"
    new ">"

    # game/screens.rpy:717
    old "Upload Sync"
    new "Subir sincronización"

    # game/screens.rpy:722
    old "Download Sync"
    new "Descargar sincronización"

    # game/screens.rpy:782
    old "Display"
    new "Pantalla"

    # game/screens.rpy:783
    old "Window"
    new "Ventana"

    # game/screens.rpy:784
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:789
    old "Unseen Text"
    new "Texto no leído"

    # game/screens.rpy:790
    old "After Choices"
    new "Después de las elecciones"

    # game/screens.rpy:791
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:804
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:808
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:815
    old "Music Volume"
    new "Volumen de la música"

    # game/screens.rpy:822
    old "Sound Volume"
    new "Volumen de sonido"

    # game/screens.rpy:828
    old "Test"
    new "Probar"

    # game/screens.rpy:832
    old "Voice Volume"
    new "Volumen de voz"

    # game/screens.rpy:843
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:852
    old "Language"
    new "Idioma"

    # game/screens.rpy:976
    old "The dialogue history is empty."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:1044
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1045
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1048
    old "Gamepad"
    new "Mando"

    # game/screens.rpy:1061
    old "Enter"
    new "Enter"

    # game/screens.rpy:1062
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1065
    old "Space"
    new "Espacio"

    # game/screens.rpy:1066
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1069
    old "Arrow Keys"
    new "Teclas de dirección"

    # game/screens.rpy:1070
    old "Navigate the interface."
    new "Permiten navegar por la interfaz."

    # game/screens.rpy:1073
    old "Escape"
    new "Escape"

    # game/screens.rpy:1074
    old "Accesses the game menu."
    new "Abre el menú del juego."

    # game/screens.rpy:1077
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1078
    old "Skips dialogue while held down."
    new "Mantenerlo pulsado permite saltar los diálogos."

    # game/screens.rpy:1081
    old "Tab"
    new "Tab"

    # game/screens.rpy:1082
    old "Toggles dialogue skipping."
    new "Activa o desactiva el salto de diálogos."

    # game/screens.rpy:1085
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1086
    old "Rolls back to earlier dialogue."
    new "Retrocede a diálogos anteriores."

    # game/screens.rpy:1089
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1090
    old "Rolls forward to later dialogue."
    new "Avanza a diálogos posteriores."

    # game/screens.rpy:1094
    old "Hides the user interface."
    new "Oculta la interfaz."

    # game/screens.rpy:1098
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1102
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa o desactiva la {a=https://www.renpy.org/l/voicing}lectura en voz alta{/a}."

    # game/screens.rpy:1106
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1112
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1116
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1120
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1124
    old "Mouse Wheel Up"
    new "Rueda del ratón hacia arriba"

    # game/screens.rpy:1128
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1135
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1139
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nBotón superior izquierdo"

    # game/screens.rpy:1143
    old "Right Shoulder"
    new "Botón superior derecho"

    # game/screens.rpy:1147
    old "D-Pad, Sticks"
    new "Cruceta y palancas"

    # game/screens.rpy:1151
    old "Start, Guide, B/Right Button"
    new "Start, Guide, B/Botón derecho"

    # game/screens.rpy:1155
    old "Y/Top Button"
    new "Y/Botón superior"

    # game/screens.rpy:1158
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1223
    old "Yes"
    new "Sí"

    # game/screens.rpy:1224
    old "No"
    new "No"

    # game/screens.rpy:1270
    old "Skipping"
    new "Saltando"

    # game/screens.rpy:1582
    old "Menu"
    new "Menú"

