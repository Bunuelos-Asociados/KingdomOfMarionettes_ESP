# TODO: Translation updated at 2026-11-09 22:40

# game/choice chapter 1.rpy:5
translate Spanish q_clean_ced71e2d:

    # "Boss said I could clean it little by little. There's no need to finish everything in one day."
    "El jefe dijo que podía limpiarlo poco a poco. No es necesario terminar todo en un solo día."

# game/choice chapter 1.rpy:6
translate Spanish q_clean_e5157ec4:

    # "In that case, I'll start by cleaning the stage."
    "En ese caso, empezaré limpiando el escenario."

# game/choice chapter 1.rpy:10
translate Spanish q_clean_8529c83d:

    # "I head toward the storage room to gather some cleaning supplies."
    "Me dirijo al cuarto de almacenamiento para reunir algunos suministros de limpieza."

# game/choice chapter 1.rpy:14
translate Spanish q_clean_ced0f145:

    # "God.... It's so dark in here. I can barely see anything"
    "Dios… Está tan oscuro aquí dentro. Apenas puedo ver algo."

# game/choice chapter 1.rpy:16
translate Spanish q_clean_518cf120:

    # "I tried to turn on the light, but of course it's broken. As expected"
    "Intenté encender la luz, pero por supuesto está rota. Como era de esperarse."

# game/choice chapter 1.rpy:17
translate Spanish q_clean_c0d8882e:

    # "I turn on my flash light"
    "Enciendo mi linterna."

# game/choice chapter 1.rpy:22
translate Spanish q_clean_2883f898:

    # "Much better."
    "Mucho mejor."

# game/choice chapter 1.rpy:23
translate Spanish q_clean_2191c56e:

    # "The storage room itself is quite dirty. I'll clean it another time."
    "El cuarto de almacenamiento en sí está bastante sucio. Lo limpiaré en otro momento."

# game/choice chapter 1.rpy:25
translate Spanish q_clean_0e40c64f:

    # "I'm so focused on gathering the supplies that I flinch when my foot step into something."
    "Estoy tan pendiente de reunir los suministros que me sobresalto cuando mi pie pisa algo."

# game/choice chapter 1.rpy:29
translate Spanish q_clean_ff4925b4:

    # "When I look down, I see a red ball."
    "Cuando miro hacia abajo, veo una pelota roja."

# game/choice chapter 1.rpy:30
translate Spanish q_clean_08b64fd9:

    # "Oh. Just a ball. I don't remember seeing a red ball earlier."
    "Oh. Solo es una pelota. No recuerdo haber visto una pelota roja antes."

# game/choice chapter 1.rpy:31
translate Spanish q_clean_d5aaebd2:

    # "I must've just missed it."
    "Debí haberla pasado por alto."

# game/choice chapter 1.rpy:36
translate Spanish q_clean_c70bec4d:

    # "Once I'm sure I've gathered all the cleaning supplies, I head back toward the stage."
    "Una vez que compruebo que he reunido todos los suministros de limpieza, regreso hacia el escenario."

# game/choice chapter 1.rpy:41
translate Spanish q_clean_5f9b772e:

    # "...."
    "…."

# game/choice chapter 1.rpy:42
translate Spanish q_clean_64d6c66e:

    # "I won't lie, this corridor is pretty unsettling. Not just this corridor, either. This entire place feels creepy and dark."
    "No voy a mentir, este pasillo es bastante inquietante. Y no solo este pasillo. Todo este lugar se siente espeluznante y oscuro."

# game/choice chapter 1.rpy:47
translate Spanish q_clean_798a6618:

    # "Rusty doors are covered with layers of old newspapers. Cracked walls are smeared with graffiti left behind by vandals."
    "Puertas oxidadas están cubiertas con capas de periódicos viejos. Las paredes agrietadas están manchadas con grafitis dejados por vándalos."

# game/choice chapter 1.rpy:48
translate Spanish q_clean_f5cb8c8d:

    # "Most of the lights are broken or dead. Only a few are still on and even those flicker. Dust and grime cling to every corner."
    "La mayoría de las luces están rotas o no funcionan. Solo unas pocas siguen encendidas y aun así parpadean. El polvo y la suciedad se adhieren a cada rincón."

# game/choice chapter 1.rpy:49
translate Spanish q_clean_0cc39226:

    # "Of course, that's not surprising. This puppet theater has been closed for a very long time. If I remember correctly, Kingdom of Marionettes shut down around the year I was born."
    "Por supuesto, eso no es sorprendente. Este teatro de marionetas ha estado cerrado durante mucho tiempo. Si no recuerdo mal, Kingdom of Marionettes cerró alrededor del año en que nací."

# game/choice chapter 1.rpy:50
translate Spanish q_clean_df28e148:

    # "Has no one really tried to take this place over all this time? It feels like such a waste to leave it abandoned. The place still looks so grand."
    "¿De verdad nadie ha intentado hacerse cargo de este lugar en todo este tiempo? Se siente como un desperdicio dejarlo abandonado. El lugar aún luce tan grandioso."

# game/choice chapter 1.rpy:51
translate Spanish q_clean_c65a501b:

    # "Maybe this place could be repurposed into a cinema...or a high end restaurant."
    "Tal vez este lugar podría reconvertirse en un cine… o en un restaurante de alta gama."

# game/choice chapter 1.rpy:52
translate Spanish q_clean_ab9bfdd1:

    # "Or perhaps someone might even reopen this puppet theater. That would certainly be interesting."
    "O quizá alguien incluso podría reabrir este teatro de marionetas. Eso sería realmente interesante."

# game/choice chapter 1.rpy:56
translate Spanish q_clean_44e1d0c4:

    # "I start sweeping the stage floor, moving from one end to the other."
    "Empiezo a barrer el suelo del escenario, moviéndome de un extremo al otro."

# game/choice chapter 1.rpy:57
translate Spanish q_clean_cb669769:

    # "Just sweeping the stage floor alone is enough to exhaust me. The stage is enormous, and the thick layers of dust are stubborn and hard to sweep away."
    "Solo barrer el suelo del escenario es suficiente para agotarme. El escenario es enorme, y las gruesas capas de polvo son persistentes y difíciles de quitar."

# game/choice chapter 1.rpy:62
translate Spanish q_clean_b2fb9f11:

    # "I look around me, then toward the audience seats."
    "Miro a mi alrededor, luego hacia los asientos del público."

# game/choice chapter 1.rpy:64
translate Spanish q_clean_408f1ebc:

    # u "....This is going to take longer than I thought"
    u "....Esto va a tomar más tiempo de lo que pensé."

# game/choice chapter 1.rpy:70
translate Spanish q_clean_cb4478df:

    # "After cleaning the stage for what feels like two or three hours, I finally finish."
    "Después de limpiar el escenario durante lo que se siente como dos o tres horas, finalmente termino."

# game/choice chapter 1.rpy:72
translate Spanish q_clean_19d2159a:

    # u "Well...at least the stage itself is done."
    u "Bueno… al menos el escenario ya está listo."

# game/choice chapter 1.rpy:74
translate Spanish q_clean_b4c22a49:

    # "At this rate, I'll probably need around two full days just to clean this area alone."
    "A este ritmo, probablemente necesitaré alrededor de dos días completos solo para limpiar esta área."

# game/choice chapter 1.rpy:75
translate Spanish q_clean_e3eb3005:

    # "My body is completely worn out after all the sweeping, mopping, cleaning the curtains, and everything else. I don't have the strength to continue."
    "Mi cuerpo está completamente agotado después de barrer, trapear, limpiar las cortinas y todo lo demás. No tengo fuerzas para continuar."

# game/choice chapter 1.rpy:76
translate Spanish q_clean_bf1e5447:

    # "It's probably because I rarely exercise and live off instant noodles. No wonder my stamina is terrible. What can I do?"
    "Probablemente, sea porque casi no hago ejercicio y vivo a base de fideos instantáneos. Con razón mi resistencia es terrible. ¿Qué puedo hacer?"

# game/choice chapter 1.rpy:77
translate Spanish q_clean_b3589ce5:

    # "For now, I'll stop cleaning."
    "Por ahora, dejaré de limpiar."

# game/choice chapter 1.rpy:89
translate Spanish q_check_340d513a:

    # u "According to boss, there are around twenty puppets in this theater. That's quite a lot."
    u "Según el jefe, hay alrededor de veinte marionetas en este teatro. Son bastantes."

# game/choice chapter 1.rpy:93
translate Spanish q_check_850ba768:

    # "I walk toward the room where all the puppets are stored, located at the very end of the corridor."
    "Camino hacia la sala donde se guardan todas las marionetas, ubicada al final del pasillo."

# game/choice chapter 1.rpy:94
translate Spanish q_check_b3aed74e:

    # "Seriously. who thought it was a good idea to place the puppet room at the end of such a dark hallway?"
    "En serio… ¿Quién pensó que era buena idea poner la sala de marionetas al final de un pasillo tan oscuro?"

# game/choice chapter 1.rpy:95
translate Spanish q_check_a368bdaa:

    # "I must be so desperate for money that I feel like someone who actually enjoys walking into a haunted house."
    "Debo necesitar tanto el dinero que hasta parece que disfruto entrar a una casa embrujada."

# game/choice chapter 1.rpy:96
translate Spanish q_check_697ea20e:

    # "I grip the doorknob and take a deep breath before finally opening the door."
    "Agarro el pomo de la puerta y respiro hondo antes de abrirla finalmente."

# game/choice chapter 1.rpy:103
translate Spanish q_check_da6f0727:

    # u "...This is the puppet room? I didn't get it wrong, did I?"
    u "...¿Esta es la sala de marionetas? No me equivoqué, ¿verdad?"

# game/choice chapter 1.rpy:105
translate Spanish q_check_c21d5803:

    # "If you ask me, it looks more like a prison."
    "Si me lo preguntas, parece más una prisión."

# game/choice chapter 1.rpy:106
translate Spanish q_check_5659b7ea:

    # "I was expecting to see a bunch of puppets hanging on the walls or something like that."
    "Esperaba ver un montón de marionetas colgadas en las paredes o algo así."

# game/choice chapter 1.rpy:107
translate Spanish q_check_b38fefda:

    # "But strangely enough, each puppet seems to have its own room."
    "Pero, curiosamente, cada marioneta parece tener su propia habitación."

# game/choice chapter 1.rpy:109
translate Spanish q_check_d2a81a0e:

    # u "Alright. Time to start counting."
    u "Bien. Hora de empezar a contar."

# game/choice chapter 1.rpy:111
translate Spanish q_check_84cadd21:

    # "I take out a piece of paper containing the list of puppets."
    "Saco un papel que contiene la lista de marionetas."

# game/choice chapter 1.rpy:112
translate Spanish q_check_d1b3f4c1:

    # "Who should I check first?"
    "¿A quién debería revisar primero?"

# game/choice chapter 1.rpy:142
translate Spanish jester_89be6b80:

    # u "Let's see the jester puppet."
    u "Veamos al bufón marioneta."

# game/choice chapter 1.rpy:144
translate Spanish jester_a4052e31:

    # "I walk toward a door with the name 'Jester' written on it and, then I check through the viewing slot in the door"
    "Camino hacia una puerta con el nombre 'Jester' escrito en ella y luego miro a través de la mirilla de la puerta."

# game/choice chapter 1.rpy:145
translate Spanish jester_f06b34b6:

    # "The jester puppet's room is decorated with striped patterns in various colors. Mostly black, red, and yellow."
    "La habitación del bufón marioneta está decorada con patrones de rayas de varios colores. Principalmente negro, rojo y amarillo."

# game/choice chapter 1.rpy:146
translate Spanish jester_53505675:

    # "It's filled with all kinds of acrobat props: balls, a unicycle, and many others."
    "Está llena de todo tipo de accesorios de acrobacia: pelotas, un monociclo y muchos otros."

# game/choice chapter 1.rpy:147
translate Spanish jester_36ccba3a:

    # "As I look more closely, I finally spot the jester puppet standing in the corner of the room."
    "Al mirar más de cerca, finalmente veo al bufón marioneta de pie en una esquina de la habitación."

# game/choice chapter 1.rpy:148
translate Spanish jester_808fe3d5:

    # "I can't see its face since the puppet is slightly hunched over, but at least I know it's there."
    "No puedo ver su rostro, ya que la marioneta está ligeramente encorvada, pero al menos sé que está ahí."

# game/choice chapter 1.rpy:149
translate Spanish jester_af8c02e6:

    # "Jester puppet check."
    "Revisión de la marioneta del bufón: completada."

# game/choice chapter 1.rpy:154
translate Spanish knight_0b59bdd9:

    # "I walk toward the door labeled 'Knight'."
    "Camino hacia la puerta que tiene escrito 'Caballero'."

# game/choice chapter 1.rpy:155
translate Spanish knight_2d3120b3:

    # "The knight puppet's room is neatly kept."
    "La habitación del caballero marioneta está ordenada."

# game/choice chapter 1.rpy:156
translate Spanish knight_90b56432:

    # "A sturdy, imposing shield is mounted on the wall, along with... various other shield decorations."
    "Un escudo robusto e imponente está montado en la pared, junto con… otros adornos con forma de escudo."

# game/choice chapter 1.rpy:157
translate Spanish knight_e8b46306:

    # "There are quite a number of shields, all in different shapes and designs."
    "Hay bastantes escudos, todos con diferentes formas y diseños."

# game/choice chapter 1.rpy:158
translate Spanish knight_f4a356a3:

    # "On the bed, I see a puppet sitting upright, a dark red cloak draped over its face."
    "Sobre la cama, veo una marioneta sentada erguida, con una capa rojo oscuro cubriendo su rostro."

# game/choice chapter 1.rpy:159
translate Spanish knight_dfe13d05:

    # "I'm certain it's the knight puppet. Checked."
    "No cabe duda de que es el caballero marioneta. Revisado."

# game/choice chapter 1.rpy:164
translate Spanish king_a4683d14:

    # "I walk toward the door labeled 'King'."
    "Camino hacia la puerta que tiene escrito 'Rey'."

# game/choice chapter 1.rpy:165
translate Spanish king_31aed451:

    # "When I look inside, the room is lavish."
    "Cuando miro dentro, la habitación es lujosa."

# game/choice chapter 1.rpy:166
translate Spanish king_3c887f24:

    # "There's a king-sized bed with curtains, a comfortable-looking chaise lounge, and several paintings."
    "Hay una cama tamaño king con cortinas, una chaise longue (sillón) que parece cómoda y varias pinturas."

# game/choice chapter 1.rpy:167
translate Spanish king_f19d06ef:

    # "I examine every corner of the room, but I can't find the king puppet anywhere."
    "Examino cada rincón de la habitación, pero no puedo encontrar al rey marioneta por ninguna parte."

# game/choice chapter 1.rpy:168
translate Spanish king_69585039:

    # "Oh no... is the king puppet missing?"
    "Oh no… ¿Falta el rey marioneta?"

# game/choice chapter 1.rpy:169
translate Spanish king_447a3416:

    # "I check the puppet list I'm carrying, but I don't see the king puppet's name on it either."
    "Reviso la lista de marionetas que llevo, pero tampoco veo el nombre del rey marioneta en ella."

# game/choice chapter 1.rpy:170
translate Spanish king_63f1d603:

    # "I suppose there was never a king puppet to begin with. Or... has it been missing for a long time?"
    "Supongo que nunca hubo un rey marioneta para empezar. O… ¿Lleva mucho tiempo desaparecido?"

# game/choice chapter 1.rpy:176
translate Spanish after_check_7aa230dd:

    # "I've only checked two puppets so far. I'd better hurry and report the results to the boss."
    "Solo he revisado dos marionetas hasta ahora. Será mejor que me dé prisa y le informe los resultados al jefe."

# game/choice chapter 1.rpy:178
translate Spanish after_check_0fd4d656:

    # "......"
    "……"

# game/choice chapter 1.rpy:179
translate Spanish after_check_3928a113:

    # "......."
    "……"

# game/choice chapter 1.rpy:182
translate Spanish after_check_2399eb56:

    # "After spending a few more minutes checking the puppets, I finally finish. Every puppet listed is present."
    "Después de pasar unos minutos más revisando las marionetas, finalmente termino. Todas las marionetas de la lista están presentes."

# game/choice chapter 1.rpy:192
translate Spanish outer_gate_c80e0215:

    # "I check the camera at the outer gate. There's nothing in there."
    "Reviso la cámara en la puerta exterior. No hay nada ahí."

# game/choice chapter 1.rpy:201
translate Spanish corridor1_217bdf67:

    # "I check the camera at the corridor 1. There's nothing in there."
    "Reviso la cámara del pasillo 1. No hay nada ahí."

# game/choice chapter 1.rpy:210
translate Spanish theater_hall_a3931e7f:

    # "I check the camera at the theater hall. There's nothing in there."
    "Reviso la cámara del teatro. No hay nada ahí."

# game/choice chapter 1.rpy:219
translate Spanish storage_1f9f0a70:

    # "I check the storage room camera. There's nothing-"
    "Reviso la cámara del cuarto de almacenamiento. No hay nad—"

# game/choice chapter 1.rpy:230
translate Spanish storage_07bdde05:

    # "....."
    "….."

# game/choice chapter 1.rpy:231
translate Spanish storage_ec12a37f:

    # "I take back what I said."
    "Retiro lo que dije."

# game/choice chapter 1.rpy:232
translate Spanish storage_d1e5ea7b:

    # "Someone just passed through the storage room."
    "Alguien acaba de pasar por el cuarto de almacenamiento."

# game/choice chapter 1.rpy:233
translate Spanish storage_ec128e67:

    # "..... Was that a vandal?"
    "..... ¿Fue un vándalo?"

# game/choice chapter 1.rpy:234
translate Spanish storage_e9464da0:

    # "No. That doesn't make sense."
    "No. Eso no tiene sentido."

# game/choice chapter 1.rpy:236
translate Spanish storage_660da02e:

    # u "How did they get inside?"
    u "¿Cómo entraron?"

# game/choice chapter 1.rpy:242
translate Spanish storage_081bcc1d:

    # "Damn it. I need to check it right now before those vandals do something that'll make my job even harder."
    "Maldita sea. Tengo que revisarlo ahora mismo antes de que esos vándalos hagan algo que complique aún más mi trabajo."

# game/choice chapter 1.rpy:244
translate Spanish storage_827a69d5:

    # "I quickly grab a flashlight and a baton to defend myself, then rush out of the room toward the storage area."
    "Rápidamente, tomo una linterna y un bastón para defenderme, luego salgo corriendo de la habitación hacia el área de almacenamiento."

# game/choice chapter 1.rpy:250
translate Spanish storage_8fae22bb:

    # "When I arrive at the storage room, I find nothing."
    "Cuando llego al cuarto de almacenamiento, no encuentro nada."

# game/choice chapter 1.rpy:251
translate Spanish storage_21109d41:

    # "However, the storage door is open. Proof that what I saw on the CCTV was real and not just my imagination."
    "Sin embargo, la puerta está abierta. Prueba de que lo que vi en el CCTV era real y no solo mi imaginación."

# game/choice chapter 1.rpy:252
translate Spanish storage_7ed43392:

    # "I have a bad feeling. Whoever this person is, they're somewhere in the corridor."
    "Tengo un mal presentimiento. Sea quien sea esta persona, está en algún lugar del pasillo."

# game/choice chapter 1.rpy:253
translate Spanish storage_d4986972:

    # "I grip my baton as tightly as I can and slowly step into the hallway."
    "Agarro mi bastón con la mayor fuerza posible y avanzo lentamente hacia el pasillo."

# game/choice chapter 1.rpy:254
translate Spanish storage_07bdde05_1:

    # "....."
    "….."

# game/choice chapter 1.rpy:255
translate Spanish storage_06d70f2c:

    # "It's pitch dark... I'd better turn on the flashlight."
    "Está completamente oscuro… será mejor que encienda la linterna."

# game/choice chapter 1.rpy:260
translate Spanish storage_75b742b1:

    # "Alright-"
    "Bien—"

# game/choice chapter 1.rpy:261
translate Spanish storage_0fd4d656:

    # "......"
    "……"

# game/choice chapter 1.rpy:262
translate Spanish storage_fae4f937:

    # "What the hell is that...?"
    "¿Qué demonios es eso…?"

# game/choice chapter 1.rpy:263
translate Spanish storage_07384e83:

    # "After turning on the flashlight, I can finally see the dark path stretching out in front of me."
    "Después de encender la linterna, finalmente puedo ver el oscuro camino que se extiende frente a mí."

# game/choice chapter 1.rpy:264
translate Spanish storage_6ce9e3dc:

    # "But I can also see something else..."
    "Pero también puedo ver otra cosa…"

# game/choice chapter 1.rpy:265
translate Spanish storage_ba16a89e:

    # "A tall figure standing at the far end of the corridor."
    "Una figura alta de pie al final del pasillo."

# game/choice chapter 1.rpy:266
translate Spanish storage_0ccefa30:

    # "The figure is draped in a red cloak, its edges torn and ragged. Its outfit resembles that of a knight."
    "La figura está envuelta en una capa roja, con los bordes desgarrados y raídos. Su atuendo se parece al de un caballero."

# game/choice chapter 1.rpy:267
translate Spanish storage_a20cefa7:

    # "..."
    "..."

# game/choice chapter 1.rpy:268
translate Spanish storage_bb47d330:

    # "No... this isn't a vandal."
    "No… esto no es un vándalo."

# game/choice chapter 1.rpy:269
translate Spanish storage_4afbc76b:

    # "It's the knight puppet I checked earlier..."
    "Es el caballero marioneta que revisé antes…"

# game/choice chapter 1.rpy:270
translate Spanish storage_764814f9:

    # "How could a puppet be standing here...?"
    "¿Cómo podría una marioneta estar de pie aquí…?"

# game/choice chapter 1.rpy:271
translate Spanish storage_28136c4c:

    # "There's no way. Puppets don't move..."
    "No puede ser. Las marionetas no se mueven…"

# game/choice chapter 1.rpy:272
translate Spanish storage_dacbdb3f:

    # "Maybe some vandals broke in and moved the knight puppet here. And because they noticed me, they put it back so they could escape as quickly as possible."
    "Tal vez unos vándalos entraron y movieron al caballero marioneta hasta aquí. Y como me notaron, la devolvieron para poder escapar lo más rápido posible."

# game/choice chapter 1.rpy:273
translate Spanish storage_67153a08:

    # "Yeah. That has to be it."
    "Sí. Tiene que ser eso."

# game/choice chapter 1.rpy:274
translate Spanish storage_02dfd0e5:

    # "Before I can calm myself with all these possibilities, the puppet's head moves and turns to look straight at me."
    "Antes de poder calmarme con todas esas posibilidades, la cabeza de la marioneta se mueve y gira para mirarme directamente."

# game/choice chapter 1.rpy:275
translate Spanish storage_07bdde05_2:

    # "....."
    "….."

# game/choice chapter 1.rpy:276
translate Spanish storage_ec12a37f_1:

    # "I take back what I said."
    "Retiro lo que dije."

# game/choice chapter 1.rpy:278
translate Spanish storage_2ad222a5:

    # knipuppet "... Intruder...."
    knipuppet "...Intruso..."

# game/choice chapter 1.rpy:281
translate Spanish storage_d232da0f:

    # "That puppet can talk."
    "Esa marioneta puede hablar."

# game/choice chapter 1.rpy:282
translate Spanish storage_f240914c:

    # "Calm down... calm down... don't panic..."
    "Cálmate... cálmate... no entres en pánico..."

# game/choice chapter 1.rpy:283
translate Spanish storage_e0bb6ecf:

    # "But what should I do in this situation???"
    "¿Pero qué debería hacer en esta situación?"

# game/choice chapter 1.rpy:296
translate Spanish keep_silent_57a11b74:

    # "I just stand there, frozen. I don't know what to do. Even if I say something, I'm afraid it'll only make things worse."
    "Me quedo ahí, sin poder moverme. No sé qué hacer. Incluso si digo algo, temo que solo empeore las cosas."

# game/choice chapter 1.rpy:297
translate Spanish keep_silent_3607f28a:

    # "I never imagined a situation where a puppet would speak to me."
    "Nunca imaginé una situación en la que una marioneta me hablara."

# game/choice chapter 1.rpy:302
translate Spanish who_04394590:

    # "He didn't say anything back."
    "No respondió nada."

# game/choice chapter 1.rpy:303
translate Spanish who_3607f28a:

    # "I never imagined a situation where a puppet would speak to me."
    "Nunca imaginé una situación en la que una marioneta me hablara."

# game/choice chapter 1.rpy:311
translate Spanish run_75016de9:

    # "Without a second thought, I spun around and ran straight toward my office."
    "Sin pensarlo dos veces, me di la vuelta y corrí directo hacia mi oficina."

# game/choice chapter 1.rpy:315
translate Spanish run_b99f9743:

    # "Once I reached it, I locked the door as quickly as I could."
    "Una vez que llegué, cerré la puerta con llave lo más rápido que pude."

# game/choice chapter 1.rpy:318
translate Spanish run_87cb2fa2:

    # u "The puppet was really alive... it talked. Am I dreaming...?"
    u "La marioneta estaba realmente viva... habló. ¿Estoy soñando...?"

# game/choice chapter 1.rpy:319
translate Spanish run_a5ba893b:

    # u "I feel like I've lost my mind... or maybe I already had..?"
    u "Siento que he perdido la cordura... ¿O tal vez ya la había perdido...?"

# game/choice chapter 1.rpy:321
translate Spanish run_739e7b43:

    # "I tried to calm myself and slowly stepped backward. But keeping my eyes on the door"
    "Intenté calmarme y retrocedí lentamente, pero manteniendo la vista fija en la puerta."

# game/choice chapter 1.rpy:322
translate Spanish run_0e668525:

    # "I braced myself for the puppet's arrival at my office, but even after five minutes passed, I heard nothing."
    "Me preparé para la llegada de la marioneta a mi oficina, pero incluso después de cinco minutos, no escuché nada."

# game/choice chapter 1.rpy:323
translate Spanish run_a42eff31:

    # "Did the puppet not follow me?"
    "¿La marioneta no me siguió?"

# game/choice chapter 1.rpy:328
translate Spanish run_c0f35448:

    # "I was just about to feel relieved when suddenly, a hand covered my eyes."
    "Justo cuando estaba a punto de sentir alivio, de repente, una mano cubrió mis ojos."

# game/choice chapter 1.rpy:329
translate Spanish run_6576ac53:

    # "My entire body froze as I sensed someone standing behind me."
    "Todo mi cuerpo se quedó rígido al sentir a alguien detrás de mí."

# game/choice chapter 1.rpy:330
translate Spanish run_5b99436a:

    # "Since when?!"
    "¿Desde cuándo?"

# game/choice chapter 1.rpy:331
translate Spanish run_9f06270b:

    # "I didn't dare scream or struggle. I was far too afraid."
    "No me atreví a gritar ni a resistirme. Tenía demasiado miedo."

# game/choice chapter 1.rpy:333
translate Spanish run_a38158a1:

    # who "Mm.. I expected you to scream. But it seems you're a good child. Far better than I anticipated."
    who "Mm... esperaba que gritaras. Pero parece que te portas muy bien. Mucho mejor de lo que anticipaba."

# game/choice chapter 1.rpy:335
translate Spanish run_a8d9624d:

    # " A soft voice whispered right against my ear. It's high-pitched, oddly playful, almost childlike."
    "Una voz suave susurró justo junto a mi oído. Es aguda, extrañamente juguetona, casi infantil."

# game/choice chapter 1.rpy:337
translate Spanish run_47c70280:

    # "Then I feel another hand slowly rest on my shoulder, making me flinch."
    "Luego siento otra mano posarse lentamente sobre mi hombro, haciéndome sobresaltar."

# game/choice chapter 1.rpy:339
translate Spanish run_87b5833c:

    # who "Easy now. The danger has passed. You may allow yourself to relax."
    who "Calma. El peligro ha pasado. Puedes permitirte relajarte."

# game/choice chapter 1.rpy:340
translate Spanish run_038465e2:

    # who "Why don't you come with me for the time being? I assure you, I am not someone you need to fear."
    who "¿Por qué no viene conmigo por ahora? Le aseguro que no soy alguien a quien deba temer."

# game/choice chapter 1.rpy:341
translate Spanish run_3906c513:

    # who "After all, any guest who sets foot in this kingdom ought to be welcomed properly. Wouldn't you agree?"
    who "Después de todo, cualquier invitado que pise este reino debería ser recibido adecuadamente. ¿No estás de acuerdo?"

# game/choice chapter 1.rpy:343
translate Spanish run_ab11727e:

    # "Alright... whoever is standing behind me sounds friendly enough. Still, it's probably best if I just go along with it."
    "Está bien... quien sea que esté detrás de mí suena lo suficientemente amable. Aun así, probablemente sea mejor seguirle el juego."

# game/choice chapter 1.rpy:344
translate Spanish run_3b9dac57:

    # "I nod my head."
    "Asiento con la cabeza."

# game/choice chapter 1.rpy:346
translate Spanish run_aa4a51a8:

    # who "Excellent, Now come with me."
    who "Excelente. Ahora venga conmigo."

# game/choice chapter 1.rpy:358
translate Spanish dicekek_cf8a8d55:

    # "Suddenly, in the blink of an eye, a hand clamps around my throat."
    "De repente, en un abrir y cerrar de ojos, una mano se cierra alrededor de mi garganta."

# game/choice chapter 1.rpy:362
translate Spanish dicekek_81d2627a:

    # u "UGH-?!"
    u "¿¡Ugh—!?"

# game/choice chapter 1.rpy:367
translate Spanish dicekek_a520c5f9:

    # "The knight puppet is right in front of me, choking me with terrifying speed."
    "El caballero marioneta está justo frente a mí, asfixiándome con una velocidad aterradora."

# game/choice chapter 1.rpy:371
translate Spanish dicekek_c77602ae:

    # knipuppet "Once again... an intruder..."
    knipuppet "Una vez más... un intruso..."

# game/choice chapter 1.rpy:372
translate Spanish dicekek_2953c777:

    # knipuppet "It seems more and more intruders have been coming to this kingdom lately."
    knipuppet "Parece que cada vez más intrusos han estado llegando a este reino últimamente."

# game/choice chapter 1.rpy:373
translate Spanish dicekek_c9d66958:

    # knipuppet "How fortunate..."
    knipuppet "Qué suerte..."

# game/choice chapter 1.rpy:375
translate Spanish dicekek_ad9b9c93:

    # "His grip tightens around my neck, cutting off my air."
    "Aprieta cada vez más la mano alrededor de mi cuello, impidiéndome respirar."

# game/choice chapter 1.rpy:376
translate Spanish dicekek_7b4e8ca1:

    # "He's going to kill me!"
    "¡Va a matarme!"

# game/choice chapter 1.rpy:377
translate Spanish dicekek_9f1a1187:

    # "I struggle with every strength I have. Punching his arm, kicking his legs, trying desperately to break free."
    "Lucho con toda la fuerza que tengo, golpeando su brazo, pateando sus piernas, intentando desesperadamente liberarme."

# game/choice chapter 1.rpy:378
translate Spanish dicekek_80dac2dd:

    # "But it's useless. He is far stronger than me. He doesn't even budge."
    "Pero es inútil. Es mucho más fuerte que yo. Ni siquiera se mueve."

# game/choice chapter 1.rpy:380
translate Spanish dicekek_1c461bb5:

    # "My vision grows blurrier, sinking deeper into darkness."
    "Mi visión se vuelve cada vez más borrosa, hundiéndose en la oscuridad."

# game/choice chapter 1.rpy:381
translate Spanish dicekek_604dcb18:

    # "Is this really how my life ends? Killed by a living puppet?"
    "¿De verdad así termina mi vida? ¿A manos de una marioneta viviente?"

# game/choice chapter 1.rpy:388
translate Spanish dicekek_1b3cfe4f:

    # "Just before my consciousness completely fades, a hand suddenly covers my eyes."
    "Justo antes de perder completamente la conciencia, una mano cubre mis ojos de repente."

# game/choice chapter 1.rpy:390
translate Spanish dicekek_82b66c7b:

    # knipuppet ".... What are you doing in here?"
    knipuppet "...¿Qué estás haciendo aquí?"

# game/choice chapter 1.rpy:392
translate Spanish dicekek_50d92b2a:

    # "Huh? Who is this behind me?? Another puppet???"
    "¿Eh? ¿Quién es este detrás de mí? ¿¿Otra marioneta??"

# game/choice chapter 1.rpy:394
translate Spanish dicekek_2e08bda1:

    # who "Knighter, I believe I've mentioned this before. Wouldn't it be better if any visitors who wander into our kingdom were entrusted to me?"
    who "Knighter, creo que ya he mencionado esto antes. ¿No sería mejor que cualquier visitante que entre en nuestro reino me sea confiado?"

# game/choice chapter 1.rpy:395
translate Spanish dicekek_acae9e6b:

    # kni "For what? So you can carry out that absurd plan of yours?"
    kni "¿Para qué? ¿Para que lleves a cabo ese absurdo plan tuyo?"

# game/choice chapter 1.rpy:396
translate Spanish dicekek_67023ae2:

    # who "My friend, you're free to doubt me if you wish. I wouldn't fault you for it. But I do need this visitor. You understand that much.. don't you?"
    who "Amigo mío, eres libre de dudar de mí si así lo deseas. No te culparía por ello. Pero necesito a este visitante. Eso lo entiendes... ¿Verdad?"

# game/choice chapter 1.rpy:398
translate Spanish dicekek_e35fbd06:

    # "Suddenly, the corridor falls silent. I have no idea what's happening."
    "De repente, el pasillo queda en silencio. No tengo idea de lo que está pasando."

# game/choice chapter 1.rpy:399
translate Spanish dicekek_60c8dd55:

    # "The knight puppet named Knighter snorts in irritation before abruptly releasing his grip from my throat."
    "El caballero marioneta llamado Knighter resopla con irritación antes de soltar abruptamente mi cuello."

# game/choice chapter 1.rpy:400
translate Spanish dicekek_55d8ce51:

    # "I hear his footsteps fading away, a clear sign that he's left."
    "Escucho sus pasos alejándose, una clara señal de que se ha ido."

# game/choice chapter 1.rpy:401
translate Spanish dicekek_c17ba29f:

    # "Yet the hand covering my eyes doesn't move, gently keeping my vision obscured."
    "Aun así, la mano que cubre mis ojos no se mueve y sigue impidiéndome ver."

# game/choice chapter 1.rpy:402
translate Spanish dicekek_47c70280:

    # "Then I feel another hand slowly rest on my shoulder, making me flinch."
    "Luego siento otra mano posarse lentamente sobre mi hombro, haciéndome sobresaltar."

# game/choice chapter 1.rpy:404
translate Spanish dicekek_87b5833c:

    # who "Easy now. The danger has passed. You may allow yourself to relax."
    who "Calma. El peligro ha pasado. Puedes permitirte relajarte."

# game/choice chapter 1.rpy:405
translate Spanish dicekek_038465e2:

    # who "Why don't you come with me for the time being? I assure you, I am not someone you need to fear."
    who "¿Por qué no viene conmigo por ahora? Le aseguro que no soy alguien a quien deba temer."

# game/choice chapter 1.rpy:406
translate Spanish dicekek_3906c513:

    # who "After all, any guest who sets foot in this kingdom ought to be welcomed properly. Wouldn't you agree?"
    who "Después de todo, cualquier invitado que pise este reino debería ser recibido adecuadamente. ¿No estás de acuerdo?"

# game/choice chapter 1.rpy:408
translate Spanish dicekek_ab11727e:

    # "Alright... whoever is standing behind me sounds friendly enough. Still, it's probably best if I just go along with it."
    "Está bien... quien sea que esté detrás de mí suena lo suficientemente amable. Aun así, probablemente sea mejor seguirle el juego."

# game/choice chapter 1.rpy:409
translate Spanish dicekek_3b9dac57:

    # "I nod my head."
    "Asiento con la cabeza."

# game/choice chapter 1.rpy:411
translate Spanish dicekek_aa4a51a8:

    # who "Excellent, Now come with me."
    who "Excelente. Ahora venga conmigo."

# game/choice chapter 1.rpy:419
translate Spanish ke_stage_b582c00f:

    # "The figure behind me guides me forward, leading me where they want while keeping my eyes covered."
    "La figura detrás de mí me guía hacia adelante, llevándome a donde quiere mientras mantiene mis ojos cubiertos."

# game/choice chapter 1.rpy:420
translate Spanish ke_stage_92577168:

    # "After a while, he stops."
    "Después de un rato, se detiene."

# game/choice chapter 1.rpy:422
translate Spanish ke_stage_e6e39f6d:

    # who "We've arrived. Now, please take a seat here and make yourself comfortable."
    who "Hemos llegado. Ahora, por favor, tome asiento aquí y póngase cómod[letra]."

# game/choice chapter 1.rpy:426
translate Spanish ke_stage_e6257ec1:

    # "They gently guide me down into a seat."
    "La figura me guía suavemente hasta el asiento."

# game/choice chapter 1.rpy:427
translate Spanish ke_stage_79c0981a:

    # "Then, their hand moves away from my eyes, finally allowing me to see."
    "Luego, su mano se aparta de mis ojos, permitiéndome ver finalmente."

# game/choice chapter 1.rpy:428
translate Spanish ke_stage_1a188bd4:

    # "This is... the theater hall..."
    "Esto es... el teatro..."

# game/choice chapter 1.rpy:429
translate Spanish ke_stage_b4c0bae0:

    # "I turn around, trying to see who has been guiding me all this time."
    "Me doy la vuelta, intentando ver quién me ha estado guiando todo este tiempo."

# game/choice chapter 1.rpy:430
translate Spanish ke_stage_e51246b1:

    # "But there's no one there."
    "Pero no hay nadie ahí."

# game/choice chapter 1.rpy:432
translate Spanish ke_stage_d74acb68:

    # u "What? Where did that person go?"
    u "¿Qué? ¿A dónde fue esa persona?"

# game/choice chapter 1.rpy:440
translate Spanish ke_stage_f8bdd8e4:

    # jespuppet "BOO!!"
    jespuppet "¡¡BOO!!"

# game/choice chapter 1.rpy:444
translate Spanish ke_stage_2d2d5001:

    # u "AAARGH!!"
    u "¡¡AAARGH!!"

# game/choice chapter 1.rpy:446
translate Spanish ke_stage_68123195:

    # "Still unprepared and struggling to process what was happening, I scream when, without warning, I notice someone standing right in front of me."
    "Aun sin haber tenido tiempo de prepararme y tratando de procesar lo que estaba pasando, grito cuando, sin previo aviso, alguien aparece justo frente a mí."

# game/choice chapter 1.rpy:451
translate Spanish ke_stage_bdebebcd:

    # "He gently covers my mouth, as if signaling that he won't hurt me and keep me silent."
    "Cubre suavemente mi boca, como indicando que no me hará daño y que guarde silencio."

# game/choice chapter 1.rpy:455
translate Spanish ke_stage_0e4a568f:

    # jespuppet "Shh..."
    jespuppet "Shh..."

# game/choice chapter 1.rpy:457
translate Spanish ke_stage_8b4132aa:

    # "I can feel my soul almost slip from my body for a second."
    "Siento como si mi alma casi hubiera salido de mi cuerpo por un segundo."

# game/choice chapter 1.rpy:458
translate Spanish ke_stage_88d43b28:

    # "Slowly, he pulls his hand away from my lips."
    "Lentamente, retira su mano de mis labios."

# game/choice chapter 1.rpy:459
translate Spanish ke_stage_bffbc981:

    # "The figure is dressed like a jester. Bells hang from the tips of its hood, and its outfit is colored red, black, white, and yellow."
    "La figura está vestida como un bufón. Campanillas cuelgan de las puntas de su gorro, y su atuendo es de color rojo, negro, blanco y amarillo."

# game/choice chapter 1.rpy:465
translate Spanish ke_stage_a20cefa7:

    # "..."
    "..."

# game/choice chapter 1.rpy:469
translate Spanish ke_stage_233f662e:

    # "Wait a second.. Isn't that-"
    "Espera un segundo... ¿no es ese—?"

# game/choice chapter 1.rpy:470
translate Spanish ke_stage_c82304b6:

    # "He is... the jester puppet."
    "Es... el bufón marioneta."

# game/choice chapter 1.rpy:471
translate Spanish ke_stage_ee744bfa:

    # "...He's... moving on his own."
    "…Está… moviéndose por sí solo."

# game/choice chapter 1.rpy:472
translate Spanish ke_stage_c32ace20:

    # "I remembered the list of duties I read before applying yesterday."
    "Recordé la lista de tareas que leí antes de postularme ayer."

# game/choice chapter 1.rpy:473
translate Spanish ke_stage_e167b255:

    # "Make sure none of the puppets are missing.... and walking around."
    "Asegurarse de que ninguno de los títeres desaparezca... ni ande deambulando."

# game/choice chapter 1.rpy:474
translate Spanish ke_stage_180adf03:

    # "At that moment, I believed it after seeing knight puppet and jester puppet moving with my own eyes and mind."
    "En ese momento lo creí, después de ver con mis propios ojos cómo se movían el caballero y el bufón."

# game/choice chapter 1.rpy:475
translate Spanish ke_stage_9680fcb1:

    # "... This isn't a joke. They are alive."
    "...Esto no es una broma. Están vivos."

# game/choice chapter 1.rpy:486
translate Spanish stage_23ad1cb8:

    # "I check the camera at the stage. There's noth-"
    "Reviso la cámara del escenario. No hay nad—"

# game/choice chapter 1.rpy:488
translate Spanish stage_b84bd283:

    # "Wait a second... what the hell is that?"
    "Espera un segundo... ¿Qué demonios es eso?"

# game/choice chapter 1.rpy:489
translate Spanish stage_c1b70496:

    # "Through the CCTV feed, I can see a figure standing upright at the center of the stage."
    "A través de la cámara de seguridad, puedo ver una figura de pie en el centro del escenario."

# game/choice chapter 1.rpy:490
translate Spanish stage_df5bba70:

    # "It's hard to make out in the darkness, but I'm certain someone is there."
    "Es difícil distinguirla en la oscuridad, pero no cabe duda de que hay alguien allí."

# game/choice chapter 1.rpy:491
translate Spanish stage_d83ab720:

    # "Is it the vandals? How did they even get inside?"
    "¿Son los vándalos? ¿Cómo lograron entrar?"

# game/choice chapter 1.rpy:496
translate Spanish stage_de2c7707:

    # "Damn it. I need to check it right now- before those vandals do something that'll make my job even harder."
    "Maldita sea. Tengo que revisarlo ahora mismo... antes de que esos vándalos hagan algo que complique aún más mi trabajo."

# game/choice chapter 1.rpy:498
translate Spanish stage_91a606e1:

    # "I quickly grab a flashlight and a baton to defend myself, then rush out of the room toward the theater hall."
    "Rápidamente, tomo una linterna y un bastón para defenderme, luego salgo corriendo hacia el teatro."

# game/choice chapter 1.rpy:502
translate Spanish stage_07bdde05:

    # "....."
    "….."

# game/choice chapter 1.rpy:506
translate Spanish stage_415559a8:

    # "I step into the theater hall and look toward the darkened stage."
    "Entro en el teatro y miro hacia el escenario oscuro."

# game/choice chapter 1.rpy:507
translate Spanish stage_b097864d:

    # "It's too dark to see anyone clearly. I'll have to get closer."
    "Está demasiado oscuro para ver a alguien con claridad. Tendré que acercarme."

# game/choice chapter 1.rpy:515
translate Spanish stage_f8bdd8e4:

    # jespuppet "BOO!!"
    jespuppet "¡¡BOO!!"

# game/choice chapter 1.rpy:519
translate Spanish stage_2d2d5001:

    # u "AAARGH!!"
    u "¡¡AAARGH!!"

# game/choice chapter 1.rpy:521
translate Spanish stage_acf8eb8e:

    # "Still unprepared and struggling to process what was happening, I let out the loudest scream i have ever make when without warning the figure was already standing right in front of me."
    "Aun sin haber tenido tiempo de prepararme y tratando de procesar lo que estaba pasando, dejo escapar el grito más fuerte de mi vida cuando, sin previo aviso, la figura ya estaba justo frente a mí."

# game/choice chapter 1.rpy:526
translate Spanish stage_3ca9f306:

    # "He gently covers my mouth, as if signaling that he won't hurt me."
    "Cubre suavemente mi boca, como indicando que no me hará daño."

# game/choice chapter 1.rpy:530
translate Spanish stage_0e4a568f:

    # jespuppet "Shh..."
    jespuppet "Shh..."

# game/choice chapter 1.rpy:532
translate Spanish stage_825c63ab:

    # "I can feel my soul almost slipped from my body for a second"
    "Siento como si mi alma casi hubiera salido de mi cuerpo por un segundo."

# game/choice chapter 1.rpy:533
translate Spanish stage_88d43b28:

    # "Slowly, he pulls his hand away from my lips."
    "Lentamente, retira su mano de mis labios."

# game/choice chapter 1.rpy:534
translate Spanish stage_bffbc981:

    # "The figure is dressed like a jester. Bells hang from the tips of its hood, and its outfit is colored red, black, white, and yellow."
    "La figura está vestida como un bufón. Campanillas cuelgan de las puntas de su gorro, y su atuendo es de color rojo, negro, blanco y amarillo."

# game/choice chapter 1.rpy:540
translate Spanish stage_a20cefa7:

    # "..."
    "..."

# game/choice chapter 1.rpy:544
translate Spanish stage_424f7eee:

    # "Wait a second.... isn't that-"
    "Espera un segundo... ¿no es ese—?"

# game/choice chapter 1.rpy:545
translate Spanish stage_25128f12:

    # "That's... the jester puppet that i check earlier."
    "Es... el bufón marioneta que revisé antes."

# game/choice chapter 1.rpy:546
translate Spanish stage_c8f7d405:

    # "He is... moving?! Moving on his own?!"
    "Está... ¿Moviéndose? ¡¿Moviéndose por sí solo?!"

# game/choice chapter 1.rpy:547
translate Spanish stage_caf1c301:

    # "How can that's even possible?!"
    "¿Cómo es eso siquiera posible?"

# game/choice chapter 1.rpy:548
translate Spanish stage_36477dbc:

    # "Suddenly, I remembered the list of duties I read before applying yesterday."
    "De repente, recordé la lista de tareas que leí antes de postularme ayer."

# game/choice chapter 1.rpy:549
translate Spanish stage_4c151d0c:

    # "Make sure none of the puppets are missing... and walking around."
    "Asegurarse de que ninguno de los títeres desaparezca... ni ande deambulando."

# game/choice chapter 1.rpy:550
translate Spanish stage_d376b6ab:

    # "At that moment, I believed it after seeing it with my own eyes and mind."
    "En ese momento, lo creí al verlo con mis propios ojos y mi propia mente."

# game/choice chapter 1.rpy:551
translate Spanish stage_911f43cd:

    # "....This isn't a joke. They are alive."
    "...Esto no es una broma. Están vivos."

# game/choice chapter 1.rpy:558
translate Spanish money_9b08e166:

    # "Maybe I could give them money... that way they could buy the things they need."
    "Tal vez podría darles dinero... así podrían comprar lo que necesiten."

# game/choice chapter 1.rpy:559
translate Spanish money_cc8d459e:

    # mc "What if I give you some funds? I'll provide whatever you need. Whether it's to buy new seeds or to cover your daily needs."
    mc "¿Y si les doy algunos fondos? Proporcionaré lo que necesiten. Ya sea para comprar nuevas semillas o cubrir sus necesidades diarias."

# game/choice chapter 1.rpy:560
translate Spanish money_7d7924a4:

    # nara "{color=#E0AE4B}Upon hearing the [title]'s decision to provide the farmers with as much funding as they needed, the farmer's heart danced with joy.{/color}"
    nara "{color=#E0AE4B}Al escuchar que [arti] [title!t] había decidido proporcionar a los agricultores todos los fondos que necesitaran, el corazón del agricultor saltó de alegría.{/color}"

# game/choice chapter 1.rpy:562
translate Spanish money_ba2d1c7c:

    # "Alright, that narrator's voice, that coming from who knows where, was starting to make me uneasy."
    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."

# game/choice chapter 1.rpy:566
translate Spanish money_436d3ea4:

    # farm "Oh, of course, Your Majesty! That sounds like a good idea. Thank you very much!"
    farm "¡Oh, por supuesto, Su Majestad! Eso suena como una buena idea. ¡Muchas gracias!"

# game/choice chapter 1.rpy:570
translate Spanish money_ee3ef29a:

    # nara "{color=#E0AE4B}With a joyful heart, the farmer finally left the palace to deliver the good news.{/color}"
    nara "{color=#E0AE4B}Con el corazón rebosante de alegría, el agricultor finalmente abandonó el palacio para dar la buena noticia.{/color}"

# game/choice chapter 1.rpy:572
translate Spanish money_abbe3b80:

    # "The farmer puppet then stood up and left the stage."
    "El agricultor marioneta se levantó y salió del escenario."

# game/choice chapter 1.rpy:577
translate Spanish money_51c559f1:

    # "I could feel Jestyn's gaze fixed on me."
    "Pude sentir la mirada de Jestyn fija en mí."

# game/choice chapter 1.rpy:582
translate Spanish money_f2905482:

    # jes "Oh, Your Majesty. such a truly wise and kind hearted decision."
    jes "Oh, Su Majestad. Qué decisión tan sabia y bondadosa."

# game/choice chapter 1.rpy:583
translate Spanish money_f1222d64:

    # jes "Providing the farmers with funds to meet their basic needs.It is not a bad idea at all."
    jes "Proporcionar fondos a los agricultores para cubrir sus necesidades básicas. No es una mala idea en absoluto."

# game/choice chapter 1.rpy:585
translate Spanish money_510a1e83:

    # "He paused."
    "Hizo una pausa."

# game/choice chapter 1.rpy:589
translate Spanish money_39a7cf8f:

    # jes "You're so kind your majesty. and Kindness is a beautiful thing"
    jes "Es usted muy amable, Su Majestad. Y la bondad es algo hermoso."

# game/choice chapter 1.rpy:590
translate Spanish money_13dea7c0:

    # jes "But when given without limits... it turns into expectation."
    jes "Pero cuando se da sin límites... se convierte en expectativa."

# game/choice chapter 1.rpy:592
translate Spanish money_a61e186e:

    # "He tilted his head."
    "Inclinó la cabeza."

# game/choice chapter 1.rpy:596
translate Spanish money_e79aa23e:

    # jes "Tell me, how many coins does it take to feed a kingdom?"
    jes "Dígame, ¿cuántas monedas se necesitan para alimentar a un reino?"

# game/choice chapter 1.rpy:597
translate Spanish money_1795641c:

    # mc "Uhm... that's..."
    mc "Uhm... eso es..."

# game/choice chapter 1.rpy:601
translate Spanish money_79861712:

    # jes "Ah, forgive me."
    jes "Ah, discúlpeme."

# game/choice chapter 1.rpy:602
translate Spanish money_173ff528:

    # jes "I forgot you are very generous."
    jes "Olvidé que es usted muy generos[letra]."

# game/choice chapter 1.rpy:606
translate Spanish money_5d8ee5db:

    # "He smiled."
    "Sonrió."

# game/choice chapter 1.rpy:608
translate Spanish money_d8235c83:

    # jes "The kingdom must be quite small...if generosity alone is enough to sustain it."
    jes "El reino debe ser bastante pequeño... si la generosidad por sí sola es suficiente para sostenerlo."

# game/choice chapter 1.rpy:610
translate Spanish money_631a098c:

    # "He is right..."
    "Tiene razón..."

# game/choice chapter 1.rpy:611
translate Spanish money_fecd91a3:

    # "Being a [title] is really hard..."
    "Ser [title!t] es realmente difícil…"

# game/choice chapter 1.rpy:612
translate Spanish money_cfdc2c5c:

    # "I mean, I'm just a security guard, desperate for money just to survive."
    "Quiero decir, solo soy [arti_2] guardia de seguridad, desesperad[letra] por dinero solo para sobrevivir."

# game/choice chapter 1.rpy:613
translate Spanish money_f4ef96a6:

    # "And now, all of a sudden, I'm being dragged into playing the role of a [title] by living puppets."
    "Y ahora, de repente, unas marionetas vivientes me están arrastrando a interpretar el papel de [title!t]."

# game/choice chapter 1.rpy:614
translate Spanish money_20449aa2:

    # "I'm really not that fit to be a leader."
    "Realmente no soy apt[letra] para ser [arti_2] líder."

# game/choice chapter 1.rpy:619
translate Spanish channels_5d8f58e0:

    # "I don't know much about farming, but I once read that drought can be handled by building water channels."
    "No sé mucho sobre agricultura, pero una vez leí que la sequía puede manejarse construyendo canales de agua."

# game/choice chapter 1.rpy:620
translate Spanish channels_c0a1d201:

    # "Mmm... I don't think that's a bad idea. Hopefully."
    "Mmm... no creo que sea una mala idea. Eso espero."

# game/choice chapter 1.rpy:622
translate Spanish channels_722f9e9e:

    # mc "How about we build water channels? That way, the crops won't dry out."
    mc "¿Qué tal si construimos canales de agua? Así los cultivos no se secarán."

# game/choice chapter 1.rpy:623
translate Spanish channels_2393df81:

    # nara "{color=#E0AE4B}Upon hearing the [title]'s decision to build the water channels, the farmer's heart danced with joy.{/color}"
    nara "{color=#E0AE4B}Al escuchar que [arti] [title!t] había decidido construir canales de agua, el corazón del agricultor saltó de alegría.{/color}"

# game/choice chapter 1.rpy:625
translate Spanish channels_ba2d1c7c:

    # "Alright, that narrator's voice, that coming from who knows where, was starting to make me uneasy."
    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."

# game/choice chapter 1.rpy:632
translate Spanish channels_ebae100a:

    # "The farmer seemed to think for a moment, then nodded in agreement"
    "El agricultor pareció reflexionar por un momento y luego asintió en señal de acuerdo."

# game/choice chapter 1.rpy:634
translate Spanish channels_385c2411:

    # farm "Of course, Your Majesty. That is a good idea."
    farm "Por supuesto, Su Majestad. Es una buena idea."

# game/choice chapter 1.rpy:636
translate Spanish channels_808ee39d:

    # "I sigh with relief"
    "Suspiro con alivio."

# game/choice chapter 1.rpy:638
translate Spanish channels_cdee7ca5:

    # mc "Then I will provide the funds to build the channels as soon as possible."
    mc "Entonces proporcionaré los fondos para construir los canales lo antes posible."

# game/choice chapter 1.rpy:642
translate Spanish channels_fcacb4d6:

    # farm "Very well, Your Majesty.Thank you very much."
    farm "Muy bien, Su Majestad. Muchas gracias."

# game/choice chapter 1.rpy:643
translate Spanish channels_ee3ef29a:

    # nara "{color=#E0AE4B}With a joyful heart, the farmer finally left the palace to deliver the good news.{/color}"
    nara "{color=#E0AE4B}Con el corazón rebosante de alegría, el agricultor finalmente abandonó el palacio para dar la buena noticia.{/color}"

# game/choice chapter 1.rpy:645
translate Spanish channels_abbe3b80:

    # "The farmer puppet then stood up and left the stage."
    "El agricultor marioneta se levantó y salió del escenario."

# game/choice chapter 1.rpy:649
translate Spanish channels_d3df1e05:

    # "After that, the farmer stood up and walked off the stage."
    "Después de eso, el agricultor se levantó y abandonó el escenario."

# game/choice chapter 1.rpy:650
translate Spanish channels_51c559f1:

    # "I could feel Jestyn's gaze fixed on me."
    "Pude sentir la mirada de Jestyn fija en mí."

# game/choice chapter 1.rpy:655
translate Spanish channels_7fcb8644:

    # jes "A truly admirable choice, Your Majesty."
    jes "Una elección verdaderamente admirable, Su Majestad."

# game/choice chapter 1.rpy:656
translate Spanish channels_e1111f9d:

    # jes "Water channels to fight drought. a solution that looks far into the future."
    jes "Canales de riego para combatir la sequía. Una solución con visión de futuro."

# game/choice chapter 1.rpy:657
translate Spanish channels_61a603ca:

    # jes "You thought about the next season... and the season after that."
    jes "Pensó en la próxima temporada... y en la siguiente."

# game/choice chapter 1.rpy:659
translate Spanish channels_466d8ae9:

    # "He paused, smiling."
    "Hizo una pausa, sonriendo."

# game/choice chapter 1.rpy:663
translate Spanish channels_51e307fc:

    # jes "Perhaps a little too far."
    jes "Quizá demasiado hacia el futuro."

# game/choice chapter 1.rpy:664
translate Spanish channels_0bd56961:

    # jes "Tell me, Your Majesty. what was the farmer's problem right now?"
    jes "Dígame, Su Majestad. ¿Cuál era el problema del agricultor en este momento?"

# game/choice chapter 1.rpy:666
translate Spanish channels_4cbe89e4:

    # "Huh?"
    "¿Eh?"

# game/choice chapter 1.rpy:667
translate Spanish channels_625d0c5d:

    # "The drought caused the crops to fail, leaving them with no income to buy new seeds...and.."
    "La sequía arruinó las cosechas, dejándolos sin ingresos para comprar nuevas semillas… y…"

# game/choice chapter 1.rpy:669
translate Spanish channels_7777ddff:

    # mc "No money to meet their daily needs..."
    mc "Sin dinero para cubrir sus necesidades diarias..."

# game/choice chapter 1.rpy:673
translate Spanish channels_7d3aa4cc:

    # jes "Oh, excellent! You remembered! Five stars for vision!"
    jes "¡Oh, excelente! ¡Lo recordó! ¡Cinco estrellas por visión!"

# game/choice chapter 1.rpy:677
translate Spanish channels_75a0ebbc:

    # jes "And yet... A hungry farmer cannot eat a future harvest."
    jes "Y aun así... un agricultor hambriento no puede comer una cosecha futura."

# game/choice chapter 1.rpy:679
translate Spanish channels_3077e7bf:

    # "He chuckled softly."
    "Se rió suavemente."

# game/choice chapter 1.rpy:681
translate Spanish channels_febb6fba:

    # jes "It seems you may need to do a little more than simply building water channels."
    jes "Parece que necesitará hacer algo más que simplemente construir canales de agua."

# game/choice chapter 1.rpy:685
translate Spanish channels_50bcfa87:

    # "Oh... he is right..."
    "Oh… tiene razón…"

# game/choice chapter 1.rpy:686
translate Spanish channels_fecd91a3:

    # "Being a [title] is really hard..."
    "Ser [title!t] es realmente difícil…"

# game/choice chapter 1.rpy:687
translate Spanish channels_cfdc2c5c:

    # "I mean, I'm just a security guard, desperate for money just to survive."
    "Quiero decir, solo soy [arti_2] guardia de seguridad, desesperad[letra] por dinero solo para sobrevivir."

# game/choice chapter 1.rpy:688
translate Spanish channels_5e35ec61:

    # "And now, all of a sudden, I'm being dragged into playing the role of a queen by living puppets."
    "Y ahora, de repente, unas marionetas vivientes me están arrastrando a interpretar el papel de [title!t]."

# game/choice chapter 1.rpy:689
translate Spanish channels_20449aa2:

    # "I'm really not that fit to be a leader."
    "Realmente no soy apt[letra] para ser [arti_2] líder."

# game/choice chapter 1.rpy:696
translate Spanish seeds_05418970:

    # "The crops failed during the dry season. If I remember correctly, there are plants that can survive dry conditions."
    "Los cultivos fallaron durante la temporada seca. Si no recuerdo mal, hay plantas que pueden sobrevivir a condiciones secas."

# game/choice chapter 1.rpy:698
translate Spanish seeds_f5412774:

    # mc "Are there any crops that can survive drought?"
    mc "¿Hay cultivos que puedan sobrevivir a la sequía?"

# game/choice chapter 1.rpy:699
translate Spanish seeds_2b54f80a:

    # "The farmer fell silent, thinking."
    "El agricultor guardó silencio, pensando."

# game/choice chapter 1.rpy:703
translate Spanish seeds_8d8bbcc6:

    # farm "Ah! There are, Your Majesty. Tomatoes, corn, and root crops, for example."
    farm "¡Ah! Sí los hay, Su Majestad. Tomates, maíz y cultivos de raíz, por ejemplo."

# game/choice chapter 1.rpy:704
translate Spanish seeds_b6241d51:

    # mc "Then how about we switch to crops that can survive the dry season? I will provide the seeds you need."
    mc "Entonces, ¿qué tal si cambiamos a cultivos que puedan sobrevivir a la temporada seca? Proporcionaré las semillas que necesiten."

# game/choice chapter 1.rpy:705
translate Spanish seeds_0ec8225e:

    # nara "{color=#E0AE4B}Upon hearing the [title]'s decision to provide the new seeds for farmers, the farmer's heart danced with joy.{/color}"
    nara "{color=#E0AE4B}Al escuchar que [arti] [title!t] había decidido proporcionar nuevas semillas a los agricultores, el corazón del agricultor saltó de alegría.{/color}"

# game/choice chapter 1.rpy:707
translate Spanish seeds_ba2d1c7c:

    # "Alright, that narrator's voice, that coming from who knows where, was starting to make me uneasy."
    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."

# game/choice chapter 1.rpy:714
translate Spanish seeds_3a688fd4:

    # "The farmer nodded in agreement."
    "El agricultor asintió de acuerdo."

# game/choice chapter 1.rpy:716
translate Spanish seeds_629c7591:

    # farm "I understand, Your Majesty. Thank you for your help."
    farm "Entiendo, Su Majestad. Gracias por su ayuda."

# game/choice chapter 1.rpy:717
translate Spanish seeds_ee3ef29a:

    # nara "{color=#E0AE4B}With a joyful heart, the farmer finally left the palace to deliver the good news.{/color}"
    nara "{color=#E0AE4B}Con el corazón rebosante de alegría, el agricultor finalmente abandonó el palacio para dar la buena noticia.{/color}"

# game/choice chapter 1.rpy:719
translate Spanish seeds_abbe3b80:

    # "The farmer puppet then stood up and left the stage."
    "El agricultor marioneta se levantó y salió del escenario."

# game/choice chapter 1.rpy:723
translate Spanish seeds_d3df1e05:

    # "After that, the farmer stood up and walked off the stage."
    "Después de eso, el agricultor se levantó y abandonó el escenario."

# game/choice chapter 1.rpy:724
translate Spanish seeds_51c559f1:

    # "I could feel Jestyn's gaze fixed on me."
    "Pude sentir la mirada de Jestyn fija en mí."

# game/choice chapter 1.rpy:729
translate Spanish seeds_934cc55f:

    # jes "Such a wise decision, Your Majesty."
    jes "Una decisión muy sabia, Su Majestad."

# game/choice chapter 1.rpy:730
translate Spanish seeds_211c6330:

    # jes "Choosing crops that can endure the harsh sunlight of the dry season, so the farmers no longer need to worry about their crops dying."
    jes "Elegir cultivos capaces de soportar el sol abrasador de la temporada seca, para que los agricultores ya no tengan que preocuparse por perder sus cosechas."

# game/choice chapter 1.rpy:731
translate Spanish seeds_25a9b9fe:

    # jes "Your way of thinking truly looks far ahead. You genuinely considered what their future might be like."
    jes "Su forma de pensar realmente mira hacia adelante. Consideró genuinamente cómo podría ser su futuro."

# game/choice chapter 1.rpy:733
translate Spanish seeds_510a1e83:

    # "He paused."
    "Hizo una pausa."

# game/choice chapter 1.rpy:737
translate Spanish seeds_1c64c52d:

    # jes "A brilliant plan for tomorrow... but what shall they eat tonight?"
    jes "Un plan brillante para mañana… pero ¿qué comerán esta noche?"

# game/choice chapter 1.rpy:739
translate Spanish seeds_0f77cfd7:

    # "I freeze."
    "Me quedo paralizad[letra]."

# game/choice chapter 1.rpy:741
translate Spanish seeds_533ce45d:

    # jes "Do you remember what kind of problem the farmer had just now?"
    jes "¿Recuerda qué tipo de problema tenía el agricultor hace un momento? "

# game/choice chapter 1.rpy:743
translate Spanish seeds_4cbe89e4:

    # "Huh?"
    "¿Eh?"

# game/choice chapter 1.rpy:744
translate Spanish seeds_625d0c5d:

    # "The drought caused the crops to fail, leaving them with no income to buy new seeds...and.."
    "La sequía arruinó las cosechas, dejándolos sin ingresos para comprar nuevas semillas… y…"

# game/choice chapter 1.rpy:746
translate Spanish seeds_7777ddff:

    # mc "No money to meet their daily needs..."
    mc "Sin dinero para cubrir sus necesidades diarias..."

# game/choice chapter 1.rpy:749
translate Spanish seeds_7d3aa4cc:

    # jes "Oh, excellent! You remembered! Five stars for vision!"
    jes "¡Oh, excelente! ¡Lo recordó! ¡Cinco estrellas por visión!"

# game/choice chapter 1.rpy:751
translate Spanish seeds_b2bb6ca5:

    # jes "Crops do not grow overnight, Your Majesty. I trust you are aware of that."
    jes "Los cultivos no crecen de la noche a la mañana, Su Majestad. Confío en que lo sabe."

# game/choice chapter 1.rpy:753
translate Spanish seeds_3077e7bf:

    # "He chuckled softly."
    "Se rió suavemente."

# game/choice chapter 1.rpy:754
translate Spanish seeds_50bcfa87:

    # "Oh... he is right..."
    "Oh… tiene razón…"

# game/choice chapter 1.rpy:756
translate Spanish seeds_12da887b:

    # jes "It seems you may need to do a little more than that."
    jes "Parece que necesitará hacer algo más que eso."

# game/choice chapter 1.rpy:758
translate Spanish seeds_50bcfa87_1:

    # "Oh... he is right..."
    "Oh… tiene razón…"

# game/choice chapter 1.rpy:759
translate Spanish seeds_fecd91a3:

    # "Being a [title] is really hard..."
    "Ser [title!t] es realmente difícil…"

# game/choice chapter 1.rpy:760
translate Spanish seeds_cfdc2c5c:

    # "I mean, I'm just a security guard, desperate for money just to survive."
    "Quiero decir, solo soy [arti_2] guardia de seguridad, desesperad[letra] por dinero solo para sobrevivir."

# game/choice chapter 1.rpy:761
translate Spanish seeds_5e35ec61:

    # "And now, all of a sudden, I'm being dragged into playing the role of a queen by living puppets."
    "Y ahora, de repente, unas marionetas vivientes me están arrastrando a interpretar el papel de [title!t]."

# game/choice chapter 1.rpy:762
translate Spanish seeds_20449aa2:

    # "I'm really not that fit to be a leader."
    "Realmente no soy apt[letra] para ser [arti_2] líder."

# game/choice chapter 1.rpy:767
translate Spanish time_7ecb0508:

    # "What does a farmer need to prevent crop failure during the dry season..?"
    "¿Qué necesita un agricultor para evitar que los cultivos fracasen durante la temporada seca…?"

# game/choice chapter 1.rpy:768
translate Spanish time_313eb8ad:

    # "Money? Seeds?? But is that really enough to deal with this?"
    "¿Dinero? ¿Semillas? ¿Pero eso realmente es suficiente para enfrentar esto?"

# game/choice chapter 1.rpy:769
translate Spanish time_3f0be528:

    # "Oh my god..."
    "Dios mío…"

# game/choice chapter 1.rpy:771
translate Spanish time_021d54eb:

    # mc "I'm sorry... I... need more time to think."
    mc "Lo siento… yo… necesito más tiempo para pensar."

# game/choice chapter 1.rpy:772
translate Spanish time_915a9346:

    # nara "{color=#E0AE4B}Hearing the [title]'s words, the farmer tried to understand that such decisions could not be made in haste. Even so, his heart remained uneasy{/color}"
    nara "{color=#E0AE4B}Tras escuchar lo que dijo [arti] [title!t], el agricultor intentó comprender que tales decisiones no podían tomarse con prisa. Aun así, su corazón seguía inquieto.{/color}"

# game/choice chapter 1.rpy:774
translate Spanish time_ba2d1c7c:

    # "Alright, that narrator's voice, that coming from who knows where, was starting to make me uneasy."
    "Bien, esa voz de narrador, que viene de quién sabe dónde, empezaba a incomodarme."

# game/choice chapter 1.rpy:779
translate Spanish time_ac1bd28d:

    # "The farmer nodded in understanding."
    "El agricultor asintió, comprendiendo."

# game/choice chapter 1.rpy:783
translate Spanish time_4c65c579:

    # farm "Very well, Your Majesty. Please, we ask for your help..."
    farm "Muy bien, Su Majestad. Por favor, le pedimos su ayuda…"

# game/choice chapter 1.rpy:787
translate Spanish time_be39b031:

    # "After that, the farmer puppet left the stage."
    "Después de eso, el agricultor marioneta abandonó el escenario."

# game/choice chapter 1.rpy:789
translate Spanish time_3702aefd:

    # nara "{color=#E0AE4B}From the corner of the room, the jester watched the [title] with a sharp gaze, his usual smile still fixed upon his face.{/color}"
    nara "{color=#E0AE4B}Desde una esquina de la sala, el bufón clavaba su mirada aguda en [arti] [title!t], con su sonrisa habitual aún dibujada en el rostro.{/color}"

# game/choice chapter 1.rpy:790
translate Spanish time_cd5e6247:

    # nara "{color=#E0AE4B}It seemed the jester wished to offer a few words to the [title].{/color}"
    nara "{color=#E0AE4B}Parecía que el bufón tenía unas palabras para [arti] [title!t].{/color}"

# game/choice chapter 1.rpy:792
translate Spanish time_51c559f1:

    # "I could feel Jestyn's gaze fixed on me."
    "Pude sentir la mirada de Jestyn fija en mí."

# game/choice chapter 1.rpy:797
translate Spanish time_cacbe634:

    # jes "More time, Your Majesty?"
    jes "¿Más tiempo, Su Majestad?"

# game/choice chapter 1.rpy:799
translate Spanish time_14688fd9:

    # "He smiled, amused."
    "Sonrió, divertido."

# game/choice chapter 1.rpy:803
translate Spanish time_fd6e3b5c:

    # jes "How charming."
    jes "Qué encantador."

# game/choice chapter 1.rpy:804
translate Spanish time_a889852b:

    # jes "Very well, take all the time you need."
    jes "Muy bien, tómese todo el tiempo que necesite."

# game/choice chapter 1.rpy:805
translate Spanish time_de9cb362:

    # jes "Just remember..."
    jes "Solo recuerde…"

# game/choice chapter 1.rpy:807
translate Spanish time_6878d401:

    # "He leaned in slightly."
    "Se inclinó ligeramente hacia adelante."

# game/choice chapter 1.rpy:809
translate Spanish time_792809bf:

    # jes "The dry season is not known for its patience. Nor are hungry people"
    jes "La temporada seca no es conocida por su paciencia. Ni tampoco las personas hambrientas."

# game/choice chapter 1.rpy:811
translate Spanish time_50bcfa87:

    # "Oh... he is right..."
    "Oh… tiene razón…"

# game/choice chapter 1.rpy:812
translate Spanish time_fecd91a3:

    # "Being a [title] is really hard..."
    "Ser [title!t] es realmente difícil…"

# game/choice chapter 1.rpy:813
translate Spanish time_cfdc2c5c:

    # "I mean, I'm just a security guard, desperate for money just to survive."
    "Quiero decir, solo soy [arti_2] guardia de seguridad, desesperad[letra] por dinero solo para sobrevivir."

# game/choice chapter 1.rpy:814
translate Spanish time_5e35ec61:

    # "And now, all of a sudden, I'm being dragged into playing the role of a queen by living puppets."
    "Y ahora, de repente, unas marionetas vivientes me están arrastrando a interpretar el papel de [title!t]."

# game/choice chapter 1.rpy:815
translate Spanish time_20449aa2:

    # "I'm really not that fit to be a leader."
    "Realmente no soy apt[letra] para ser [arti_2] líder."

# game/choice chapter 1.rpy:820
translate Spanish yourselves_5f9b772e:

    # "...."
    "…."

# game/choice chapter 1.rpy:821
translate Spanish yourselves_9373dc2d:

    # "This is stupid."
    "Esto es estúpido."

# game/choice chapter 1.rpy:822
translate Spanish yourselves_3b49e318:

    # "I'm not a [title]. I'm just a security guard."
    "No soy [title!t]. Solo soy [arti_2] guardia de seguridad."

# game/choice chapter 1.rpy:823
translate Spanish yourselves_e40328e6:

    # "I want to go home."
    "Quiero irme a casa."

# game/choice chapter 1.rpy:825
translate Spanish yourselves_2297ff89:

    # mc "I think you can solve your problem on your own."
    mc "Creo que puedes resolver tu problema por tu cuenta."

# game/choice chapter 1.rpy:826
translate Spanish yourselves_97d48595:

    # mc "I don't understand farming, and as a farmer, you should know better what to do."
    mc "No entiendo de agricultura, y como agricultor, deberías saber mejor qué hacer."

# game/choice chapter 1.rpy:831
translate Spanish yourselves_7426e176:

    # farm ".....Your Majesty....i beg you..."
    farm "...Su Majestad... se lo suplico..."

# game/choice chapter 1.rpy:836
translate Spanish yourselves_8aa21722:

    # farm "I BEG YOU!!!"
    farm "¡¡SE LO SUPLICO!!"

# game/choice chapter 1.rpy:840
translate Spanish yourselves_01cea383:

    # "The puppet hold my shoulder tightly"
    "La marioneta sujetó mi hombro con fuerza."

# game/choice chapter 1.rpy:841
translate Spanish yourselves_69eb1ab6:

    # "Really really tight"
    "Muy, muy fuerte."

# game/choice chapter 1.rpy:843
translate Spanish yourselves_fee87583:

    # farm "{color=#FF2727}{cps=220}not again{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}no otra vez{/cps}{/color}"

# game/choice chapter 1.rpy:850
translate Spanish yourselves_fcbf8c3d:

    # farm "{color=#FF2727}{cps=220}NOT AGAIN!!{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}¡¡NO OTRA VEZ!!{/cps}{/color}"

# game/choice chapter 1.rpy:851
translate Spanish yourselves_5d4cb9bd:

    # "W-what... is this..?"
    "¿Q–qué... es esto...?"

# game/choice chapter 1.rpy:852
translate Spanish yourselves_078dff8c:

    # "Suddenly, Suddenly, my head began to throb violently, as if it were being twisted."
    "De repente, mi cabeza comenzó a palpitar violentamente, como si la estuvieran retorciendo."

# game/choice chapter 1.rpy:853
translate Spanish yourselves_cb3e95a4:

    # "My vision blurred. Yet through the haze, I saw something. something I couldn't even begin to understand."
    "Mi visión se volvió borrosa. Aun así, entre la niebla, vi algo... algo que ni siquiera podía empezar a comprender."

# game/choice chapter 1.rpy:856
translate Spanish yourselves_606f26f5:

    # farm "{color=#FF2727}{cps=220}YOU WON'T LEAVE ME LIKE HE DID WON'T YOU?!{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}¡NO ME ABANDONARÁS COMO ÉL, ¿VERDAD?!{/cps}{/color}"

# game/choice chapter 1.rpy:858
translate Spanish yourselves_cfc71ebb:

    # farm "{color=#FF2727}{cps=220}DON'T LEAVE ME!!{/cps}{/color}"
    farm "{color=#FF2727}{cps=220}¡¡NO ME ABANDONES!!{/cps}{/color}"

# game/choice chapter 1.rpy:864
translate Spanish yourselves_642fb35c:

    # jes "Ooopsyy~"
    jes "Ups~"

# game/choice chapter 1.rpy:868
translate Spanish yourselves_4ca1c9a7:

    # "Jestyn took hold of his shoulder and pulled him away from me."
    "Jestyn lo tomó del hombro y lo apartó de mí."

# game/choice chapter 1.rpy:874
translate Spanish yourselves_3bab5051:

    # jes "Didn't you hear what [poss] Majesty said, my dear farmer friend?"
    jes "¿No escuchaste lo que dijo Su Majestad, mi querido amigo agricultor?"

# game/choice chapter 1.rpy:875
translate Spanish yourselves_9ec360c0:

    # jes "[poss] Majesty said you may find your own way out. At the very least, [poss] Majesty believes in your abilities!"
    jes "Su Majestad dijo que puedes encontrar tu propio camino. Al menos, ¡Su Majestad cree en tus capacidades!"

# game/choice chapter 1.rpy:876
translate Spanish yourselves_fe4073fe:

    # jes "To be granted trust by [poss] Majesty herself is as though you've been blessed by the Fairy Mother's miracle. You should feel honored."
    jes "Ser honrado con la confianza de Su Majestad es como haber sido bendecido por el milagro del Hada Madre. Deberías sentirte honrado."

# game/choice chapter 1.rpy:877
translate Spanish yourselves_8de16e70:

    # jes "Now, it would be best for you to return and think carefully about what you must do. Do you understand, my friend?"
    jes "Ahora, lo mejor sería que regresaras y pensaras cuidadosamente en lo que debes hacer. ¿Entiendes, amigo mío?"

# game/choice chapter 1.rpy:878
translate Spanish yourselves_73880861:

    # farm "I... I understand... please forgive my insolence, Your Majesty."
    farm "Yo... lo entiendo... por favor, perdone mi insolencia, Su Majestad."

# game/choice chapter 1.rpy:883
translate Spanish yourselves_860a1e6b:

    # nara "{color=#E0AE4B}With a heavy heart, the farmer finally left the kingdom.{/color}"
    nara "{color=#E0AE4B}Con pesar, el agricultor finalmente abandonó el reino.{/color}"

# game/choice chapter 1.rpy:884
translate Spanish yourselves_fca9d1e0:

    # nara "{color=#E0AE4B}Upon hearing [poss] Majesty's decision earlier, Jestyn merely wore his usual smile.{/color}"
    nara "{color=#E0AE4B}Al escuchar la decisión que acababa de tomar Su Majestad, Jestyn se limitó a mostrar su sonrisa habitual.{/color}"

# game/choice chapter 1.rpy:886
translate Spanish yourselves_7789aa70:

    # "I could feel Jestyn's sharp gaze directed at me."
    "Pude sentir la mirada aguda de Jestyn dirigida hacia mí."

# game/choice chapter 1.rpy:890
translate Spanish yourselves_70f40038:

    # jes "...."
    jes "…."

# game/choice chapter 1.rpy:894
translate Spanish yourselves_8f599295:

    # jes "Pffft... {size= 15}not very different, hm?{/size}"
    jes "Pffft… {size= 15}no muy diferente, ¿eh?{/size}"

# game/choice chapter 1.rpy:895
translate Spanish yourselves_6046db3b:

    # mc "Huh? Did you say something?"
    mc "¿Eh? ¿Dijiste algo?"

# game/choice chapter 1.rpy:900
translate Spanish yourselves_2661682e:

    # jes "No, no, no. I didn't say anything, Your Majesty."
    jes "No, no, no. No dije nada, Su Majestad."

# game/choice chapter 1.rpy:901
translate Spanish yourselves_b6a39c97:

    # jes "You are not wrong. All the power is in your hands."
    jes "No está equivocad[letra]. Todo el poder está en sus manos."

# game/choice chapter 1.rpy:902
translate Spanish yourselves_43d17dc6:

    # jes "You may do anything you wish with that power."
    jes "Puede hacer lo que desee con ese poder."

# game/choice chapter 1.rpy:906
translate Spanish yourselves_fdb0e29e:

    # "Even though Jestyn said so, I could see his smile sharpen."
    "Aunque Jestyn dijo eso, pude ver cómo su sonrisa se volvía más afilada."

# game/choice chapter 1.rpy:909
translate Spanish yourselves_c4879b39:

    # jes "Hmm...though, to be perfectly honest, it's rather disappointing... if you were to ask me."
    jes "Hmm… aunque, para ser completamente honesto, es algo decepcionante… si me lo pregunta."

# game/choice chapter 1.rpy:916
translate Spanish teach_a8068edd:

    # mc "Well as the jester who good at juggling, why don't you just teach me?"
    mc "Bueno, si eres tan buen bufón y se te dan tan bien los malabares, ¿por qué no me enseñas?"

# game/choice chapter 1.rpy:918
translate Spanish teach_1c3b3e2c:

    # "He freezes for a moment."
    "Se queda inmóvil por un momento."

# game/choice chapter 1.rpy:920
translate Spanish teach_9b495d15:

    # jes "Teach you? You mean... teach you how to juggle?"
    jes "¿Enseñarle? ¿Quiere decir… enseñarle a hacer malabares?"

# game/choice chapter 1.rpy:921
translate Spanish teach_6fd4a9b4:

    # mc "Yes. at the very least, I want to try to not drop them right away."
    mc "Sí. Al menos, quiero intentar no dejarlas caer de inmediato."

# game/choice chapter 1.rpy:923
translate Spanish teach_0263f09b:

    # "Truthfully, I am already exhausted. But I feel like I cannot stop here."
    "La verdad, ya estoy exhaust[letra]. Pero siento que no puedo detenerme aquí."

# game/choice chapter 1.rpy:925
translate Spanish teach_24c2a984:

    # "Jestyn's surprised expression slowly turns into a wide smile."
    "La expresión sorprendida de Jestyn se transforma lentamente en una amplia sonrisa."

# game/choice chapter 1.rpy:927
translate Spanish teach_4f006298:

    # jes "How interesting, Very well, then."
    jes "Qué interesante. Muy bien, entonces."

# game/choice chapter 1.rpy:930
translate Spanish teach_8bf8d88c:

    # "He picks up the balls that had fallen and hands them back to me."
    "Recoge las pelotas que habían caído y me las devuelve."

# game/choice chapter 1.rpy:932
translate Spanish teach_eacef35b:

    # jes "Go on, give it a try."
    jes "Adelante, inténtelo."

# game/choice chapter 1.rpy:934
translate Spanish teach_b7917d9e:

    # "I brace myself and start tossing the balls, but Jestyn's gaze makes me nervous."
    "Me preparo y empiezo a lanzar las pelotas, pero la mirada de Jestyn me pone nervios[letra]."

# game/choice chapter 1.rpy:935
translate Spanish teach_4fae875f:

    # "Even so, I throw them into the air."
    "Aun así, las lanzo al aire."

# game/choice chapter 1.rpy:937
translate Spanish teach_0ed3c7cd:

    # "Jestyn lets out a soft laugh as he watches my attempt."
    "Jestyn deja escapar una risa suave mientras observa mi intento."

# game/choice chapter 1.rpy:939
translate Spanish teach_e0860bcf:

    # jes "Your majesty, it can hardly be called juggling if you do it that slowly."
    jes "Su Majestad, difícilmente puede llamarse malabares si lo hace tan lento."

# game/choice chapter 1.rpy:940
translate Spanish teach_4b89bc23:

    # mc "Oh, come on! I'm learning here!"
    mc "¡Oh, vamos! ¡Estoy aprendiendo!"

# game/choice chapter 1.rpy:943
translate Spanish teach_ec065d5c:

    # "He snaps his fingers, and suddenly more balls appear in his hand."
    "Chasquea los dedos y, de repente, aparecen más pelotas en su mano."

# game/choice chapter 1.rpy:944
translate Spanish teach_daa28512:

    # "He begins juggling as well. Though it feels less like practice and more like showing off."
    "Él también empieza a hacer malabares. Aunque se siente menos como práctica y más como presumir."

# game/choice chapter 1.rpy:945
translate Spanish teach_b466695c:

    # "He performs trick after trick with ease, while I... continue tossing the balls slowly, what I insist on calling 'juggling.'"
    "Realiza truco tras truco con facilidad, mientras yo… continúo lanzando las pelotas lentamente, lo que insisto en llamar “malabares”."

# game/choice chapter 1.rpy:946
translate Spanish teach_ffdb6aa0:

    # "The way he teases me is genuinely irritating."
    "La forma en que se burla de mí es realmente irritante."

# game/choice chapter 1.rpy:947
translate Spanish teach_e097e94f:

    # "When I try to speed up, a few balls nearly slip from my hands, and some fall to the floor."
    "Cuando intento acelerar, algunas pelotas casi se me escapan de las manos y otras caen al suelo."

# game/choice chapter 1.rpy:950
translate Spanish teach_2353fec3:

    # jes "Hahahaha! Come now, just accept it you simply can't do it your majesty."
    jes "¡Ja, ja, ja! Vamos, admítalo, simplemente no puede hacerlo, Su Majestad."

# game/choice chapter 1.rpy:952
translate Spanish teach_d7f95ee5:

    # mc "But i asked you to teach me. Not mocking me. I don't feel like you teach me something about juggling"
    mc "Pero te pedí que me enseñaras. No que te burlaras de mí. No siento que me estés enseñando algo sobre malabares."

# game/choice chapter 1.rpy:953
translate Spanish teach_89d9c769:

    # jes "I do my dear, i teach you through experience"
    jes "Sí lo hago, querid[letra]. Le enseño a través de la experiencia."

# game/choice chapter 1.rpy:954
translate Spanish teach_54057719:

    # mc "I don't think that is how it works..."
    mc "No creo que así funcione…"

# game/choice chapter 1.rpy:955
translate Spanish teach_59761f3d:

    # jes "Ah, but what a truly remarkable enthusiasm for learning, dear. Such dedication surely deserves... a gift."
    jes "Ah, pero qué entusiasmo tan notable por aprender, querid[letra]. Tal dedicación sin duda merece… un regalo."

# game/choice chapter 1.rpy:957
translate Spanish teach_75dac18b:

    # "Jestyn suddenly tosses a single ball toward me, startling me and causing all of my balls to fall."
    "Jestyn de repente lanza una sola pelota hacia mí, sobresaltándome y haciendo que todas las demás se me caigan."

# game/choice chapter 1.rpy:958
translate Spanish teach_d9c47830:

    # "As I try to catch it, the ball suddenly vanishes into thin air."
    "Cuando intento atraparla, la pelota desaparece de la nada."

# game/choice chapter 1.rpy:961
translate Spanish teach_7b26cc90:

    # jes "Oh? It seems your catching skills are just as dreadful, your majesty"
    jes "¿Oh? Parece que sus habilidades para atrapar son igual de pésimas, Su Majestad."

# game/choice chapter 1.rpy:962
translate Spanish teach_ccdac953:

    # jes "Allow me. I shall catch it for you."
    jes "Permítame. La atraparé por usted."

# game/choice chapter 1.rpy:964
translate Spanish teach_4a05fb50:

    # "His arm reaches out, stopping just behind my ear."
    "Su brazo se extiende, deteniéndose justo detrás de mi oreja."

# game/choice chapter 1.rpy:968
translate Spanish teach_562d842e:

    # jes "Care to guess where the ball is?"
    jes "¿Le gustaría adivinar dónde está la pelota?"

# game/choice chapter 1.rpy:980
translate Spanish snakebunny_9bb39788:

    # jes "When I choose his left hand, a small snake doll appears."
    jes "Cuando elijo su mano izquierda, aparece un pequeño muñeco de serpiente."

# game/choice chapter 1.rpy:981
translate Spanish snakebunny_640c5bae:

    # jes "An excellent choice, Your Majesty."
    jes "Una excelente elección, Su Majestad."

# game/choice chapter 1.rpy:982
translate Spanish snakebunny_bc7fc48c:

    # jes "A gift from me... to you."
    jes "Un regalo de mí… para usted."

# game/choice chapter 1.rpy:985
translate Spanish snakebunny_78dff35c:

    # "He takes a step back."
    "Da un paso atrás."

# game/choice chapter 1.rpy:986
translate Spanish snakebunny_5ae637bc:

    # "Did he just do a magic trick?!"
    "¿Acaba de hacer un truco de magia?"

# game/choice chapter 1.rpy:988
translate Spanish snakebunny_bd4a4813:

    # mc "Oh! That's so cool! How did you do that?!"
    mc "¡Oh! ¡Eso es genial! ¡¿Cómo lo has hecho?!"

# game/choice chapter 1.rpy:991
translate Spanish snakebunny_597f50e6:

    # "Jestyn fell silent for a moment, before his smile slowly returned."
    "Jestyn guarda silencio por un momento, antes de que su sonrisa regrese lentamente."

# game/choice chapter 1.rpy:993
translate Spanish snakebunny_0b0481e1:

    # jes "That is a jester's secret, my dear. I could never tell you~"
    jes "Ese es un secreto de bufón, querid[letra]. Nunca podría decírselo~"

# game/choice chapter 1.rpy:995
translate Spanish snakebunny_1a1e1df0:

    # "Jestyn said teasingly"
    "Dijo Jestyn con tono juguetón."

# game/choice chapter 1.rpy:997
translate Spanish snakebunny_b2afd01b:

    # mc "Then... Can i see more?."
    mc "Entonces… ¿puedo ver más?"

# game/choice chapter 1.rpy:999
translate Spanish snakebunny_deeff8f2:

    # jes "Oh..."
    jes "Oh…"

# game/choice chapter 1.rpy:1001
translate Spanish snakebunny_8a7b7d6c:

    # "Why did he make that expression? Did I say something wrong?"
    "¿Por qué puso esa expresión? ¿Dije algo mal?"

# game/choice chapter 1.rpy:1004
translate Spanish snakebunny_b007eb96:

    # jes "Hahaha! Such a curious little thing, hm?"
    jes "¡Jajaja! Qué cosita tan curiosa, ¿eh?"

# game/choice chapter 1.rpy:1007
translate Spanish snakebunny_bbb3891f:

    # "He start to clenched his hand, then began pulling a piece of cloth from his palm."
    "Empieza a cerrar el puño, luego comienza a sacar un trozo de tela desde su palma."

# game/choice chapter 1.rpy:1008
translate Spanish snakebunny_e13e12a8:

    # "As he pulled, the cloth only grew longer and longer."
    "A medida que tira de ella, la tela solo se hace más y más larga."

# game/choice chapter 1.rpy:1011
translate Spanish snakebunny_f7392af4:

    # mc "How is that possible?!"
    mc "¡¿Cómo es eso posible?!"

# game/choice chapter 1.rpy:1013
translate Spanish snakebunny_6b9b7aff:

    # "He squeezed the cloth tightly."
    "Aprieta la tela con fuerza."

# game/choice chapter 1.rpy:1014
translate Spanish snakebunny_b986bf3b:

    # "What is he doing now?"
    "¿Qué está haciendo ahora?"

# game/choice chapter 1.rpy:1016
translate Spanish snakebunny_354dc1bc:

    # "When he opened it again, a small rabbit doll suddenly appeared inside."
    "Cuando la abre de nuevo, un pequeño muñeco de conejo aparece de repente dentro."

# game/choice chapter 1.rpy:1018
translate Spanish snakebunny_ecebd32f:

    # mc "Oh! that's amazing!"
    mc "¡Oh! ¡Eso es increíble!"

# game/choice chapter 1.rpy:1021
translate Spanish snakebunny_08e2e355:

    # jes "And now, the royal jester's magic show has come to an end. Thank you for your attention."
    jes "Y ahora, el espectáculo de magia del bufón real ha llegado a su fin. Gracias por su atención."

# game/choice chapter 1.rpy:1028
translate Spanish bunnysnake_bc84d5b1:

    # jes "When I choose his right hand, a small bunny doll appears."
    jes "Cuando elijo su mano derecha, aparece un pequeño muñeco de conejo."

# game/choice chapter 1.rpy:1029
translate Spanish bunnysnake_640c5bae:

    # jes "An excellent choice, Your Majesty."
    jes "Una excelente elección, Su Majestad."

# game/choice chapter 1.rpy:1030
translate Spanish bunnysnake_bc7fc48c:

    # jes "A gift from me... to you."
    jes "Un regalo de mí… para usted."

# game/choice chapter 1.rpy:1033
translate Spanish bunnysnake_78dff35c:

    # "He takes a step back."
    "Da un paso atrás."

# game/choice chapter 1.rpy:1034
translate Spanish bunnysnake_5ae637bc:

    # "Did he just do a magic trick?!"
    "¿Acaba de hacer un truco de magia?"

# game/choice chapter 1.rpy:1036
translate Spanish bunnysnake_bd4a4813:

    # mc "Oh! That's so cool! How did you do that?!"
    mc "¡Oh! ¡Eso es genial! ¡¿Cómo lo has hecho?!"

# game/choice chapter 1.rpy:1039
translate Spanish bunnysnake_597f50e6:

    # "Jestyn fell silent for a moment, before his smile slowly returned."
    "Jestyn guarda silencio por un momento, antes de que su sonrisa regrese lentamente."

# game/choice chapter 1.rpy:1041
translate Spanish bunnysnake_0b0481e1:

    # jes "That is a jester's secret, my dear. I could never tell you~"
    jes "Ese es un secreto de bufón, querid[letra]. Nunca podría decírselo~"

# game/choice chapter 1.rpy:1043
translate Spanish bunnysnake_1a1e1df0:

    # "Jestyn said teasingly"
    "Dijo Jestyn con tono juguetón."

# game/choice chapter 1.rpy:1045
translate Spanish bunnysnake_b2afd01b:

    # mc "Then... Can i see more?."
    mc "Entonces… ¿puedo ver más?"

# game/choice chapter 1.rpy:1047
translate Spanish bunnysnake_deeff8f2:

    # jes "Oh..."
    jes "Oh…"

# game/choice chapter 1.rpy:1049
translate Spanish bunnysnake_8a7b7d6c:

    # "Why did he make that expression? Did I say something wrong?"
    "¿Por qué puso esa expresión? ¿Dije algo mal?"

# game/choice chapter 1.rpy:1052
translate Spanish bunnysnake_b007eb96:

    # jes "Hahaha! Such a curious little thing, hm?"
    jes "¡Jajaja! Qué cosita tan curiosa, ¿eh?"

# game/choice chapter 1.rpy:1055
translate Spanish bunnysnake_bbb3891f:

    # "He start to clenched his hand, then began pulling a piece of cloth from his palm."
    "Empieza a cerrar el puño, luego comienza a sacar un trozo de tela desde su palma."

# game/choice chapter 1.rpy:1056
translate Spanish bunnysnake_e13e12a8:

    # "As he pulled, the cloth only grew longer and longer."
    "A medida que tira de ella, la tela solo se hace más y más larga."

# game/choice chapter 1.rpy:1058
translate Spanish bunnysnake_f7392af4:

    # mc "How is that possible?!"
    mc "¡¿Cómo es eso posible?!"

# game/choice chapter 1.rpy:1061
translate Spanish bunnysnake_6b9b7aff:

    # "He squeezed the cloth tightly."
    "Aprieta la tela con fuerza."

# game/choice chapter 1.rpy:1062
translate Spanish bunnysnake_b986bf3b:

    # "What is he doing now?"
    "¿Qué está haciendo ahora?"

# game/choice chapter 1.rpy:1064
translate Spanish bunnysnake_8509cf99:

    # "When he opened it again, a small snake doll suddenly appeared inside."
    "Cuando la abre de nuevo, un pequeño muñeco de serpiente aparece de repente dentro."

# game/choice chapter 1.rpy:1066
translate Spanish bunnysnake_ecebd32f:

    # mc "Oh! that's amazing!"
    mc "¡Oh! ¡Eso es increíble!"

# game/choice chapter 1.rpy:1069
translate Spanish bunnysnake_08e2e355:

    # jes "And now, the royal jester's magic show has come to an end. Thank you for your attention."
    jes "Y ahora, el espectáculo de magia del bufón real ha llegado a su fin. Gracias por su atención."

# game/choice chapter 1.rpy:1077
translate Spanish agree_1d66e373:

    # jes "How decisive, Your Majesty."
    jes "Qué decisión tan firme, Su Majestad."

# game/choice chapter 1.rpy:1078
translate Spanish agree_88549114:

    # jes "Gold has a way of making difficult choices appear... simpler."
    jes "El oro tiene una forma de hacer que las decisiones difíciles parezcan… más simples."

# game/choice chapter 1.rpy:1080
translate Spanish agree_13c3b0b7:

    # jes "Let us hope the land proves less costly than it seems."
    jes "Esperemos que la tierra resulte menos costosa de lo que parece."

# game/choice chapter 1.rpy:1086
translate Spanish Refuse_27f4f767:

    # jes "Oh?"
    jes "¿Oh?"

# game/choice chapter 1.rpy:1087
translate Spanish Refuse_2e654457:

    # jes "To turn down such generosity... how admirable."
    jes "Rechazar semejante generosidad… qué admirable."

# game/choice chapter 1.rpy:1089
translate Spanish Refuse_a40bea02:

    # jes "One can only hope our neighbors share Your Majesty's appreciation for principles."
    jes "Solo cabe esperar que nuestros vecinos compartan el apego de Su Majestad a sus principios."

# game/choice chapter 1.rpy:1096
translate Spanish delay_db12c9a8:

    # jes "Hehe...Your Majesty, truly?"
    jes "Jeje… Su Majestad, ¿en serio?"

# game/choice chapter 1.rpy:1097
translate Spanish delay_caf27151:

    # jes "Surely you don't intend to keep postponing your decisions whenever a problem arises?"
    jes "¿No pretenderá seguir posponiendo sus decisiones cada vez que surja un problema?"

# game/choice chapter 1.rpy:1099
translate Spanish delay_3a38b30d:

    # jes "Since I pride myself on being an honest man, I must say...that is terribly naive. And rather pitiful."
    jes "Como me enorgullezco de ser un hombre honesto, debo decir… que eso es terriblemente ingenuo. Y bastante lamentable."

# game/choice chapter 1.rpy:1100
translate Spanish delay_315de719:

    # jes "Perhaps we should revise the wording. Instead of 'taking your time to decide'... we might call it what it truly is, 'running away from your problems'"
    jes "Quizá deberíamos reformularlo. En lugar de “tomarse su tiempo para decidir”… podríamos llamarlo por lo que realmente es: “huir de sus problemas”."

# game/choice chapter 1.rpy:1101
translate Spanish delay_4cd35246:

    # jes "No matter how far you run, no matter how fast you run... time will always run alongside you."
    jes "No importa qué tan lejos corra, no importa qué tan rápido corra… el tiempo siempre correrá a su lado."

# game/choice chapter 1.rpy:1103
translate Spanish delay_58244563:

    # jes "So... tick tock, tick tock, Your Majesty~"
    jes "Así que… tic tac, tic tac, Su Majestad~"

# game/choice chapter 1.rpy:1109
translate Spanish delay_cb35ed05:

    # jes "Of course, Your Majesty."
    jes "Por supuesto, Su Majestad."

# game/choice chapter 1.rpy:1111
translate Spanish delay_a120d3c0:

    # jes "After all, a choice left undecided is still a choice."
    jes "Después de todo, una decisión no tomada sigue siendo una decisión."

# game/choice chapter 1.rpy:1113
translate Spanish delay_82634f5a:

    # jes "Time, however, is rarely as patient as we wish it to be."
    jes "El tiempo, sin embargo, rara vez es tan paciente como quisiéramos."

# game/choice chapter 1.rpy:1119
translate Spanish collar_e5aed65e:

    # mc "A collar?"
    mc "¿Un collar?"

# game/choice chapter 1.rpy:1121
translate Spanish collar_ffdc22c3:

    # "In his hand appears a red collar, with a golden bell at its center."
    "En su mano aparece un collar rojo, con una campana dorada en el centro."

# game/choice chapter 1.rpy:1123
translate Spanish collar_16429228:

    # jes "That is correct, Your Majesty."
    jes "Así es, Su Majestad."

# game/choice chapter 1.rpy:1128
translate Spanish collar_894d6f7f:

    # "He then removes his tie and loosens his collar."
    "Luego se quita la corbata y afloja el cuello de su camisa."

# game/choice chapter 1.rpy:1129
translate Spanish collar_acafd5f8:

    # "Confused, I can only remain seated, unable to move."
    "Confundid[letra], solo puedo permanecer sentad[letra], incapaz de moverme."

# game/choice chapter 1.rpy:1131
translate Spanish collar_722aa7ad:

    # "Yet the moment he places the collar around his neck, I begin to understand what he intends."
    "Pero en el momento en que se coloca el collar alrededor del cuello, empiezo a entender lo que pretende."

# game/choice chapter 1.rpy:1132
translate Spanish collar_cc94c9be:

    # "Once it is fastened, he gently places the leash into my hand."
    "Una vez ajustado, coloca suavemente la correa en mi mano."

# game/choice chapter 1.rpy:1133
translate Spanish collar_2cf97c0f:

    # "I take it."
    "La tomo."

# game/choice chapter 1.rpy:1136
translate Spanish collar_e7f9ccd9:

    # jes "Please..."
    jes "Por favor…"

# game/choice chapter 1.rpy:1139
translate Spanish collar_5ecd1880:

    # "His voice grows heavy."
    "Su voz se vuelve más pesada."

# game/choice chapter 1.rpy:1143
translate Spanish collar_ab6bad21:

    # jes "I am yours to command, Your Majesty... Do with me whatever you wish."
    jes "Soy suyo para que me dé órdenes, Su Majestad… Haga conmigo lo que desee."

# game/choice chapter 1.rpy:1145
translate Spanish collar_bab2099c:

    # "How did things end up like this?!"
    "¡¿Cómo hemos llegado a esto?!"

# game/choice chapter 1.rpy:1147
translate Spanish collar_46da67fd:

    # mc "J-Jestyn... this..."
    mc "J–Jestyn… esto…"

# game/choice chapter 1.rpy:1149
translate Spanish collar_db6d0895:

    # jes "You may command me to do anything, Your Majesty."
    jes "Puede ordenarme cualquier cosa, Su Majestad."

# game/choice chapter 1.rpy:1151
translate Spanish collar_0e2c9658:

    # jes "Sit. Lie down. Open my mouth... Whatever you order, I shall obey."
    jes "Sentarme. Acostarme. Abrir la boca… Lo que usted ordene, lo obedeceré."

# game/choice chapter 1.rpy:1152
translate Spanish collar_050160d9:

    # jes "Please, relax yourself, Your Majesty. And enjoy yourself with me."
    jes "Por favor, relájese, Su Majestad. Y disfrute conmigo."

# game/choice chapter 1.rpy:1154
translate Spanish collar_3f232bfb:

    # jes "I will entertain you."
    jes "Le entretendré."

# game/choice chapter 1.rpy:1156
translate Spanish collar_d6ed0595:

    # "I've never done anything like this before."
    "Nunca he hecho algo así antes."

# game/choice chapter 1.rpy:1157
translate Spanish collar_bdc39949:

    # "But... if he says he'll do anything... then, I suppose... fine."
    "Pero… si dice que hará cualquier cosa… entonces, supongo… está bien."

# game/choice chapter 1.rpy:1169
translate Spanish sit_6cea9129:

    # "The moment I give the order, Jestyn obediently sits on the stage floor."
    "En el momento en que doy la orden, Jestyn se sienta obedientemente en el suelo del escenario."

# game/choice chapter 1.rpy:1170
translate Spanish sit_a0a396a9:

    # "He looks stright at me, waiting for my next command."
    "Me mira directamente, esperando mi siguiente orden."

# game/choice chapter 1.rpy:1176
translate Spanish sit_a6f8b666:

    # "I decide to tug on his collar, drawing a surprised gasp from him."
    "Decido tirar de su collar, provocando un jadeo sorprendido en él."

# game/choice chapter 1.rpy:1177
translate Spanish sit_e175d71d:

    # "His smile only widens."
    "Su sonrisa solo se ensancha."

# game/choice chapter 1.rpy:1180
translate Spanish sit_108799bc:

    # jes "Your Majesty..."
    jes "Su Majestad…"

# game/choice chapter 1.rpy:1181
translate Spanish sit_4e3164ad:

    # mc "Come closer."
    mc "Acércate."

# game/choice chapter 1.rpy:1185
translate Spanish sit_88d535aa:

    # "He crawls toward me."
    "Se arrastra hacia mí."

# game/choice chapter 1.rpy:1188
translate Spanish sit_da7f9393:

    # "I can't believe I'm really doing this."
    "No puedo creer que realmente esté haciendo esto."

# game/choice chapter 1.rpy:1189
translate Spanish sit_afaf268f:

    # "But strangely despite me still feel scared... it feels exciting."
    "Pero, aunque todavía tengo miedo… extrañamente, también me resulta emocionante."

# game/choice chapter 1.rpy:1190
translate Spanish sit_efcbcf89:

    # "Watching the face I've never been able to read behind that constant smile slowly shift into something almost... adorable."
    "Observar ese rostro que nunca he podido descifrar detrás de esa sonrisa constante cambiar lentamente a algo casi… adorable."

# game/choice chapter 1.rpy:1193
translate Spanish sit_50bf0686:

    # jes "I had assumed you were inexperienced, Your Majesty..."
    jes "Había asumido que no tenía experiencia, Su Majestad…"

# game/choice chapter 1.rpy:1195
translate Spanish sit_88fca87a:

    # jes "Yet from what I am witnessing now, you resemble someone who is far more... accustomed to such things."
    jes "Sin embargo, por lo que estoy viendo ahora, parece alguien mucho más… acostumbrad[letra] a este tipo de cosas."

# game/choice chapter 1.rpy:1197
translate Spanish sit_76fcfa43:

    # jes "With others..."
    jes "Con otros…"

# game/choice chapter 1.rpy:1199
translate Spanish sit_12c554f6:

    # "For just a fleeting second, the warmth in his smile falters."
    "Por un breve instante, la calidez en su sonrisa vacila."

# game/choice chapter 1.rpy:1200
translate Spanish sit_d551021a:

    # "Something darker slips through, an emotion I can't quite name. Sharp and sudden, before he masks it again."
    "Algo más oscuro se filtra, una emoción que no puedo nombrar del todo… aguda y repentina, antes de que la oculte de nuevo."

# game/choice chapter 1.rpy:1202
translate Spanish sit_ceab5d6d:

    # mc "Of course not. I've never done anything like this before. I'm only following my instincts."
    mc "Claro que no. Nunca he hecho algo así antes. Solo estoy siguiendo mis instintos."

# game/choice chapter 1.rpy:1206
translate Spanish sit_f694b0af:

    # jes "Hehe... is that so?"
    jes "Jeje… ¿es así?"

# game/choice chapter 1.rpy:1209
translate Spanish sit_949d98d1:

    # "On impulse, I lift my hand and gently run my fingers through his hood."
    "Por impulso, levanto la mano y paso suavemente mis dedos por su gorro."

# game/choice chapter 1.rpy:1212
translate Spanish sit_3968d4e4:

    # "For a moment, he stiffens. Just slightly as if caught off guard by the tenderness of the gesture."
    "Por un momento, se tensa. Solo un poco, como si le sorprendiera la delicadeza del gesto."

# game/choice chapter 1.rpy:1214
translate Spanish sit_ea073ec7:

    # "Then, slowly, he relaxes."
    "Luego, lentamente, se relaja."

# game/choice chapter 1.rpy:1216
translate Spanish sit_8ac2c9f1:

    # "Jestyn closes his eyes and leans into my touch, as though seeking more of it."
    "Jestyn cierra los ojos y se inclina hacia mi toque, como si buscara más."

# game/choice chapter 1.rpy:1217
translate Spanish sit_1b489dd2:

    # "The smile he wears now is different from his usual one. It's softer, unguarded, almost vulnerable."
    "La sonrisa que lleva ahora es diferente a la habitual. Es más suave, desprotegida, casi vulnerable."

# game/choice chapter 1.rpy:1218
translate Spanish sit_60f757ec:

    # ".... It seems he likes it."
    "… Parece que le gusta."

# game/choice chapter 1.rpy:1219
translate Spanish sit_99ed04fd:

    # jes "...You are a kind person, Your Majesty."
    jes "… Es usted una persona amable, Su Majestad."

# game/choice chapter 1.rpy:1220
translate Spanish sit_2727f7ad:

    # mc "What makes you think that?"
    mc "¿Qué le hace pensar eso?"

# game/choice chapter 1.rpy:1222
translate Spanish sit_40b7c6a1:

    # jes "I had expected you to be rough with me in this situation."
    jes "Esperaba que fuera brusc[letra] conmigo en esta situación."

# game/choice chapter 1.rpy:1223
translate Spanish sit_5eb35cff:

    # jes "But instead, you chose to touch me gently... It feels strange. But I certainly will not complain about that."
    jes "Pero en cambio, eligió tocarme con suavidad… Se siente extraño. Pero ciertamente no me quejaré de ello."

# game/choice chapter 1.rpy:1225
translate Spanish sit_cc6d22af:

    # "Is being gentle really that strange?"
    "¿Ser amable es realmente tan extraño?"

# game/choice chapter 1.rpy:1229
translate Spanish sit_e58ca943:

    # "I'm startled when Jestyn suddenly lowers his head into my lap."
    "Me sobresalto cuando Jestyn de repente baja la cabeza hasta mi regazo."

# game/choice chapter 1.rpy:1230
translate Spanish sit_07bdde05:

    # "....."
    "….."

# game/choice chapter 1.rpy:1231
translate Spanish sit_dfef9dae:

    # "For some reason, it feels as though I've gained a strange little pet."
    "Por alguna razón, se siente como si hubiera ganado una extraña pequeña mascota."

# game/choice chapter 1.rpy:1232
translate Spanish sit_8480bbe8:

    # "The fear and confusion I felt earlier slowly melt away, replaced by something unexpectedly calming."
    "El miedo y la confusión que sentía antes se desvanecen lentamente, reemplazados por algo inesperadamente reconfortante."

# game/choice chapter 1.rpy:1234
translate Spanish sit_70f40038:

    # jes "...."
    jes "…."

# game/choice chapter 1.rpy:1235
translate Spanish sit_5f312095:

    # jes "This is the first time I've ever felt something like this, Your Majesty."
    jes "Es la primera vez que siento algo así, Su Majestad."

# game/choice chapter 1.rpy:1236
translate Spanish sit_1c45e19a:

    # mc "Hm? Felt what?"
    mc "¿Hm? ¿Qué sentiste?"

# game/choice chapter 1.rpy:1238
translate Spanish sit_cd6e4ea2:

    # jes "I don't know. Strangely, I can't seem to put it into words."
    jes "No lo sé. Extrañamente, no logro ponerlo en palabras."

# game/choice chapter 1.rpy:1239
translate Spanish sit_1834ea2e:

    # jes "For someone who loves talking, I'm usually never at a loss when it comes to expressing what I feel... what I think."
    jes "Para alguien a quien le encanta hablar, normalmente nunca me quedo sin palabras cuando se trata de expresar lo que siento… lo que pienso."

# game/choice chapter 1.rpy:1241
translate Spanish sit_ae242643:

    # jes "But this... I don't know. It feels something like happiness, perhaps. Yet even that word doesn't quite seem right."
    jes "Pero esto… no lo sé. Se siente como algo parecido a la felicidad, tal vez. Aunque ni siquiera esa palabra parece del todo correcta."

# game/choice chapter 1.rpy:1242
translate Spanish sit_c06d04cc:

    # jes "Perhaps Your Majesty has cast a spell on me?"
    jes "¿Quizá Su Majestad me ha lanzado un hechizo?"

# game/choice chapter 1.rpy:1244
translate Spanish sit_c0a88657:

    # "I let out a small laugh at his ridiculous speculation."
    "Dejo escapar una pequeña risa ante su ridícula suposición."

# game/choice chapter 1.rpy:1246
translate Spanish sit_857b17fa:

    # mc "Don't be silly."
    mc "No seas tonto."

# game/choice chapter 1.rpy:1249
translate Spanish sit_17aa1f60:

    # "Silence settles around us for a while. But it isn't awkward."
    "El silencio se instala entre nosotros por un momento. Pero no es incómodo."

# game/choice chapter 1.rpy:1250
translate Spanish sit_ef50337f:

    # "Throughout it, I continue stroking Jestyn's head."
    "Durante todo ese tiempo, sigo acariciando la cabeza de Jestyn."

# game/choice chapter 1.rpy:1251
translate Spanish sit_04cdf4c4:

    # "This strange situation somehow makes me feel at ease... my miserable life has never felt quite like this."
    "De alguna manera, esta extraña situación me hace sentir en paz… Nunca había experimentado algo así en mi miserable vida."

# game/choice chapter 1.rpy:1254
translate Spanish sit_d05e83be:

    # "After several minutes in the same position, Jestyn finally snaps his fingers and in an instant, the collar around his neck vanishes."
    "Después de varios minutos en la misma posición, Jestyn finalmente chasquea los dedos y, en un instante, el collar alrededor de su cuello desaparece."

# game/choice chapter 1.rpy:1260
translate Spanish lie_d56c4269:

    # "The moment I give the order, Jestyn obediently lie down on the stage floor."
    "En el momento en que doy la orden, Jestyn se acuesta obedientemente en el suelo del escenario."

# game/choice chapter 1.rpy:1261
translate Spanish lie_850ab860:

    # "After he lies down, I begin to walk toward him."
    "Después de que se recuesta, empiezo a caminar hacia él."

# game/choice chapter 1.rpy:1265
translate Spanish lie_b8c4b568:

    # "He looks up at me from below, waiting for my next command."
    "Me mira desde abajo, esperando mi siguiente orden."

# game/choice chapter 1.rpy:1266
translate Spanish lie_a6f8b666:

    # "I decide to tug on his collar, drawing a surprised gasp from him."
    "Decido tirar de su collar, provocando un jadeo sorprendido en él."

# game/choice chapter 1.rpy:1267
translate Spanish lie_e175d71d:

    # "His smile only widens."
    "Su sonrisa solo se ensancha."

# game/choice chapter 1.rpy:1269
translate Spanish lie_108799bc:

    # jes "Your Majesty..."
    jes "Su Majestad…"

# game/choice chapter 1.rpy:1271
translate Spanish lie_40b395b0:

    # "Alright.... I've never done anything like this in my life. What do people usually do in situations like this?"
    "Está bien… nunca he hecho algo así en mi vida. ¿Qué suele hacer la gente en situaciones como esta?"

# game/choice chapter 1.rpy:1272
translate Spanish lie_566b0074:

    # "I've seen people step on their partners before... should I try that?"
    "He visto a personas pisar a sus parejas antes… ¿debería intentarlo?"

# game/choice chapter 1.rpy:1273
translate Spanish lie_16cfddb0:

    # "Armed with the little knowledge I picked up from the internet, I carefully place my foot on his chest."
    "Armad[letra] con el poco conocimiento que recogí de internet, coloco cuidadosamente mi pie sobre su pecho."

# game/choice chapter 1.rpy:1279
translate Spanish lie_ec795997:

    # jes "Nnn.."
    jes "Nnn…"

# game/choice chapter 1.rpy:1281
translate Spanish lie_093e6837:

    # "I do place my foot there, but I'm certain he can tell I'm still hesitant."
    "Sí pongo mi pie ahí, pero estoy segur[letra] de que puede notar que aún dudo."

# game/choice chapter 1.rpy:1282
translate Spanish lie_717d1cef:

    # "I'm not putting any real pressure on him."
    "No estoy ejerciendo presión real sobre él."

# game/choice chapter 1.rpy:1285
translate Spanish lie_996931a3:

    # jes "Hehe.. Your Majesty, you're very adoreable."
    jes "Jeje… Su Majestad, es usted muy adorable."

# game/choice chapter 1.rpy:1286
translate Spanish lie_cd2666c8:

    # mc "Hm...?"
    mc "Hm…?"

# game/choice chapter 1.rpy:1287
translate Spanish lie_55a1f6d7:

    # jes "You're trying to be rough... but it seems your heart is far too gentle for that."
    jes "Está intentando ser brusc[letra]… pero parece que su corazón es demasiado gentil para eso."

# game/choice chapter 1.rpy:1289
translate Spanish lie_658671f0:

    # "Just as I thought, he noticed."
    "Tal como pensé, lo notó."

# game/choice chapter 1.rpy:1291
translate Spanish lie_52cdd364:

    # jes "It's very sweet, knowing you don't want to hurt me, Your Majesty... But rest assured, I'll be just fine."
    jes "Es muy dulce saber que no quiere lastimarme, Su Majestad… Pero tenga la seguridad de que estaré bien."

# game/choice chapter 1.rpy:1292
translate Spanish lie_c88fb2a5:

    # jes "So, if you wish to be rough with me... please don't hesitate."
    jes "Así que, si desea ser brusc[letra] conmigo… por favor, no dude."

# game/choice chapter 1.rpy:1294
translate Spanish lie_34b5a568:

    # "My heart starts pounding, sweat dampening my back."
    "Mi corazón empieza a latir con fuerza, el sudor humedece mi espalda."

# game/choice chapter 1.rpy:1295
translate Spanish lie_14edcecb:

    # "How am I supposed to know when I've gone too far... and when I haven't?"
    "¿Cómo se supone que voy a saber cuándo me he pasado… y cuándo no?"

# game/choice chapter 1.rpy:1296
translate Spanish lie_98252d2e:

    # "Sensing my fear and uncertainty, Jestyn decides to guide me instead."
    "Percibiendo mi miedo e incertidumbre, Jestyn decide guiarme."

# game/choice chapter 1.rpy:1299
translate Spanish lie_796ed025:

    # jes "Focus your strength in your foot, then slowly press it against my chest."
    jes "Concentre su fuerza en su pie, luego presiónelo lentamente contra mi pecho."

# game/choice chapter 1.rpy:1301
translate Spanish lie_fed21080:

    # "I follow his instructions."
    "Sigo sus instrucciones."

# game/choice chapter 1.rpy:1302
translate Spanish lie_8812d370:

    # "I shift my weight into my foot and gently press down on Jestyn's chest."
    "Cambio mi peso hacia el pie y presiono suavemente el pecho de Jestyn."

# game/choice chapter 1.rpy:1305
translate Spanish lie_a568a0f2:

    # jes "... Very good..."
    jes "…Muy bien…"

# game/choice chapter 1.rpy:1306
translate Spanish lie_36195334:

    # jes "See? I'm still perfectly fine..."
    jes "¿Ve? Sigo perfectamente bien…"

# game/choice chapter 1.rpy:1308
translate Spanish lie_8ce61eb8:

    # "I nod."
    "Asiento con la cabeza."

# game/choice chapter 1.rpy:1310
translate Spanish lie_a9a4b134:

    # jes "Now try stomping down, Your Majesty... just once."
    jes "Ahora intente pisar con más fuerza, Su Majestad… solo una vez."

# game/choice chapter 1.rpy:1315
translate Spanish lie_90b5f220:

    # "When I stomp my foot against his chest, Jestyn lets out a soft sound that instantly makes my heart pound even harder."
    "Cuando piso su pecho, Jestyn deja escapar un suave sonido que hace que mi corazón lata aún más rápido."

# game/choice chapter 1.rpy:1317
translate Spanish lie_3cdc56b9:

    # "This... strangely feels good."
    "Esto… se siente extrañamente bien."

# game/choice chapter 1.rpy:1319
translate Spanish lie_16feb3c4:

    # jes "Now you're learning, Your Majesty... Try stepping on my chest while tugging on my collar."
    jes "Ahora está aprendiendo, Su Majestad… Intente pisar mi pecho mientras tira de mi collar."

# game/choice chapter 1.rpy:1321
translate Spanish lie_7aa9032c:

    # "I press my foot against his chest again while tugging on his collar."
    "Presiono mi pie contra su pecho nuevamente mientras tiro de su collar."

# game/choice chapter 1.rpy:1326
translate Spanish lie_83f1a972:

    # jes "Ah-!"
    jes "Ah—"

# game/choice chapter 1.rpy:1329
translate Spanish lie_0934efd4:

    # "Jestyn's face grows even redder."
    "El rostro de Jestyn se enrojece aún más."

# game/choice chapter 1.rpy:1332
translate Spanish lie_b13c6026:

    # jes "How is your gift so far, Your Majesty...? Are you enjoying it...?"
    jes "¿Qué le está pareciendo su regalo, Su Majestad…? ¿Lo está disfrutando…?"

# game/choice chapter 1.rpy:1334
translate Spanish lie_5f9b772e:

    # "...."
    "…."

# game/choice chapter 1.rpy:1336
translate Spanish lie_fe9daad5:

    # mc "Y-yeah... this is nice..."
    mc "S–sí… esto es agradable…"

# game/choice chapter 1.rpy:1338
translate Spanish lie_f2dcf0de:

    # "Maybe I could try something else."
    "Quizá podría intentar algo más."

# game/choice chapter 1.rpy:1345
translate Spanish lie_8c06c07f:

    # "This time, I place my hand on his chest and slowly run it over him instead."
    "Esta vez, coloco mi mano sobre su pecho y la deslizo lentamente sobre él."

# game/choice chapter 1.rpy:1347
translate Spanish lie_152be7c4:

    # jes "Nh... oh.. I see.."
    jes "Nh… oh… ya veo…"

# game/choice chapter 1.rpy:1348
translate Spanish lie_1fb6601e:

    # jes "From being rough to being gentle... Are you rewarding me for pleasing you, Your Majesty?"
    jes "De ser brusc[letra] a ser gentil… ¿me está recompensando por complacerl[letra], Su Majestad?"

# game/choice chapter 1.rpy:1349
translate Spanish lie_e015665d:

    # mc "...You can think of it that way."
    mc "…Puede verlo de esa manera."

# game/choice chapter 1.rpy:1352
translate Spanish lie_fad5a13f:

    # "My hand, which was resting on his chest, slowly moves up to his neck to the collar around it."
    "Mi mano, que estaba sobre su pecho, se desliza lentamente hacia su cuello, hacia el collar."

# game/choice chapter 1.rpy:1353
translate Spanish lie_77e4b7ea:

    # "I begin stroking his neck slowly."
    "Empiezo a acariciar su cuello lentamente."

# game/choice chapter 1.rpy:1355
translate Spanish lie_108799bc_1:

    # jes "Your Majesty..."
    jes "Su Majestad…"

# game/choice chapter 1.rpy:1357
translate Spanish lie_e345da8e:

    # "That's strange..."
    "Eso es extraño…"

# game/choice chapter 1.rpy:1358
translate Spanish lie_87b00841:

    # "When I brushed my hand along his neck, the texture wasn't hard like the surface of a puppet I had imagined."
    "Cuando pasé mi mano por su cuello, la textura no era dura como la superficie de una marioneta que imaginaba."

# game/choice chapter 1.rpy:1359
translate Spanish lie_4cf27b1a:

    # "It felt soft just like human skin. But colder."
    "Se sentía suave, como piel humana. Pero más fría."

# game/choice chapter 1.rpy:1360
translate Spanish lie_1b3cc250:

    # "What kind of puppet is he, really...?"
    "¿Qué tipo de marioneta es realmente…?"

# game/choice chapter 1.rpy:1363
translate Spanish lie_25b5e8f8:

    # "After lingering there for a moment, my hand moves upward to his cheek."
    "Después de quedarme ahí un momento, mi mano sube hasta su mejilla."

# game/choice chapter 1.rpy:1364
translate Spanish lie_4c8c3a2e:

    # "Every sound he makes in response to my touch feels strangely satisfying to hear."
    "Escuchar cada sonido que hace en respuesta a mis caricias me resulta extrañamente placentero."

# game/choice chapter 1.rpy:1365
translate Spanish lie_71140198:

    # "His eyes look hazy, his face flushed."
    "Sus ojos se ven vidriosos y tiene el rostro enrojecido."

# game/choice chapter 1.rpy:1366
translate Spanish lie_b4a72430:

    # "Incredible... that a puppet can feel something like this."
    "Increíble… que una marioneta pueda sentir algo así."

# game/choice chapter 1.rpy:1368
translate Spanish lie_4995b5a9:

    # "My thumb gently brushes over his lips."
    "Mi pulgar roza suavemente sus labios."

# game/choice chapter 1.rpy:1370
translate Spanish lie_70f40038:

    # jes "...."
    jes "…."

# game/choice chapter 1.rpy:1371
translate Spanish lie_2ffb9d3c:

    # jes "Your Majesty... I've never felt anything like this before..."
    jes "Su Majestad… nunca había sentido algo así antes…"

# game/choice chapter 1.rpy:1372
translate Spanish lie_1b562e8f:

    # mc "You mean the feeling of BDSM?"
    mc "¿Te refieres a la sensación del BDSM?"

# game/choice chapter 1.rpy:1374
translate Spanish lie_3811e565:

    # jes "Hehe, no, no, no... I've felt that plenty of times before."
    jes "Jeje, no, no, no… eso lo he sentido muchas veces antes."

# game/choice chapter 1.rpy:1375
translate Spanish lie_e37c0486:

    # jes "What I mean is this feeling... The one I can't even put into words."
    jes "A lo que me refiero es a esta sensación… esa que ni siquiera puedo poner en palabras."

# game/choice chapter 1.rpy:1376
translate Spanish lie_c2e7ff67:

    # jes "It feels... pleasant. But I'm not certain that word is quite right to describe what I'm feeling right now."
    jes "Se siente… agradable. Pero no estoy seguro de que esa palabra sea la correcta para describir lo que siento ahora mismo."

# game/choice chapter 1.rpy:1377
translate Spanish lie_49d1e513:

    # jes "Tell me, Your Majesty... Have you perhaps used forbidden magic on me?"
    jes "Dígame, Su Majestad… ¿acaso ha usado magia prohibida en mí?"

# game/choice chapter 1.rpy:1379
translate Spanish lie_a4b25528:

    # "I let out a confused laugh at his ridiculous speculation."
    "Dejo escapar una risa confundida ante su ridícula suposición."

# game/choice chapter 1.rpy:1381
translate Spanish lie_857b17fa:

    # mc "Don't be silly."
    mc "No seas tonto."

# game/choice chapter 1.rpy:1385
translate Spanish lie_04cdf4c4:

    # "This strange situation somehow makes me feel at ease... my miserable life has never felt quite like this."
    "De alguna manera, esta extraña situación me hace sentir en paz… Nunca había experimentado algo así en mi miserable vida."

# game/choice chapter 1.rpy:1389
translate Spanish lie_440585cc:

    # "After several minutes, Jestyn finally snaps his fingers and in an instant, the collar around his neck vanishes."
    "Después de varios minutos, Jestyn finalmente chasquea los dedos y, en un instante, el collar alrededor de su cuello desaparece."

# game/choice chapter 1.rpy:1397
translate Spanish bad_end_38ef1abf:

    # jes "Very well. I shall inform our neighbors of Your Majesty's will."
    jes "Muy bien. Informaré a nuestros vecinos de la voluntad de Su Majestad."

# game/choice chapter 1.rpy:1398
translate Spanish bad_end_8942a864:

    # jes "And I believe that, for now, the matters Your Majesty was required to resolve have reached the end of today's program."
    jes "Y creo que, por ahora, los asuntos que Su Majestad debía resolver concluyen aquí por hoy."

# game/choice chapter 1.rpy:1400
translate Spanish bad_end_65db4673:

    # "Finally..... it ends. I don't know if my brain can handle these kingdom things anymore."
    "Por fin… terminó. No sé si mi cerebro pueda soportar más cosas de este reino."

# game/choice chapter 1.rpy:1402
translate Spanish bad_end_3911f608:

    # jes "You must be tired, Your Majesty. How about we do something... calming?"
    jes "Debe estar cansad[letra], Su Majestad. ¿Qué tal si hacemos algo… relajante?"

# game/choice chapter 1.rpy:1404
translate Spanish bad_end_c3877920:

    # jes "Perhaps a dance?"
    jes "¿Quizá un baile?"

# game/choice chapter 1.rpy:1408
translate Spanish bad_end_a12ac849:

    # "Jestyn offered his hand, inviting me to dance."
    "Jestyn me ofreció su mano, invitándome a bailar."

# game/choice chapter 1.rpy:1410
translate Spanish bad_end_a7741239:

    # mc "But I've never danced before... "
    mc "Pero nunca he bailado antes…"

# game/choice chapter 1.rpy:1411
translate Spanish bad_end_de2b3138:

    # jes "That won't be a problem, Your Majesty. This dance is very slow. It won't trouble you at all."
    jes "Eso no será un problema, Su Majestad. Este baile es muy lento. No le causará ninguna dificultad."

# game/choice chapter 1.rpy:1413
translate Spanish bad_end_1d79b838:

    # "I hesitated for a moment. But seeing that expression on his face, I felt I couldn't refuse."
    "Dudé por un momento. Pero al ver esa expresión en su rostro, sentí que no podía negarme."

# game/choice chapter 1.rpy:1415
translate Spanish bad_end_900966a3:

    # mc "Alright.."
    mc "Está bien…"

# game/choice chapter 1.rpy:1419
translate Spanish bad_end_c408cc1d:

    # "The moment I took his hand, the stage lights suddenly went out."
    "En el momento en que tomé su mano, las luces del escenario se apagaron de repente."

# game/choice chapter 1.rpy:1422
translate Spanish bad_end_19b3acff:

    # "And when they came back on, without realizing it, I was already in a dancing position with Jestyn."
    "Y cuando volvieron a encenderse, sin darme cuenta, ya estaba en posición de baile con Jestyn."

# game/choice chapter 1.rpy:1423
translate Spanish bad_end_f53412e1:

    # "Jestyn's steps were as slow as he had promised."
    "Los pasos de Jestyn eran tan lentos como había prometido."

# game/choice chapter 1.rpy:1424
translate Spanish bad_end_a0e58515:

    # "And I followed his rhythm."
    "Y yo seguí su ritmo."

# game/choice chapter 1.rpy:1425
translate Spanish bad_end_0e470271:

    # "We didn't say a word. Only the dance music filled the silence on the stage."
    "No dijimos una palabra. Solo la música de baile llenaba el silencio en el escenario."

# game/choice chapter 1.rpy:1427
translate Spanish bad_end_11e531b8:

    # jes "You're doing quite well, Your Majesty."
    jes "Lo está haciendo bastante bien, Su Majestad."

# game/choice chapter 1.rpy:1428
translate Spanish bad_end_9e8ac604:

    # mc "... I'm just following you."
    mc "…Solo lo estoy siguiendo."

# game/choice chapter 1.rpy:1429
translate Spanish bad_end_b2c0340c:

    # jes "And that is more than enough."
    jes "Y eso es más que suficiente."

# game/choice chapter 1.rpy:1431
translate Spanish bad_end_405dd147:

    # "The room fell silent once again."
    "La sala volvió a quedar en silencio."

# game/choice chapter 1.rpy:1433
translate Spanish bad_end_36e91ef5:

    # jes "Do you know the name of this dance, Your Majesty?"
    jes "¿Sabe cómo se llama este baile, Su Majestad?"

# game/choice chapter 1.rpy:1434
translate Spanish bad_end_1fe5fc2b:

    # mc "I don't think so."
    mc "No lo creo."

# game/choice chapter 1.rpy:1435
translate Spanish bad_end_dab30120:

    # jes "You could say this is the most iconic dance in the Kingdom of Marionettes."
    jes "Podría decirse que este es el baile más icónico de Kingdom of Marionettes."

# game/choice chapter 1.rpy:1436
translate Spanish bad_end_15d48f8a:

    # jes "At the end of every performance, we always dance this one."
    jes "Al final de cada función, siempre bailamos este."

# game/choice chapter 1.rpy:1438
translate Spanish bad_end_8e4b4abf:

    # jes "We call it Danse Macabre."
    jes "Lo llamamos Danse Macabre."

# game/choice chapter 1.rpy:1440
translate Spanish bad_end_dd55df2c:

    # "Our steps grew more perfectly synchronized after Jestyn said that."
    "Nuestros pasos se volvieron más perfectamente sincronizados después de que Jestyn dijera eso."

# game/choice chapter 1.rpy:1442
translate Spanish bad_end_5f213e86:

    # mc "Danse Macabre..."
    mc "Danse Macabre…"

# game/choice chapter 1.rpy:1443
translate Spanish bad_end_7fcb4609:

    # mc "I've never heard of it before. Why is it called that?"
    mc "Nunca había oído hablar de ella. ¿Por qué se llama así?"

# game/choice chapter 1.rpy:1445
translate Spanish bad_end_f62eac9a:

    # "Suddenly, a sharp dizziness washed over my head."
    "De repente, un fuerte mareo me invadió la cabeza."

# game/choice chapter 1.rpy:1446
translate Spanish bad_end_0d4d6fde:

    # "My head.. it hurts so much."
    "Mi cabeza… duele mucho."

# game/choice chapter 1.rpy:1447
translate Spanish bad_end_dfadc1e1:

    # "I feel as though something inside me is being slowly pulled out."
    "Siento como si algo dentro de mí estuviera siendo lentamente arrancado."

# game/choice chapter 1.rpy:1449
translate Spanish bad_end_2188e88d:

    # "My steps faltered, and my entire body weakened in an instant."
    "Mis pasos vacilaron, y todo mi cuerpo se debilitó en un instante."

# game/choice chapter 1.rpy:1451
translate Spanish bad_end_09faf371:

    # "But Jestyn's arm caught me, keeping me from falling."
    "Pero el brazo de Jestyn me sostuvo, evitando que cayera."

# game/choice chapter 1.rpy:1452
translate Spanish bad_end_e34e4811:

    # "My whole body become weak and trembled."
    "Todo mi cuerpo se volvió débil y comenzó a temblar."

# game/choice chapter 1.rpy:1455
translate Spanish bad_end_f7ebb397:

    # mc "J-Jestyn... what is-"
    mc "J–Jestyn… ¿qué es—"

# game/choice chapter 1.rpy:1459
translate Spanish bad_end_bbd50ba8:

    # jes "Seconds passed... then hours... days... weeks... months... years..."
    jes "Pasaron segundos… luego horas… después días… semanas… meses… años…"

# game/choice chapter 1.rpy:1460
translate Spanish bad_end_cfeb39ac:

    # jes "It has been so very long since all of that faded away."
    jes "Ha pasado tanto tiempo desde que todo aquello se desvaneció."

# game/choice chapter 1.rpy:1461
translate Spanish bad_end_7d7d8357:

    # jes "And after so long...."
    jes "Y después de tanto…"

# game/choice chapter 1.rpy:1463
translate Spanish bad_end_84c60eaf:

    # jes "It seems, fate has not yet chosen our side."
    jes "Parece que el destino aún no está de nuestro lado."

# game/choice chapter 1.rpy:1464
translate Spanish bad_end_3a8cf506:

    # jes "In the end, this aimless fate of ours must continue on its path."
    jes "Al final, este destino sin rumbo nuestro debe continuar su camino."

# game/choice chapter 1.rpy:1467
translate Spanish bad_end_07eb5fcf:

    # jes "Because, ultimately... you are unworthy."
    jes "Porque, en última instancia… no es dign[letra]."

# game/choice chapter 1.rpy:1468
translate Spanish bad_end_8794e25a:

    # jes "Your reign as [title] ends here. Now, it is time for you to rest peacefully."
    jes "Su reinado como [title!t] termina aquí. Ahora es hora de que descanse en paz."

# game/choice chapter 1.rpy:1469
translate Spanish bad_end_355059a8:

    # jes "Close your eyes... and let this dance guide you into eternal serenity."
    jes "Cierra los ojos… y deja que este baile te guíe hacia la serenidad eterna."

# game/choice chapter 1.rpy:1472
translate Spanish bad_end_eb515044:

    # jes "Fin."
    jes "Fin."

# game/choice chapter 1.rpy:1480
translate Spanish cursed1_d7afdc3b:

    # mc "I-"
    mc "Yo—"

# game/choice chapter 1.rpy:1483
translate Spanish cursed1_fa8c385a:

    # "Suddenly, My head feels so hurt"
    "De repente, mi cabeza duele muchísimo."

# game/choice chapter 1.rpy:1484
translate Spanish cursed1_30eb29fd:

    # "Everything around me become blur"
    "Todo a mi alrededor se vuelve borroso."

# game/choice chapter 1.rpy:1491
translate Spanish cursed1_23adb90c:

    # mc "{color=#FF2727}Mmmm.... how unfortunate. My poor farmers...{/color}"
    mc "{color=#FF2727}Mmmm… qué desafortunado. Mis pobres agricultores…{/color}"

# game/choice chapter 1.rpy:1492
translate Spanish cursed1_b0e3cfcc:

    # mc "{color=#FF2727}As your [title], it is only natural that I provide for you. I would never ignore your hardships.{/color}"
    mc "{color=#FF2727}Como su [title!t], es natural que vele por ustedes. Nunca ignoraría las dificultades que atraviesan.{/color}"

# game/choice chapter 1.rpy:1493
translate Spanish cursed1_75ea4c4b:

    # mc "{color=#FF2727}Money? Finer seeds of the highest quality? Perhaps food to ease your burdens?{/color}"
    mc "{color=#FF2727}¿Dinero? ¿Semillas selectas de la mejor calidad? ¿Quizá alimentos para aliviar sus dificultades?{/color}"

# game/choice chapter 1.rpy:1495
translate Spanish cursed1_486300be:

    # farm "O-oh... Your Majesty is far too gracious.."
    farm "O-oh… Su Majestad es demasiado generos[letra]…"

# game/choice chapter 1.rpy:1496
translate Spanish cursed1_91fc4504:

    # mc "{color=#FF2727}However...{/color}"
    mc "{color=#FF2727}Sin embargo…{/color}"

# game/choice chapter 1.rpy:1497
translate Spanish cursed1_312f9426:

    # mc "{color=#FF2727}If I am to pour my generosity upon you... shouldn't you offer something in return?{/color}"
    mc "{color=#FF2727}Si voy a derramar mi generosidad sobre ustedes… ¿no deberían ofrecer algo a cambio?{/color}"

# game/choice chapter 1.rpy:1498
translate Spanish cursed1_9d4bb413:

    # mc "{color=#FF2727}It would be terribly unfair otherwise, wouldn't it? I give, and you simply receive?{/color}"
    mc "{color=#FF2727}De lo contrario sería terriblemente injusto, ¿no es así? ¿Yo doy y ustedes simplemente reciben?{/color}"

# game/choice chapter 1.rpy:1499
translate Spanish cursed1_a6ddc768:

    # mc "{color=#FF2727}No... if I am to bless you with such kindness, then I expect your loyalty... and your labor... to reflect your gratitude.{/color}"
    mc "{color=#FF2727}No… si voy a bendecirlos con tal bondad, entonces espero que su lealtad… y su trabajo… reflejen su gratitud.{/color}"

# game/choice chapter 1.rpy:1501
translate Spanish cursed1_4d38ab1b:

    # farm "Y-You are absolutely right, Your Majesty! I will devote myself entirely!"
    farm "¡T–Tiene toda la razón, Su Majestad! ¡Me dedicaré por completo!"

# game/choice chapter 1.rpy:1506
translate Spanish cursed1_70f40038:

    # jes "...."
    jes "…."

# game/choice chapter 1.rpy:1507
translate Spanish cursed1_1b46e124:

    # jes "How remarkable, Your Majesty."
    jes "Qué admirable, Su Majestad."

# game/choice chapter 1.rpy:1508
translate Spanish cursed1_f9fd318f:

    # jes "One can only hope your actions prove as sweet as your words."
    jes "Solo cabe esperar que sus acciones estén a la altura de sus dulces palabras."

# game/choice chapter 1.rpy:1511
translate Spanish cursed1_ec969f39:

    # jes "...Indeed?"
    jes "…¿En serio?"

# game/choice chapter 1.rpy:1513
translate Spanish cursed1_329ddb6e:

    # "{color=#FF2727}.......{/color}"
    "{color=#FF2727}…….{/color}"

# game/choice chapter 1.rpy:1515
translate Spanish cursed1_0fd4d656:

    # "......"
    "……"

# game/choice chapter 1.rpy:1517
translate Spanish cursed1_42051be0:

    # mc "Y-...Yes.... Indeed."
    mc "S–…Sí… en efecto."

# game/choice chapter 1.rpy:1524
translate Spanish cursed2_1ad94e56:

    # mc "{color=#FF2727}Oh? For trade, you say?{/color}"
    mc "{color=#FF2727}¿Oh? ¿Comercio, dices?{/color}"

# game/choice chapter 1.rpy:1525
translate Spanish cursed2_bae050fd:

    # mc "{color=#FF2727}That is quite an interesting offer.{/color}"
    mc "{color=#FF2727}Esa es una propuesta bastante interesante.{/color}"

# game/choice chapter 1.rpy:1526
translate Spanish cursed2_bc7c3c59:

    # mc "{color=#FF2727}Very well. Why not?{/color}"
    mc "{color=#FF2727}Muy bien. ¿Por qué no?{/color}"

# game/choice chapter 1.rpy:1527
translate Spanish cursed2_f1c4eb89:

    # mc "{color=#FF2727}I make this decision for the sake of my people.{/color}"
    mc "{color=#FF2727}Tomo esta decisión por el bien de mi pueblo.{/color}"

# game/choice chapter 1.rpy:1528
translate Spanish cursed2_7e28d336:

    # mc "{color=#FF2727}Trade will become far more convenient for them. And at the same time, we may establish stronger ties with another kingdom.{/color}"
    mc "{color=#FF2727}El comercio les resultará mucho más fácil. Al mismo tiempo, podremos estrechar nuestros lazos con otro reino.{/color}"

# game/choice chapter 1.rpy:1532
translate Spanish cursed2_c01f7d84:

    # jes "Hm...? Yes, that is certainly an understandable decision, Your Majesty."
    jes "Hm…? Sí, esa es ciertamente una decisión comprensible, Su Majestad."

# game/choice chapter 1.rpy:1533
translate Spanish cursed2_97fd71fe:

    # jes "From your words, you appear deeply concerned for your people."
    jes "Por lo que dice, parece estar muy preocupad[letra] por su pueblo."

# game/choice chapter 1.rpy:1535
translate Spanish cursed2_a4f31376:

    # jes "Mmm... but what of the citizens who reside upon the land you intend to sell, Your Majesty?"
    jes "Mmm… pero, ¿qué hay de los ciudadanos que viven en la tierra que pretende vender, Su Majestad?"

# game/choice chapter 1.rpy:1536
translate Spanish cursed2_8456d889:

    # jes "If you part with it... would that not mean they must abandon their homes?"
    jes "Si se deshace de esas tierras… ¿no significaría eso que tendrían que abandonar sus hogares?"

# game/choice chapter 1.rpy:1537
translate Spanish cursed2_b7c129b6:

    # jes "It does seem rather contradictory to what you just said about caring so dearly for your people."
    jes "Eso parece contradecir bastante lo que acaba de decir sobre cuánto le importa su pueblo."

# game/choice chapter 1.rpy:1539
translate Spanish cursed2_eed8927c:

    # jes "Unless... you are a liar, Your Majesty~?"
    jes "¿A menos que… sea usted [arti_2] mentiros[letra], Su Majestad~?"

# game/choice chapter 1.rpy:1540
translate Spanish cursed2_968c8596:

    # mc "{color=#FF2727}Haha... Jestyn..{/color}"
    mc "{color=#FF2727}Jaja… Jestyn…{/color}"

# game/choice chapter 1.rpy:1541
translate Spanish cursed2_d1032bef:

    # mc "{color=#FF2727}Are you questioning my decision?{/color}"
    mc "{color=#FF2727}¿Estás cuestionando mi decisión?{/color}"

# game/choice chapter 1.rpy:1543
translate Spanish cursed2_50611cc0:

    # jes "......."
    jes "……"

# game/choice chapter 1.rpy:1545
translate Spanish cursed2_3ea684e4:

    # jes "Oh, of course not, Your Majesty. How foolish of me. To even think of questioning your judgment..."
    jes "Oh, por supuesto que no, Su Majestad. Qué tonto de mi parte. Incluso pensar en cuestionar su juicio…"

# game/choice chapter 1.rpy:1547
translate Spanish cursed2_6c7d49d5:

    # jes "Indeed. This is all for the good of the entire kingdom."
    jes "En efecto. Todo es por el bien del reino entero."

# game/choice chapter 1.rpy:1550
translate Spanish cursed2_20edf98e:

    # jes "Very well then. I shall inform our neighbors of Your Majesty's will."
    jes "Muy bien entonces. Informaré a nuestros vecinos de la voluntad de Su Majestad."

# game/choice chapter 1.rpy:1551
translate Spanish cursed2_8942a864:

    # jes "And I believe that, for now, the matters Your Majesty was required to resolve have reached the end of today's program."
    jes "Y creo que, por ahora, los asuntos que Su Majestad debía resolver concluyen aquí por hoy."

# game/choice chapter 1.rpy:1552
translate Spanish cursed2_917307e9:

    # jes "You may rest your head now your majesty~"
    jes "Puede descansar ahora, Su Majestad~"

# game/choice chapter 1.rpy:1555
translate Spanish cursed2_7af8e284:

    # jes "Oh! I nearly forgot, Your Majesty. Before that, I have a gift for you."
    jes "¡Oh! Casi lo olvido, Su Majestad. Antes de eso, tengo un regalo para usted."

# game/choice chapter 1.rpy:1557
translate Spanish cursed2_6a22b7be:

    # mc "Huh..? What gift-"
    mc "¿Eh…? ¿Qué regalo—?"

# game/choice chapter 1.rpy:1562
translate Spanish cursed2_0a956b60:

    # "A rope suddenly coiled around my body after Jestyn snapped his fingers."
    "Una cuerda se enrolló de repente alrededor de mi cuerpo después de que Jestyn chasqueara los dedos."

# game/choice chapter 1.rpy:1565
translate Spanish cursed2_68492187:

    # "He snapped his fingers once more. An axe appeared in his hand."
    "Chasqueó los dedos una vez más. Un hacha apareció en su mano."

# game/choice chapter 1.rpy:1566
translate Spanish cursed2_c9e9ed07:

    # "Panic seized me instantly."
    "El pánico se apoderó de mí al instante."

# game/choice chapter 1.rpy:1568
translate Spanish cursed2_05e3f134:

    # mc "W-What are you doing?!"
    mc "¡¿Q–Qué estás haciendo?!"

# game/choice chapter 1.rpy:1577
translate Spanish cursed2_534af6fb:

    # "Without answering my question, Jestyn swung the axe toward my neck."
    "Sin responder a mi pregunta, Jestyn blandió el hacha hacia mi cuello."

# game/choice chapter 1.rpy:1588
translate Spanish cursed2_84d35058:

    # jes "Hope you Have a nice dream this time, [player_call]"
    jes "Espero que esta vez tenga un buen sueño, [player_call]."

# game/choice chapter 1.rpy:1601
translate Spanish handsome_d44e7d4f:

    # "His irritated expression instantly shifted into confusion and shock."
    "Su expresión de irritación se transformó al instante en una mezcla de confusión y sorpresa."

# game/choice chapter 1.rpy:1603
translate Spanish handsome_0ce78278:

    # kni "What the hell did you just say?"
    kni "¿Qué demonios acabas de decir?"

# game/choice chapter 1.rpy:1604
translate Spanish handsome_a54ff068:

    # mc "I was only telling the truth."
    mc "Solo estaba diciendo la verdad."

# game/choice chapter 1.rpy:1606
translate Spanish handsome_9b5b6b19:

    # "Honestly, I wasn’t sure if saying that was a good idea."
    "Sinceramente, no sabía si había sido buena idea decir eso."

# game/choice chapter 1.rpy:1608
translate Spanish handsome_4722190d:

    # kni "There must be something wrong with your head. Are you truly speaking the truth?"
    kni "Debe haber algo mal en tu cabeza. ¿De verdad estás diciendo la verdad?"

# game/choice chapter 1.rpy:1610
translate Spanish handsome_36f5b714:

    # "Oh, did I just manage to soften him a little?"
    "Ah, ¿acabo de lograr ablandarlo un poco?"

# game/choice chapter 1.rpy:1612
translate Spanish handsome_81b5e682:

    # mc "Of course~. Who could possibly resist such a handsome face?"
    mc "Por supuesto~. ¿Quién podría resistirse a un rostro tan apuesto?"

# game/choice chapter 1.rpy:1613
translate Spanish handsome_7b7a20db:

    # mc "I’m certain that anyone who lays eyes on you for the first time would be driven completely crazy over you one hundred percent."
    mc "Estoy segur[letra] de que cualquiera que te vea por primera vez sentirá una atracción irresistible por ti."

# game/choice chapter 1.rpy:1615
translate Spanish handsome_2740387a:

    # "His lips slowly curled into a grin."
    "Sus labios se curvaron lentamente en una sonrisa."

# game/choice chapter 1.rpy:1617
translate Spanish handsome_56e38707:

    # kni "Heh. In that case you deserve to die."
    kni "Jeh. En ese caso, mereces morir."

# game/choice chapter 1.rpy:1619
translate Spanish handsome_9d469299:

    # "Fuck."
    "Mierda."

# game/choice chapter 1.rpy:1624
translate Spanish notreally_dd94f96d:

    # mc "Well... uh actually not really..."
    mc "Bueno… eh, en realidad no…"

# game/choice chapter 1.rpy:1625
translate Spanish notreally_492bf80b:

    # kni "In that case you deserve to die."
    kni "En ese caso, mereces morir."

# game/choice chapter 1.rpy:1627
translate Spanish notreally_9d469299:

    # "Fuck."
    "Mierda."

# game/choice chapter 1.rpy:1633
translate Spanish juggle_cf7942b1:

    # mc "Where did you learn to juggle?"
    mc "¿Dónde aprendiste a hacer malabares?"

# game/choice chapter 1.rpy:1634
translate Spanish juggle_2980266b:

    # jes "I didn’t expect Your Majesty to take such an interest in juggling."
    jes "No esperaba que Su Majestad mostrara tanto interés en los malabares."

# game/choice chapter 1.rpy:1635
translate Spanish juggle_5311080f:

    # jes "Hmmmm... let me think for a moment...."
    jes "Hmmmm… permítame pensar un momento…"

# game/choice chapter 1.rpy:1637
translate Spanish juggle_73ec2189:

    # "He taps his index finger lightly as he ponders."
    "Se da unos ligeros golpecitos en el dedo índice mientras reflexiona."

# game/choice chapter 1.rpy:1639
translate Spanish juggle_f75bae67:

    # jes "Ah, yes... Master Adam."
    jes "Ah, sí… el Maestro Adam."

# game/choice chapter 1.rpy:1640
translate Spanish juggle_6ebcf28f:

    # mc "Uh... who’s that?"
    mc "Eh… ¿Quién es ese?"

# game/choice chapter 1.rpy:1641
translate Spanish juggle_1324166a:

    # jes "He is the one who taught me how to properly perform the role of a true royal jester."
    jes "Es quien me enseñó a interpretar correctamente el papel de un verdadero bufón real."

# game/choice chapter 1.rpy:1642
translate Spanish juggle_21986bd3:

    # jes "The person I am today exists because of him. And naturally, that includes the proper way to juggle."
    jes "La persona que soy hoy existe gracias a él. Y naturalmente, eso incluye la forma adecuada de hacer malabares."

# game/choice chapter 1.rpy:1643
translate Spanish juggle_2b3ce3e9:

    # mc "He sounds like someone important."
    mc "Suena como alguien importante."

# game/choice chapter 1.rpy:1644
translate Spanish juggle_40f5e215:

    # jes "Indeed, he was. A most kind gentleman."
    jes "En efecto, lo era. Un caballero muy amable."

translate Spanish strings:

    # game/choice chapter 1.rpy:126
    old "Check Jester puppet"
    new "Revisar Bufón marioneta"

    # game/choice chapter 1.rpy:130
    old "Check Knight puppet"
    new "Revisar Caballero marioneta"

    # game/choice chapter 1.rpy:134
    old "Check King puppet"
    new "Revisar Rey marioneta"

    # game/choice chapter 1.rpy:138
    old "Check the next puppet"
    new "Revisar la siguiente marioneta"

    # game/choice chapter 1.rpy:286
    old "Keep silent"
    new "Guardar silencio"

    # game/choice chapter 1.rpy:289
    old "Who are you?"
    new "¿Quién eres?"

    # game/choice chapter 1.rpy:292
    old "Run"
    new "Correr"

    # game/choice chapter 1.rpy:972
    old "Left"
    new "Izquierda"

    # game/choice chapter 1.rpy:975
    old "Right"
    new "Derecha"

    # game/choice chapter 1.rpy:1161
    old "Sit"
    new "Sentarse"

    # game/choice chapter 1.rpy:1164
    old "Lie down"
    new "Acostarse"

