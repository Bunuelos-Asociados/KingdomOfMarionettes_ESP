
init -100 python:

    def actualizar_genero():

        if not hasattr(store, "subj"):
            return

        if store.subj == "she":
            store.letra = "a"
            store.arti = "la"
            store.arti_2 = "una"

        elif store.subj == "he":
            store.letra = "o"
            store.arti = "el"
            store.arti_2 = "un"

        else:
            store.letra = "e"
            store.arti = "le"
            store.arti_2 = "une"


    def hook_actualizar_genero(*args):
        actualizar_genero()


    config.statement_callbacks.append(hook_actualizar_genero)


init 1000 python:
    renpy.game.preferences.language = "Spanish"


label before_main_menu:
    $ actualizar_genero()
    return


label after_load:
    $ actualizar_genero()
    return
